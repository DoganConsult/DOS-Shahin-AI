--
-- PostgreSQL database dump
--

\restrict 6TubOnMJ9OYpXHtiO5sSlDQP0lfF4szqCw62w55Pjri313OLXro2w1PIGlf0QxQ

-- Dumped from database version 18.3 (Ubuntu 18.3-1.pgdg22.04+1)
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: dos; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dos;


--
-- Name: ui_ai_action_draft_state_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_ai_action_draft_state_t AS ENUM (
    'pending',
    'confirmed',
    'executed',
    'rejected',
    'expired'
);


--
-- Name: ui_ai_panel_position_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_ai_panel_position_t AS ENUM (
    'left',
    'right',
    'bottom',
    'floating'
);


--
-- Name: ui_brand_asset_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_brand_asset_kind_t AS ENUM (
    'logo',
    'favicon',
    'hero',
    'watermark',
    'social_card',
    'letterhead',
    'email_header'
);


--
-- Name: ui_change_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_change_kind_t AS ENUM (
    'create',
    'update',
    'delete',
    'publish',
    'rollback',
    'approve',
    'reject'
);


--
-- Name: ui_checklist_step_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_checklist_step_status_t AS ENUM (
    'not_started',
    'in_progress',
    'completed',
    'skipped',
    'blocked'
);


--
-- Name: ui_command_surface_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_command_surface_t AS ENUM (
    'palette',
    'shortcut',
    'menu',
    'toolbar',
    'context_menu',
    'programmatic'
);


--
-- Name: ui_contextual_help_display_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_contextual_help_display_t AS ENUM (
    'tooltip',
    'popover',
    'panel',
    'inline',
    'modal'
);


--
-- Name: ui_contrast_mode_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_contrast_mode_t AS ENUM (
    'default',
    'high',
    'inverted'
);


--
-- Name: ui_device_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_device_kind_t AS ENUM (
    'desktop',
    'tablet',
    'mobile',
    'tv',
    'watch'
);


--
-- Name: ui_error_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_error_kind_t AS ENUM (
    'render',
    'api',
    'permission',
    'validation',
    'timeout',
    'network',
    'unknown'
);


--
-- Name: ui_flag_target_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_flag_target_kind_t AS ENUM (
    'tenant',
    'role',
    'user',
    'product',
    'module'
);


--
-- Name: ui_form_decision_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_decision_t AS ENUM (
    'pending',
    'approved',
    'rejected',
    'delegated',
    'escalated'
);


--
-- Name: ui_form_default_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_default_kind_t AS ENUM (
    'static',
    'expression',
    'from_user',
    'from_tenant',
    'from_workflow'
);


--
-- Name: ui_form_field_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_field_kind_t AS ENUM (
    'text',
    'textarea',
    'number',
    'integer',
    'boolean',
    'date',
    'datetime',
    'select',
    'multiselect',
    'radio',
    'checkbox',
    'file',
    'user_picker',
    'entity_picker',
    'rich_text',
    'signature',
    'json',
    'rating'
);


--
-- Name: ui_form_rule_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_rule_kind_t AS ENUM (
    'visible_when',
    'required_when',
    'enabled_when',
    'value_when'
);


--
-- Name: ui_form_submission_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_submission_status_t AS ENUM (
    'draft',
    'submitted',
    'approved',
    'rejected',
    'withdrawn',
    'superseded'
);


--
-- Name: ui_form_validator_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_validator_kind_t AS ENUM (
    'required',
    'pattern',
    'range',
    'min_length',
    'max_length',
    'min',
    'max',
    'email',
    'url',
    'phone',
    'custom'
);


--
-- Name: ui_grid_column_capability_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_grid_column_capability_t AS ENUM (
    'view',
    'edit',
    'export',
    'filter',
    'sort'
);


--
-- Name: ui_grid_column_data_type_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_grid_column_data_type_t AS ENUM (
    'text',
    'number',
    'integer',
    'boolean',
    'date',
    'datetime',
    'json',
    'uuid',
    'enum',
    'badge',
    'link',
    'currency',
    'percent'
);


--
-- Name: ui_grid_export_format_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_grid_export_format_t AS ENUM (
    'csv',
    'xlsx',
    'pdf',
    'json'
);


--
-- Name: ui_http_method_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_http_method_t AS ENUM (
    'GET',
    'POST',
    'PUT',
    'DELETE',
    'PATCH'
);


--
-- Name: ui_job_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_job_status_t AS ENUM (
    'queued',
    'running',
    'succeeded',
    'failed',
    'expired',
    'cancelled'
);


--
-- Name: ui_locale_direction_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_locale_direction_t AS ENUM (
    'ltr',
    'rtl'
);


--
-- Name: ui_manager_draft_state_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_manager_draft_state_t AS ENUM (
    'draft',
    'validating',
    'submitted',
    'rejected',
    'published'
);


--
-- Name: ui_notification_channel_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_notification_channel_t AS ENUM (
    'in_app',
    'email',
    'sms',
    'push',
    'webhook'
);


--
-- Name: ui_notification_digest_window_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_notification_digest_window_t AS ENUM (
    'instant',
    'hourly',
    'daily',
    'weekly'
);


--
-- Name: ui_notification_severity_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_notification_severity_t AS ENUM (
    'info',
    'success',
    'warning',
    'error',
    'critical'
);


--
-- Name: ui_perm_effect_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_perm_effect_t AS ENUM (
    'allow',
    'deny'
);


--
-- Name: ui_print_engine_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_print_engine_t AS ENUM (
    'html',
    'latex',
    'docx'
);


--
-- Name: ui_publish_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_publish_status_t AS ENUM (
    'pending',
    'approved',
    'rejected',
    'cancelled',
    'superseded'
);


--
-- Name: ui_retry_strategy_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_retry_strategy_t AS ENUM (
    'manual',
    'linear',
    'exponential',
    'none'
);


--
-- Name: ui_split_orientation_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_split_orientation_t AS ENUM (
    'horizontal',
    'vertical'
);


--
-- Name: ui_target_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_target_kind_t AS ENUM (
    'route',
    'page_layout',
    'dashboard',
    'widget_instance',
    'action',
    'form',
    'navigation_node',
    'menu_item',
    'tour',
    'field',
    'grid_column'
);


--
-- Name: ui_theme_target_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_theme_target_kind_t AS ENUM (
    'tenant',
    'role',
    'user',
    'product',
    'module'
);


--
-- Name: ui_theme_token_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_theme_token_kind_t AS ENUM (
    'color',
    'radius',
    'shadow',
    'spacing',
    'typography',
    'motion',
    'z_index',
    'breakpoint'
);


--
-- Name: ui_viewport_breakpoint_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_viewport_breakpoint_t AS ENUM (
    'xs',
    'sm',
    'md',
    'lg',
    'xl',
    'xxl'
);


--
-- Name: ui_visibility_effect_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_visibility_effect_t AS ENUM (
    'show',
    'hide'
);


--
-- Name: ui_visibility_rule_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_visibility_rule_kind_t AS ENUM (
    'permission',
    'role',
    'feature_flag',
    'expression',
    'module_status',
    'time_window',
    'tenant_attribute'
);


--
-- Name: ui_widget_binding_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_widget_binding_kind_t AS ENUM (
    'rest',
    'graphql',
    'static',
    'temporal_workflow',
    'ai_query',
    'sql_view'
);


--
-- Name: acquire_migration_lock(character varying, character varying, integer); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.acquire_migration_lock(p_service_name character varying, p_locked_by character varying, p_lock_duration_minutes integer DEFAULT 30) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_lock_acquired BOOLEAN;
BEGIN
    -- Clean up expired locks
    DELETE FROM dos.migration_lock WHERE lock_expires_at <= NOW();
    
    -- Try to acquire lock
    INSERT INTO dos.migration_lock (service_name, locked_by, lock_expires_at)
    VALUES (p_service_name, p_locked_by, NOW() + (p_lock_duration_minutes || ' minutes')::INTERVAL)
    ON CONFLICT (service_name) DO NOTHING;
    
    -- Check if lock was acquired
    SELECT EXISTS (
        SELECT 1 FROM dos.migration_lock 
        WHERE service_name = p_service_name 
        AND locked_by = p_locked_by
    ) INTO v_lock_acquired;
    
    RETURN v_lock_acquired;
END;
$$;


--
-- Name: assert_published_by_only(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.assert_published_by_only() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  publisher TEXT;
BEGIN
  publisher := current_setting('dos.publisher_session', true);
  IF publisher IS NULL OR publisher = '' THEN
    RAISE EXCEPTION
      '[contract-publisher] table %.% is publisher-owned; manual writes forbidden. '
      'Run via `pnpm module:publish <code>`.',
      TG_TABLE_SCHEMA, TG_TABLE_NAME;
  END IF;
  IF publisher <> 'contract-publisher@v1' THEN
    RAISE EXCEPTION
      '[contract-publisher] unknown publisher signature %', publisher;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: bump_ui_override_version(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.bump_ui_override_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version    := COALESCE(OLD.version, 0) + 1;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: bump_ui_route_template_version(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.bump_ui_route_template_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version := COALESCE(OLD.version,0) + 1;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: bump_workspace_shell_binding_version(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.bump_workspace_shell_binding_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version := COALESCE(OLD.version, 0) + 1;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: can_execute_migration(character varying, integer, character varying); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.can_execute_migration(p_service_name character varying, p_migration_number integer, p_migration_type character varying) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_last_migration INTEGER;
    v_has_lock BOOLEAN;
BEGIN
    -- Check if service is locked for migration
    SELECT EXISTS (
        SELECT 1 FROM dos.migration_lock 
        WHERE service_name = p_service_name 
        AND lock_expires_at > NOW()
    ) INTO v_has_lock;
    
    IF v_has_lock THEN
        RETURN FALSE;
    END IF;
    
    -- For UP migrations, check if previous migration exists
    IF p_migration_type = 'up' AND p_migration_number > 1 THEN
        SELECT COALESCE(MAX(migration_number), 0) INTO v_last_migration
        FROM dos.migration_history 
        WHERE service_name = p_service_name 
        AND migration_type = 'up' 
        AND success = true;
        
        IF v_last_migration != p_migration_number - 1 THEN
            RETURN FALSE;
        END IF;
    END IF;
    
    -- Check if this migration was already executed successfully
    IF EXISTS (
        SELECT 1 FROM dos.migration_history 
        WHERE service_name = p_service_name 
        AND migration_number = p_migration_number 
        AND migration_type = p_migration_type 
        AND success = true
    ) THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
$$;


--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.current_tenant_id() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  SELECT NULLIF(current_setting('dos.tenant_id', true), '')
$$;


--
-- Name: fn_audit_trail_entitlement_on_tenant(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_audit_trail_entitlement_on_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO dos.tenant_module_entitlements
    (entitlement_id, tenant_id, product_code, module_code, entitlement_status, source, starts_at, metadata)
  VALUES
    (substr(replace(gen_random_uuid()::text,'-',''),1,28), NEW.tenant_id::text,
     'shahin-ai', 'audit_trail', 'active',
     'platform_dna', NOW(), '{"reason":"trigger-platform-dna"}'::jsonb)
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: fn_block_non_ibm_catalog_row(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_block_non_ibm_catalog_row() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.vendor IS DISTINCT FROM 'ibm-carbon' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: ui_carbon_components row "%" rejected — vendor=% (must be ibm-carbon)',
      NEW.carbon_key, NEW.vendor;
  END IF;

  IF NEW.package_name NOT LIKE '@carbon/%'
     AND NEW.package_name <> 'carbon-components-angular' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: ui_carbon_components row "%" rejected — package_name % is not an IBM Carbon package',
      NEW.carbon_key, NEW.package_name;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: fn_block_non_ibm_runtime_row(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_block_non_ibm_runtime_row() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  catalog_vendor          VARCHAR(40);
  catalog_runtime_status  VARCHAR(40);
BEGIN
  -- Vendor lock — registry row must declare ibm-carbon.
  IF NEW.vendor IS DISTINCT FROM 'ibm-carbon' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — vendor=% (must be ibm-carbon)',
      NEW.component_key, NEW.vendor;
  END IF;

  -- Approval lock — only approved rows render.
  IF NEW.approval_status IS DISTINCT FROM 'approved' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — approval_status=% (must be approved)',
      NEW.component_key, NEW.approval_status;
  END IF;

  -- carbon_key linkage — must point at a real catalog row whose vendor is
  -- ibm-carbon and whose runtime_status permits runtime use.
  IF NEW.carbon_key IS NULL THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — carbon_key is NULL (must FK into dos.ui_carbon_components)',
      NEW.component_key;
  END IF;

  SELECT vendor, runtime_status
    INTO catalog_vendor, catalog_runtime_status
    FROM dos.ui_carbon_components
   WHERE carbon_key = NEW.carbon_key;

  IF NOT FOUND THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — carbon_key % not in dos.ui_carbon_components',
      NEW.component_key, NEW.carbon_key;
  END IF;

  IF catalog_vendor <> 'ibm-carbon' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — catalog row % has vendor=% (must be ibm-carbon)',
      NEW.component_key, NEW.carbon_key, catalog_vendor;
  END IF;

  IF catalog_runtime_status IN ('blocked-react-only', 'missing-upstream-angular-binding', 'catalog-only') THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — catalog row % runtime_status=% is not runtime-eligible',
      NEW.component_key, NEW.carbon_key, catalog_runtime_status;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: fn_dos_component_carbon_map_check(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_dos_component_carbon_map_check() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rs text;
BEGIN
  SELECT runtime_status INTO rs
    FROM dos.ui_carbon_components
   WHERE carbon_key = NEW.carbon_key
     AND vendor = 'ibm-carbon'
     AND is_active = true;
  IF rs IS NULL THEN
    RAISE EXCEPTION 'carbon_key % is not an active ibm-carbon catalog row', NEW.carbon_key;
  END IF;
  IF rs NOT IN ('active','wrapper-required') THEN
    RAISE EXCEPTION 'carbon_key % runtime_status=% is not Angular-usable', NEW.carbon_key, rs;
  END IF;
  NEW.updated_at := NOW();
  RETURN NEW;
END $$;


--
-- Name: fn_dos_tenants_touch_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_dos_tenants_touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.updated_at IS NOT DISTINCT FROM OLD.updated_at THEN
    NEW.updated_at := now();
  END IF;
  RETURN NEW;
END $$;


--
-- Name: fn_ensure_tenant_module_entitlements(text); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_ensure_tenant_module_entitlements(p_tenant_id text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE
  v_schema text := 'tenant_' || regexp_replace(p_tenant_id, '[^a-zA-Z0-9_]', '', 'g');
BEGIN
  -- Ensure the per-tenant schema exists. Self-registered tenants whose
  -- per-tenant provisioning has not run yet would otherwise leave dauth's
  -- product_enabled check reading from a non-existent schema.
  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', v_schema);
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='dos_migrator') THEN
    EXECUTE format('GRANT USAGE, CREATE ON SCHEMA %I TO dos_migrator', v_schema);
  END IF;

  EXECUTE format($f$
    CREATE TABLE IF NOT EXISTS %I.tenant_module_entitlements (
      id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      module_code         text NOT NULL UNIQUE,
      is_active           boolean DEFAULT true,
      entitlement_source  text DEFAULT 'platform_dna',
      activated_at        timestamptz DEFAULT NOW(),
      tenant_id           text,
      created_at          timestamptz DEFAULT NOW(),
      updated_at          timestamptz DEFAULT NOW()
    )
  $f$, v_schema);

  EXECUTE format($f$
    INSERT INTO %I.tenant_module_entitlements
      (module_code, is_active, entitlement_source, tenant_id)
    VALUES
      ('foundation',   true, 'platform_dna', %L),
      ('audit_trail',  true, 'platform_dna', %L),
      ('role',         true, 'platform_dna', %L),
      ('profile',      true, 'platform_dna', %L),
      ('navigation',   true, 'platform_dna', %L),
      ('workspace',    true, 'platform_dna', %L),
      ('tenant',       true, 'platform_dna', %L),
      ('users',        true, 'platform_dna', %L),
      ('access',       true, 'platform_dna', %L),
      ('access_review',true, 'platform_dna', %L)
    ON CONFLICT (module_code) DO UPDATE
      SET is_active = true, updated_at = NOW()
  $f$, v_schema,
       p_tenant_id, p_tenant_id, p_tenant_id, p_tenant_id, p_tenant_id,
       p_tenant_id, p_tenant_id, p_tenant_id, p_tenant_id, p_tenant_id);

  -- Grant runtime read.
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='dos_auth') THEN
    EXECUTE format('GRANT USAGE ON SCHEMA %I TO dos_auth', v_schema);
    EXECUTE format('GRANT SELECT ON %I.tenant_module_entitlements TO dos_auth', v_schema);
  END IF;
END;
$_$;


--
-- Name: fn_ensure_tenant_role_permission_map(text); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_ensure_tenant_role_permission_map(p_tenant_id text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE
  v_schema text := 'tenant_' || regexp_replace(p_tenant_id, '[^a-zA-Z0-9_]', '', 'g');
BEGIN
  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', v_schema);

  EXECUTE format($f$
    CREATE TABLE IF NOT EXISTS %I.role_permission_map (
      tenant_id        text NOT NULL,
      role_code        text NOT NULL,
      permission_code  text NOT NULL,
      source           text NOT NULL DEFAULT 'platform_dna',
      created_at       timestamptz NOT NULL DEFAULT NOW(),
      PRIMARY KEY (tenant_id, role_code, permission_code)
    )
  $f$, v_schema);

  EXECUTE format($f$
    INSERT INTO %I.role_permission_map (tenant_id, role_code, permission_code, source)
    SELECT %L, fr.role_code, p.permission_code, 'platform_dna'
      FROM platform_dauth.functional_roles fr
      CROSS JOIN LATERAL unnest(COALESCE(fr.permissions, ARRAY[]::text[])) AS p(permission_code)
     WHERE fr.role_code IN (
       SELECT DISTINCT role_code
         FROM platform_dauth.user_role_assignments
        WHERE tenant_id = %L AND is_active = true
          AND (revoked_at IS NULL)
          AND (expires_at IS NULL OR expires_at > NOW())
     )
    ON CONFLICT DO NOTHING
  $f$, v_schema, p_tenant_id, p_tenant_id);

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='dos_auth') THEN
    EXECUTE format('GRANT USAGE ON SCHEMA %I TO dos_auth', v_schema);
    EXECUTE format('GRANT SELECT ON %I.role_permission_map TO dos_auth', v_schema);
  END IF;
END;
$_$;


--
-- Name: fn_forward_membership_to_public(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_forward_membership_to_public() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Ensure user row exists in public.users (FK target).
  INSERT INTO public.users (user_id, email, display_name, status, created_at, updated_at)
    SELECT u.user_id::varchar, u.email,
           COALESCE(u.display_name, u.full_name, u.email),
           COALESCE(u.status, 'active'),
           COALESCE(u.created_at, NOW()), NOW()
      FROM dos.users u
     WHERE u.user_id = NEW.user_id AND u.email IS NOT NULL
  ON CONFLICT DO NOTHING;

  INSERT INTO public.tenant_user_memberships
    (membership_id, tenant_id, user_id, membership_type, is_tenant_owner,
     status, joined_at, updated_at, authz_version, org_role_code)
  VALUES
    (gen_random_uuid(), NEW.tenant_id::varchar, NEW.user_id::varchar,
     COALESCE(NEW.membership_type, 'internal'),
     COALESCE(NEW.is_tenant_owner, false),
     CASE WHEN NEW.status IN ('active','inactive','pending','revoked')
       THEN NEW.status ELSE 'active' END,
     COALESCE(NEW.created_at, NOW()), NOW(), 1, NEW.role_code)
  ON CONFLICT (tenant_id, user_id) DO UPDATE
    SET status     = EXCLUDED.status,
        updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: fn_forward_tenant_to_public(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_forward_tenant_to_public() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
  IF NEW.tenant_id::text !~ '^[a-z0-9](?:[a-z0-9_-]{0,62}[a-z0-9])?$' THEN
    RETURN NEW;
  END IF;
  INSERT INTO public.tenants
    (tenant_id, org_name, tenant_code, tenant_name_en, schema_name, status,
     industry, org_size, created_at, updated_at)
  VALUES
    (NEW.tenant_id::varchar,
     COALESCE(NEW.tenant_name, NEW.tenant_code, NEW.tenant_id::text),
     NEW.tenant_code,
     COALESCE(NEW.tenant_name, NEW.tenant_code, NEW.tenant_id::text),
     ('tenant_' || regexp_replace(NEW.tenant_id::text, '[^a-zA-Z0-9_]', '', 'g')),
     CASE WHEN NEW.status IN ('active','suspended','archived','onboarding','registered',
                              'pending_onboarding','provisioning','onboarding_ready',
                              'verified','email_pending','pending','deleted')
       THEN NEW.status::varchar ELSE 'active'::varchar END,
     'other', '1-50',
     COALESCE(NEW.created_at, NOW()), NOW())
  ON CONFLICT (tenant_id) DO UPDATE
    SET status     = EXCLUDED.status,
        updated_at = NOW();
  RETURN NEW;
END;
$_$;


--
-- Name: fn_foundation_entitlement_on_tenant(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_foundation_entitlement_on_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO dos.tenant_module_entitlements
    (entitlement_id, tenant_id, product_code, module_code, entitlement_status, source, starts_at, metadata)
  VALUES
    (substr(replace(gen_random_uuid()::text,'-',''),1,28), NEW.tenant_id::text, 'shahin-ai', 'foundation', 'active',
     'platform_dna', NOW(), '{"reason":"trigger-platform-dna"}'::jsonb)
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: fn_reproject_role_permission_map_on_ura(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_reproject_role_permission_map_on_ura() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM dos.fn_ensure_tenant_role_permission_map(NEW.tenant_id::text);
  RETURN NEW;
END;
$$;


--
-- Name: fn_role_profile_project_to_ura(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_role_profile_project_to_ura() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM set_config('app.via_role_profile', 'true', true);
  IF TG_OP IN ('INSERT','UPDATE') THEN
    INSERT INTO platform_dauth.user_role_assignments
      (assignment_id, tenant_id, user_id, role_code, scope, granted_by, granted_at, is_active)
    VALUES
      (NEW.profile_id::text, NEW.tenant_id, NEW.user_id, NEW.role_code, NEW.scope,
       NEW.source_system, NEW.created_at, NEW.lifecycle_state = 'active')
    ON CONFLICT (assignment_id) DO UPDATE
      SET role_code = EXCLUDED.role_code,
          scope     = EXCLUDED.scope,
          is_active = EXCLUDED.is_active;
  ELSIF TG_OP = 'DELETE' THEN
    DELETE FROM platform_dauth.user_role_assignments
     WHERE assignment_id = OLD.profile_id::text;
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;


--
-- Name: fn_role_profile_touch_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_role_profile_touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = COALESCE(OLD.version,1) + 1;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: fn_seed_tenant_module_entitlements_on_insert(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_seed_tenant_module_entitlements_on_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM dos.fn_ensure_tenant_module_entitlements(NEW.tenant_id::text);
  RETURN NEW;
END;
$$;


--
-- Name: fn_workspace_chrome_dna_on_tenant(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_workspace_chrome_dna_on_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO dos.ui_workspace_chrome (tenant_id, chrome_key, value_json)
    SELECT NEW.tenant_id::text, c.chrome_key, c.value_json::jsonb
      FROM (VALUES
        ('product.name',     '{"i18nKey":"chrome.product.name","fallback":"Shahin AI"}'),
        ('product.tagline',  '{"i18nKey":"chrome.product.tagline","fallback":"Enterprise GRC, AI-native"}'),
        ('header.brand',     '{"i18nKey":"chrome.header.brand","fallback":"Shahin AI"}'),
        ('footer.copyright', '{"i18nKey":"chrome.footer.copyright","fallback":"\u00a9 Dogan Consulting"}'),
        ('locale.default',   '{"primary":"en","supported":["en","ar"],"rtl":["ar"]}'),
        ('theme.default',    '{"name":"carbon-g100","mode":"dark"}')
      ) AS c(chrome_key, value_json)
  ON CONFLICT DO NOTHING;
  INSERT INTO dos.ui_workspace_policy (tenant_id, policy_key, value_json)
    SELECT NEW.tenant_id::text, p.policy_key, p.value_json::jsonb
      FROM (VALUES
        ('session.idle_timeout_seconds', '{"value":1800}'),
        ('session.warning_seconds',      '{"value":300}'),
        ('autosave.interval_ms',         '{"value":15000}'),
        ('rtl.enabled',                  '{"value":true}')
      ) AS p(policy_key, value_json)
  ON CONFLICT DO NOTHING;
  INSERT INTO dos.ui_workspace_shortcut (tenant_id, shortcut_id, combo, action_json, sort_order)
    SELECT NEW.tenant_id::text, s.shortcut_id, s.combo, s.action_json::jsonb, s.sort_order
      FROM (VALUES
        ('command.open',  'mod+k',      '{"kind":"open_command"}', 10),
        ('lang.toggle',   'mod+shift+l','{"kind":"toggle_language"}', 20),
        ('theme.toggle',  'mod+shift+t','{"kind":"toggle_theme"}', 30),
        ('overlay.close', 'escape',     '{"kind":"close_overlay"}', 40)
      ) AS s(shortcut_id, combo, action_json, sort_order)
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: module_registry_alias_sync(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.module_registry_alias_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.code IS NULL AND NEW.module_code IS NOT NULL THEN NEW.code := NEW.module_code; END IF;
  IF NEW.module_code IS NULL AND NEW.code IS NOT NULL THEN NEW.module_code := NEW.code; END IF;
  IF NEW.product_code IS NULL AND NEW.product_key IS NOT NULL THEN NEW.product_code := NEW.product_key; END IF;
  IF NEW.product_key IS NULL AND NEW.product_code IS NOT NULL THEN NEW.product_key := NEW.product_code; END IF;
  IF NEW.display_name IS NULL AND NEW.name_en IS NOT NULL THEN NEW.display_name := NEW.name_en; END IF;
  IF NEW.name_en IS NULL AND NEW.display_name IS NOT NULL THEN NEW.name_en := NEW.display_name; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: product_registry_alias_sync(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.product_registry_alias_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.code IS NULL AND NEW.product_key IS NOT NULL THEN NEW.code := NEW.product_key; END IF;
  IF NEW.product_key IS NULL AND NEW.code IS NOT NULL THEN NEW.product_key := NEW.code; END IF;
  IF NEW.display_name IS NULL AND NEW.name_en IS NOT NULL THEN NEW.display_name := NEW.name_en; END IF;
  IF NEW.name_en IS NULL AND NEW.display_name IS NOT NULL THEN NEW.name_en := NEW.display_name; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: record_migration(character varying, integer, character varying, character varying, character varying, character varying, character varying, integer, boolean, text, boolean); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.record_migration(p_service_name character varying, p_migration_number integer, p_migration_name character varying, p_migration_type character varying, p_executed_by character varying, p_git_sha character varying DEFAULT NULL::character varying, p_checksum character varying DEFAULT NULL::character varying, p_duration_ms integer DEFAULT NULL::integer, p_success boolean DEFAULT true, p_error_message text DEFAULT NULL::text, p_rollback_available boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    INSERT INTO dos.migration_history (
        service_name, migration_number, migration_name, migration_type,
        executed_by, git_sha, checksum, duration_ms, success, error_message, rollback_available
    ) VALUES (
        p_service_name, p_migration_number, p_migration_name, p_migration_type,
        p_executed_by, p_git_sha, p_checksum, p_duration_ms, p_success, p_error_message, p_rollback_available
    );
END;
$$;


--
-- Name: release_migration_lock(character varying, character varying); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.release_migration_lock(p_service_name character varying, p_locked_by character varying) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    DELETE FROM dos.migration_lock 
    WHERE service_name = p_service_name 
    AND locked_by = p_locked_by;
END;
$$;


--
-- Name: seed_workspace_shell_binding_for_tenant(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.seed_workspace_shell_binding_for_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   INSERT INTO dos.workspace_shell_binding 
     (tenant_id, component_key, position, perms_required, props, enabled)
   SELECT 
     NEW.tenant_id, 
     r.component_key, 
     COALESCE(NULLIF(r.metadata->>'position','')::int, row_number() OVER (ORDER BY r.component_key)::int),
     ARRAY[]::text[],
     '{}'::jsonb,
     TRUE -- Force enabled for structural components
     FROM dos.dynamic_ui_component_registry r
    WHERE r.component_key LIKE 'workspace.%'
      AND r.approval_status = 'approved'
    ON CONFLICT (tenant_id, component_key) DO UPDATE
    SET enabled = TRUE;
   RETURN NEW;
END;
$$;


--
-- Name: FUNCTION seed_workspace_shell_binding_for_tenant(); Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON FUNCTION dos.seed_workspace_shell_binding_for_tenant() IS '2026-05-05 v3 — registry-driven auto-seed for newly-inserted dos.tenants rows. Reads every approved workspace.* component_key from dos.dynamic_ui_component_registry; position lifted from metadata.position with row_number fallback. Idempotent on UNIQUE(tenant_id, component_key).';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: tpa_alias_sync(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.tpa_alias_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.product_code IS NULL AND NEW.product_key IS NOT NULL THEN NEW.product_code := NEW.product_key; END IF;
  IF NEW.product_key IS NULL AND NEW.product_code IS NOT NULL THEN NEW.product_key := NEW.product_code; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trg_dos_master_only(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'dos', 'public'
    AS $$
DECLARE
  v_actor   text := current_setting('dos.actor', true);
  v_role    text := current_setting('dos.actor_role', true);
  v_cr      uuid := nullif(current_setting('dos.change_request_id', true), '')::uuid;
  v_ring    text := nullif(current_setting('dos.rollout_ring', true), '');
  v_corr    uuid := nullif(current_setting('dos.correlation_id', true), '')::uuid;
  v_session text := current_user;
  v_pk      text;
  v_old     jsonb;
  v_new     jsonb;
BEGIN
  -- Floor: session role must inherit dos_master (skipped only if the
  -- role does not yet exist, which happens when the ops migration has
  -- not been run; the application-identity check below still applies).
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'dos_master')
     AND NOT pg_has_role(v_session, 'dos_master', 'USAGE') THEN
    RAISE EXCEPTION 'DOS Master only: session role % is not granted dos_master', v_session
      USING ERRCODE = '42501';
  END IF;

  -- Application identity must self-identify as dos-master.
  IF v_actor IS NULL OR v_actor = '' OR v_actor <> 'dos-master' THEN
    RAISE EXCEPTION 'DOS Master only: dos.actor must be set to ''dos-master'' (got %)',
      coalesce(v_actor, '<unset>')
      USING ERRCODE = '42501';
  END IF;

  -- Snapshot row payloads for audit.
  IF (TG_OP = 'INSERT') THEN
    v_new := to_jsonb(NEW);
    v_pk  := coalesce(v_new->>'id', v_new->>'code', v_new->>'key');
  ELSIF (TG_OP = 'UPDATE') THEN
    v_old := to_jsonb(OLD);
    v_new := to_jsonb(NEW);
    v_pk  := coalesce(v_new->>'id', v_new->>'code', v_new->>'key');
  ELSE
    v_old := to_jsonb(OLD);
    v_pk  := coalesce(v_old->>'id', v_old->>'code', v_old->>'key');
  END IF;

  INSERT INTO dos.dos_master_writer_audit
    (actor, session_role, table_schema, table_name, op, row_pk,
     old_row, new_row, change_request_id, rollout_ring, correlation_id,
     client_addr, application_name)
  VALUES
    (v_actor, v_session, TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP, v_pk,
     v_old, v_new, v_cr, v_ring, v_corr,
     inet_client_addr(), current_setting('application_name', true));

  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END
$$;


--
-- Name: FUNCTION trg_dos_master_only(); Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON FUNCTION dos.trg_dos_master_only() IS 'M1 D1 — reusable BEFORE INSERT/UPDATE/DELETE trigger. Rejects writes unless the session role inherits dos_master AND dos.actor=''dos-master''. On accept, mirrors the write to dos_master_writer_audit. Attached to every controlled table in M1 D2..D4.';


--
-- Name: trg_dos_master_only_platform_slo(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only_platform_slo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF coalesce(current_setting('dos.actor', true), '') <> 'dos-master' THEN
    RAISE EXCEPTION 'dos.platform_slo write rejected: actor=% (only dos-master may write)',
      coalesce(current_setting('dos.actor', true), '∅');
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: trg_dos_master_only_platform_slo_event(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only_platform_slo_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF coalesce(current_setting('dos.actor', true), '') = '' THEN
    RAISE EXCEPTION 'dos.platform_slo_event write rejected: dos.actor unset';
  END IF;
  IF TG_OP = 'UPDATE' OR TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'dos.platform_slo_event is append-only (TG_OP=%)', TG_OP;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: trg_dos_master_only_session_policy(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only_session_policy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF coalesce(current_setting('dos.actor', true), '') <> 'dos-master' THEN
    RAISE EXCEPTION 'dos.platform_session_policy write rejected: actor=%', current_setting('dos.actor', true);
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: update_i18n_fallback_values_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.update_i18n_fallback_values_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: update_tenant_landing_config_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.update_tenant_landing_config_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: validate_carbon_key_exists(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.validate_carbon_key_exists() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.carbon_key IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM dos.ui_carbon_components
      WHERE carbon_key = NEW.carbon_key
    ) THEN
      RAISE EXCEPTION 'carbon_key "%" does not exist in ui_carbon_components',
        NEW.carbon_key;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_template_export_registry(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.validate_template_export_registry() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.template_export IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM dos.dynamic_ui_component_registry
      WHERE component_key = NEW.template_export
      AND approval_status = 'approved'
    ) THEN
      RAISE EXCEPTION 'template_export "%" does not exist in dynamic_ui_component_registry or is not approved',
        NEW.template_export;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: _t_perl(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._t_perl() RETURNS text
    LANGUAGE plperl
    AS $$return "plperl OK";$$;


--
-- Name: _t_v8(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._t_v8() RETURNS text
    LANGUAGE plv8
    AS $$return "plv8 OK";$$;


--
-- Name: app_current_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_current_tenant_id() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
  tid TEXT;
BEGIN
  tid := current_setting('app.current_tenant_id', true);
  IF tid IS NULL OR tid = '' THEN
    RETURN NULL;
  END IF;
  RETURN tid;
EXCEPTION WHEN OTHERS THEN
  RETURN NULL;
END;
$$;


--
-- Name: audit_question_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_question_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_old_values JSONB;
  v_new_values JSONB;
  v_action VARCHAR(20);
BEGIN
  -- Determine action type
  IF TG_OP = 'INSERT' THEN
    v_action := 'INSERT';
    v_old_values := NULL;
    v_new_values := to_jsonb(NEW);
  ELSIF TG_OP = 'UPDATE' THEN
    v_action := 'UPDATE';
    v_old_values := to_jsonb(OLD);
    v_new_values := to_jsonb(NEW);
  ELSIF TG_OP = 'DELETE' THEN
    v_action := 'DELETE';
    v_old_values := to_jsonb(OLD);
    v_new_values := NULL;
  END IF;
  
  -- Insert audit record
  INSERT INTO public.onboarding_question_audit (
    question_code,
    action,
    old_values,
    new_values,
    changed_by,
    changed_by_user_id,
    tenant_id,
    created_at
  ) VALUES (
    COALESCE(NEW.question_code, OLD.question_code),
    v_action,
    v_old_values,
    v_new_values,
    current_user,
    NULL, -- Can be populated from application context
    NULL, -- Platform-level questions have no tenant
    NOW()
  );
  
  -- Return appropriate row
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;


--
-- Name: FUNCTION audit_question_changes(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.audit_question_changes() IS 'Records all changes to question bank for compliance auditing';


--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.current_tenant_id() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
  tid TEXT;
BEGIN
  tid := current_setting('app.current_tenant_id', true);
  IF tid IS NULL OR tid = '' THEN
    RETURN NULL;
  END IF;
  RETURN tid;
EXCEPTION WHEN OTHERS THEN
  RETURN NULL;
END;
$$;


--
-- Name: dos_tenant_list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dos_tenant_list() RETURNS TABLE(tenant_id character varying, tenant_name character varying)
    LANGUAGE sql STABLE
    AS $$
  SELECT tenant_id::VARCHAR(255), org_name::VARCHAR(255) FROM public.tenants;
$$;


--
-- Name: evaluate_visibility_rule(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.evaluate_visibility_rule(p_rule_json jsonb, p_answers jsonb) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
  v_all_conditions BOOLEAN := TRUE;
  v_any_conditions BOOLEAN := FALSE;
  v_condition JSONB;
  v_question_code TEXT;
  v_operator TEXT;
  v_expected_value TEXT;
  v_actual_value TEXT;
  v_result BOOLEAN := TRUE;
BEGIN
  -- Handle NULL rules (visible by default)
  IF p_rule_json IS NULL OR p_rule_json = '{}'::jsonb THEN
    RETURN TRUE;
  END IF;
  
  -- Evaluate "all" conditions (AND logic)
  IF p_rule_json->'all' IS NOT NULL THEN
    FOR v_condition IN SELECT jsonb_array_elements(p_rule_json->'all')
    LOOP
      v_question_code := v_condition->>'question_code';
      v_operator := v_condition->>'operator';
      v_expected_value := v_condition->>'value';
      
      -- Get actual answer value
      v_actual_value := p_answers->>v_question_code;
      
      -- Evaluate condition
      CASE v_operator
        WHEN 'equals' THEN
          v_result := (v_actual_value = v_expected_value);
        WHEN 'not_equals' THEN
          v_result := (v_actual_value != v_expected_value);
        WHEN 'contains' THEN
          v_result := (v_actual_value ILIKE '%' || v_expected_value || '%');
        WHEN 'in' THEN
          v_result := (v_actual_value = ANY(ARRAY(SELECT jsonb_array_elements_text(v_condition->'values'))));
        WHEN 'not_empty' THEN
          v_result := (v_actual_value IS NOT NULL AND v_actual_value != '');
        WHEN 'gt' THEN
          v_result := (v_actual_value::numeric > v_expected_value::numeric);
        WHEN 'lt' THEN
          v_result := (v_actual_value::numeric < v_expected_value::numeric);
        ELSE
          v_result := TRUE; -- Unknown operator, default to visible
      END CASE;
      
      v_all_conditions := v_all_conditions AND v_result;
    END LOOP;
    
    RETURN v_all_conditions;
  END IF;
  
  -- Evaluate "any" conditions (OR logic)
  IF p_rule_json->'any' IS NOT NULL THEN
    FOR v_condition IN SELECT jsonb_array_elements(p_rule_json->'any')
    LOOP
      -- Similar evaluation logic for "any"
      v_question_code := v_condition->>'question_code';
      v_operator := v_condition->>'operator';
      v_expected_value := v_condition->>'value';
      v_actual_value := p_answers->>v_question_code;
      
      CASE v_operator
        WHEN 'equals' THEN v_result := (v_actual_value = v_expected_value);
        WHEN 'contains' THEN v_result := (v_actual_value ILIKE '%' || v_expected_value || '%');
        WHEN 'in' THEN v_result := (v_actual_value = ANY(ARRAY(SELECT jsonb_array_elements_text(v_condition->'values'))));
        ELSE v_result := FALSE;
      END CASE;
      
      v_any_conditions := v_any_conditions OR v_result;
    END LOOP;
    
    RETURN v_any_conditions;
  END IF;
  
  RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION evaluate_visibility_rule(p_rule_json jsonb, p_answers jsonb); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.evaluate_visibility_rule(p_rule_json jsonb, p_answers jsonb) IS 'Evaluates visibility_rule_json against provided answers to determine if question should be shown';


--
-- Name: fn_tenant_latest_workspace(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_tenant_latest_workspace(p_schema_name text) RETURNS TABLE(workspace_id text, name text, status text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$
BEGIN
  IF p_schema_name IS NULL OR length(trim(p_schema_name)) = 0 THEN
    RETURN;
  END IF;
  IF trim(p_schema_name) !~ '^(t|tenant)_[a-zA-Z0-9_-]{1,64}$' THEN
    RAISE WARNING 'fn_tenant_latest_workspace: rejected schema name %', p_schema_name;
    RETURN;
  END IF;
  BEGIN
    RETURN QUERY EXECUTE format(
      'SELECT w.workspace_id::text, w.name::text, w.status::text
         FROM %I.workspaces w
        ORDER BY w.created_at DESC NULLS LAST
        LIMIT 1',
      trim(p_schema_name)
    );
  EXCEPTION
    WHEN undefined_table THEN
      RETURN;
    WHEN invalid_schema_name THEN
      RETURN;
    WHEN insufficient_privilege THEN
      -- Schema exists but the DEFINER role lacks SELECT — surface a
      -- warning for ops and return empty (same shape as undefined_table).
      RAISE WARNING 'fn_tenant_latest_workspace: insufficient privilege on %', p_schema_name;
      RETURN;
  END;
END;
$_$;


--
-- Name: FUNCTION fn_tenant_latest_workspace(p_schema_name text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.fn_tenant_latest_workspace(p_schema_name text) IS 'Returns latest tenant-scoped workspace row by created_at; empty if schema/table missing. SECURITY DEFINER — runs with migrator privileges, input is whitelist-regex-gated so dynamic SQL is safe.';


--
-- Name: get_ai_accuracy_metrics(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_ai_accuracy_metrics(p_days_back integer DEFAULT 30) RETURNS TABLE(question_tier text, total_suggestions integer, accepted integer, rejected integer, acceptance_rate numeric, avg_confidence numeric)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.question_tier_at_answer,
    COUNT(*)::INTEGER as total_suggestions,
    COUNT(*) FILTER (WHERE a.ai_suggested_value IS NOT NULL AND NOT a.user_modified_ai)::INTEGER as accepted,
    COUNT(*) FILTER (WHERE a.ai_suggested_value IS NOT NULL AND a.user_modified_ai)::INTEGER as rejected,
    CASE 
      WHEN COUNT(*) FILTER (WHERE a.ai_suggested_value IS NOT NULL) > 0
      THEN (COUNT(*) FILTER (WHERE a.ai_suggested_value IS NOT NULL AND NOT a.user_modified_ai)::DECIMAL / 
            COUNT(*) FILTER (WHERE a.ai_suggested_value IS NOT NULL) * 100)::DECIMAL(5,2)
      ELSE 0.0
    END as acceptance_rate,
    AVG(a.ai_confidence_score)::DECIMAL(3,2) as avg_confidence
  FROM public.onboarding_session_answers a
  WHERE a.answered_at > NOW() - (p_days_back || ' days')::INTERVAL
    AND a.ai_suggested_value IS NOT NULL
  GROUP BY a.question_tier_at_answer
  ORDER BY acceptance_rate DESC;
END;
$$;


--
-- Name: get_onboarding_funnel(timestamp with time zone, timestamp with time zone, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_onboarding_funnel(p_start_date timestamp with time zone, p_end_date timestamp with time zone, p_tenant_id text DEFAULT NULL::text) RETURNS TABLE(stage_code text, total_questions integer, questions_started integer, questions_completed integer, avg_time_seconds integer, drop_off_rate numeric)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    q.stage_code,
    COUNT(DISTINCT q.question_code)::INTEGER as total_questions,
    COUNT(DISTINCT a.question_code)::INTEGER as questions_started,
    COUNT(DISTINCT CASE WHEN a.validation_passed THEN a.question_code END)::INTEGER as questions_completed,
    COALESCE(AVG(EXTRACT(EPOCH FROM (a.answered_at - s.created_at))))::INTEGER as avg_time_seconds,
    CASE 
      WHEN COUNT(a.id) > 0 THEN 
        (100.0 - (COUNT(DISTINCT CASE WHEN a.validation_passed THEN a.question_code END)::DECIMAL / 
         NULLIF(COUNT(DISTINCT q.question_code), 0) * 100))
      ELSE 0.0 
    END::DECIMAL(5,2) as drop_off_rate
  FROM public.onboarding_question_bank q
  CROSS JOIN public.onboarding_sessions s
  LEFT JOIN public.onboarding_session_answers a 
    ON q.question_code = a.question_code 
    AND s.id = a.session_id
  WHERE q.is_active = TRUE
    AND s.created_at BETWEEN p_start_date AND p_end_date
    AND (p_tenant_id IS NULL OR s.tenant_id = p_tenant_id)
  GROUP BY q.stage_code
  ORDER BY MIN(q.sort_order);
END;
$$;


--
-- Name: get_visible_questions(uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_visible_questions(p_session_id uuid, p_stage_code text, p_mode text DEFAULT 'guided'::text) RETURNS TABLE(question_code text, question_type text, label_en text, label_ar text, is_required boolean, sort_order integer, lookup_table text, lookup_depends_on text, visibility_reason text)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
  v_answers JSONB;
  v_tenant_id TEXT;
BEGIN
  -- Get current answers for this session
  SELECT 
    jsonb_object_agg(a.question_code, a.answer_value),
    s.tenant_id
  INTO v_answers, v_tenant_id
  FROM public.onboarding_session_answers a
  JOIN public.onboarding_sessions s ON a.session_id = s.id
  WHERE a.session_id = p_session_id;
  
  RETURN QUERY
  SELECT 
    q.question_code,
    q.question_type,
    q.label_en,
    q.label_ar,
    q.is_required,
    q.sort_order,
    q.lookup_table,
    q.lookup_depends_on,
    CASE 
      WHEN p_mode = 'express' AND q.question_tier NOT IN ('anchor', 'inferred') THEN 'hidden_by_mode'
      WHEN q.visibility_rule_json IS NULL THEN 'always_visible'
      WHEN public.evaluate_visibility_rule(q.visibility_rule_json, COALESCE(v_answers, '{}'::jsonb)) THEN 'visible_by_rule'
      ELSE 'hidden_by_rule'
    END as visibility_reason
  FROM public.onboarding_question_bank q
  WHERE q.stage_code = p_stage_code
    AND q.is_active = TRUE
    AND (
      p_mode != 'express' 
      OR q.question_tier IN ('anchor', 'inferred')
    )
    AND (
      q.visibility_rule_json IS NULL
      OR public.evaluate_visibility_rule(q.visibility_rule_json, COALESCE(v_answers, '{}'::jsonb))
    )
  ORDER BY q.sort_order;
END;
$$;


--
-- Name: FUNCTION get_visible_questions(p_session_id uuid, p_stage_code text, p_mode text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_visible_questions(p_session_id uuid, p_stage_code text, p_mode text) IS 'Returns questions visible for a session based on mode and visibility rules';


--
-- Name: iam_identities_touch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.iam_identities_touch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: recalculate_session_progress(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.recalculate_session_progress(p_session_id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_tenant_id          TEXT;
  v_current_stage      TEXT;
  v_journey_codes      TEXT[];
  v_required_codes     TEXT[];
  v_answered_codes     TEXT[];
  v_journey_total      INTEGER;
  v_journey_answered   INTEGER;
  v_required_total     INTEGER;
  v_required_answered  INTEGER;
  v_blocked_by         TEXT[];
  v_can_progress       BOOLEAN;
  v_completion_pct     INTEGER;
  v_stage_progress     JSONB;
BEGIN
  -- Resolve session metadata + journey contract.
  SELECT
    tenant_id,
    current_stage_code,
    COALESCE(effective_question_codes, ARRAY[]::TEXT[]),
    COALESCE(effective_required_question_codes, ARRAY[]::TEXT[])
  INTO v_tenant_id, v_current_stage, v_journey_codes, v_required_codes
  FROM public.onboarding_sessions
  WHERE id = p_session_id;

  IF v_tenant_id IS NULL THEN
    RETURN;
  END IF;

  -- Fallback: when the session has no resolved journey yet, score against
  -- the active anchor pool only — NEVER the full catalog.
  IF array_length(v_journey_codes, 1) IS NULL THEN
    SELECT COALESCE(array_agg(question_code ORDER BY stage_code, sort_order), ARRAY[]::TEXT[])
    INTO v_journey_codes
    FROM public.onboarding_question_bank
    WHERE is_active = TRUE AND COALESCE(question_tier, 'anchor') = 'anchor';

    SELECT COALESCE(array_agg(question_code ORDER BY stage_code, sort_order), ARRAY[]::TEXT[])
    INTO v_required_codes
    FROM public.onboarding_question_bank
    WHERE is_active = TRUE AND COALESCE(question_tier, 'anchor') = 'anchor' AND is_required = TRUE;
  END IF;

  -- Pull every persisted answer for this session from the canonical table.
  SELECT COALESCE(array_agg(question_code), ARRAY[]::TEXT[])
  INTO v_answered_codes
  FROM public.onboarding_session_answers
  WHERE session_id = p_session_id;

  -- Journey-wide totals.
  v_journey_total := COALESCE(array_length(v_journey_codes, 1), 0);
  SELECT COUNT(*)::INTEGER INTO v_journey_answered
    FROM unnest(v_journey_codes) c WHERE c = ANY(v_answered_codes);

  -- Required-anchor gate.
  v_required_total := COALESCE(array_length(v_required_codes, 1), 0);
  SELECT COUNT(*)::INTEGER INTO v_required_answered
    FROM unnest(v_required_codes) c WHERE c = ANY(v_answered_codes);

  SELECT COALESCE(array_agg(c), ARRAY[]::TEXT[])
  INTO v_blocked_by
  FROM unnest(v_required_codes) c
  WHERE NOT (c = ANY(v_answered_codes));
  v_can_progress := (COALESCE(array_length(v_blocked_by, 1), 0) = 0);

  v_completion_pct := CASE
    WHEN v_journey_total > 0
      THEN LEAST(100, GREATEST(0, (v_journey_answered::FLOAT / v_journey_total::FLOAT * 100)::INTEGER))
    ELSE 0
  END;

  -- Per-stage breakdown.
  WITH journey AS (
    SELECT q.question_code, q.stage_code
    FROM public.onboarding_question_bank q
    WHERE q.question_code = ANY(v_journey_codes) AND q.is_active = TRUE
  ),
  per_stage AS (
    SELECT
      j.stage_code,
      COUNT(*)::INTEGER AS total,
      COUNT(*) FILTER (WHERE j.question_code = ANY(v_answered_codes))::INTEGER AS answered,
      COUNT(*) FILTER (WHERE j.question_code = ANY(v_required_codes))::INTEGER AS required_total,
      COUNT(*) FILTER (
        WHERE j.question_code = ANY(v_required_codes)
          AND j.question_code = ANY(v_answered_codes)
      )::INTEGER AS required_answered
    FROM journey j
    GROUP BY j.stage_code
  )
  SELECT COALESCE(jsonb_object_agg(
    ps.stage_code,
    jsonb_build_object(
      'total', ps.total,
      'answered', ps.answered,
      'required_total', ps.required_total,
      'required_answered', ps.required_answered,
      'percent', CASE WHEN ps.total > 0
                       THEN LEAST(100, GREATEST(0, (ps.answered::FLOAT / ps.total::FLOAT * 100)::INTEGER))
                       ELSE 0 END
    )
  ), '{}'::jsonb)
  INTO v_stage_progress
  FROM per_stage ps;

  INSERT INTO public.onboarding_session_progress (
    session_id, tenant_id,
    total_questions, answered_questions,
    required_questions, required_answered,
    completion_percentage,
    journey_total, journey_answered,
    journey_required_total, journey_required_answered,
    can_progress, blocked_by,
    current_stage, stage_progress,
    last_activity_at, updated_at
  ) VALUES (
    p_session_id, v_tenant_id,
    v_journey_total, v_journey_answered,
    v_required_total, v_required_answered,
    v_completion_pct,
    v_journey_total, v_journey_answered,
    v_required_total, v_required_answered,
    v_can_progress, v_blocked_by,
    v_current_stage, v_stage_progress,
    NOW(), NOW()
  )
  ON CONFLICT (session_id) DO UPDATE SET
    tenant_id                  = EXCLUDED.tenant_id,
    total_questions            = EXCLUDED.total_questions,
    answered_questions         = EXCLUDED.answered_questions,
    required_questions         = EXCLUDED.required_questions,
    required_answered          = EXCLUDED.required_answered,
    completion_percentage      = EXCLUDED.completion_percentage,
    journey_total              = EXCLUDED.journey_total,
    journey_answered           = EXCLUDED.journey_answered,
    journey_required_total     = EXCLUDED.journey_required_total,
    journey_required_answered  = EXCLUDED.journey_required_answered,
    can_progress               = EXCLUDED.can_progress,
    blocked_by                 = EXCLUDED.blocked_by,
    current_stage              = EXCLUDED.current_stage,
    stage_progress             = EXCLUDED.stage_progress,
    last_activity_at           = NOW(),
    updated_at                 = NOW();

  -- Mirror progress_percent on the session row so callers that read the
  -- session directly stay consistent with the aggregate table. This
  -- removes the need for the route handler to UPDATE progress_percent
  -- separately after each save.
  UPDATE public.onboarding_sessions
  SET progress_percent = v_completion_pct,
      updated_at = NOW()
  WHERE id = p_session_id;
END;
$$;


--
-- Name: refresh_mv_question_performance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.refresh_mv_question_performance() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  REFRESH MATERIALIZED VIEW public.mv_question_performance;
END;
$$;


--
-- Name: FUNCTION refresh_mv_question_performance(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.refresh_mv_question_performance() IS 'Refreshes the question performance materialized view';


--
-- Name: update_progress_on_answer(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_progress_on_answer() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM public.recalculate_session_progress(NEW.session_id);
  RETURN NEW;
END;
$$;


--
-- Name: validate_answer_value(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_answer_value() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_question public.onboarding_question_bank%ROWTYPE;
  v_validation_rules JSONB;
  v_rule_key TEXT;
  v_rule_value TEXT;
  v_answer_text TEXT;
  v_answer_num NUMERIC;
  v_is_valid BOOLEAN := TRUE;
  v_errors TEXT[] := ARRAY[]::TEXT[];
BEGIN
  SELECT * INTO v_question
  FROM public.onboarding_question_bank
  WHERE question_code = NEW.question_code;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid question_code: %', NEW.question_code;
  END IF;

  v_answer_text := NEW.answer_value::TEXT;

  CASE v_question.question_type
    WHEN 'number' THEN
      BEGIN
        v_answer_num := (NEW.answer_value->>'value')::NUMERIC;
      EXCEPTION WHEN OTHERS THEN
        v_is_valid := FALSE;
        v_errors := array_append(v_errors, 'Answer must be a valid number');
      END;

    WHEN 'boolean' THEN
      IF NOT (NEW.answer_value->>'value' IN ('true', 'false', '1', '0')) THEN
        v_is_valid := FALSE;
        v_errors := array_append(v_errors, 'Answer must be true or false');
      END IF;

    WHEN 'date' THEN
      BEGIN
        PERFORM (NEW.answer_value->>'value')::DATE;
      EXCEPTION WHEN OTHERS THEN
        v_is_valid := FALSE;
        v_errors := array_append(v_errors, 'Answer must be a valid date (YYYY-MM-DD)');
      END;

    WHEN 'select' THEN
      IF v_question.options_json IS NOT NULL THEN
        IF NOT EXISTS (
          SELECT 1
          FROM jsonb_array_elements(v_question.options_json) AS opt
          WHERE opt->>'value' = NEW.answer_value->>'value'
        ) THEN
          v_is_valid := FALSE;
          v_errors := array_append(v_errors, 'Answer must be one of the provided options');
        END IF;
      END IF;

    WHEN 'multi_select' THEN
      IF v_question.options_json IS NOT NULL AND jsonb_typeof(NEW.answer_value) = 'array' THEN
        IF EXISTS (
          SELECT 1
          FROM jsonb_array_elements_text(NEW.answer_value) AS val
          WHERE NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_question.options_json) AS opt
            WHERE opt->>'value' = val
          )
        ) THEN
          v_is_valid := FALSE;
          v_errors := array_append(v_errors, 'All selected values must be valid options');
        END IF;
      END IF;

    WHEN 'lookup' THEN
      -- Lookup tables validated at application level (dynamic table name).
      NULL;

    WHEN 'text' THEN
      -- Free-form text — accept as-is; length / regex enforced by Zod at API.
      NULL;

    ELSE
      -- Unknown question_type (json_rows / chips / future additions): pass.
      NULL;
  END CASE;

  -- Set validation_passed + validation_errors but never block the insert
  -- on a soft validation failure; row goes in with validation_passed=false
  -- so the FE can surface errors.
  NEW.validation_passed := v_is_valid;
  IF array_length(v_errors, 1) IS NOT NULL THEN
    NEW.validation_errors := to_jsonb(v_errors);
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_answer_value(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_answer_value() IS 'Production-grade validation for all answer types with rule enforcement';


--
-- Name: access_profiles; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.access_profiles AS
 SELECT profile_id,
    profile_code,
    display_name,
    description,
    permissions,
    created_at
   FROM platform_dauth.access_profiles_legacy;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_review_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.access_review_items (
    item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    resource_type text NOT NULL,
    resource_id character varying(64) NOT NULL,
    entitlement text,
    decision text,
    decided_by character varying(64),
    decided_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: access_reviews; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.access_reviews (
    review_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    campaign_name text NOT NULL,
    description text,
    scope jsonb DEFAULT '{}'::jsonb,
    status text DEFAULT 'draft'::text NOT NULL,
    due_date timestamp with time zone,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: action_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.action_items (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    remediation_id uuid,
    title text NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    assigned_to character varying(64),
    due_date date,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: admin_pillar; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.admin_pillar (
    pillar_code text NOT NULL,
    display_name text NOT NULL,
    description text,
    enabled boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT admin_pillar_pillar_code_check CHECK ((pillar_code = ANY (ARRAY['DNOC'::text, 'DSOC'::text, 'DOS'::text, 'DAuth'::text])))
);


--
-- Name: admin_pillar_page; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.admin_pillar_page (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pillar_code text NOT NULL,
    page_key text NOT NULL,
    display_name text NOT NULL,
    archetype text NOT NULL,
    route text NOT NULL,
    permission_required text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: admin_pillar_widget; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.admin_pillar_widget (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    widget_key text NOT NULL,
    carbon_key text NOT NULL,
    title_en text,
    title_ar text,
    data_source text NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    permission_required text
);


--
-- Name: agent_action_receipts; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_action_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    run_id uuid,
    agent_id text NOT NULL,
    action_id text NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    before_state jsonb,
    after_state jsonb,
    evidence_ref text,
    rollback_ref text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_evidence_links; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_evidence_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    run_id uuid,
    evidence_type text NOT NULL,
    evidence_ref text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_memory; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_memory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    agent_id text NOT NULL,
    subject_type text,
    subject_id text,
    memory_key text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_module_binding; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_module_binding (
    agent_code text NOT NULL,
    module_code text NOT NULL,
    workbench_route text,
    audit_route text,
    followup_route text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE agent_module_binding; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.agent_module_binding IS 'M0.5 — per-module enrolment of agents (M:N agent×module).';


--
-- Name: agent_recommendations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_recommendations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    route text,
    subject_type text,
    subject_id text,
    agent_id text NOT NULL,
    recommendation text NOT NULL,
    rationale text,
    confidence numeric(5,4),
    risk_level text,
    status text DEFAULT 'open'::text NOT NULL,
    evidence_links jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT agent_recommendations_risk_level_check CHECK (((risk_level IS NULL) OR (risk_level = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))),
    CONSTRAINT agent_recommendations_status_check CHECK ((status = ANY (ARRAY['open'::text, 'acknowledged'::text, 'accepted'::text, 'rejected'::text, 'expired'::text])))
);


--
-- Name: agent_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_registry (
    agent_code text NOT NULL,
    display_name_en text NOT NULL,
    display_name_ar text NOT NULL,
    role_key text NOT NULL,
    capabilities text[] DEFAULT ARRAY[]::text[] NOT NULL,
    permission_key text NOT NULL,
    brand_tile_kind text DEFAULT 'agent-tile'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    confidence_default numeric(3,2) DEFAULT 0.75 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_registry_brand_tile_chk CHECK ((brand_tile_kind = 'agent-tile'::text)),
    CONSTRAINT agent_registry_code_chk CHECK ((agent_code ~ '^A[0-9]{2}$'::text)),
    CONSTRAINT agent_registry_conf_chk CHECK (((confidence_default >= (0)::numeric) AND (confidence_default <= (1)::numeric))),
    CONSTRAINT agent_registry_status_chk CHECK ((status = ANY (ARRAY['active'::text, 'retired'::text, 'draft'::text])))
);


--
-- Name: TABLE agent_registry; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.agent_registry IS 'M0.5 agentic registry — one row per logical agent (A01..An).';


--
-- Name: agent_run_steps; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_run_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    step_index integer NOT NULL,
    agent_id text,
    step_type text NOT NULL,
    payload jsonb,
    result jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: agent_runs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_runs (
    run_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    route text,
    agent_id text NOT NULL,
    user_id text,
    status text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    confidence numeric(5,4),
    risk_level text,
    approval_required boolean DEFAULT false NOT NULL,
    correlation_id text,
    CONSTRAINT agent_runs_risk_level_check CHECK (((risk_level IS NULL) OR (risk_level = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))),
    CONSTRAINT agent_runs_status_check CHECK ((status = ANY (ARRAY['running'::text, 'completed'::text, 'failed'::text, 'aborted'::text])))
);


--
-- Name: agrc_agent_memory; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_agent_memory (
    memory_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    agent_id character varying(10) NOT NULL,
    scope character varying(20) DEFAULT 'working'::character varying NOT NULL,
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    cycle_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_agent_runs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_agent_runs (
    run_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    agent_id character varying(10) NOT NULL,
    cycle_id uuid,
    status character varying(30) DEFAULT 'running'::character varying NOT NULL,
    mode character varying(20) DEFAULT 'hybrid'::character varying NOT NULL,
    task text,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb,
    discovery_count integer DEFAULT 0 NOT NULL,
    action_count integer DEFAULT 0 NOT NULL,
    token_usage integer DEFAULT 0 NOT NULL,
    duration_ms integer,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: agrc_cycles; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_cycles (
    cycle_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    mode character varying(20) DEFAULT 'hybrid'::character varying NOT NULL,
    status character varying(30) DEFAULT 'running'::character varying NOT NULL,
    agents jsonb DEFAULT '[]'::jsonb NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    results jsonb,
    wave_count integer DEFAULT 0 NOT NULL,
    discovery_count integer DEFAULT 0 NOT NULL,
    action_count integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_discoveries; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_discoveries (
    discovery_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    cycle_id uuid,
    agent_id character varying(10) NOT NULL,
    run_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'info'::character varying NOT NULL,
    title text NOT NULL,
    description text,
    entity_type character varying(50),
    entity_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_handoffs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_handoffs (
    handoff_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    from_agent character varying(10) NOT NULL,
    to_agent character varying(10) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_proposed_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_proposed_actions (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    cycle_id uuid,
    agent_id character varying(10) NOT NULL,
    run_id uuid,
    type character varying(50) NOT NULL,
    title text NOT NULL,
    description text,
    target_entity_type character varying(50),
    target_entity_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_level character varying(20) DEFAULT 'low'::character varying NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    review_reason text,
    reviewed_at timestamp with time zone,
    reviewed_by character varying(64),
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_tasks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_tasks (
    task_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    task_type character varying(50),
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    assigned_to character varying(64),
    due_date date,
    source_module character varying(100),
    source_entity_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    type character varying(50),
    module character varying(100),
    agent_id character varying(10),
    assignee_id character varying(64),
    input_data jsonb,
    output_data jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


--
-- Name: ai_agent_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_agent_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_code character varying(200) NOT NULL,
    name_en character varying(255),
    name_ar character varying(255),
    capabilities jsonb DEFAULT '[]'::jsonb,
    model_code character varying(200),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ai_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ai_event_id_seq OWNED BY dos.ai_event.id;


--
-- Name: ai_model_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_model_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider character varying(100) NOT NULL,
    model_code character varying(200) NOT NULL,
    name character varying(255),
    capabilities jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_prompt_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_prompt_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    prompt_code character varying(200) NOT NULL,
    name character varying(255),
    template text,
    model_code character varying(200),
    module_code character varying(128),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT ai_record_kind_check CHECK ((kind = ANY (ARRAY['llm'::text, 'retrieval'::text, 'classifier'::text, 'agent'::text, 'embedding'::text]))),
    CONSTRAINT ai_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT ai_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: approval_matrix_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.approval_matrix_rules (
    rule_id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text,
    action_code text,
    required_authority_code text,
    min_approvals integer DEFAULT 1,
    value_threshold numeric,
    description text,
    is_active boolean DEFAULT true,
    created_by text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: assets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.assets (
    asset_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    type text,
    category text,
    status text DEFAULT 'active'::text,
    owner_id text,
    classification text,
    location text,
    value numeric,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    asset_type character varying(100),
    criticality character varying(20) DEFAULT 'medium'::character varying,
    department_id uuid,
    owner_user_id character varying(64),
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: audit_findings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_findings (
    finding_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    severity text DEFAULT 'medium'::text,
    status text DEFAULT 'open'::text,
    control_id uuid,
    assigned_to text,
    due_date timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: platform_audit_logs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_audit_logs (
    id integer NOT NULL,
    tenant_id character varying(16),
    user_id character varying(64),
    action character varying(100),
    resource_type character varying(50),
    resource_id character varying(64),
    details jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_log; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.audit_log AS
 SELECT id,
    tenant_id,
    user_id,
    action,
    resource_type,
    resource_id,
    details,
    created_at
   FROM dos.platform_audit_logs;


--
-- Name: audit_log_archive; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_log_archive (
    entry_id uuid NOT NULL,
    tenant_id text NOT NULL,
    actor_id text,
    action text NOT NULL,
    module text,
    entity_type text,
    entity_id text,
    before_state jsonb,
    after_state jsonb,
    ip_address text,
    created_at timestamp with time zone,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_logs (
    log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    actor_id text,
    actor_email text,
    before_state jsonb,
    after_state jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_plans; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_plans (
    plan_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    audit_type text,
    scope text,
    frequency text,
    year integer,
    status text DEFAULT 'planning'::text,
    owner_id text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_signoff_ledger; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_signoff_ledger (
    bundle_id bigint NOT NULL,
    tenant_id character varying(64) NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    generated_by character varying(128) NOT NULL,
    bundle_hash character varying(96) NOT NULL,
    bundle_path text,
    section_counts jsonb DEFAULT '{}'::jsonb NOT NULL,
    signed_by character varying(128),
    signed_at timestamp with time zone,
    signature_hash character varying(96),
    notes text
);


--
-- Name: TABLE audit_signoff_ledger; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.audit_signoff_ledger IS 'Append-only ledger of audit-shelf bundle exports and counter-signatures.
Every row is one regulator-handover deliverable.';


--
-- Name: audit_signoff_ledger_bundle_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.audit_signoff_ledger_bundle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_signoff_ledger_bundle_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.audit_signoff_ledger_bundle_id_seq OWNED BY dos.audit_signoff_ledger.bundle_id;


--
-- Name: audit_trail; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_trail (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    actor_id character varying(64),
    action text NOT NULL,
    entity_type text,
    entity_id character varying(64),
    module text,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.audit_trail FORCE ROW LEVEL SECURITY;


--
-- Name: auth_mfa_otp; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.auth_mfa_otp (
    otp_id character varying(48) NOT NULL,
    user_sub character varying(255) NOT NULL,
    email character varying(320) NOT NULL,
    code_hash character varying(128) NOT NULL,
    channel character varying(16) DEFAULT 'email'::character varying NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    ip character varying(64),
    user_agent character varying(512),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: bcp_plans; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.bcp_plans (
    plan_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'draft'::text,
    priority text DEFAULT 'medium'::text,
    owner_id text,
    last_tested timestamp with time zone,
    next_test timestamp with time zone,
    rto_hours integer,
    rpo_hours integer,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: billing_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.billing_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: billing_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.billing_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.billing_event_id_seq OWNED BY dos.billing_event.id;


--
-- Name: billing_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.billing_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT billing_record_kind_check CHECK ((kind = ANY (ARRAY['plan'::text, 'addon'::text, 'one-shot'::text, 'metered'::text]))),
    CONSTRAINT billing_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT billing_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: brand_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.brand_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    domain text NOT NULL,
    brand_color_primary text NOT NULL,
    brand_color_accent text NOT NULL,
    brand_color_background text NOT NULL,
    brand_color_surface text NOT NULL,
    brand_color_text text NOT NULL,
    brand_color_muted text NOT NULL,
    brand_icon text NOT NULL,
    brand_token_prefix text NOT NULL,
    dogan_meaning_en text NOT NULL,
    dogan_meaning_ar text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: briefings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.briefings (
    briefing_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'weekly'::text,
    status text DEFAULT 'draft'::text,
    content jsonb DEFAULT '{}'::jsonb,
    audience jsonb DEFAULT '[]'::jsonb,
    published_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: business_units; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.business_units (
    bu_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    organization_id uuid,
    parent_bu_id uuid,
    bu_type text,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.business_units FORCE ROW LEVEL SECURITY;


--
-- Name: committee_meetings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.committee_meetings (
    meeting_id uuid DEFAULT gen_random_uuid() NOT NULL,
    committee_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title text NOT NULL,
    agenda text,
    scheduled_at timestamp with time zone NOT NULL,
    location text,
    status text DEFAULT 'scheduled'::text NOT NULL,
    minutes text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: committee_members; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.committee_members (
    member_id uuid DEFAULT gen_random_uuid() NOT NULL,
    committee_id uuid NOT NULL,
    user_id character varying(64) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    role_in_committee text DEFAULT 'member'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.committee_members FORCE ROW LEVEL SECURITY;


--
-- Name: committees; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.committees (
    committee_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    committee_type text,
    charter text,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by character varying(64)
);

ALTER TABLE ONLY dos.committees FORCE ROW LEVEL SECURITY;


--
-- Name: compliance_frameworks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.compliance_frameworks (
    framework_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    version text,
    status text DEFAULT 'active'::text,
    description text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: compliance_requirements; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.compliance_requirements (
    requirement_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    framework_id uuid,
    code character varying(100),
    title text NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: component_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.component_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    csn character varying(500) NOT NULL,
    component_key character varying(255) NOT NULL,
    layer character varying(50) DEFAULT 'frontend'::character varying NOT NULL,
    route_path character varying(500),
    sort_order integer DEFAULT 0 NOT NULL,
    i18n_key character varying(255),
    platform_object_id character varying(255),
    module_code character varying(128),
    product_code character varying(128),
    required_permission character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    tenant_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: config_audit_logs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_audit_logs (
    id integer NOT NULL,
    config_key character varying(200),
    tenant_id character varying(16),
    old_value jsonb,
    new_value jsonb,
    changed_by character varying(64),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_audit_logs_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_audit_logs_id_seq OWNED BY dos.config_audit_logs.id;


--
-- Name: config_center_audit_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_center_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    actor_id uuid,
    actor_type character varying(50) DEFAULT 'user'::character varying,
    change_type character varying(20) NOT NULL,
    key character varying(500) NOT NULL,
    scope character varying(20),
    old_value text,
    new_value text,
    source character varying(100),
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_definitions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_definitions (
    id integer NOT NULL,
    config_key character varying(200),
    display_name character varying(255),
    description text,
    data_type character varying(30) DEFAULT 'string'::character varying,
    default_value jsonb,
    module_code character varying(50),
    category character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    is_secret boolean DEFAULT false NOT NULL,
    deployment_only boolean DEFAULT false NOT NULL,
    ui_exposable boolean DEFAULT true NOT NULL,
    label text,
    owner_domain text,
    value_type text,
    allowed_scopes text[] DEFAULT '{platform}'::text[],
    validation_schema jsonb,
    enum_values text[] DEFAULT '{}'::text[],
    is_required boolean DEFAULT false NOT NULL,
    is_overridable boolean DEFAULT true NOT NULL,
    is_lockable boolean DEFAULT true NOT NULL,
    requires_restart boolean DEFAULT false NOT NULL,
    sdk_exposable boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    key text
);


--
-- Name: config_definitions_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_definitions_id_seq OWNED BY dos.config_definitions.id;


--
-- Name: config_locks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_locks (
    id integer NOT NULL,
    config_key character varying(200) NOT NULL,
    tenant_id character varying(16),
    locked_by character varying(64),
    locked_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


--
-- Name: config_locks_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_locks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_locks_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_locks_id_seq OWNED BY dos.config_locks.id;


--
-- Name: config_runtime_overrides; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_runtime_overrides (
    id integer NOT NULL,
    config_key character varying(200) NOT NULL,
    tenant_id character varying(16),
    override_value jsonb,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_runtime_overrides_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_runtime_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_runtime_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_runtime_overrides_id_seq OWNED BY dos.config_runtime_overrides.id;


--
-- Name: config_values; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_values (
    id integer NOT NULL,
    config_key character varying(200) NOT NULL,
    tenant_id character varying(16),
    value jsonb,
    updated_by character varying(64),
    updated_at timestamp with time zone DEFAULT now(),
    definition_id integer,
    scope_type character varying(50) DEFAULT 'platform'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    scope_id text DEFAULT 'platform'::text NOT NULL,
    value_hash text,
    is_encrypted boolean DEFAULT false NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: config_values_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_values_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_values_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_values_id_seq OWNED BY dos.config_values.id;


--
-- Name: controls; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.controls (
    control_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    framework_id uuid,
    control_ref text,
    title text NOT NULL,
    description text,
    status text DEFAULT 'not_implemented'::text,
    owner_id text,
    effectiveness text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: dashboards; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dashboards (
    dashboard_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'custom'::text,
    config jsonb DEFAULT '{}'::jsonb,
    owner_id text,
    is_public boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: data_governance_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.data_governance_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: data_governance_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.data_governance_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_governance_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.data_governance_event_id_seq OWNED BY dos.data_governance_event.id;


--
-- Name: data_governance_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.data_governance_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT data_governance_record_kind_check CHECK ((kind = ANY (ARRAY['classification'::text, 'retention'::text, 'consent'::text, 'dlp'::text, 'dsar'::text]))),
    CONSTRAINT data_governance_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT data_governance_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: delegations; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.delegations AS
 SELECT delegation_id,
    from_user_id AS delegator_id,
    to_user_id AS delegate_id,
    from_user_id,
    to_user_id,
    tenant_id,
    scope,
    valid_from,
    valid_until,
    created_at,
    deleted_at,
    updated_at,
    permissions,
    reason,
    status,
    approved_by,
    approved_at,
    rejected_reason,
    created_by
   FROM platform_dauth.delegations d;


--
-- Name: departments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.departments (
    department_id character varying(64) NOT NULL,
    department_code character varying(100),
    display_name character varying(255),
    tenant_id character varying(64),
    parent_id character varying(64),
    created_at timestamp with time zone DEFAULT now(),
    description text,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    name_en character varying(255),
    name_ar character varying(255),
    code character varying(100),
    bu_id uuid,
    head_user_id character varying(64),
    status character varying(20) DEFAULT 'active'::character varying,
    created_by character varying(64)
);

ALTER TABLE ONLY dos.departments FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.deployment_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deployment_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.deployment_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deployment_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.deployment_event_id_seq OWNED BY dos.deployment_event.id;


--
-- Name: deployment_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.deployment_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT deployment_record_kind_check CHECK ((kind = ANY (ARRAY['blue-green'::text, 'canary'::text, 'rolling'::text, 'recreate'::text]))),
    CONSTRAINT deployment_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT deployment_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: dora_assessments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dora_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'draft'::text,
    pillar text,
    score integer,
    findings jsonb DEFAULT '[]'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: dos_master_actor_session; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_actor_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor text NOT NULL,
    session_jwe text NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    scopes text[] DEFAULT ARRAY[]::text[] NOT NULL
);


--
-- Name: dos_master_change_request; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_change_request (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    summary text,
    requested_by text NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    status text DEFAULT 'open'::text NOT NULL,
    rollout_plan_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT dos_master_change_request_status_check CHECK ((status = ANY (ARRAY['open'::text, 'approved'::text, 'executed'::text, 'rolled_back'::text, 'rejected'::text])))
);


--
-- Name: dos_master_compensation_chain; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_compensation_chain (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    change_request_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    step_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT dos_master_compensation_chain_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'succeeded'::text, 'failed'::text, 'compensated'::text])))
);


--
-- Name: dos_master_drift_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_drift_event (
    id bigint NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    source text NOT NULL,
    drift_kind text NOT NULL,
    resource_key text,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    resolved_at timestamp with time zone,
    resolution_note text
);


--
-- Name: dos_master_drift_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dos_master_drift_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dos_master_drift_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dos_master_drift_event_id_seq OWNED BY dos.dos_master_drift_event.id;


--
-- Name: dos_master_grant; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_grant (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor text NOT NULL,
    role_code text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    granted_by text NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    reason text
);


--
-- Name: TABLE dos_master_grant; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.dos_master_grant IS 'Application-level grants of DOS Master roles to service or operator actors. PG role membership is the DB-level floor; this table is the audit truth.';


--
-- Name: dos_master_invalidation_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_invalidation_log (
    id bigint NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL,
    scope text NOT NULL,
    scope_key text,
    reason text NOT NULL,
    cache_version text NOT NULL,
    fan_out_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT dos_master_invalidation_log_scope_check CHECK ((scope = ANY (ARRAY['tenant'::text, 'role'::text, 'module'::text, 'permission'::text, 'global'::text])))
);


--
-- Name: dos_master_invalidation_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dos_master_invalidation_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dos_master_invalidation_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dos_master_invalidation_log_id_seq OWNED BY dos.dos_master_invalidation_log.id;


--
-- Name: dos_master_lock; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_lock (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    resource_key text NOT NULL,
    held_by text NOT NULL,
    acquired_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    released_at timestamp with time zone
);


--
-- Name: dos_master_publish_handle; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_publish_handle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    channel text DEFAULT 'live'::text NOT NULL,
    revision_id uuid NOT NULL,
    activated_at timestamp with time zone DEFAULT now() NOT NULL,
    activated_by text NOT NULL,
    CONSTRAINT dos_master_publish_handle_channel_check CHECK ((channel = ANY (ARRAY['draft'::text, 'staging'::text, 'live'::text, 'rolled_back'::text])))
);


--
-- Name: dos_master_role; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_role (
    role_code text NOT NULL,
    display_name text NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_master_writer_audit; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_writer_audit (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor text NOT NULL,
    session_role text NOT NULL,
    table_schema text NOT NULL,
    table_name text NOT NULL,
    op text NOT NULL,
    row_pk text,
    old_row jsonb,
    new_row jsonb,
    change_request_id uuid,
    rollout_ring text,
    correlation_id uuid,
    client_addr inet,
    application_name text,
    CONSTRAINT dos_master_writer_audit_op_check CHECK ((op = ANY (ARRAY['INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: TABLE dos_master_writer_audit; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.dos_master_writer_audit IS 'Append-only audit of every accepted write to a DOS Master controlled table. Source of truth for change history; rollups feed the decision ledger and PPD evaluations.';


--
-- Name: dos_master_writer_audit_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dos_master_writer_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dos_master_writer_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dos_master_writer_audit_id_seq OWNED BY dos.dos_master_writer_audit.id;


--
-- Name: dr_drill_runs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dr_drill_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scenario text NOT NULL,
    from_region text NOT NULL,
    to_region text,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text DEFAULT 'in_progress'::text NOT NULL,
    rpo_actual_seconds integer,
    rto_actual_seconds integer,
    rpo_target_seconds integer DEFAULT 3600 NOT NULL,
    rto_target_seconds integer DEFAULT 14400 NOT NULL,
    notes text,
    CONSTRAINT dr_drill_runs_scenario_check CHECK ((scenario = ANY (ARRAY['replica-promote'::text, 'pitr-restore'::text, 'region-failover'::text, 'tenant-restore'::text]))),
    CONSTRAINT dr_drill_runs_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'in_progress'::text, 'passed'::text, 'failed'::text, 'aborted'::text])))
);


--
-- Name: TABLE dr_drill_runs; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.dr_drill_runs IS 'Wave 13: cross-region DR drill records. Quarterly cadence required for production promotion.';


--
-- Name: dr_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dr_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dr_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dr_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dr_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dr_event_id_seq OWNED BY dos.dr_event.id;


--
-- Name: dr_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dr_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT dr_record_kind_check CHECK ((kind = ANY (ARRAY['failover'::text, 'restore'::text, 'rebuild'::text, 'simulate'::text]))),
    CONSTRAINT dr_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT dr_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: dynamic_ui_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    action_id character varying(150) NOT NULL,
    "position" character varying(60),
    label_key character varying(150),
    icon character varying(120),
    permission character varying(150),
    profiles text[],
    risk_level character varying(40),
    requires_approval boolean DEFAULT false NOT NULL,
    workflow_code character varying(150),
    evidence_required boolean DEFAULT false NOT NULL,
    handler_key character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_agent_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_agent_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    agent_id character varying(150) NOT NULL,
    action_id character varying(150) NOT NULL,
    label_key character varying(150),
    permission character varying(150),
    level character varying(40),
    risk_level character varying(40),
    requires_approval boolean DEFAULT true NOT NULL,
    workflow_code character varying(150),
    evidence_required boolean DEFAULT false NOT NULL,
    prompt_template_ref character varying(200),
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_agent_squad_members; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_agent_squad_members (
    squad_id character varying(150) NOT NULL,
    agent_id character varying(150) NOT NULL,
    role_in_squad character varying(60) DEFAULT 'member'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: dynamic_ui_agent_squads; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_agent_squads (
    squad_id character varying(150) NOT NULL,
    module_code character varying(100) NOT NULL,
    name_key character varying(150) NOT NULL,
    orchestrator_agent_id character varying(150),
    max_depth integer DEFAULT 3 NOT NULL,
    prevent_circular_delegation boolean DEFAULT true NOT NULL,
    ledger_required boolean DEFAULT true NOT NULL,
    human_approval_required boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_agents; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_agents (
    agent_id character varying(150) NOT NULL,
    module_code character varying(100),
    name_key character varying(150) NOT NULL,
    description_key character varying(200),
    level character varying(40) DEFAULT 'L1'::character varying NOT NULL,
    scope character varying(60),
    capabilities jsonb DEFAULT '{}'::jsonb NOT NULL,
    allowed_page_types text[],
    allowed_actions text[],
    requires_human_approval boolean DEFAULT true NOT NULL,
    audit_required boolean DEFAULT true NOT NULL,
    default_risk_level character varying(40) DEFAULT 'low'::character varying NOT NULL,
    prompt_template_ref character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_ai_tips; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_ai_tips (
    tenant_id character varying(80) DEFAULT ''::character varying NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) DEFAULT ''::character varying NOT NULL,
    tip_code character varying(120) NOT NULL,
    severity character varying(20) DEFAULT 'info'::character varying NOT NULL,
    title_key character varying(200) NOT NULL,
    body_key character varying(200) NOT NULL,
    cta_label_key character varying(200),
    cta_route character varying(300),
    cta_action_id character varying(120),
    audience_role character varying(80),
    source character varying(40) DEFAULT 'rule'::character varying NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT dynamic_ui_ai_tips_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'success'::character varying, 'warning'::character varying, 'danger'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_ai_tips_source_check CHECK (((source)::text = ANY ((ARRAY['rule'::character varying, 'heuristic'::character varying, 'llm'::character varying, 'agent'::character varying])::text[])))
);


--
-- Name: dynamic_ui_component_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_component_registry (
    component_key text NOT NULL,
    bundle_url text,
    schema_version text DEFAULT '1'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    vendor character varying(40) DEFAULT 'custom'::character varying NOT NULL,
    approval_status character varying(20) DEFAULT 'unapproved'::character varying NOT NULL,
    carbon_key character varying(80),
    approved_at timestamp with time zone,
    renderer_key text,
    component_type text,
    mobile_variant_props jsonb,
    mobile_touch_enabled boolean DEFAULT false,
    mobile_density character varying(20) DEFAULT 'normal'::character varying,
    CONSTRAINT chk_mobile_density_values CHECK (((mobile_density)::text = ANY ((ARRAY['compact'::character varying, 'normal'::character varying, 'comfortable'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_component_registry_approval_status_check CHECK (((approval_status)::text = ANY ((ARRAY['approved'::character varying, 'unapproved'::character varying, 'deprecated'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: dynamic_ui_data_resources; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_data_resources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    resource_key character varying(150) NOT NULL,
    resource_type character varying(40) NOT NULL,
    url_or_query text NOT NULL,
    permission character varying(150),
    cache_ttl_sec integer,
    realtime_topic character varying(200),
    pagination jsonb,
    shape_ref character varying(200),
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_empty_states; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_empty_states (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state_key character varying(150) NOT NULL,
    title_key character varying(300) NOT NULL,
    description_key character varying(300),
    tone character varying(20) DEFAULT 'neutral'::character varying NOT NULL,
    illustration character varying(80),
    primary_label_key character varying(300),
    primary_route character varying(300),
    primary_permission character varying(150),
    secondary_label_key character varying(300),
    secondary_route character varying(300),
    secondary_permission character varying(150),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_empty_states_tone_check CHECK (((tone)::text = ANY ((ARRAY['neutral'::character varying, 'brand'::character varying, 'accent'::character varying, 'success'::character varying, 'warning'::character varying, 'danger'::character varying, 'info'::character varying])::text[])))
);


--
-- Name: dynamic_ui_grid_columns; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_grid_columns (
    tenant_id character varying(80) DEFAULT ''::character varying NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    column_key character varying(120) NOT NULL,
    label_i18n_key character varying(200) NOT NULL,
    data_path character varying(200) NOT NULL,
    data_type character varying(40) NOT NULL,
    formatter_key character varying(120),
    width_px integer,
    align character varying(20) DEFAULT 'start'::character varying NOT NULL,
    sortable boolean DEFAULT true NOT NULL,
    filterable boolean DEFAULT false NOT NULL,
    hidden_default boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT dynamic_ui_grid_columns_align_check CHECK (((align)::text = ANY ((ARRAY['start'::character varying, 'center'::character varying, 'end'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_grid_columns_data_type_check CHECK (((data_type)::text = ANY ((ARRAY['string'::character varying, 'number'::character varying, 'boolean'::character varying, 'date'::character varying, 'datetime'::character varying, 'enum'::character varying, 'badge'::character varying, 'user'::character varying, 'avatar'::character varying, 'json'::character varying])::text[])))
);


--
-- Name: dynamic_ui_health_probes; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_health_probes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    probe_key character varying(150) NOT NULL,
    label_key character varying(300) NOT NULL,
    description_key character varying(300),
    source_endpoint character varying(500),
    source_kind character varying(40) DEFAULT 'http_status'::character varying NOT NULL,
    ok_threshold jsonb DEFAULT '{}'::jsonb NOT NULL,
    required_permission character varying(150) DEFAULT 'tenant_admin'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_health_probes_source_kind_check CHECK (((source_kind)::text = ANY ((ARRAY['http_status'::character varying, 'count'::character varying, 'signal'::character varying, 'derived'::character varying])::text[])))
);


--
-- Name: dynamic_ui_i18n_keys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_i18n_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    key_path text NOT NULL,
    en text NOT NULL,
    ar text,
    notes text
);


--
-- Name: dynamic_ui_intents; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_intents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    intent_key character varying(150) NOT NULL,
    utterance_en text,
    utterance_ar text,
    route character varying(300),
    action_id character varying(150),
    permission character varying(150),
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_kpis; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_kpis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    route character varying(300),
    kpi_key character varying(150) NOT NULL,
    label_key character varying(150),
    unit character varying(40),
    data_resource character varying(150),
    permission character varying(150),
    profiles text[],
    scope character varying(60) DEFAULT 'page'::character varying NOT NULL,
    format character varying(60),
    trend_enabled boolean DEFAULT false NOT NULL,
    threshold jsonb,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_module_icons; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_module_icons (
    module_code text NOT NULL,
    icon text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_module_status; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_module_status (
    tenant_id character varying(64) NOT NULL,
    module_code character varying(100) NOT NULL,
    enrollment_status character varying(40) DEFAULT 'enabled'::character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_modules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_modules (
    module_code character varying(100) NOT NULL,
    platform_key character varying(50),
    product_key character varying(50) NOT NULL,
    display_name character varying(200) NOT NULL,
    default_route character varying(300) NOT NULL,
    registry_status character varying(40) DEFAULT 'active'::character varying NOT NULL,
    default_tenant_enrollment_status character varying(40) DEFAULT 'enabled'::character varying NOT NULL,
    canonical_source character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_navigation; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_navigation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    label character varying(200) NOT NULL,
    route character varying(300) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    parent_id uuid,
    readiness character varying(40),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_navigation_icons; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_navigation_icons (
    module_code text NOT NULL,
    route text NOT NULL,
    icon text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_page_agent; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_page_agent (
    module_code text NOT NULL,
    page_id text NOT NULL,
    agent_id text NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    presentation text DEFAULT 'side-panel'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_page_agents; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_page_agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    agent_id character varying(150) NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    presentation character varying(60),
    profiles text[],
    permission character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_page_archetype; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_page_archetype (
    archetype_id text NOT NULL,
    description_key text NOT NULL,
    default_layout text NOT NULL,
    default_zones jsonb DEFAULT '[]'::jsonb NOT NULL,
    agent_capable boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_page_headers; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_page_headers (
    tenant_id character varying(80) DEFAULT ''::character varying NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    variant character varying(40) DEFAULT 'standard'::character varying NOT NULL,
    eyebrow_key character varying(200),
    title_key character varying(200) NOT NULL,
    subtitle_key character varying(200),
    badge_key character varying(200),
    cta_action_id character varying(120),
    show_breadcrumb boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_page_headers_variant_check CHECK (((variant)::text = ANY ((ARRAY['standard'::character varying, 'hero'::character varying, 'compact'::character varying, 'split'::character varying])::text[])))
);


--
-- Name: dynamic_ui_page_persona; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_page_persona (
    module_code text NOT NULL,
    page_id text NOT NULL,
    persona_id text NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_quick_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_quick_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    surface_key character varying(150) DEFAULT 'workspace.home'::character varying NOT NULL,
    action_key character varying(150) NOT NULL,
    eyebrow_key character varying(300),
    label_key character varying(300) NOT NULL,
    description_key character varying(300),
    icon character varying(80),
    route character varying(300) NOT NULL,
    required_permission character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    variant character varying(20) DEFAULT 'solid'::character varying NOT NULL,
    tone character varying(20) DEFAULT 'neutral'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_quick_actions_tone_check CHECK (((tone)::text = ANY ((ARRAY['neutral'::character varying, 'brand'::character varying, 'accent'::character varying, 'success'::character varying, 'warning'::character varying, 'danger'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_quick_actions_variant_check CHECK (((variant)::text = ANY ((ARRAY['solid'::character varying, 'gradient'::character varying, 'minimal'::character varying])::text[])))
);


--
-- Name: dynamic_ui_route_metadata; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_route_metadata (
    route text NOT NULL,
    render_mode text DEFAULT 'template'::text NOT NULL,
    template_binding_required boolean DEFAULT true NOT NULL,
    notes text,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata_public boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_dynamic_ui_route_metadata_render_mode CHECK ((render_mode = ANY (ARRAY['template'::text, 'shell-only'::text, 'redirect'::text])))
);


--
-- Name: dynamic_ui_route_permissions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_route_permissions (
    route_id uuid NOT NULL,
    permission_key text NOT NULL,
    effect text NOT NULL,
    CONSTRAINT dynamic_ui_route_permissions_effect_check CHECK ((effect = ANY (ARRAY['allow'::text, 'deny'::text])))
);


--
-- Name: dynamic_ui_routes; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_routes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    path_pattern character varying(300) NOT NULL,
    component_key character varying(150) NOT NULL,
    permission_key character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    readiness character varying(40),
    page_type character varying(60),
    layout character varying(60),
    kpi_scope character varying(60),
    user_intent character varying(120),
    audience_profiles text[],
    data_scope_mode character varying(40),
    realtime_channels text[],
    evidence_required boolean,
    signature_widget character varying(120),
    mobile_variant jsonb,
    empty_state_key character varying(120),
    error_state_key character varying(120),
    help_key character varying(120),
    title_key character varying(150),
    subtitle_key character varying(150),
    data_resource_key character varying(150),
    visible_when_perm text[],
    visible_when_profile text[],
    default_view character varying(60),
    audit_enabled boolean,
    realtime_enabled boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    mobile_layout_config jsonb,
    mobile_touch_config jsonb,
    mobile_density_preference character varying(20) DEFAULT 'normal'::character varying,
    mobile_gestures_enabled boolean DEFAULT true,
    CONSTRAINT chk_mobile_density_preference_values CHECK (((mobile_density_preference)::text = ANY ((ARRAY['compact'::character varying, 'normal'::character varying, 'comfortable'::character varying])::text[])))
);


--
-- Name: dynamic_ui_setup_steps; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_setup_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    step_key character varying(150) NOT NULL,
    label_key character varying(300) NOT NULL,
    description_key character varying(300),
    icon character varying(80),
    route character varying(300) NOT NULL,
    required_permission character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    condition_kind character varying(60) DEFAULT 'always_pending'::character varying NOT NULL,
    condition_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_setup_steps_condition_kind_check CHECK (((condition_kind)::text = ANY ((ARRAY['has_user_name'::character varying, 'has_tenant_id'::character varying, 'has_modules'::character varying, 'has_team_members'::character varying, 'custom'::character varying, 'always_pending'::character varying, 'always_done'::character varying])::text[])))
);


--
-- Name: dynamic_ui_shells; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_shells (
    module_code character varying(100) NOT NULL,
    layout_version character varying(40) DEFAULT 'v1'::character varying NOT NULL,
    layout jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_skill_packs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_skill_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pack_code text NOT NULL,
    name_key text NOT NULL,
    vendor text,
    version text NOT NULL,
    module_codes text[] DEFAULT '{}'::text[] NOT NULL,
    capabilities text[] DEFAULT '{}'::text[] NOT NULL,
    manifest_uri text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_tenant_overrides; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_tenant_overrides (
    tenant_id text NOT NULL,
    override_key text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_theme_tokens; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_theme_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100),
    token_key character varying(150) NOT NULL,
    token_value text NOT NULL,
    scope character varying(60) DEFAULT 'global'::character varying NOT NULL,
    route character varying(300),
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_trial_banner_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_trial_banner_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    threshold_days_min integer DEFAULT 0 NOT NULL,
    threshold_days_max integer DEFAULT 365 NOT NULL,
    severity character varying(20) NOT NULL,
    title_key character varying(300) NOT NULL,
    message_key character varying(300) NOT NULL,
    cta_label_key character varying(300),
    cta_route character varying(300),
    dismissible boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dui_trial_banner_threshold_chk CHECK ((threshold_days_min <= threshold_days_max)),
    CONSTRAINT dynamic_ui_trial_banner_rules_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'danger'::character varying])::text[])))
);


--
-- Name: dynamic_ui_user_preferences; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_user_preferences (
    tenant_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) DEFAULT '*'::character varying NOT NULL,
    pref_key character varying(150) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    scope character varying(60) DEFAULT 'user'::character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_widgets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_widgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    widget_key character varying(150) NOT NULL,
    zone character varying(60),
    permission character varying(150),
    profiles text[],
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_signature boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_workflow_agents; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workflow_agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    module_code character varying(100) NOT NULL,
    workflow_code character varying(150) NOT NULL,
    step_code character varying(150) NOT NULL,
    agent_id character varying(150) NOT NULL,
    agent_action_id character varying(150),
    blocking boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dynamic_ui_workspace_ai_tips; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workspace_ai_tips (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    tip_key character varying(150) NOT NULL,
    title_key character varying(300) NOT NULL,
    body_key character varying(300) NOT NULL,
    cta_label_key character varying(300),
    cta_route character varying(300),
    icon character varying(80),
    condition_kind character varying(60) DEFAULT 'always'::character varying NOT NULL,
    condition_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    required_permission character varying(150),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_workspace_ai_tips_condition_kind_check CHECK (((condition_kind)::text = ANY ((ARRAY['always'::character varying, 'setup_below'::character varying, 'setup_above'::character varying, 'has_modules'::character varying, 'no_modules'::character varying, 'tenant_admin'::character varying, 'member_count_below'::character varying, 'trial_active'::character varying, 'trial_expired'::character varying, 'custom'::character varying])::text[])))
);


--
-- Name: dynamic_ui_workspace_grid_columns; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workspace_grid_columns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    scope character varying(150) NOT NULL,
    col_key character varying(80) NOT NULL,
    label_key character varying(300) NOT NULL,
    data_field character varying(150) NOT NULL,
    data_kind character varying(40) DEFAULT 'text'::character varying NOT NULL,
    format_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_sortable boolean DEFAULT true NOT NULL,
    is_filterable boolean DEFAULT false NOT NULL,
    default_sort character varying(10),
    sort_priority integer,
    width_hint character varying(40),
    align character varying(20) DEFAULT 'start'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_workspace_grid_columns_align_check CHECK (((align)::text = ANY ((ARRAY['start'::character varying, 'center'::character varying, 'end'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_workspace_grid_columns_data_kind_check CHECK (((data_kind)::text = ANY ((ARRAY['text'::character varying, 'number'::character varying, 'date'::character varying, 'status_pill'::character varying, 'badge'::character varying, 'link'::character varying, 'icon'::character varying, 'code'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_workspace_grid_columns_default_sort_check CHECK (((default_sort)::text = ANY ((ARRAY['asc'::character varying, 'desc'::character varying])::text[])))
);


--
-- Name: dynamic_ui_workspace_page_headers; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workspace_page_headers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    route_key character varying(300) NOT NULL,
    variant character varying(40) DEFAULT 'signature'::character varying NOT NULL,
    density character varying(20) DEFAULT 'comfortable'::character varying NOT NULL,
    eyebrow_key character varying(300),
    title_key character varying(300) NOT NULL,
    subtitle_key character varying(300),
    gradient_token character varying(120) DEFAULT '--dos-gradient-brand-soft'::character varying NOT NULL,
    mesh_layers jsonb DEFAULT '[]'::jsonb NOT NULL,
    hairline_visible boolean DEFAULT true NOT NULL,
    hairline_token character varying(120) DEFAULT '--dos-gradient-kpi-line'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_workspace_page_headers_density_check CHECK (((density)::text = ANY ((ARRAY['compact'::character varying, 'comfortable'::character varying, 'spacious'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_workspace_page_headers_variant_check CHECK (((variant)::text = ANY ((ARRAY['standard'::character varying, 'hero'::character varying, 'compact'::character varying, 'split'::character varying, 'signature'::character varying])::text[])))
);


--
-- Name: event_dead_letter_queue; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.event_dead_letter_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message text,
    service text DEFAULT 'onboarding-service'::text NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'failed'::text NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT event_dead_letter_queue_status_check CHECK ((status = ANY (ARRAY['failed'::text, 'retrying'::text, 'resolved'::text, 'expired'::text])))
);


--
-- Name: evidence; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.evidence (
    evidence_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text,
    control_id uuid,
    status text DEFAULT 'pending'::text,
    file_path text,
    file_size bigint,
    uploaded_by text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: evidences; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.evidences (
    evidence_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    control_id uuid,
    file_url text,
    file_type character varying(50),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    collected_by character varying(64),
    reviewed_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: executive_briefings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.executive_briefings (
    briefing_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    content text,
    briefing_type character varying(50) DEFAULT 'weekly'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    target_audience text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: feature_flag_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.feature_flag_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: feature_flag_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.feature_flag_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_flag_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.feature_flag_event_id_seq OWNED BY dos.feature_flag_event.id;


--
-- Name: feature_flag_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.feature_flag_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT feature_flag_record_kind_check CHECK ((kind = ANY (ARRAY['boolean'::text, 'percentage'::text, 'cohort'::text, 'kill-switch'::text]))),
    CONSTRAINT feature_flag_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT feature_flag_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: feature_flags; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.feature_flags (
    flag_code character varying(100) NOT NULL,
    display_name character varying(255),
    enabled boolean DEFAULT false,
    module_code character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    name_en text,
    name_ar text,
    default_value boolean,
    owner_layer text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_authority_kinds; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_authority_kinds (
    authority_kind text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    is_monetary boolean DEFAULT false NOT NULL,
    default_unit text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_cat_audit_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_audit_actions (
    action_code text NOT NULL,
    category text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    default_severity text NOT NULL,
    evidence_required boolean DEFAULT false NOT NULL,
    CONSTRAINT foundation_cat_audit_actions_category_check CHECK ((category = ANY (ARRAY['crud'::text, 'access'::text, 'workflow'::text, 'security'::text, 'admin'::text]))),
    CONSTRAINT foundation_cat_audit_actions_default_severity_check CHECK ((default_severity = ANY (ARRAY['info'::text, 'low'::text, 'medium'::text, 'high'::text, 'critical'::text])))
);


--
-- Name: foundation_cat_bu_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_bu_templates (
    template_code text NOT NULL,
    sector_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    bu_type text NOT NULL,
    parent_template text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT foundation_cat_bu_templates_bu_type_check CHECK ((bu_type = ANY (ARRAY['line_of_business'::text, 'support'::text, 'control'::text, 'shared_service'::text, 'regulatory_reporting'::text])))
);


--
-- Name: foundation_cat_calendar_systems; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_calendar_systems (
    calendar_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    is_default_in_regions text[]
);


--
-- Name: foundation_cat_coi_categories; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_coi_categories (
    category_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    evidence_required boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_committee_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_committee_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_code text NOT NULL,
    sector_code text,
    name_en text NOT NULL,
    name_ar text,
    charter_en text,
    charter_ar text,
    member_roles text[],
    quorum_pct numeric(5,2) DEFAULT 50.0 NOT NULL,
    meeting_cadence text,
    term_months integer,
    is_mandatory boolean DEFAULT false NOT NULL,
    required_by_frameworks text[],
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_data_classifications; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_data_classifications (
    level_code text NOT NULL,
    level_order integer NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    default_color text,
    encryption_required boolean DEFAULT false CONSTRAINT foundation_cat_data_classification_encryption_required_not_null NOT NULL,
    audit_required boolean DEFAULT false NOT NULL
);


--
-- Name: foundation_cat_dept_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_dept_templates (
    template_code text NOT NULL,
    sector_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    dept_function text NOT NULL,
    bu_template text,
    is_mandatory boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_lawful_bases; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_lawful_bases (
    basis_code text NOT NULL,
    framework text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    requires_consent boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT foundation_cat_lawful_bases_framework_check CHECK ((framework = ANY (ARRAY['PDPL'::text, 'GDPR'::text, 'Both'::text])))
);


--
-- Name: foundation_cat_location_types; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_location_types (
    type_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    applicable_sectors text[],
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_org_types; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_org_types (
    org_type_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    levels integer NOT NULL,
    sample_structure jsonb DEFAULT '[]'::jsonb NOT NULL,
    applicable_sectors text[],
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_ownership_domains; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_ownership_domains (
    domain_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    source_module text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_position_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_position_templates (
    template_code text NOT NULL,
    sector_code text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    grade_code text NOT NULL,
    grade_order integer NOT NULL,
    dept_function text,
    is_executive boolean DEFAULT false NOT NULL,
    required_skills text[],
    reports_to_grade text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_profile_types; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_profile_types (
    profile_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    default_perm_pack text,
    has_lifecycle boolean DEFAULT true NOT NULL,
    has_probation boolean DEFAULT false NOT NULL,
    requires_nda boolean DEFAULT false NOT NULL,
    requires_coi boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_readiness_dimensions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_readiness_dimensions (
    dimension_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    weight numeric(5,2) DEFAULT 1.0 NOT NULL,
    query_ref text,
    threshold_warn numeric(5,2) DEFAULT 70.0 NOT NULL,
    threshold_crit numeric(5,2) DEFAULT 50.0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_reference; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_reference (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    parent_code text,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_role_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_role_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_code text NOT NULL,
    sector_code text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    permissions text[],
    applies_to_profiles text[],
    is_platform_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_tenant_defaults; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_tenant_defaults (
    region_code text NOT NULL,
    sector_code text,
    default_locale text NOT NULL,
    timezone text NOT NULL,
    currency text NOT NULL,
    fiscal_year_end_month integer NOT NULL,
    calendar_systems text[] NOT NULL,
    date_format text NOT NULL,
    regulators text[] NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: foundation_coi_declarations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_coi_declarations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    declaration_period text NOT NULL,
    has_conflicts boolean NOT NULL,
    disclosures jsonb DEFAULT '[]'::jsonb NOT NULL,
    declared_at timestamp with time zone DEFAULT now() NOT NULL,
    evidence_ref text,
    reviewed_at timestamp with time zone,
    reviewed_by text,
    review_decision text,
    review_note text,
    CONSTRAINT foundation_coi_declarations_review_decision_check CHECK ((review_decision = ANY (ARRAY['cleared'::text, 'mitigation_required'::text, 'blocked'::text])))
);

ALTER TABLE ONLY dos.foundation_coi_declarations FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_employee_lifecycle_state; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_state (
    user_id text NOT NULL,
    tenant_id text NOT NULL,
    state text NOT NULL,
    state_since timestamp with time zone DEFAULT now() NOT NULL,
    state_due_by timestamp with time zone,
    state_owner text,
    state_meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    workflow_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_employee_lifecycle_state_state_check CHECK ((state = ANY (ARRAY['candidate'::text, 'hired'::text, 'onboarding'::text, 'active'::text, 'probation'::text, 'confirmed'::text, 'on_leave'::text, 'under_review'::text, 'pip'::text, 'transfer_pending'::text, 'promoted'::text, 'exiting'::text, 'alumni'::text])))
);

ALTER TABLE ONLY dos.foundation_employee_lifecycle_state FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_employee_lifecycle_tasks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    workflow_code text NOT NULL,
    workflow_id uuid,
    step_code text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    assigned_to text,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    completed_by text,
    status text DEFAULT 'open'::text NOT NULL,
    blocked_reason text,
    evidence_refs text[],
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_employee_lifecycle_tasks_status_check CHECK ((status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text, 'skipped'::text])))
);

ALTER TABLE ONLY dos.foundation_employee_lifecycle_tasks FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_employee_lifecycle_transitions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_transitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    from_state text,
    to_state text NOT NULL,
    workflow_code text,
    workflow_id uuid,
    approved_by text[],
    evidence_refs text[],
    reason text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_id text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL
);

ALTER TABLE ONLY dos.foundation_employee_lifecycle_transitions FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_employee_lifecycle_workflows; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_workflows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_code text NOT NULL,
    tenant_id text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    trigger_state text NOT NULL,
    steps jsonb NOT NULL,
    sla_hours integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.foundation_employee_lifecycle_workflows FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_policy_acknowledgments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_policy_acknowledgments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    policy_id text NOT NULL,
    policy_version text NOT NULL,
    required boolean DEFAULT true NOT NULL,
    due_at timestamp with time zone,
    acknowledged_at timestamp with time zone,
    evidence_ref text,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.foundation_policy_acknowledgments FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_position_authority; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_position_authority (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    position_id text NOT NULL,
    authority_kind text NOT NULL,
    monetary_limit numeric(18,2),
    monetary_unit text,
    qualifications text[],
    conditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    effective_from date,
    effective_to date,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text
);

ALTER TABLE ONLY dos.foundation_position_authority FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_sod_exception; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_exception (
    exception_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    rule_code text NOT NULL,
    user_id text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    business_reason text NOT NULL,
    compensating_control text,
    status text DEFAULT 'pending'::text NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    rejected_reason text,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_sod_exception_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'expired'::text, 'revoked'::text])))
);

ALTER TABLE ONLY dos.foundation_sod_exception FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_sod_review_attestation; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_review_attestation (
    attestation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    cycle_id uuid NOT NULL,
    rule_code text NOT NULL,
    user_id text NOT NULL,
    reviewer_id text,
    decision text DEFAULT 'pending'::text NOT NULL,
    rationale text,
    evidence_uri text,
    decided_at timestamp with time zone,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_sod_review_attestation_decision_check CHECK ((decision = ANY (ARRAY['pending'::text, 'accept_risk'::text, 'remediate'::text, 'revoke'::text, 'escalate'::text, 'no_change'::text])))
);

ALTER TABLE ONLY dos.foundation_sod_review_attestation FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_sod_review_cycle; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_review_cycle (
    cycle_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    cycle_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    cadence text DEFAULT 'quarterly'::text NOT NULL,
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    due_at timestamp with time zone NOT NULL,
    closed_at timestamp with time zone,
    status text DEFAULT 'open'::text NOT NULL,
    scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_sod_review_cycle_cadence_check CHECK ((cadence = ANY (ARRAY['monthly'::text, 'quarterly'::text, 'annual'::text, 'adhoc'::text]))),
    CONSTRAINT foundation_sod_review_cycle_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'open'::text, 'in_review'::text, 'closed'::text, 'cancelled'::text])))
);

ALTER TABLE ONLY dos.foundation_sod_review_cycle FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_sod_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_rules (
    rule_code text NOT NULL,
    tenant_id text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    rule_kind text NOT NULL,
    parameters jsonb NOT NULL,
    severity text NOT NULL,
    is_enforcing boolean DEFAULT true NOT NULL,
    remediation_hint_en text,
    remediation_hint_ar text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    CONSTRAINT foundation_sod_rules_rule_kind_check CHECK ((rule_kind = ANY (ARRAY['mutually_exclusive_roles'::text, 'blocked_role_pair'::text, 'blocked_authority_pair'::text, 'time_separation'::text, 'approval_self_block'::text, 'committee_self_block'::text]))),
    CONSTRAINT foundation_sod_rules_severity_check CHECK ((severity = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))
);

ALTER TABLE ONLY dos.foundation_sod_rules FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_sod_violations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_violations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    rule_code text NOT NULL,
    user_id text NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    severity text,
    resolution text DEFAULT 'open'::text NOT NULL,
    resolution_note text,
    resolved_at timestamp with time zone,
    resolved_by text,
    CONSTRAINT foundation_sod_violations_resolution_check CHECK ((resolution = ANY (ARRAY['open'::text, 'accepted_risk'::text, 'remediated'::text, 'false_positive'::text, 'expired'::text])))
);

ALTER TABLE ONLY dos.foundation_sod_violations FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_training_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_training_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    course_code text NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    assigned_by text,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    score numeric(5,2),
    pass_threshold numeric(5,2),
    status text DEFAULT 'assigned'::text NOT NULL,
    evidence_ref text,
    reason_assigned text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_training_assignments_status_check CHECK ((status = ANY (ARRAY['assigned'::text, 'in_progress'::text, 'completed'::text, 'failed'::text, 'overdue'::text, 'exempted'::text])))
);

ALTER TABLE ONLY dos.foundation_training_assignments FORCE ROW LEVEL SECURITY;


--
-- Name: foundation_training_courses; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_training_courses (
    course_code text NOT NULL,
    tenant_id text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    category text,
    duration_minutes integer,
    provider text,
    is_mandatory boolean DEFAULT false NOT NULL,
    renewal_months integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.foundation_training_courses FORCE ROW LEVEL SECURITY;


--
-- Name: functional_roles; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.functional_roles AS
 SELECT role_id,
    role_code,
    display_name,
    description,
    permissions,
    created_at
   FROM platform_dauth.functional_roles;


--
-- Name: governance_decisions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.governance_decisions (
    decision_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title text NOT NULL,
    summary text,
    decision_type text DEFAULT 'board'::text NOT NULL,
    status text DEFAULT 'recorded'::text NOT NULL,
    committee_id uuid,
    decided_at timestamp with time zone DEFAULT now() NOT NULL,
    decided_by character varying(64),
    rationale text,
    linked_entity_type text,
    linked_entity_id character varying(64),
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: governance_policies; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.governance_policies (
    policy_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    code text,
    category text,
    scope text,
    description text,
    effective_date date,
    review_date date,
    status text DEFAULT 'draft'::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    approved_by text,
    approved_at timestamp with time zone
);


--
-- Name: i18n_fallback_values; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.i18n_fallback_values (
    id bigint NOT NULL,
    i18n_key character varying(255) NOT NULL,
    fallback_value_en text NOT NULL,
    fallback_value_ar text,
    tenant_id character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE i18n_fallback_values; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.i18n_fallback_values IS 'I18n fallback values with tenant-specific overrides. NULL tenant_id = global default. Eliminates hardcoded i18n maps.';


--
-- Name: COLUMN i18n_fallback_values.fallback_value_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.i18n_fallback_values.fallback_value_en IS 'English fallback value';


--
-- Name: COLUMN i18n_fallback_values.fallback_value_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.i18n_fallback_values.fallback_value_ar IS 'Arabic fallback value (optional)';


--
-- Name: COLUMN i18n_fallback_values.tenant_id; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.i18n_fallback_values.tenant_id IS 'NULL = global default, specific value = tenant override';


--
-- Name: i18n_fallback_values_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.i18n_fallback_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: i18n_fallback_values_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.i18n_fallback_values_id_seq OWNED BY dos.i18n_fallback_values.id;


--
-- Name: inbox_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.inbox_items (
    item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    type text DEFAULT 'notification'::text NOT NULL,
    title text NOT NULL,
    body text,
    source text,
    entity_type text,
    entity_id text,
    read boolean DEFAULT false,
    actioned boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: incidents; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.incidents (
    incident_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    severity character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    risk_id uuid,
    reported_by character varying(64),
    assigned_to character varying(64),
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: integration_connector_catalog; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integration_connector_catalog (
    connector_key text NOT NULL,
    vendor text NOT NULL,
    display_name text NOT NULL,
    description text,
    category text NOT NULL,
    icon_ref text,
    auth_kinds text[] DEFAULT '{}'::text[] NOT NULL,
    capability_keys text[] DEFAULT '{}'::text[] NOT NULL,
    evidence_kinds text[] DEFAULT '{}'::text[] NOT NULL,
    doc_url text,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_integration_connector_category CHECK ((category = ANY (ARRAY['productivity'::text, 'identity'::text, 'collaboration'::text, 'storage'::text, 'calendar'::text, 'crm'::text, 'service_desk'::text, 'project_tracking'::text, 'soar'::text, 'siem'::text, 'grc'::text, 'custom'::text]))),
    CONSTRAINT chk_integration_connector_vendor CHECK ((vendor <> ''::text))
);


--
-- Name: integration_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integration_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: integration_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.integration_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: integration_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.integration_event_id_seq OWNED BY dos.integration_event.id;


--
-- Name: integration_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integration_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT integration_record_kind_check CHECK ((kind = ANY (ARRAY['inbound'::text, 'outbound'::text, 'bidirectional'::text, 'webhook'::text]))),
    CONSTRAINT integration_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT integration_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: integrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integrations (
    integration_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    provider text,
    status text DEFAULT 'inactive'::text,
    config jsonb DEFAULT '{}'::jsonb,
    credentials jsonb DEFAULT '{}'::jsonb,
    last_sync_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: invitations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.invitations (
    invitation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    email text NOT NULL,
    display_name text,
    role text,
    department_id character varying(64),
    status text DEFAULT 'pending'::text NOT NULL,
    batch_id uuid,
    invited_by character varying(64),
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    accepted_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL
);

ALTER TABLE ONLY dos.invitations FORCE ROW LEVEL SECURITY;


--
-- Name: job_executions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.job_executions (
    execution_id character varying(64) NOT NULL,
    job_id character varying(64) NOT NULL,
    tenant_id character varying(16),
    status character varying(20) DEFAULT 'running'::character varying,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    result jsonb,
    error text,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: job_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.job_registry (
    job_id character varying(64) NOT NULL,
    job_code character varying(100) NOT NULL,
    module_code character varying(50),
    schedule character varying(100),
    handler character varying(255),
    config jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    description text,
    last_run_at timestamp with time zone,
    last_status text,
    last_error text,
    next_run_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lifecycle_auth_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.lifecycle_auth_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text,
    user_id text,
    entity_type text,
    entity_id text,
    action text,
    decision text,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: location_bu_map; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.location_bu_map (
    location_id uuid NOT NULL,
    bu_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.location_bu_map FORCE ROW LEVEL SECURITY;


--
-- Name: locations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.locations (
    location_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    location_type text,
    country text,
    city text,
    address text,
    parent_location_id uuid,
    latitude numeric(10,7),
    longitude numeric(10,7),
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.locations FORCE ROW LEVEL SECURITY;


--
-- Name: login_attempts; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.login_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255),
    user_id uuid,
    tenant_id text,
    ip_address character varying(45),
    user_agent text,
    success boolean DEFAULT false,
    failure_reason text,
    attempted_at timestamp with time zone DEFAULT now()
);


--
-- Name: marketing_assets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_assets (
    asset_key text NOT NULL,
    brand_code text NOT NULL,
    locale text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    asset_type text NOT NULL,
    file_url text NOT NULL,
    thumbnail_url text,
    is_gated boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    approval_status text DEFAULT 'approved'::text NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT marketing_assets_approval_chk CHECK ((approval_status = ANY (ARRAY['draft'::text, 'approved'::text, 'retired'::text]))),
    CONSTRAINT marketing_assets_brand_chk CHECK ((brand_code = ANY (ARRAY['shahin-ai'::text, 'dogan-ai-os'::text]))),
    CONSTRAINT marketing_assets_locale_chk CHECK ((locale = ANY (ARRAY['en'::text, 'ar'::text]))),
    CONSTRAINT marketing_assets_type_chk CHECK ((asset_type = ANY (ARRAY['pdf'::text, 'xlsx'::text, 'pptx'::text, 'zip'::text, 'diagram'::text, 'video'::text, 'png'::text, 'svg'::text])))
);


--
-- Name: TABLE marketing_assets; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_assets IS 'M1.5 — registry of downloadable marketing kits. Public read.';


--
-- Name: marketing_brand_assets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_brand_assets (
    id bigint NOT NULL,
    brand_code text NOT NULL,
    asset_kind text NOT NULL,
    theme text DEFAULT 'light'::text NOT NULL,
    locale text,
    direction text,
    source_kind text NOT NULL,
    svg text,
    url text,
    mime text,
    width integer NOT NULL,
    height integer NOT NULL,
    alt_en text NOT NULL,
    alt_ar text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    asset_code text,
    CONSTRAINT marketing_brand_assets_brand_chk CHECK ((brand_code = ANY (ARRAY['shahin-ai'::text, 'dogan-ai-os'::text]))),
    CONSTRAINT marketing_brand_assets_dims_chk CHECK (((width > 0) AND (height > 0))),
    CONSTRAINT marketing_brand_assets_dir_chk CHECK (((direction IS NULL) OR (direction = ANY (ARRAY['ltr'::text, 'rtl'::text])))),
    CONSTRAINT marketing_brand_assets_kind_chk CHECK ((asset_kind = ANY (ARRAY['logo-eagle'::text, 'logo-wordmark'::text, 'logo-lockup'::text, 'favicon'::text, 'og-image'::text, 'hero-bg'::text, 'agent-tile'::text]))),
    CONSTRAINT marketing_brand_assets_locale_chk CHECK (((locale IS NULL) OR (locale = ANY (ARRAY['en'::text, 'ar'::text])))),
    CONSTRAINT marketing_brand_assets_payload_chk CHECK ((((source_kind = 'svg'::text) AND (svg IS NOT NULL)) OR ((source_kind = 'url'::text) AND (url IS NOT NULL) AND (mime IS NOT NULL)))),
    CONSTRAINT marketing_brand_assets_source_chk CHECK ((source_kind = ANY (ARRAY['svg'::text, 'url'::text]))),
    CONSTRAINT marketing_brand_assets_theme_chk CHECK ((theme = ANY (ARRAY['light'::text, 'dark'::text, 'mono-light'::text, 'mono-dark'::text])))
);


--
-- Name: TABLE marketing_brand_assets; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_brand_assets IS 'M0 brand DNA — per-brand asset rows resolved by BrandResolverService.';


--
-- Name: marketing_brand_assets_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.marketing_brand_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketing_brand_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.marketing_brand_assets_id_seq OWNED BY dos.marketing_brand_assets.id;


--
-- Name: marketing_brand_tokens; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_brand_tokens (
    brand_code text NOT NULL,
    token_key text NOT NULL,
    token_value text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT marketing_brand_tokens_brand_chk CHECK ((brand_code = ANY (ARRAY['shahin-ai'::text, 'dogan-ai-os'::text]))),
    CONSTRAINT marketing_brand_tokens_key_chk CHECK ((token_key ~~ '--dos-%'::text))
);


--
-- Name: TABLE marketing_brand_tokens; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_brand_tokens IS 'M0 brand DNA — semantic-token overlays per brand. Mirrors brand-overlays.css.';


--
-- Name: marketing_download_events; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_download_events (
    id bigint NOT NULL,
    event_key text NOT NULL,
    asset_key text NOT NULL,
    brand_code text NOT NULL,
    locale text NOT NULL,
    email text,
    company text,
    job_title text,
    country text,
    interest_area text,
    user_agent text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    visitor_name text,
    CONSTRAINT marketing_download_events_event_chk CHECK ((event_key = ANY (ARRAY['marketing.download.opened'::text, 'marketing.download.submitted'::text, 'marketing.download.completed'::text])))
);


--
-- Name: TABLE marketing_download_events; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_download_events IS 'M1.5 — append-only event sink for download CTA telemetry.';


--
-- Name: marketing_download_events_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.marketing_download_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketing_download_events_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.marketing_download_events_id_seq OWNED BY dos.marketing_download_events.id;


--
-- Name: marketing_footer_groups; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_footer_groups (
    id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    title_en text NOT NULL,
    title_ar text NOT NULL,
    title_key text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_footer_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_footer_items (
    id text NOT NULL,
    group_id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    label_key text NOT NULL,
    href text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_home_content; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_home_content (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    brand_code text NOT NULL,
    locale text NOT NULL,
    content jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: marketing_nav_groups; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_nav_groups (
    id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: marketing_nav_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_nav_items (
    id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    label_key text NOT NULL,
    href text NOT NULL,
    variant text DEFAULT 'link'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    hide_for_locales text[],
    carbon_key text DEFAULT 'link'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    nav_group text,
    nav_group_label_en text,
    nav_group_label_ar text,
    CONSTRAINT marketing_nav_items_carbon_key_check CHECK ((carbon_key = ANY (ARRAY['link'::text, 'button'::text, 'header-menu-item'::text]))),
    CONSTRAINT marketing_nav_items_variant_check CHECK ((variant = ANY (ARRAY['link'::text, 'primary'::text, 'secondary'::text, 'ghost'::text])))
);


--
-- Name: marketing_pages; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    title_en text NOT NULL,
    title_ar text NOT NULL,
    content_en text,
    content_ar text,
    last_updated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: marketplace_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketplace_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketplace_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.marketplace_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketplace_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.marketplace_event_id_seq OWNED BY dos.marketplace_event.id;


--
-- Name: marketplace_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketplace_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT marketplace_record_kind_check CHECK ((kind = ANY (ARRAY['app'::text, 'module'::text, 'template'::text, 'dataset'::text]))),
    CONSTRAINT marketplace_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT marketplace_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: maturity_assessments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.maturity_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    framework character varying(100),
    overall_score numeric(5,2),
    status character varying(50) DEFAULT 'in_progress'::character varying NOT NULL,
    dimensions jsonb DEFAULT '{}'::jsonb,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: migration_history; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.migration_history (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    migration_number integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    migration_type character varying(20) NOT NULL,
    executed_at timestamp with time zone DEFAULT now(),
    executed_by character varying(255) NOT NULL,
    git_sha character varying(40),
    checksum character varying(64) NOT NULL,
    duration_ms integer,
    success boolean DEFAULT true,
    error_message text,
    rollback_available boolean DEFAULT false,
    CONSTRAINT migration_history_migration_type_check CHECK (((migration_type)::text = ANY ((ARRAY['up'::character varying, 'down'::character varying])::text[])))
);


--
-- Name: migration_history_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.migration_history_id_seq OWNED BY dos.migration_history.id;


--
-- Name: migration_lock; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.migration_lock (
    service_name character varying(100) NOT NULL,
    locked_at timestamp with time zone DEFAULT now(),
    locked_by character varying(255) NOT NULL,
    lock_expires_at timestamp with time zone,
    CONSTRAINT check_lock_expiry CHECK ((lock_expires_at > locked_at))
);


--
-- Name: migration_status; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.migration_status AS
 SELECT service_name,
    max(
        CASE
            WHEN (((migration_type)::text = 'up'::text) AND (success = true)) THEN migration_number
            ELSE NULL::integer
        END) AS last_up_migration,
    max(
        CASE
            WHEN (((migration_type)::text = 'down'::text) AND (success = true)) THEN migration_number
            ELSE NULL::integer
        END) AS last_down_migration,
    count(
        CASE
            WHEN (success = true) THEN 1
            ELSE NULL::integer
        END) AS successful_migrations,
    count(
        CASE
            WHEN (success = false) THEN 1
            ELSE NULL::integer
        END) AS failed_migrations,
    max(executed_at) AS last_execution,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM dos.migration_lock
              WHERE (((migration_lock.service_name)::text = (mh.service_name)::text) AND (migration_lock.lock_expires_at > now())))) THEN 'locked'::text
            ELSE 'ready'::text
        END AS status
   FROM dos.migration_history mh
  GROUP BY service_name;


--
-- Name: mobile_breakpoint_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.mobile_breakpoint_config (
    tenant_id character varying(64),
    breakpoint_key character varying(50) NOT NULL,
    min_px integer NOT NULL,
    max_px integer NOT NULL,
    default_behavior character varying(100),
    is_active boolean DEFAULT true
);


--
-- Name: mobile_component_variants; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.mobile_component_variants (
    variant_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    component_key character varying(150) NOT NULL,
    variant_name character varying(100) NOT NULL,
    breakpoint character varying(20) NOT NULL,
    props_override jsonb DEFAULT '{}'::jsonb NOT NULL,
    layout_override jsonb,
    is_default boolean DEFAULT false NOT NULL
);


--
-- Name: mobile_sessions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.mobile_sessions (
    session_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    device_id text,
    device_type text,
    os_version text,
    app_version text,
    push_token text,
    status text DEFAULT 'active'::text,
    last_active timestamp with time zone DEFAULT now(),
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: mobile_touch_gestures; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.mobile_touch_gestures (
    gesture_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    gesture_type character varying(50) NOT NULL,
    component_key character varying(150),
    action_config jsonb NOT NULL,
    haptic_feedback boolean DEFAULT false,
    is_active boolean DEFAULT true
);


--
-- Name: module_capability_bindings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_capability_bindings (
    consumer_module text NOT NULL,
    capability_key text NOT NULL,
    semver_range text DEFAULT '*'::text NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: module_capability_flags; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_capability_flags (
    module_code character varying(100) NOT NULL,
    capability_key character varying(120) NOT NULL,
    capability_value text DEFAULT 'true'::text NOT NULL
);


--
-- Name: module_contract_errors; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_contract_errors (
    id bigint NOT NULL,
    module_code text NOT NULL,
    contract_version text NOT NULL,
    phase text NOT NULL,
    error_type text NOT NULL,
    error_path text,
    message text NOT NULL,
    severity text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT module_contract_errors_phase_check CHECK ((phase = ANY (ARRAY['validate'::text, 'dry-run'::text, 'publish'::text, 'activate'::text, 'verify'::text]))),
    CONSTRAINT module_contract_errors_severity_check CHECK ((severity = ANY (ARRAY['BLOCKER'::text, 'WARNING'::text, 'INFO'::text])))
);


--
-- Name: module_contract_errors_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.module_contract_errors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_contract_errors_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.module_contract_errors_id_seq OWNED BY dos.module_contract_errors.id;


--
-- Name: module_contract_publish_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_contract_publish_log (
    id bigint NOT NULL,
    module_code text NOT NULL,
    contract_version text NOT NULL,
    schema_version integer NOT NULL,
    contract_sha256 text NOT NULL,
    sql_sha256 text NOT NULL,
    rows_emitted jsonb DEFAULT '{}'::jsonb NOT NULL,
    applied_by text DEFAULT 'contract-publisher@v1'::text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    summary text
);


--
-- Name: module_contract_publish_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.module_contract_publish_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_contract_publish_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.module_contract_publish_log_id_seq OWNED BY dos.module_contract_publish_log.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.schema_migrations (
    id integer NOT NULL,
    filename text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_by text DEFAULT CURRENT_USER NOT NULL,
    duration_ms integer
);


--
-- Name: module_migrations; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.module_migrations AS
 SELECT split_part(filename, '/'::text, 2) AS module,
    split_part(filename, '/'::text, 3) AS file,
    checksum AS sha,
    applied_at
   FROM dos.schema_migrations
  WHERE (filename ~~ 'module/%'::text);


--
-- Name: module_pool_slots; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_pool_slots (
    slot_id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    module_version text NOT NULL,
    schema_template text NOT NULL,
    state text DEFAULT 'building'::text NOT NULL,
    built_at timestamp with time zone,
    attached_tenant text,
    attached_at timestamp with time zone,
    build_log jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT module_pool_slots_state_check CHECK ((state = ANY (ARRAY['building'::text, 'hot'::text, 'attached'::text, 'draining'::text, 'failed'::text])))
);


--
-- Name: module_readiness; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_readiness (
    module_code text NOT NULL,
    module_version text NOT NULL,
    verdict text NOT NULL,
    gates jsonb DEFAULT '{}'::jsonb NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    computed_by text DEFAULT 'verifier'::text NOT NULL,
    CONSTRAINT module_readiness_verdict_check CHECK ((verdict = ANY (ARRAY['GOLDEN_READY'::text, 'DRIFT'::text, 'BLOCKED'::text, 'UNKNOWN'::text])))
);


--
-- Name: module_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_registry (
    module_code character varying(50) NOT NULL,
    product_key character varying(50),
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    code text,
    product_code text,
    name_en text,
    name_ar text,
    description text,
    tier text,
    updated_at timestamp with time zone DEFAULT now(),
    sort_order integer DEFAULT 999 NOT NULL
);


--
-- Name: module_sla_defaults; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_sla_defaults (
    id integer NOT NULL,
    module_code character varying(50) NOT NULL,
    sla_type character varying(50),
    threshold_hours integer,
    created_at timestamp with time zone DEFAULT now(),
    description text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: module_sla_defaults_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.module_sla_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_sla_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.module_sla_defaults_id_seq OWNED BY dos.module_sla_defaults.id;


--
-- Name: module_sod_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_sod_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    action_a text NOT NULL,
    action_b text NOT NULL,
    conflict_type text DEFAULT 'hard'::text NOT NULL,
    resolution_strategy text DEFAULT 'escalate'::text NOT NULL,
    description_en text,
    description_ar text,
    severity text DEFAULT 'high'::text,
    delegate_to_role text,
    escalation_roles text[] DEFAULT '{}'::text[],
    deadline_hours integer DEFAULT 48,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    rule_code text,
    role_a text,
    role_b text,
    enabled boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT module_sod_rules_conflict_type_check CHECK ((conflict_type = ANY (ARRAY['hard'::text, 'soft'::text]))),
    CONSTRAINT module_sod_rules_resolution_strategy_check CHECK ((resolution_strategy = ANY (ARRAY['block'::text, 'warn'::text, 'escalate'::text, 'allow'::text])))
);


--
-- Name: ui_route_template_binding; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_template_binding (
    route text NOT NULL,
    archetype text NOT NULL,
    template_export text NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    title_en text,
    title_ar text,
    subtitle_en text,
    subtitle_ar text,
    eyebrow_en text,
    eyebrow_ar text,
    ai_headline_en text,
    ai_headline_ar text,
    status_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    primary_action jsonb,
    CONSTRAINT chk_archetype CHECK ((archetype = ANY (ARRAY['command-home'::text, 'decision-dashboard'::text, 'command-dashboard'::text, 'posture-overview'::text, 'trend-intelligence'::text, 'intelligent-register'::text, 'risk-landscape'::text, 'record-story'::text, 'guided-create'::text, 'action-queue'::text, 'workflow-control'::text, 'workflow-timeline'::text, 'follow-up-center'::text, 'evidence-reports'::text, 'export-center'::text, 'audit-trail'::text, 'audit-trail-ledger'::text, 'audit-trail-evidence'::text, 'calendar-timeline'::text, 'compliance-calendar'::text, 'remediation-roadmap'::text, 'org-chart'::text, 'ownership-map'::text, 'delegation-center'::text, 'ai-advisor'::text, 'agent-flow'::text, 'agent-registry'::text, 'user-agent-workbench'::text, 'module-settings'::text, 'activation-journey'::text, 'incident-response'::text, 'case-finalization'::text, 'marketing-landing'::text, 'auth-page'::text])))
);


--
-- Name: COLUMN ui_route_template_binding.props; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.props IS 'JSONB props bag for marketing page configuration. For platform: {brandCode, eyebrow, title, sub, overview, architecture, features, integrations, ctaLabel, ctaHref}';


--
-- Name: COLUMN ui_route_template_binding.title_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.title_en IS 'Masthead H1 (en) — projected to props.masthead.title';


--
-- Name: COLUMN ui_route_template_binding.title_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.title_ar IS 'Masthead H1 (ar) — projected to props.masthead.title';


--
-- Name: COLUMN ui_route_template_binding.subtitle_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.subtitle_en IS 'Masthead subtitle (en)';


--
-- Name: COLUMN ui_route_template_binding.subtitle_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.subtitle_ar IS 'Masthead subtitle (ar)';


--
-- Name: COLUMN ui_route_template_binding.eyebrow_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.eyebrow_en IS 'Masthead breadcrumb eyebrow (en)';


--
-- Name: COLUMN ui_route_template_binding.eyebrow_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.eyebrow_ar IS 'Masthead breadcrumb eyebrow (ar)';


--
-- Name: COLUMN ui_route_template_binding.ai_headline_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.ai_headline_en IS 'Inline cds-ai-label headline (en)';


--
-- Name: COLUMN ui_route_template_binding.ai_headline_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.ai_headline_ar IS 'Inline cds-ai-label headline (ar)';


--
-- Name: COLUMN ui_route_template_binding.status_tags; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.status_tags IS 'Array of {label,severity} surfacing as cds-tag chips.';


--
-- Name: COLUMN ui_route_template_binding.primary_action; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.primary_action IS '{label, route, permission?} object surfacing as cdsButton.';


--
-- Name: workspace_shell_binding; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_shell_binding (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    component_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    perms_required text[] DEFAULT '{}'::text[] NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_workspace_component_key CHECK ((component_key = ANY (ARRAY['workspace.frame.ui-shell'::text, 'workspace.frame.header'::text, 'workspace.frame.header-name'::text, 'workspace.frame.header-navigation'::text, 'workspace.frame.header-menu'::text, 'workspace.frame.header-menu-item'::text, 'workspace.frame.header-global-bar'::text, 'workspace.frame.header-global-action'::text, 'workspace.frame.side-nav'::text, 'workspace.frame.side-nav-items'::text, 'workspace.frame.side-nav-menu'::text, 'workspace.frame.side-nav-menu-item'::text, 'workspace.frame.side-nav-link'::text, 'workspace.frame.content'::text, 'workspace.nav.grid'::text, 'workspace.nav.column'::text, 'workspace.nav.layer'::text, 'workspace.nav.breadcrumb'::text, 'workspace.nav.tabs'::text, 'workspace.nav.tab'::text, 'workspace.nav.tile'::text, 'workspace.nav.clickable-tile'::text, 'workspace.nav.expandable-tile'::text, 'workspace.nav.tag'::text, 'workspace.data.data-table'::text, 'workspace.data.table-toolbar'::text, 'workspace.data.table-toolbar-search'::text, 'workspace.data.table-toolbar-actions'::text, 'workspace.data.table-batch-actions'::text, 'workspace.data.pagination'::text, 'workspace.data.structured-list'::text, 'workspace.input.search'::text, 'workspace.input.dropdown'::text, 'workspace.input.combo-box'::text, 'workspace.input.multi-select'::text, 'workspace.input.date-picker'::text, 'workspace.input.text-input'::text, 'workspace.input.text-area'::text, 'workspace.input.number-input'::text, 'workspace.input.select'::text, 'workspace.input.checkbox'::text, 'workspace.input.radio'::text, 'workspace.input.toggle'::text, 'workspace.action.button'::text, 'workspace.action.icon-button'::text, 'workspace.action.overflow-menu'::text, 'workspace.action.overflow-menu-option'::text, 'workspace.action.modal'::text, 'workspace.action.inline-notification'::text, 'workspace.action.toast-notification'::text, 'workspace.polish.tooltip'::text, 'workspace.polish.toggletip'::text, 'workspace.polish.popover'::text, 'workspace.polish.progress-bar'::text, 'workspace.polish.inline-loading'::text, 'workspace.polish.skeleton-text'::text, 'workspace.polish.skeleton-placeholder'::text, 'workspace.polish.context-menu'::text, 'workspace.polish.file-uploader'::text, 'workspace.polish.accordion'::text, 'workspace.shell.brand'::text, 'workspace.shell.workspace-title'::text, 'workspace.shell.user-menu'::text, 'workspace.shell.settings-action'::text, 'workspace.shell.sidebar-nav'::text, 'workspace.shell.empty-state'::text, 'workspace.shell.module-cards'::text, 'workspace.shell.global-quick-actions'::text, 'workspace.mobile.button'::text, 'workspace.mobile.input'::text, 'workspace.mobile.dropdown'::text, 'workspace.mobile.data-table'::text, 'workspace.mobile.tabs'::text, 'workspace.mobile.modal'::text, 'workspace.mobile.card'::text])))
);


--
-- Name: COLUMN workspace_shell_binding.props; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.workspace_shell_binding.props IS 'JSONB props bag for component configuration. For workspace.header: {logoHref, brandLabel, homeRoute, ...}';


--
-- Name: mv_workspace_bootstrap; Type: MATERIALIZED VIEW; Schema: dos; Owner: -
--

CREATE MATERIALIZED VIEW dos.mv_workspace_bootstrap AS
 SELECT tenant_id,
    'v1'::text AS ui_catalog_version,
    COALESCE(( SELECT jsonb_agg(jsonb_build_object('route', b.route, 'archetype', b.archetype, 'titleEn', b.title_en, 'titleAr', b.title_ar) ORDER BY b.route) AS jsonb_agg
           FROM dos.ui_route_template_binding b), '[]'::jsonb) AS routes,
    COALESCE(( SELECT jsonb_agg(jsonb_build_object('componentKey', s.component_key, 'enabled', s.enabled, 'position', s."position", 'permsRequired', s.perms_required) ORDER BY s.component_key) AS jsonb_agg
           FROM dos.workspace_shell_binding s
          WHERE (s.tenant_id = t.tenant_id)), '[]'::jsonb) AS shell,
    COALESCE(( SELECT jsonb_agg(DISTINCT jsonb_build_object('componentKey', r.component_key, 'carbonKey', r.carbon_key)) AS jsonb_agg
           FROM dos.dynamic_ui_component_registry r
          WHERE ((r.approval_status)::text = 'approved'::text)), '[]'::jsonb) AS components,
    now() AS refreshed_at
   FROM ( SELECT DISTINCT workspace_shell_binding.tenant_id
           FROM dos.workspace_shell_binding) t
  WITH NO DATA;


--
-- Name: MATERIALIZED VIEW mv_workspace_bootstrap; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON MATERIALIZED VIEW dos.mv_workspace_bootstrap IS 'M4 D1 — backing store for JWE-signed /api/workspace/bootstrap. Refreshed by workspace-bff on permission/module/binding mutations (M5 SSE channel).';


--
-- Name: navigation_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.navigation_registry (
    id integer NOT NULL,
    module_code character varying(50) NOT NULL,
    nav_item_code character varying(100),
    label_en character varying(255),
    label_ar character varying(255),
    icon character varying(50),
    route character varying(255),
    parent_code character varying(100),
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: navigation_registry_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.navigation_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: navigation_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.navigation_registry_id_seq OWNED BY dos.navigation_registry.id;


--
-- Name: notification_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.notification_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.notification_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.notification_event_id_seq OWNED BY dos.notification_event.id;


--
-- Name: notification_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.notification_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT notification_record_kind_check CHECK ((kind = ANY (ARRAY['email'::text, 'sms'::text, 'push'::text, 'webhook'::text, 'in-app'::text]))),
    CONSTRAINT notification_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT notification_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: onboarding_journeys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.onboarding_journeys (
    journey_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    user_id character varying(64) NOT NULL,
    status character varying(50) DEFAULT 'in_progress'::character varying NOT NULL,
    current_step character varying(100),
    completed_steps text[] DEFAULT '{}'::text[],
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: organizations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.organizations (
    organization_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    parent_id uuid,
    org_type text,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.organizations FORCE ROW LEVEL SECURITY;


--
-- Name: orphan_schema_audit; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.orphan_schema_audit (
    id bigint NOT NULL,
    schema_name text NOT NULL,
    table_count integer NOT NULL,
    total_size text NOT NULL,
    data_summary jsonb NOT NULL,
    decision text NOT NULL,
    applied boolean NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    recorded_by text DEFAULT CURRENT_USER NOT NULL
);


--
-- Name: orphan_schema_audit_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.orphan_schema_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orphan_schema_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.orphan_schema_audit_id_seq OWNED BY dos.orphan_schema_audit.id;


--
-- Name: ownership_mappings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ownership_mappings (
    mapping_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying(64) NOT NULL,
    owner_user_id character varying(64) NOT NULL,
    ownership_type text DEFAULT 'primary'::text NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_to timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.ownership_mappings FORCE ROW LEVEL SECURITY;


--
-- Name: permissions; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.permissions AS
 SELECT permission_id,
    permission_code,
    module_code,
    resource_type,
    action_type,
    description,
    created_at
   FROM platform_dauth.permissions;


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_audit_logs_id_seq OWNED BY dos.platform_audit_logs.id;


--
-- Name: platform_drift_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_drift_log (
    id bigint NOT NULL,
    sampled_at timestamp with time zone DEFAULT now() NOT NULL,
    metric_key text NOT NULL,
    value_num numeric,
    value_text text,
    severity text DEFAULT 'info'::text NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT platform_drift_log_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warn'::text, 'critical'::text])))
);


--
-- Name: TABLE platform_drift_log; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.platform_drift_log IS 'Phase 6 runtime drift telemetry. Hourly sampler appends one row per
metric_key. Severity raises to ''critical'' when a CI-guard equivalent
predicate trips at runtime — surfaced to PagerDuty via
scripts/ops/drift-telemetry-sample.mjs';


--
-- Name: platform_drift_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_drift_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_drift_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_drift_log_id_seq OWNED BY dos.platform_drift_log.id;


--
-- Name: platform_migrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_migrations (
    filename text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_ms integer NOT NULL
);


--
-- Name: platform_operation_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_operation_config (
    id integer NOT NULL,
    operation_key character varying(200),
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    description text,
    owner_layer character varying(50) DEFAULT 'DOS'::character varying,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    config_key character varying(200),
    config_value jsonb
);


--
-- Name: platform_operation_config_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_operation_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_operation_config_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_operation_config_id_seq OWNED BY dos.platform_operation_config.id;


--
-- Name: platform_secret; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_secret (
    secret_id bigint NOT NULL,
    secret_key character varying(128) NOT NULL,
    scope character varying(16) DEFAULT 'platform'::character varying NOT NULL,
    tenant_id character varying(64),
    value_ciphertext bytea,
    value_iv bytea,
    value_tag bytea,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(128),
    CONSTRAINT chk_platform_secret_scope CHECK (((scope)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying])::text[]))),
    CONSTRAINT chk_platform_secret_scope_tenant CHECK (((((scope)::text = 'platform'::text) AND (tenant_id IS NULL)) OR (((scope)::text = 'tenant'::text) AND (tenant_id IS NOT NULL))))
);


--
-- Name: platform_secret_definition; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_secret_definition (
    secret_key character varying(128) NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    display_label character varying(160) NOT NULL,
    description text,
    is_sensitive boolean DEFAULT true NOT NULL,
    consumer_service character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_secret_secret_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_secret_secret_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_secret_secret_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_secret_secret_id_seq OWNED BY dos.platform_secret.secret_id;


--
-- Name: platform_session_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_session_policy (
    trust_zone text NOT NULL,
    access_token_ttl_seconds integer NOT NULL,
    refresh_token_ttl_seconds integer NOT NULL,
    pkce_required boolean DEFAULT false NOT NULL,
    cookie_secure boolean DEFAULT true NOT NULL,
    cookie_samesite text DEFAULT 'Lax'::text NOT NULL,
    rate_limit_per_minute integer DEFAULT 600 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    written_by text DEFAULT current_setting('dos.actor'::text, true) NOT NULL,
    CONSTRAINT platform_session_policy_access_token_ttl_seconds_check CHECK ((access_token_ttl_seconds > 0)),
    CONSTRAINT platform_session_policy_cookie_samesite_check CHECK ((cookie_samesite = ANY (ARRAY['Strict'::text, 'Lax'::text, 'None'::text]))),
    CONSTRAINT platform_session_policy_rate_limit_per_minute_check CHECK ((rate_limit_per_minute > 0)),
    CONSTRAINT platform_session_policy_refresh_token_ttl_seconds_check CHECK ((refresh_token_ttl_seconds > 0)),
    CONSTRAINT platform_session_policy_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['admin'::text, 'tenant'::text, 'customer'::text])))
);


--
-- Name: platform_slo; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_slo (
    service_code text NOT NULL,
    availability_target numeric(5,4) NOT NULL,
    latency_p99_ms integer NOT NULL,
    error_budget_seconds_30d integer NOT NULL,
    trust_zone text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    written_by text DEFAULT current_setting('dos.actor'::text, true) NOT NULL,
    CONSTRAINT platform_slo_availability_target_check CHECK (((availability_target > (0)::numeric) AND (availability_target <= (1)::numeric))),
    CONSTRAINT platform_slo_error_budget_seconds_30d_check CHECK ((error_budget_seconds_30d >= 0)),
    CONSTRAINT platform_slo_latency_p99_ms_check CHECK ((latency_p99_ms > 0)),
    CONSTRAINT platform_slo_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['admin'::text, 'tenant'::text, 'customer'::text])))
);


--
-- Name: platform_slo_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_slo_event (
    id bigint NOT NULL,
    service_code text NOT NULL,
    probed_at timestamp with time zone DEFAULT now() NOT NULL,
    ok boolean NOT NULL,
    http_status integer,
    latency_ms integer,
    error_message text,
    emitted_by text DEFAULT current_setting('dos.actor'::text, true) NOT NULL
);


--
-- Name: platform_slo_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_slo_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_slo_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_slo_event_id_seq OWNED BY dos.platform_slo_event.id;


--
-- Name: policies; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.policies (
    policy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    body text,
    version text DEFAULT '1.0'::text,
    status text DEFAULT 'draft'::text,
    category text,
    owner_id text,
    approved_by text,
    approved_at timestamp with time zone,
    effective_date timestamp with time zone,
    review_date timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: portals; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.portals (
    portal_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    name text NOT NULL,
    portal_type character varying(50) DEFAULT 'vendor'::character varying NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    custom_domain character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: position_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.position_assignments (
    assignment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    position_id uuid NOT NULL,
    user_id character varying(64) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    is_primary boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.position_assignments FORCE ROW LEVEL SECURITY;


--
-- Name: positions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.positions (
    position_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    code text,
    bu_id uuid,
    grade text,
    level integer,
    reports_to uuid,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.positions FORCE ROW LEVEL SECURITY;


--
-- Name: privacy_assessments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.privacy_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    assessment_type character varying(50) DEFAULT 'dpia'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    data_categories text[],
    processing_purposes text[],
    risk_level character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: product_licenses; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.product_licenses (
    license_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(50) NOT NULL,
    license_type character varying(50) DEFAULT 'standard'::character varying NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    seats_limit integer,
    valid_from date,
    valid_until date,
    features jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: product_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.product_registry (
    product_key character varying(50) NOT NULL,
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    code text,
    name_en text,
    name_ar text,
    description text,
    version text,
    updated_at timestamp with time zone DEFAULT now(),
    tier text,
    CONSTRAINT product_registry_tier_chk CHECK (((tier IS NULL) OR (tier = ANY (ARRAY['free'::text, 'starter'::text, 'professional'::text, 'enterprise'::text, 'custom'::text]))))
);


--
-- Name: publish_dependency; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_dependency (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_target_id uuid NOT NULL,
    child_target_id uuid NOT NULL,
    dep_kind text NOT NULL,
    CONSTRAINT publish_dependency_check CHECK ((parent_target_id <> child_target_id))
);


--
-- Name: publish_revision; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_revision (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    revision_no bigint NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text NOT NULL,
    change_request_id uuid,
    status text DEFAULT 'draft'::text NOT NULL,
    CONSTRAINT publish_revision_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'staged'::text, 'live'::text, 'rolled_back'::text, 'superseded'::text])))
);


--
-- Name: publish_rollback; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_rollback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    revision_id uuid NOT NULL,
    rolled_back_at timestamp with time zone DEFAULT now() NOT NULL,
    rolled_back_by text NOT NULL,
    reason text NOT NULL
);


--
-- Name: publish_target; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_target (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    display_name text NOT NULL,
    owner_team text,
    notes text
);


--
-- Name: qiyas_journeys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.qiyas_journeys (
    journey_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'assessment'::text,
    status text DEFAULT 'draft'::text,
    score integer,
    config jsonb DEFAULT '{}'::jsonb,
    results jsonb DEFAULT '{}'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: records; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.records (
    record_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    record_type character varying(100) NOT NULL,
    title text NOT NULL,
    content jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    retention_until date,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: release_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.release_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: release_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.release_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: release_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.release_event_id_seq OWNED BY dos.release_event.id;


--
-- Name: release_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.release_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT release_record_kind_check CHECK ((kind = ANY (ARRAY['minor'::text, 'patch'::text, 'major'::text, 'hotfix'::text]))),
    CONSTRAINT release_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT release_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: remediation_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.remediation_actions (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'open'::text,
    priority text DEFAULT 'medium'::text,
    assigned_to text,
    source_type text,
    source_id text,
    due_date timestamp with time zone,
    completed_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: remediations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.remediations (
    remediation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    source_type character varying(50),
    source_id uuid,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    assigned_to character varying(64),
    due_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: report_schedules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.report_schedules (
    schedule_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    report_type text NOT NULL,
    cron text,
    recipients jsonb DEFAULT '[]'::jsonb,
    config jsonb DEFAULT '{}'::jsonb,
    enabled boolean DEFAULT true,
    last_run_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: risks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.risks (
    risk_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    category character varying(100),
    likelihood integer,
    impact integer,
    risk_score integer GENERATED ALWAYS AS ((likelihood * impact)) STORED,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    treatment_plan text,
    owner_user_id character varying(64),
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    CONSTRAINT risks_impact_check CHECK (((impact >= 1) AND (impact <= 5))),
    CONSTRAINT risks_likelihood_check CHECK (((likelihood >= 1) AND (likelihood <= 5)))
);


--
-- Name: role_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    role_code character varying(100) NOT NULL,
    scope_type character varying(50),
    scope_id character varying(64),
    assigned_by character varying(64),
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: role_permissions; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.role_permissions AS
 SELECT role_id,
    permission_id,
    created_at
   FROM platform_dauth.role_permissions;


--
-- Name: role_profile_acceptors; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_profile_acceptors (
    acceptor_id character varying(64) NOT NULL,
    display_name text NOT NULL,
    direction character varying(16) NOT NULL,
    endpoint_url text,
    auth_strategy character varying(32) DEFAULT 'oauth2'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    last_sync_at timestamp with time zone,
    last_status character varying(16),
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT role_profile_acceptors_direction_check CHECK (((direction)::text = ANY ((ARRAY['pull'::character varying, 'push'::character varying, 'two-way'::character varying])::text[])))
);


--
-- Name: TABLE role_profile_acceptors; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.role_profile_acceptors IS 'Registry of stakeholder systems that participate in 2-way role-profile sync.';


--
-- Name: role_profile_sync; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_profile_sync (
    profile_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    role_code character varying(64) NOT NULL,
    scope character varying(32) DEFAULT 'tenant'::character varying NOT NULL,
    permissions text[] DEFAULT ARRAY[]::text[] NOT NULL,
    business_unit_id character varying(64),
    location_id character varying(64),
    lifecycle_state character varying(24) DEFAULT 'active'::character varying NOT NULL,
    external_idp_refs jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_system character varying(64) DEFAULT 'role-profile-service'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT role_profile_sync_lifecycle_state_check CHECK (((lifecycle_state)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'suspended'::character varying, 'offboarding'::character varying, 'terminated'::character varying])::text[])))
);


--
-- Name: TABLE role_profile_sync; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.role_profile_sync IS 'Canonical role-profile substrate. The ONLY legitimate writer to
platform_dauth.user_role_assignments. 2-way sync target for HRIS/SCIM/Okta/AAD
adapters. URA is now a derived projection — see trg_ura_via_role_profile_only.';


--
-- Name: role_profile_sync_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_profile_sync_log (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    acceptor_id character varying(64),
    direction character varying(16) NOT NULL,
    profile_id uuid,
    tenant_id character varying(64),
    user_id character varying(64),
    role_code character varying(64),
    outcome character varying(16) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT role_profile_sync_log_direction_check CHECK (((direction)::text = ANY ((ARRAY['pull'::character varying, 'push'::character varying, 'reconcile'::character varying])::text[]))),
    CONSTRAINT role_profile_sync_log_outcome_check CHECK (((outcome)::text = ANY ((ARRAY['ok'::character varying, 'error'::character varying, 'skipped'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: role_profile_sync_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.role_profile_sync_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_profile_sync_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.role_profile_sync_log_id_seq OWNED BY dos.role_profile_sync_log.id;


--
-- Name: rollout_cohort; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_cohort (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ring_id uuid NOT NULL,
    selector_kind text NOT NULL,
    selector_value text NOT NULL,
    weight integer DEFAULT 100 NOT NULL,
    CONSTRAINT rollout_cohort_selector_kind_check CHECK ((selector_kind = ANY (ARRAY['tenant_id'::text, 'region'::text, 'product'::text, 'edition'::text, 'route_pattern'::text, 'slot'::text, 'archetype'::text, 'tag'::text]))),
    CONSTRAINT rollout_cohort_weight_check CHECK (((weight >= 0) AND (weight <= 100)))
);


--
-- Name: rollout_compensation_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_compensation_step (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    chain_id uuid NOT NULL,
    step_order integer NOT NULL,
    step_kind text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    CONSTRAINT rollout_compensation_step_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: rollout_evaluation; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_evaluation (
    id bigint NOT NULL,
    ring_id uuid NOT NULL,
    evaluated_at timestamp with time zone DEFAULT now() NOT NULL,
    decision text NOT NULL,
    signals jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT rollout_evaluation_decision_check CHECK ((decision = ANY (ARRAY['hold'::text, 'advance'::text, 'rollback'::text])))
);


--
-- Name: rollout_evaluation_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.rollout_evaluation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rollout_evaluation_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.rollout_evaluation_id_seq OWNED BY dos.rollout_evaluation.id;


--
-- Name: rollout_health_gate; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_health_gate (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ring_id uuid NOT NULL,
    gate_kind text NOT NULL,
    threshold numeric NOT NULL,
    comparator text NOT NULL,
    window_sec integer DEFAULT 300 NOT NULL,
    CONSTRAINT rollout_health_gate_comparator_check CHECK ((comparator = ANY (ARRAY['lt'::text, 'lte'::text, 'gt'::text, 'gte'::text, 'eq'::text]))),
    CONSTRAINT rollout_health_gate_gate_kind_check CHECK ((gate_kind = ANY (ARRAY['prom_error_rate'::text, 'jaeger_p95_latency'::text, 'loki_error_volume'::text, 'audit_denial_spike'::text, 'synthetic_pageload'::text])))
);


--
-- Name: rollout_plan; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_plan (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    change_request_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    CONSTRAINT rollout_plan_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'running'::text, 'paused'::text, 'succeeded'::text, 'failed'::text, 'rolled_back'::text])))
);


--
-- Name: rollout_ring; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_ring (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    ring_code text NOT NULL,
    ring_order integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    CONSTRAINT rollout_ring_ring_code_check CHECK ((ring_code = ANY (ARRAY['R0'::text, 'R1'::text, 'R2'::text, 'R3'::text, 'R4'::text, 'R5'::text]))),
    CONSTRAINT rollout_ring_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'succeeded'::text, 'failed'::text, 'rolled_back'::text])))
);


--
-- Name: rollout_rollback; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_rollback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ring_id uuid NOT NULL,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    triggered_by text NOT NULL,
    reason text NOT NULL,
    succeeded_at timestamp with time zone
);


--
-- Name: rollout_signal_threshold; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_signal_threshold (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    signal_kind text NOT NULL,
    default_value numeric NOT NULL,
    unit text NOT NULL,
    notes text
);


--
-- Name: runtime_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.runtime_config (
    config_key character varying(200) NOT NULL,
    config_value jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: runtime_config_history; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.runtime_config_history (
    id integer NOT NULL,
    config_key character varying(200),
    old_value jsonb,
    new_value jsonb,
    changed_by character varying(64),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: runtime_config_history_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.runtime_config_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runtime_config_history_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.runtime_config_history_id_seq OWNED BY dos.runtime_config_history.id;


--
-- Name: schema_authoring_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.schema_authoring_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_authoring_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.schema_authoring_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schema_authoring_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.schema_authoring_event_id_seq OWNED BY dos.schema_authoring_event.id;


--
-- Name: schema_authoring_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.schema_authoring_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT schema_authoring_record_kind_check CHECK ((kind = ANY (ARRAY['typescript'::text, 'sql'::text, 'json-schema'::text, 'protobuf'::text]))),
    CONSTRAINT schema_authoring_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT schema_authoring_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.schema_migrations_id_seq OWNED BY dos.schema_migrations.id;


--
-- Name: security_secret_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.security_secret_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: security_secret_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.security_secret_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_secret_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.security_secret_event_id_seq OWNED BY dos.security_secret_event.id;


--
-- Name: security_secret_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.security_secret_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT security_secret_record_kind_check CHECK ((kind = ANY (ARRAY['static'::text, 'rotating'::text, 'dynamic'::text, 'federated'::text]))),
    CONSTRAINT security_secret_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT security_secret_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: sessions; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.sessions AS
 SELECT session_id,
    user_id,
    tenant_id,
    jti,
    refresh_jti,
    ip_address,
    user_agent,
    created_at,
    last_active_at,
    expires_at,
    revoked_at
   FROM platform_dauth.sessions_legacy;


--
-- Name: shell_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.shell_config (
    config_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    scope_type character varying(20) NOT NULL,
    scope_key character varying(200),
    module_code character varying(100) NOT NULL,
    product_code character varying(100),
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(64),
    CONSTRAINT shell_config_scope_type_check CHECK (((scope_type)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying, 'role'::character varying, 'user'::character varying])::text[])))
);


--
-- Name: sod_conflict_audit; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sod_conflict_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text,
    user_id text,
    module_code text,
    action_a text,
    action_b text,
    conflict_type text,
    resolution_strategy text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sod_rules; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.sod_rules AS
 SELECT rule_id,
    rule_code,
    module_code,
    conflicting_permissions,
    severity,
    description,
    created_at
   FROM platform_dauth.sod_rules;


--
-- Name: sso_identities; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_identities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    protocol text NOT NULL,
    external_id text NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb,
    linked_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sso_providers; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    protocol text NOT NULL,
    status text DEFAULT 'testing'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sso_providers_protocol_check CHECK ((protocol = ANY (ARRAY['saml'::text, 'oidc'::text]))),
    CONSTRAINT sso_providers_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'testing'::text])))
);


--
-- Name: sso_role_mappings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_role_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    idp_group text NOT NULL,
    platform_role text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sso_sessions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_sessions (
    session_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id uuid NOT NULL,
    idp_session_id text,
    protocol text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT sso_sessions_protocol_check CHECK ((protocol = ANY (ARRAY['saml'::text, 'oidc'::text])))
);


--
-- Name: system_events; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.system_events (
    id integer NOT NULL,
    event_type character varying(100) NOT NULL,
    source character varying(100),
    payload jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    occurred_at timestamp with time zone DEFAULT now()
);


--
-- Name: system_events_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.system_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_events_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.system_events_id_seq OWNED BY dos.system_events.id;


--
-- Name: team_members; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.team_members (
    id integer NOT NULL,
    team_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    role character varying(50) DEFAULT 'member'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    team_member_id uuid DEFAULT gen_random_uuid(),
    role_in_team character varying(100),
    is_owner boolean DEFAULT false,
    joined_at timestamp with time zone,
    ended_at timestamp with time zone
);


--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.team_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.team_members_id_seq OWNED BY dos.team_members.id;


--
-- Name: team_raci_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.team_raci_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    team_id uuid NOT NULL,
    user_id text NOT NULL,
    scope_type character varying(100) NOT NULL,
    scope_id uuid,
    raci_role character varying(20) NOT NULL,
    assigned_by text,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT team_raci_assignments_raci_role_check CHECK (((raci_role)::text = ANY ((ARRAY['responsible'::character varying, 'accountable'::character varying, 'consulted'::character varying, 'informed'::character varying])::text[])))
);


--
-- Name: teams; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.teams (
    team_id character varying(64) NOT NULL,
    team_code character varying(100) NOT NULL,
    display_name character varying(255),
    tenant_id character varying(64),
    created_at timestamp with time zone DEFAULT now(),
    description text,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    name character varying(255),
    code character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    created_by character varying(64),
    head_user_id character varying(64),
    department_id character varying(64),
    name_en text,
    name_ar text,
    bu_id uuid,
    team_type text,
    function_code text,
    owner_user_id text,
    metadata_json jsonb
);

ALTER TABLE ONLY dos.teams FORCE ROW LEVEL SECURITY;


--
-- Name: telemetry_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.telemetry_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: telemetry_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.telemetry_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: telemetry_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.telemetry_event_id_seq OWNED BY dos.telemetry_event.id;


--
-- Name: telemetry_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.telemetry_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT telemetry_record_kind_check CHECK ((kind = ANY (ARRAY['sink'::text, 'alert'::text, 'dashboard'::text, 'synthetic'::text]))),
    CONSTRAINT telemetry_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT telemetry_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: tenant_config_versions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_config_versions (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT tenant_config_versions_id_not_null1 NOT NULL,
    tenant_id text CONSTRAINT tenant_config_versions_tenant_id_not_null1 NOT NULL,
    config_key character varying(500) CONSTRAINT tenant_config_versions_config_key_not_null1 NOT NULL,
    config_value jsonb,
    version_number integer DEFAULT 1 NOT NULL,
    is_current boolean DEFAULT true,
    set_by text,
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_config_versions_legacy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_config_versions_legacy (
    id integer CONSTRAINT tenant_config_versions_id_not_null NOT NULL,
    tenant_id character varying(16) CONSTRAINT tenant_config_versions_tenant_id_not_null NOT NULL,
    config_key character varying(200) CONSTRAINT tenant_config_versions_config_key_not_null NOT NULL,
    version integer DEFAULT 1,
    config_value jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_config_versions_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_config_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_config_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_config_versions_id_seq OWNED BY dos.tenant_config_versions_legacy.id;


--
-- Name: tenant_feature_flag_overrides; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_feature_flag_overrides (
    id integer NOT NULL,
    tenant_id character varying(16) NOT NULL,
    flag_code character varying(100) NOT NULL,
    enabled boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_feature_flag_overrides_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_feature_flag_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_feature_flag_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_feature_flag_overrides_id_seq OWNED BY dos.tenant_feature_flag_overrides.id;


--
-- Name: tenant_kms_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_kms_config (
    tenant_id text NOT NULL,
    provider text NOT NULL,
    kek_ref text NOT NULL,
    region text,
    rotation_days integer DEFAULT 365 NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_kms_config_provider_check CHECK ((provider = ANY (ARRAY['aws-kms'::text, 'azure-keyvault'::text, 'gcp-kms'::text, 'hashicorp-vault'::text, 'platform-managed'::text]))),
    CONSTRAINT tenant_kms_config_status_check CHECK ((status = ANY (ARRAY['active'::text, 'rotating'::text, 'disabled'::text, 'crypto-erased'::text])))
);


--
-- Name: TABLE tenant_kms_config; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_kms_config IS 'Wave 11: per-tenant CMEK/BYOK configuration. KEK lives in customer KMS.';


--
-- Name: tenant_kms_keys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_kms_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    kek_ref text NOT NULL,
    algorithm text DEFAULT 'AES-256-GCM'::text NOT NULL,
    wrapped_dek bytea NOT NULL,
    scope text DEFAULT 'compliance'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    rotated_from uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


--
-- Name: TABLE tenant_kms_keys; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_kms_keys IS 'Wave 11: wrapped DEKs per tenant. Plaintext DEKs never persisted.';


--
-- Name: COLUMN tenant_kms_keys.wrapped_dek; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_kms_keys.wrapped_dek IS 'DEK wrapped by KEK in customer KMS. AES-256-GCM (iv || tag || ciphertext).';


--
-- Name: tenant_landing_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_landing_config (
    id bigint NOT NULL,
    tenant_id character varying(255) NOT NULL,
    authenticated_route character varying(255),
    unauthenticated_route character varying(255),
    session_expired_route character varying(255),
    post_auth_route character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE tenant_landing_config; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_landing_config IS 'Tenant-specific landing page configuration for different auth states. Eliminates hardcoded route fallbacks.';


--
-- Name: COLUMN tenant_landing_config.authenticated_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.authenticated_route IS 'Route for authenticated users (e.g., /workspace-home, /admin-hub)';


--
-- Name: COLUMN tenant_landing_config.unauthenticated_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.unauthenticated_route IS 'Route for unauthenticated users (e.g., /)';


--
-- Name: COLUMN tenant_landing_config.session_expired_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.session_expired_route IS 'Route when session expires (e.g., /)';


--
-- Name: COLUMN tenant_landing_config.post_auth_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.post_auth_route IS 'Route after successful authentication (overrides authenticated_route)';


--
-- Name: tenant_landing_config_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_landing_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_landing_config_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_landing_config_id_seq OWNED BY dos.tenant_landing_config.id;


--
-- Name: tenant_memberships; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_memberships (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    role_code character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    membership_type text DEFAULT 'internal'::text,
    is_tenant_owner boolean DEFAULT false
);


--
-- Name: tenant_memberships_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_memberships_id_seq OWNED BY dos.tenant_memberships.id;


--
-- Name: tenant_migrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_migrations (
    tenant_id text NOT NULL,
    migration_id text NOT NULL,
    source text NOT NULL,
    filename text NOT NULL,
    checksum text NOT NULL,
    status text NOT NULL,
    duration_ms integer,
    error_message text,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_by text,
    CONSTRAINT chk_tenant_migrations_status_v2 CHECK ((status = ANY (ARRAY['applied'::text, 'failed'::text, 'verified-by-backfill'::text, 'superseded-misclassified'::text])))
);


--
-- Name: tenant_migrations_latest; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.tenant_migrations_latest AS
 SELECT DISTINCT ON (tenant_id, migration_id) tenant_id,
    migration_id,
    source,
    filename,
    checksum,
    status,
    duration_ms,
    error_message,
    applied_at,
    applied_by
   FROM dos.tenant_migrations
  ORDER BY tenant_id, migration_id, applied_at DESC;


--
-- Name: tenant_migrations_failed; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.tenant_migrations_failed AS
 SELECT tenant_id,
    migration_id,
    filename,
    error_message,
    applied_at
   FROM dos.tenant_migrations_latest
  WHERE (status = 'failed'::text);


--
-- Name: tenant_module_entitlements; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_module_entitlements (
    entitlement_id character varying(32) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(64) NOT NULL,
    module_code character varying(64) NOT NULL,
    entitlement_status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    source character varying(32) DEFAULT 'paid'::character varying NOT NULL,
    trial_id character varying(32),
    subscription_id character varying(32),
    limits_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    ends_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_tenant_module_entitlements_source CHECK (((source)::text = ANY ((ARRAY['trial'::character varying, 'paid'::character varying, 'internal'::character varying, 'admin'::character varying, 'manual'::character varying, 'platform_dna'::character varying])::text[]))),
    CONSTRAINT chk_tenant_module_entitlements_status CHECK (((entitlement_status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'suspended'::character varying, 'cancelled'::character varying, 'pending'::character varying, 'not_entitled'::character varying])::text[])))
);


--
-- Name: tenant_modules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_modules (
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    module_version text NOT NULL,
    status text DEFAULT 'eligible'::text NOT NULL,
    provisioning_mode text DEFAULT 'eager'::text NOT NULL,
    attached_slot_id uuid,
    materialized_at timestamp with time zone,
    last_error text,
    idempotency_key text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_modules_provisioning_mode_check CHECK ((provisioning_mode = ANY (ARRAY['eager'::text, 'on_demand'::text, 'pool_warmed'::text]))),
    CONSTRAINT tenant_modules_status_check CHECK ((status = ANY (ARRAY['eligible'::text, 'attaching'::text, 'active'::text, 'failed'::text, 'draining'::text, 'disabled'::text])))
);


--
-- Name: tenant_product_activation; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_product_activation (
    id integer NOT NULL,
    tenant_id character varying(64) NOT NULL,
    product_key character varying(50) NOT NULL,
    activated_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'active'::character varying,
    product_code text
);


--
-- Name: tenant_product_activation_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_product_activation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_product_activation_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_product_activation_id_seq OWNED BY dos.tenant_product_activation.id;


--
-- Name: tenant_product_entitlements; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_product_entitlements (
    entitlement_id character varying(32) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(64) NOT NULL,
    entitlement_status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    source character varying(32) DEFAULT 'trial'::character varying NOT NULL,
    trial_id character varying(32),
    subscription_id character varying(32),
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    ends_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_tenant_product_entitlements_source CHECK (((source)::text = ANY ((ARRAY['trial'::character varying, 'paid'::character varying, 'internal'::character varying, 'admin'::character varying, 'manual'::character varying])::text[]))),
    CONSTRAINT chk_tenant_product_entitlements_status CHECK (((entitlement_status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'suspended'::character varying, 'cancelled'::character varying, 'pending'::character varying])::text[])))
);


--
-- Name: tenant_schema_allowlist; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_schema_allowlist (
    schema_name character varying(100) NOT NULL,
    reason text NOT NULL,
    evidence text,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    added_by text
);


--
-- Name: TABLE tenant_schema_allowlist; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_schema_allowlist IS 'Explicit allow-list for `tenant_*` schemas that legitimately exist without
 a `dos.tenants` registry row. Consumed by
 scripts/ci-guards/per-tenant-schema-orphan-detector.mjs. Add a row only
 when the schema carries live data and registration is blocked (e.g.
 tenant_id length cap prevents back-registration).';


--
-- Name: tenant_security_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_security_policy (
    tenant_id character varying(64) NOT NULL,
    mfa_required boolean DEFAULT false NOT NULL,
    mfa_channel character varying(16) DEFAULT 'email'::character varying NOT NULL,
    mfa_otp_ttl_sec integer DEFAULT 300 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(128)
);


--
-- Name: tenant_settings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_settings (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT tenant_settings_id_not_null1 NOT NULL,
    key character varying(500) NOT NULL,
    value text,
    scope character varying(20) DEFAULT 'tenant'::character varying NOT NULL,
    product_key character varying(128),
    module_code character varying(128),
    workspace_id text,
    owner_user_id text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_settings_legacy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_settings_legacy (
    id integer CONSTRAINT tenant_settings_id_not_null NOT NULL,
    tenant_id character varying(16) CONSTRAINT tenant_settings_tenant_id_not_null NOT NULL,
    setting_key character varying(200) CONSTRAINT tenant_settings_setting_key_not_null NOT NULL,
    setting_value jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_settings_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_settings_id_seq OWNED BY dos.tenant_settings_legacy.id;


--
-- Name: tenant_subscriptions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_subscriptions (
    subscription_id character varying(32) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(64) NOT NULL,
    plan_code character varying(64),
    status character varying(32) DEFAULT 'trialing'::character varying NOT NULL,
    billing_status character varying(40) DEFAULT 'no_payment_required'::character varying NOT NULL,
    trial_id character varying(32),
    current_period_start timestamp with time zone DEFAULT now() NOT NULL,
    current_period_end timestamp with time zone,
    grace_ends_at timestamp with time zone,
    provider_mode character varying(40) DEFAULT 'manual'::character varying NOT NULL,
    provider_ref character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_tenant_subscriptions_billing CHECK (((billing_status)::text = ANY ((ARRAY['no_payment_required'::character varying, 'payment_provider_pending'::character varying, 'invoice_pending'::character varying, 'invoice_paid'::character varying, 'payment_failed'::character varying, 'manually_approved'::character varying, 'external_provider_active'::character varying])::text[]))),
    CONSTRAINT chk_tenant_subscriptions_provider_mode CHECK (((provider_mode)::text = ANY ((ARRAY['manual'::character varying, 'invoice_offline'::character varying, 'payment_provider_pending'::character varying, 'external_provider'::character varying])::text[]))),
    CONSTRAINT chk_tenant_subscriptions_status CHECK (((status)::text = ANY ((ARRAY['trialing'::character varying, 'active'::character varying, 'past_due'::character varying, 'grace'::character varying, 'suspended'::character varying, 'cancelled'::character varying, 'expired'::character varying, 'converted'::character varying])::text[])))
);


--
-- Name: tenant_trials; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_trials (
    trial_id character varying(32) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(64) NOT NULL,
    plan_code character varying(64),
    status character varying(40) DEFAULT 'trial_pending_verification'::character varying NOT NULL,
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    grace_ends_at timestamp with time zone,
    converted_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    suspended_at timestamp with time zone,
    created_by_user_id character varying(64),
    signup_domain character varying(255),
    verification_status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    source character varying(64) DEFAULT 'self_registration'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_tenant_trials_status CHECK (((status)::text = ANY ((ARRAY['trial_pending_verification'::character varying, 'trial_active'::character varying, 'trial_expiring'::character varying, 'trial_grace'::character varying, 'trial_suspended'::character varying, 'trial_converted'::character varying, 'trial_cancelled'::character varying, 'trial_expired'::character varying, 'tenant_archived'::character varying])::text[]))),
    CONSTRAINT chk_tenant_trials_verification CHECK (((verification_status)::text = ANY ((ARRAY['pending'::character varying, 'verified'::character varying, 'rejected'::character varying, 'bypassed'::character varying])::text[])))
);


--
-- Name: tenants; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenants (
    tenant_id character varying(64) NOT NULL,
    tenant_code character varying(50) NOT NULL,
    tenant_name character varying(255),
    schema_name character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    display_name character varying(255),
    parent_tenant_id character varying(64),
    primary_domain text,
    custom_domain text,
    default_locale text DEFAULT 'en'::text NOT NULL,
    default_rtl boolean DEFAULT false NOT NULL,
    product_key text,
    tier text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    archived_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT dos_tenants_status_chk CHECK (((status IS NULL) OR ((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying, 'archived'::character varying, 'pending'::character varying, 'trial'::character varying])::text[])))),
    CONSTRAINT dos_tenants_tier_chk CHECK (((tier IS NULL) OR (tier = ANY (ARRAY['free'::text, 'starter'::text, 'professional'::text, 'enterprise'::text, 'custom'::text]))))
);


--
-- Name: training_courses; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.training_courses (
    course_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    category text,
    status text DEFAULT 'active'::text,
    duration_min integer,
    is_mandatory boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: training_enrollments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.training_enrollments (
    enrollment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    course_id uuid,
    user_id text NOT NULL,
    status text DEFAULT 'enrolled'::text,
    progress integer DEFAULT 0,
    completed_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: training_programs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.training_programs (
    program_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    category character varying(100),
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    mandatory boolean DEFAULT false,
    due_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: trial_audit_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.trial_audit_log (
    audit_id bigint NOT NULL,
    tenant_id character varying(16) NOT NULL,
    trial_id character varying(32),
    user_id character varying(64),
    product_code character varying(64),
    action character varying(64) NOT NULL,
    old_status character varying(40),
    new_status character varying(40),
    reason text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: trial_audit_log_audit_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.trial_audit_log_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trial_audit_log_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.trial_audit_log_audit_id_seq OWNED BY dos.trial_audit_log.audit_id;


--
-- Name: ui_admin_activity_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_admin_activity_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    actor_id character varying(64) NOT NULL,
    action_code character varying(150) NOT NULL,
    target_kind dos.ui_target_kind_t,
    target_id character varying(150),
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_admin_activity_log; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_admin_activity_log IS 'UI-OS §16 — append-only admin action audit (actor_id, action_code, target).';


--
-- Name: ui_carbon_components; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_carbon_components (
    carbon_key character varying(80) NOT NULL,
    package_name character varying(120) DEFAULT 'carbon-components-angular'::character varying NOT NULL,
    package_version character varying(40) DEFAULT '5.69.0'::character varying NOT NULL,
    category character varying(40) DEFAULT 'component'::character varying NOT NULL,
    is_experimental boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    source_component_name character varying(120),
    integration_mode character varying(40) DEFAULT 'native-angular'::character varying NOT NULL,
    runtime_status character varying(40) DEFAULT 'active'::character varying NOT NULL,
    angular_native boolean DEFAULT true NOT NULL,
    wrapper_required boolean DEFAULT true NOT NULL,
    stability character varying(20) DEFAULT 'stable'::character varying NOT NULL,
    dynamic_ui_allowed boolean DEFAULT true NOT NULL,
    notes text,
    vendor character varying(40) DEFAULT 'ibm-carbon'::character varying NOT NULL,
    CONSTRAINT ui_carbon_components_category_check CHECK (((category)::text = ANY ((ARRAY['component'::character varying, 'primitive'::character varying, 'layout'::character varying, 'utility'::character varying, 'experimental'::character varying, 'shell'::character varying, 'chart'::character varying, 'ai'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_integration_mode_check CHECK (((integration_mode)::text = ANY ((ARRAY['native-angular'::character varying, 'angular-chart'::character varying, 'web-component-wrapper'::character varying, 'asset-package'::character varying, 'react-only-reference'::character varying, 'deprecated-alias'::character varying, 'unavailable'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_runtime_status_check CHECK (((runtime_status)::text = ANY ((ARRAY['active'::character varying, 'wrapper-required'::character varying, 'catalog-only'::character varying, 'blocked-react-only'::character varying, 'deprecated'::character varying, 'experimental'::character varying, 'missing-upstream-angular-binding'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_stability_check CHECK (((stability)::text = ANY ((ARRAY['stable'::character varying, 'canary'::character varying, 'experimental'::character varying, 'deprecated'::character varying, 'beta'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_vendor_check CHECK (((vendor)::text = 'ibm-carbon'::text))
);


--
-- Name: ui_dos_component_carbon_map; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_dos_component_carbon_map (
    dos_component_key text NOT NULL,
    carbon_key character varying NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_draft_versions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_draft_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    target_kind dos.ui_target_kind_t NOT NULL,
    target_id character varying(150) NOT NULL,
    version character varying(40) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    author_id character varying(64) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_draft_versions; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_draft_versions IS 'UI-OS §16 — author-owned drafts pending publish; multiple drafts per target via version key.';


--
-- Name: ui_module_nav_group; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_group (
    module_code text NOT NULL,
    group_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_key text,
    label_en text,
    label_ar text,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_group; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_group IS 'Phase F-F10 layer 3.a: ordered groups (sidebar sections) per module. Groups themselves have sort_order; items reference (module_code, group_id).';


--
-- Name: ui_module_nav_item; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_item (
    module_code text NOT NULL,
    item_id text NOT NULL,
    group_id text,
    sort_order integer DEFAULT 0 NOT NULL,
    route text NOT NULL,
    icon text,
    permission text,
    label_key text,
    label_en text,
    label_ar text,
    badge text,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_item; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_item IS 'Phase F-F10 layer 3.b: ordered items per module. Items optionally belong to a group; both groups and items have explicit sort_order.';


--
-- Name: ui_module_nav_override_tenant; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_override_tenant (
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    item_id text NOT NULL,
    sort_order integer,
    enabled boolean,
    label_en text,
    label_ar text,
    badge text,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_override_tenant; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_override_tenant IS 'Phase F-F10 layer 4: per-tenant sparse override. Each non-NULL column wins over the module default; NULL columns inherit.';


--
-- Name: ui_module_nav_override_user; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_override_user (
    user_id text NOT NULL,
    module_code text NOT NULL,
    item_id text NOT NULL,
    sort_order integer,
    enabled boolean,
    pinned boolean,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_override_user; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_override_user IS 'Phase F-F10 layer 5: per-user sparse override + pin. Wins over tenant override.';


--
-- Name: ui_override_module; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_module (
    module_code text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_module; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_module IS 'Phase F-F9 layer 3: per-module UI patch (e.g. compliance, risk, foundation, platform-admin). Sparse jsonb merged after product, before route.';


--
-- Name: ui_override_product; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_product (
    product_code text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_product; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_product IS 'Phase F-F9 layer 2: per-product UI patch (e.g. shahin-ai, doganhub). Sparse jsonb merged after workspace defaults, before module layer.';


--
-- Name: COLUMN ui_override_product.patch; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_override_product.patch IS 'Sparse jsonb. Object keys replace; arrays REPLACE in full.';


--
-- Name: ui_override_tenant; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_tenant (
    tenant_id text NOT NULL,
    route text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_tenant; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_tenant IS 'Phase F-F9 layer 5: per-tenant UI patch. Two rows resolved in order: (tenant_id, ''*'') then (tenant_id, route) — both deep-merged after the route layer, with the specific row winning.';


--
-- Name: ui_override_user; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_user (
    user_id text NOT NULL,
    route text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_user; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_user IS 'Phase F-F9 layer 6: per-user UI patch. Final, narrowest layer — deep-merged after the tenant layer.';


--
-- Name: ui_published_versions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_published_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    target_kind dos.ui_target_kind_t NOT NULL,
    target_id character varying(150) NOT NULL,
    version character varying(40) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    published_by character varying(64) NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    is_current boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE ui_published_versions; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_published_versions IS 'UI-OS §16 — current/historical published payloads per (target_kind,target_id,version). DKNF via dos.ui_target_kind_t.';


--
-- Name: ui_rollback_points; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_rollback_points (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    target_kind dos.ui_target_kind_t NOT NULL,
    target_id character varying(150) NOT NULL,
    version character varying(40) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    reason text,
    created_by character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_rollback_points; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_rollback_points IS 'UI-OS §16 — explicit restore-points captured before risky publishes; supports rollback flows.';


--
-- Name: ui_route_access_review_campaign; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_access_review_campaign (
    route text NOT NULL,
    campaign_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    title_en text NOT NULL,
    title_ar text NOT NULL,
    status text NOT NULL,
    sla_due_at timestamp with time zone,
    pending_items integer DEFAULT 0 NOT NULL,
    escalated_items integer DEFAULT 0 NOT NULL,
    completed_items integer DEFAULT 0 NOT NULL,
    decision_action jsonb
);


--
-- Name: ui_route_access_review_evidence; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_access_review_evidence (
    route text NOT NULL,
    evidence_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    title_en text NOT NULL,
    title_ar text NOT NULL,
    description_en text,
    description_ar text,
    actor text,
    status text,
    payload_json jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: ui_route_agent_flow_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_agent_flow_step (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    step_id text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    step_type text,
    agent_id text,
    status text,
    evidence_uri text
);


--
-- Name: ui_route_agent_flow_step_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_agent_flow_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_agent_flow_step_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_agent_flow_step_id_seq OWNED BY dos.ui_route_agent_flow_step.id;


--
-- Name: ui_route_agent_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_agent_registry (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    agent_id text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    agent_type text,
    capability text,
    status text,
    owner text,
    ai_model text
);


--
-- Name: ui_route_agent_registry_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_agent_registry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_agent_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_agent_registry_id_seq OWNED BY dos.ui_route_agent_registry.id;


--
-- Name: ui_route_ai_explainability_block; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_ai_explainability_block (
    id bigint NOT NULL,
    route text NOT NULL,
    block_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    rationale_en text,
    rationale_ar text,
    confidence numeric(5,2),
    status text,
    action_json jsonb
);


--
-- Name: ui_route_ai_explainability_block_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_ai_explainability_block_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_ai_explainability_block_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_ai_explainability_block_id_seq OWNED BY dos.ui_route_ai_explainability_block.id;


--
-- Name: ui_route_ai_insight; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_ai_insight (
    route text NOT NULL,
    insight_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    text_en text NOT NULL,
    text_ar text NOT NULL,
    severity text,
    action jsonb
);


--
-- Name: ui_route_audit_evidence_artifact; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_audit_evidence_artifact (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    artifact_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    artifact_type text,
    hash text,
    collected_at timestamp with time zone NOT NULL,
    collected_by text,
    download_url text
);


--
-- Name: ui_route_audit_evidence_artifact_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_audit_evidence_artifact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_audit_evidence_artifact_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_audit_evidence_artifact_id_seq OWNED BY dos.ui_route_audit_evidence_artifact.id;


--
-- Name: ui_route_audit_ledger_row; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_audit_ledger_row (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    ledger_id text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    actor text NOT NULL,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    prev_hash text,
    hash text NOT NULL,
    decision_ref text
);


--
-- Name: ui_route_audit_ledger_row_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_audit_ledger_row_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_audit_ledger_row_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_audit_ledger_row_id_seq OWNED BY dos.ui_route_audit_ledger_row.id;


--
-- Name: ui_route_calendar_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_calendar_event (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    event_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    category text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    status text,
    severity text,
    link text
);


--
-- Name: ui_route_calendar_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_calendar_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_calendar_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_calendar_event_id_seq OWNED BY dos.ui_route_calendar_event.id;


--
-- Name: ui_route_case_finalization; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_case_finalization (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    case_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    case_type text,
    origin_ref text,
    decision text,
    decision_owner text,
    decision_at timestamp with time zone,
    signoff_status text,
    evidence_uri text,
    rationale_en text,
    rationale_ar text,
    next_review_at date,
    status text,
    CONSTRAINT chk_case_finalization_decision CHECK (((decision IS NULL) OR (decision = ANY (ARRAY['approve'::text, 'reject'::text, 'accept-risk'::text, 'escalate'::text, 'defer'::text])))),
    CONSTRAINT chk_case_finalization_signoff CHECK (((signoff_status IS NULL) OR (signoff_status = ANY (ARRAY['pending'::text, 'partial'::text, 'complete'::text, 'rejected'::text])))),
    CONSTRAINT chk_case_finalization_status CHECK (((status IS NULL) OR (status = ANY (ARRAY['open'::text, 'in-review'::text, 'finalized'::text, 'reopened'::text]))))
);


--
-- Name: ui_route_case_finalization_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_case_finalization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_case_finalization_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_case_finalization_id_seq OWNED BY dos.ui_route_case_finalization.id;


--
-- Name: ui_route_column; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_column (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    field_key text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    type text,
    sortable boolean DEFAULT false NOT NULL
);


--
-- Name: ui_route_column_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_column_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_column_id_seq OWNED BY dos.ui_route_column.id;


--
-- Name: ui_route_delegation_rule; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_delegation_rule (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    rule_id text NOT NULL,
    delegator text NOT NULL,
    delegate text NOT NULL,
    scope text NOT NULL,
    permission text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    status text,
    risk_level text,
    risk_score integer,
    escalation_required boolean DEFAULT false NOT NULL,
    escalation_target text,
    escalation_due_at timestamp with time zone,
    escalation_reason text,
    CONSTRAINT chk_ui_route_delegation_rule_risk_level CHECK (((risk_level IS NULL) OR (risk_level = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text]))))
);


--
-- Name: ui_route_delegation_rule_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_delegation_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_delegation_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_delegation_rule_id_seq OWNED BY dos.ui_route_delegation_rule.id;


--
-- Name: ui_route_event_handler; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_event_handler (
    handler_id uuid DEFAULT gen_random_uuid() NOT NULL,
    route text NOT NULL,
    event_name text NOT NULL,
    handler jsonb NOT NULL,
    permission text,
    enabled boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_route_export_artifact; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_export_artifact (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    artifact_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    format text NOT NULL,
    status text NOT NULL,
    size_kb integer,
    download_url text,
    generated_at timestamp with time zone,
    CONSTRAINT chk_export_format CHECK ((format = ANY (ARRAY['pdf'::text, 'csv'::text, 'xlsx'::text, 'json'::text]))),
    CONSTRAINT chk_export_status CHECK ((status = ANY (ARRAY['ready'::text, 'generating'::text, 'failed'::text])))
);


--
-- Name: ui_route_export_artifact_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_export_artifact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_export_artifact_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_export_artifact_id_seq OWNED BY dos.ui_route_export_artifact.id;


--
-- Name: ui_route_filter; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_filter (
    id bigint NOT NULL,
    route text NOT NULL,
    filter_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    field_key text NOT NULL,
    operator text DEFAULT 'eq'::text NOT NULL,
    control text DEFAULT 'select'::text NOT NULL,
    options_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    default_value text,
    permission text
);


--
-- Name: ui_route_filter_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_filter_id_seq OWNED BY dos.ui_route_filter.id;


--
-- Name: ui_route_follow_up_item; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_follow_up_item (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    item_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    origin_ref text,
    owner text,
    due_at timestamp with time zone,
    status text,
    severity text,
    ai_score integer
);


--
-- Name: ui_route_follow_up_item_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_follow_up_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_follow_up_item_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_follow_up_item_id_seq OWNED BY dos.ui_route_follow_up_item.id;


--
-- Name: ui_route_heatmap_axis; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_heatmap_axis (
    id bigint NOT NULL,
    route text NOT NULL,
    axis text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    bucket_key text,
    CONSTRAINT ui_route_heatmap_axis_axis_check CHECK ((axis = ANY (ARRAY['x'::text, 'y'::text])))
);


--
-- Name: ui_route_heatmap_axis_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_heatmap_axis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_heatmap_axis_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_heatmap_axis_id_seq OWNED BY dos.ui_route_heatmap_axis.id;


--
-- Name: ui_route_identity_graph_edge; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_identity_graph_edge (
    id bigint NOT NULL,
    route text NOT NULL,
    edge_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    source_node text NOT NULL,
    target_node text NOT NULL,
    relation text NOT NULL,
    confidence numeric(5,2),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: ui_route_identity_graph_edge_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_identity_graph_edge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_identity_graph_edge_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_identity_graph_edge_id_seq OWNED BY dos.ui_route_identity_graph_edge.id;


--
-- Name: ui_route_identity_graph_node; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_identity_graph_node (
    id bigint NOT NULL,
    route text NOT NULL,
    node_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    node_type text NOT NULL,
    owner text,
    risk_level text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: ui_route_identity_graph_node_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_identity_graph_node_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_identity_graph_node_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_identity_graph_node_id_seq OWNED BY dos.ui_route_identity_graph_node.id;


--
-- Name: ui_route_incident_communication; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_incident_communication (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    comm_id text NOT NULL,
    channel text NOT NULL,
    audience text NOT NULL,
    sent_at timestamp with time zone NOT NULL,
    message_en text NOT NULL,
    message_ar text
);


--
-- Name: ui_route_incident_communication_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_incident_communication_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_incident_communication_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_incident_communication_id_seq OWNED BY dos.ui_route_incident_communication.id;


--
-- Name: ui_route_incident_runbook_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_incident_runbook_step (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    step_id text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    phase text,
    owner text,
    due_at timestamp with time zone,
    status text,
    evidence_uri text
);


--
-- Name: ui_route_incident_runbook_step_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_incident_runbook_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_incident_runbook_step_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_incident_runbook_step_id_seq OWNED BY dos.ui_route_incident_runbook_step.id;


--
-- Name: ui_route_kpi; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_kpi (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    source_path text,
    format text,
    ai_insight text,
    status text,
    link text
);


--
-- Name: ui_route_kpi_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_kpi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_kpi_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_kpi_id_seq OWNED BY dos.ui_route_kpi.id;


--
-- Name: ui_route_nba; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_nba (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    description text,
    ai_score integer,
    target_route text,
    permission text,
    severity text
);


--
-- Name: ui_route_nba_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_nba_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_nba_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_nba_id_seq OWNED BY dos.ui_route_nba.id;


--
-- Name: ui_route_org_chart_node; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_org_chart_node (
    id bigint NOT NULL,
    route text NOT NULL,
    node_id text NOT NULL,
    parent_id text,
    sort_order integer DEFAULT 0 NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    role text,
    owner text,
    badge text
);


--
-- Name: ui_route_org_chart_node_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_org_chart_node_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_org_chart_node_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_org_chart_node_id_seq OWNED BY dos.ui_route_org_chart_node.id;


--
-- Name: ui_route_ownership_edge; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_ownership_edge (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    edge_id text NOT NULL,
    entity_id text NOT NULL,
    entity_label text NOT NULL,
    owner text NOT NULL,
    ownership_role text NOT NULL,
    effective_from date,
    effective_to date,
    CONSTRAINT chk_ownership_role CHECK ((ownership_role = ANY (ARRAY['accountable'::text, 'responsible'::text, 'consulted'::text, 'informed'::text, 'custodian'::text, 'approver'::text, 'reviewer'::text, 'executor'::text, 'observer'::text])))
);


--
-- Name: ui_route_ownership_edge_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_ownership_edge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_ownership_edge_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_ownership_edge_id_seq OWNED BY dos.ui_route_ownership_edge.id;


--
-- Name: ui_route_policy_simulation_scenario; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_policy_simulation_scenario (
    id bigint NOT NULL,
    route text NOT NULL,
    scenario_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    assumption_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    impact_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    recommended_action jsonb,
    status text
);


--
-- Name: ui_route_policy_simulation_scenario_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_policy_simulation_scenario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_policy_simulation_scenario_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_policy_simulation_scenario_id_seq OWNED BY dos.ui_route_policy_simulation_scenario.id;


--
-- Name: ui_route_posture_score; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_posture_score (
    route text NOT NULL,
    score_id text NOT NULL,
    kind text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    value numeric DEFAULT 0 NOT NULL,
    max_value numeric,
    severity text,
    status text
);


--
-- Name: ui_route_record_field; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_record_field (
    route text NOT NULL,
    field_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    value text,
    kind text
);


--
-- Name: ui_route_record_row; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_record_row (
    route text NOT NULL,
    row_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    severity text,
    status text
);


--
-- Name: ui_route_report_card; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_report_card (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    report_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    description text,
    status text DEFAULT 'ready'::text NOT NULL,
    tag text,
    ai_generated boolean DEFAULT false NOT NULL,
    download_url text
);


--
-- Name: ui_route_report_card_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_report_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_report_card_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_report_card_id_seq OWNED BY dos.ui_route_report_card.id;


--
-- Name: ui_route_roadmap_milestone; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_roadmap_milestone (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    milestone_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    description text,
    target_date date,
    progress integer DEFAULT 0 NOT NULL,
    status text,
    owner text,
    CONSTRAINT chk_roadmap_progress CHECK (((progress >= 0) AND (progress <= 100)))
);


--
-- Name: ui_route_roadmap_milestone_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_roadmap_milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_roadmap_milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_roadmap_milestone_id_seq OWNED BY dos.ui_route_roadmap_milestone.id;


--
-- Name: ui_route_role_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_role_policy (
    policy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    route text NOT NULL,
    write_roles text[] DEFAULT '{}'::text[] NOT NULL,
    read_roles text[] DEFAULT '{}'::text[] NOT NULL,
    default_role text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_route_setting_section; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_setting_section (
    id bigint NOT NULL,
    route text NOT NULL,
    section_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    icon text
);


--
-- Name: ui_route_setting_section_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_setting_section_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_setting_section_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_setting_section_id_seq OWNED BY dos.ui_route_setting_section.id;


--
-- Name: ui_route_tab; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_tab (
    id bigint NOT NULL,
    route text NOT NULL,
    tab_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    permission text
);


--
-- Name: ui_route_tab_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_tab_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_tab_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_tab_id_seq OWNED BY dos.ui_route_tab.id;


--
-- Name: ui_route_table_action; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_table_action (
    id bigint NOT NULL,
    route text NOT NULL,
    action_id text NOT NULL,
    scope text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    action_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    permission text,
    emphasis text,
    CONSTRAINT ui_route_table_action_scope_check CHECK ((scope = ANY (ARRAY['toolbar'::text, 'row'::text, 'batch'::text])))
);


--
-- Name: ui_route_table_action_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_table_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_table_action_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_table_action_id_seq OWNED BY dos.ui_route_table_action.id;


--
-- Name: ui_route_trend_series; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_trend_series (
    route text NOT NULL,
    series_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    color text,
    points jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: ui_route_workflow_timeline_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_workflow_timeline_step (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    step_id text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    state text NOT NULL,
    description text,
    occurred_at timestamp with time zone,
    actor text,
    CONSTRAINT chk_wf_timeline_state CHECK ((state = ANY (ARRAY['complete'::text, 'current'::text, 'incomplete'::text, 'invalid'::text, 'disabled'::text])))
);


--
-- Name: ui_route_workflow_timeline_step_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_workflow_timeline_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_workflow_timeline_step_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_workflow_timeline_step_id_seq OWNED BY dos.ui_route_workflow_timeline_step.id;


--
-- Name: ui_route_workqueue_group; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_workqueue_group (
    id bigint NOT NULL,
    route text NOT NULL,
    group_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    urgency text,
    filter_expr jsonb
);


--
-- Name: ui_route_workqueue_group_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_workqueue_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_workqueue_group_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_workqueue_group_id_seq OWNED BY dos.ui_route_workqueue_group.id;


--
-- Name: ui_service_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_service_registry (
    service_code character varying(80) NOT NULL,
    display_name character varying(200) NOT NULL,
    module_code character varying(100),
    port integer NOT NULL,
    gateway_prefix character varying(120),
    cwd character varying(300) NOT NULL,
    wave integer,
    registry_status character varying(40) DEFAULT 'active'::character varying NOT NULL,
    health_path character varying(120) DEFAULT '/health'::character varying NOT NULL,
    manifest_path character varying(120) DEFAULT '/manifest'::character varying NOT NULL,
    admin_route character varying(300),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ui_service_registry_registry_status_check CHECK (((registry_status)::text = ANY ((ARRAY['active'::character varying, 'blocked'::character varying, 'deprecated'::character varying, 'draft'::character varying])::text[])))
);


--
-- Name: ui_service_registry_prefixes; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_service_registry_prefixes (
    service_code character varying(80) NOT NULL,
    prefix character varying(120) NOT NULL,
    is_primary boolean DEFAULT false NOT NULL
);


--
-- Name: ui_touch_target_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_touch_target_config (
    id bigint NOT NULL,
    tenant_id character varying(64),
    min_size_px integer DEFAULT 44 NOT NULL,
    min_spacing_px integer DEFAULT 8 NOT NULL,
    haptic_feedback_enabled boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_ui_touch_target_min_size_px CHECK (((min_size_px >= 16) AND (min_size_px <= 96))),
    CONSTRAINT chk_ui_touch_target_min_spacing_px CHECK (((min_spacing_px >= 0) AND (min_spacing_px <= 64)))
);


--
-- Name: ui_touch_target_config_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_touch_target_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_touch_target_config_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_touch_target_config_id_seq OWNED BY dos.ui_touch_target_config.id;


--
-- Name: ui_workspace_banner; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_banner (
    tenant_id character varying(64) NOT NULL,
    banner_id text NOT NULL,
    gate text DEFAULT 'always'::text NOT NULL,
    kind text DEFAULT 'info'::text NOT NULL,
    title_key text,
    title_fallback text,
    message_key text,
    message_fallback text,
    action_label_key text,
    action_json jsonb,
    dismissible boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ui_workspace_banner_kind_check CHECK ((kind = ANY (ARRAY['info'::text, 'warning'::text, 'error'::text, 'success'::text, 'danger'::text])))
);


--
-- Name: ui_workspace_chrome; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_chrome (
    tenant_id character varying(64) NOT NULL,
    chrome_key text NOT NULL,
    value_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_workspace_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_policy (
    tenant_id character varying(64) NOT NULL,
    policy_key text NOT NULL,
    value_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_workspace_shortcut; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_shortcut (
    tenant_id character varying(64) NOT NULL,
    shortcut_id text NOT NULL,
    combo text NOT NULL,
    action_json jsonb NOT NULL,
    when_clause text,
    sort_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_access_profiles; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.user_access_profiles AS
 SELECT id,
    user_id,
    profile_id,
    tenant_id,
    granted_at,
    granted_by
   FROM platform_dauth.user_access_profiles_legacy;


--
-- Name: user_org_scope; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.user_org_scope (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    scope_type text NOT NULL,
    scope_id text NOT NULL,
    role text,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_org_scope_scope_type_check CHECK ((scope_type = ANY (ARRAY['business_unit'::text, 'department'::text, 'team'::text, 'location'::text, 'position'::text, 'organization'::text])))
);


--
-- Name: user_role_assignments; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.user_role_assignments AS
 SELECT assignment_id,
    tenant_id,
    user_id,
    role_code,
    scope,
    granted_by,
    granted_at,
    expires_at,
    revoked_at,
    revoked_by,
    is_active
   FROM platform_dauth.user_role_assignments;


--
-- Name: user_roles; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.user_roles (
    user_id uuid NOT NULL,
    role_code character varying(100) NOT NULL,
    tenant_id uuid,
    scope character varying(30) DEFAULT 'org'::character varying,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    granted_by uuid,
    ended_at timestamp with time zone
);


--
-- Name: users; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.users (
    user_id character varying(64) NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    tenant_id character varying(64),
    role character varying(100),
    department_id character varying(64),
    deleted_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now(),
    onboarding_complete boolean DEFAULT false,
    member_onboarded boolean DEFAULT false,
    platform_role character varying(100),
    last_login timestamp with time zone,
    full_name character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    password_hash text,
    must_change_password boolean DEFAULT false,
    password_changed_at timestamp with time zone,
    login_count integer DEFAULT 0,
    email_verified boolean DEFAULT false,
    email_verified_at timestamp with time zone,
    sso_provider text,
    sso_protocol text
);


--
-- Name: v_foundation_entities; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.v_foundation_entities AS
 SELECT (u.tenant_id)::text AS tenant_id,
    'user'::text AS entity_type,
    (u.user_id)::text AS entity_id,
    COALESCE(u.full_name, u.display_name, u.email, u.user_id) AS label
   FROM dos.users u
UNION ALL
 SELECT (d.tenant_id)::text AS tenant_id,
    'department'::text AS entity_type,
    (d.department_id)::text AS entity_id,
    COALESCE(d.display_name, d.department_code, d.department_id) AS label
   FROM dos.departments d
UNION ALL
 SELECT (t.tenant_id)::text AS tenant_id,
    'team'::text AS entity_type,
    (t.team_id)::text AS entity_id,
    COALESCE(t.display_name, t.team_code, t.team_id) AS label
   FROM dos.teams t
UNION ALL
 SELECT (l.tenant_id)::text AS tenant_id,
    'location'::text AS entity_type,
    (l.location_id)::text AS entity_id,
    COALESCE(l.name_en, l.code, (l.location_id)::text) AS label
   FROM dos.locations l
UNION ALL
 SELECT (b.tenant_id)::text AS tenant_id,
    'business_unit'::text AS entity_type,
    (b.bu_id)::text AS entity_id,
    COALESCE(b.name_en, b.code, (b.bu_id)::text) AS label
   FROM dos.business_units b;


--
-- Name: vendor_risk_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.vendor_risk_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendor_risk_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.vendor_risk_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_risk_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.vendor_risk_event_id_seq OWNED BY dos.vendor_risk_event.id;


--
-- Name: vendor_risk_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.vendor_risk_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT vendor_risk_record_kind_check CHECK ((kind = ANY (ARRAY['critical'::text, 'elevated'::text, 'standard'::text, 'baseline'::text]))),
    CONSTRAINT vendor_risk_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT vendor_risk_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: vendors; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.vendors (
    vendor_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    name text NOT NULL,
    category character varying(100),
    tier character varying(20) DEFAULT 'standard'::character varying,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    contact_email character varying(255),
    contact_phone character varying(50),
    risk_rating character varying(20),
    last_assessment_date date,
    contract_expiry date,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: widgets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.widgets (
    widget_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    dashboard_id uuid,
    title text NOT NULL,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    "position" jsonb DEFAULT '{}'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: work_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.work_items (
    work_item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    source character varying(50) DEFAULT 'workflow_tasks'::character varying NOT NULL,
    source_id uuid,
    title text NOT NULL,
    description text,
    task_type character varying(100),
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    assigned_to text,
    due_date timestamp with time zone,
    entity_type character varying(100),
    entity_id uuid,
    context jsonb DEFAULT '{}'::jsonb,
    completed_at timestamp with time zone,
    completed_by text,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_approvals; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_approvals (
    approval_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workflow_instance_id uuid,
    subject text,
    status text DEFAULT 'pending'::text,
    requested_by text NOT NULL,
    approvers jsonb DEFAULT '[]'::jsonb,
    approved_by text,
    rejected_by text,
    escalated_by text,
    escalated_to text,
    comment text,
    reject_reason text,
    escalation_reason text,
    context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


--
-- Name: workflow_definition; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_definition (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    definition jsonb NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT workflow_definition_kind_check CHECK ((kind = ANY (ARRAY['approval'::text, 'provisioning'::text, 'review'::text, 'remediation'::text, 'attestation'::text, 'generic'::text]))),
    CONSTRAINT workflow_definition_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT workflow_definition_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: workflow_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_event (
    id bigint NOT NULL,
    instance_id uuid,
    workflow_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workflow_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workflow_event_id_seq OWNED BY dos.workflow_event.id;


--
-- Name: workflow_instance; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_instance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_id uuid NOT NULL,
    tenant_id uuid,
    initiated_by text NOT NULL,
    status text DEFAULT 'running'::text NOT NULL,
    current_step text,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    error text,
    correlation_id text,
    CONSTRAINT workflow_instance_status_check CHECK ((status = ANY (ARRAY['running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text, 'suspended'::text])))
);


--
-- Name: workflow_instances; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_instances (
    instance_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workflow_type text NOT NULL,
    name text,
    status text DEFAULT 'pending'::text NOT NULL,
    current_step text,
    total_steps integer DEFAULT 0,
    created_by text,
    entity_type text,
    entity_id text,
    context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancel_reason text
);


--
-- Name: workflow_schedules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_schedules (
    schedule_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    cron_expression text NOT NULL,
    workflow_template_id uuid,
    enabled boolean DEFAULT true,
    config jsonb DEFAULT '{}'::jsonb,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: workflow_sla_configs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_sla_configs (
    sla_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workflow_type text NOT NULL,
    name text NOT NULL,
    max_duration_hours integer DEFAULT 72 NOT NULL,
    escalation_rules jsonb DEFAULT '[]'::jsonb,
    enabled boolean DEFAULT true,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: workflow_step_run; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_step_run (
    id bigint NOT NULL,
    instance_id uuid NOT NULL,
    step_id text NOT NULL,
    step_kind text NOT NULL,
    status text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    input jsonb,
    output jsonb,
    error text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    CONSTRAINT workflow_step_run_status_check CHECK ((status = ANY (ARRAY['started'::text, 'completed'::text, 'failed'::text, 'skipped'::text, 'timed-out'::text, 'rolled-back'::text])))
);


--
-- Name: workflow_step_run_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workflow_step_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_step_run_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workflow_step_run_id_seq OWNED BY dos.workflow_step_run.id;


--
-- Name: workflow_tasks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_tasks (
    task_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    instance_id uuid,
    task_type text,
    title text NOT NULL,
    description text,
    status text DEFAULT 'pending'::text NOT NULL,
    assigned_to text,
    assigned_by text,
    completed_by text,
    outcome text,
    notes text,
    due_at timestamp with time zone,
    context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


--
-- Name: workflow_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_templates (
    template_id character varying(64) NOT NULL,
    template_code character varying(100) NOT NULL,
    module_code character varying(50),
    display_name character varying(255),
    definition jsonb NOT NULL,
    version integer DEFAULT 1,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    tenant_id character varying(64),
    name character varying(255),
    description text,
    category character varying(100),
    parameters_schema jsonb,
    is_active boolean DEFAULT true,
    created_by character varying(64),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: workspace_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    config_key character varying(500) NOT NULL,
    config_value jsonb DEFAULT '{}'::jsonb NOT NULL,
    scope character varying(30) DEFAULT 'workspace'::character varying NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_global_quick_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_global_quick_actions (
    tenant_id text NOT NULL,
    item_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    icon text,
    action_json jsonb NOT NULL,
    perms_required text[] DEFAULT ARRAY[]::text[] NOT NULL,
    badge text,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_global_quick_action_kind CHECK (((action_json ? 'kind'::text) AND (jsonb_typeof((action_json -> 'kind'::text)) = 'string'::text)))
);


--
-- Name: workspace_settings_menu_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_settings_menu_items (
    tenant_id text NOT NULL,
    item_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    icon text,
    action_json jsonb NOT NULL,
    perms_required text[] DEFAULT ARRAY[]::text[] NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_settings_menu_action_kind CHECK (((action_json ? 'kind'::text) AND (jsonb_typeof((action_json -> 'kind'::text)) = 'string'::text)))
);


--
-- Name: workspace_shell_binding_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workspace_shell_binding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspace_shell_binding_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workspace_shell_binding_id_seq OWNED BY dos.workspace_shell_binding.id;


--
-- Name: workspace_shell_i18n; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_shell_i18n (
    id bigint NOT NULL,
    ns text NOT NULL,
    key text NOT NULL,
    locale text NOT NULL,
    value text NOT NULL,
    module_code text DEFAULT 'workspace-shell'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_shell_i18n_locale_check CHECK ((locale = ANY (ARRAY['en'::text, 'ar'::text])))
);


--
-- Name: workspace_shell_i18n_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workspace_shell_i18n_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspace_shell_i18n_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workspace_shell_i18n_id_seq OWNED BY dos.workspace_shell_i18n.id;


--
-- Name: workspace_shell_status_label; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_shell_status_label (
    id bigint NOT NULL,
    catalog text NOT NULL,
    code text NOT NULL,
    label_key text NOT NULL,
    tone text NOT NULL,
    icon text,
    module_code text DEFAULT 'workspace-shell'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_shell_status_label_catalog_check CHECK ((catalog = ANY (ARRAY['tenant'::text, 'health'::text, 'sync'::text]))),
    CONSTRAINT workspace_shell_status_label_tone_check CHECK ((tone = ANY (ARRAY['ok'::text, 'info'::text, 'warn'::text, 'error'::text, 'critical'::text, 'neutral'::text])))
);


--
-- Name: workspace_shell_status_label_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workspace_shell_status_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspace_shell_status_label_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workspace_shell_status_label_id_seq OWNED BY dos.workspace_shell_status_label.id;


--
-- Name: workspace_user_menu_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_user_menu_items (
    tenant_id text NOT NULL,
    item_id text NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    icon text,
    action_json jsonb NOT NULL,
    perms_required text[] DEFAULT ARRAY[]::text[] NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_user_menu_action_kind CHECK (((action_json ? 'kind'::text) AND (jsonb_typeof((action_json -> 'kind'::text)) = 'string'::text)))
);


--
-- Name: workspaces; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspaces (
    workspace_id character varying(64) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    workspace_name character varying(255),
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: onboarding_question_bank; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_question_bank (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    question_code text NOT NULL,
    stage_code text NOT NULL,
    section_code text,
    question_type text DEFAULT 'text'::text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    placeholder_en text,
    placeholder_ar text,
    help_text_en text,
    help_text_ar text,
    options_json jsonb,
    validation_json jsonb DEFAULT '{}'::jsonb,
    visibility_rule_json jsonb,
    lookup_table text,
    lookup_depends_on text,
    question_tier text,
    signals jsonb,
    information_gain_weight numeric(4,3),
    is_required boolean DEFAULT false,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    version integer DEFAULT 1 NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    CONSTRAINT chk_info_gain_weight CHECK (((information_gain_weight >= 0.0) AND (information_gain_weight <= 1.0))),
    CONSTRAINT chk_question_tier CHECK ((question_tier = ANY (ARRAY['anchor'::text, 'inferred'::text, 'advanced'::text, 'expert'::text, 'hidden'::text, 'P0'::text, 'P1'::text, 'P2'::text, 'P3'::text, 'foundation'::text, 'tier1'::text, 'tier2'::text, 'tier3'::text]))),
    CONSTRAINT chk_question_type CHECK ((question_type = ANY (ARRAY['text'::text, 'number'::text, 'boolean'::text, 'date'::text, 'select'::text, 'multi_select'::text, 'json'::text, 'lookup'::text, 'chips'::text, 'json_rows'::text])))
);


--
-- Name: access_profiles; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.access_profiles AS
 SELECT profile_id,
    profile_code,
    display_name,
    description,
    permissions,
    created_at
   FROM platform_dauth.access_profiles;


--
-- Name: access_snapshots; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.access_snapshots AS
 SELECT snapshot_id,
    user_id,
    tenant_id,
    snapshot_data,
    captured_at
   FROM platform_dauth.access_snapshots;


--
-- Name: active_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_alerts (
    alert_id character varying(255) NOT NULL,
    alert_name character varying(255) NOT NULL,
    severity character varying(20) NOT NULL,
    alert_class character varying(20) NOT NULL,
    summary text DEFAULT ''::text NOT NULL,
    affected_service character varying(255),
    correlation_id character varying(255),
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp with time zone,
    metadata jsonb
);


--
-- Name: active_sessions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.active_sessions AS
 SELECT session_id,
    user_id,
    tenant_id,
    ip_address,
    user_agent,
    started_at,
    last_seen_at
   FROM platform_dauth.active_sessions;


--
-- Name: actors; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.actors AS
 SELECT actor_id,
    user_id,
    actor_type,
    display_name,
    metadata,
    created_at
   FROM platform_dauth.actors;


--
-- Name: agent_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_credentials (
    credential_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    actor_id character varying(128) NOT NULL,
    credential_hash text NOT NULL,
    scopes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    created_by character varying(128),
    CONSTRAINT agent_credentials_active_scopes CHECK (((array_length(scopes, 1) IS NULL) OR (array_length(scopes, 1) <= 64)))
);

ALTER TABLE ONLY public.agent_credentials FORCE ROW LEVEL SECURITY;


--
-- Name: agent_feedback_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_feedback_log (
    feedback_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    agent_id character varying(10) NOT NULL,
    task_id uuid,
    feedback_type character varying(20) NOT NULL,
    task_title text,
    responded_by character varying(64),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: agent_monitoring_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_monitoring_targets (
    target_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    agent_id character varying(10) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority character varying(10) DEFAULT 'medium'::character varying,
    source character varying(50) DEFAULT 'onboarding'::character varying,
    enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: agent_performance_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_performance_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    agent_id character varying(10) NOT NULL,
    session_id character varying(255),
    duration_ms integer NOT NULL,
    tokens_in integer DEFAULT 0,
    tokens_out integer DEFAULT 0,
    tool_calls integer DEFAULT 0,
    stop_reason character varying(50),
    is_error boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: agent_priority_weights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_priority_weights (
    agent_id character varying(10) NOT NULL,
    tenant_id character varying(64),
    acceptance_rate numeric(5,2) DEFAULT 100,
    total_accepted integer DEFAULT 0,
    total_rejected integer DEFAULT 0,
    priority_boost numeric(3,2) DEFAULT 1.0,
    last_updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: mcp_agent_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_agent_registry (
    agent_id character varying(20) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255) NOT NULL,
    summary_en text,
    summary_ar text,
    owner_module_code character varying(64) NOT NULL,
    domain_code character varying(64) NOT NULL,
    module_codes text[] DEFAULT '{}'::text[] NOT NULL,
    capabilities text[] DEFAULT '{}'::text[] NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    guardrails jsonb DEFAULT '{"maxSteps": 12, "allowInternet": false}'::jsonb NOT NULL,
    icon character varying(50),
    color character varying(20),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    replaced_by character varying(20),
    change_notes text,
    visibility_scope character varying(30) DEFAULT 'all'::character varying NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_by text DEFAULT 'system'::text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    product_code character varying(64),
    public_visible boolean DEFAULT false NOT NULL,
    public_identity character varying(20),
    role_en character varying(255),
    role_ar character varying(255),
    visitor_runnable boolean DEFAULT false NOT NULL,
    image_path character varying(255),
    tools text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT mcp_agent_registry_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('active'::character varying)::text, ('deprecated'::character varying)::text, ('retired'::character varying)::text]))),
    CONSTRAINT mcp_agent_registry_visibility_scope_check CHECK (((visibility_scope)::text = ANY (ARRAY[('all'::character varying)::text, ('internal'::character varying)::text, ('admin_only'::character varying)::text, ('beta'::character varying)::text])))
);


--
-- Name: agent_registry; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.agent_registry AS
 SELECT agent_id,
    name_en,
    name_ar,
    COALESCE(role_en, domain_code) AS role_en,
    COALESCE(role_ar, name_ar) AS role_ar,
    domain_code AS domain_en,
    is_enabled AS enabled,
    sort_order,
    summary_en,
    summary_ar,
    owner_module_code,
    capabilities,
    tools,
    tags,
    icon,
    color,
    status,
    is_system,
    product_code,
    public_visible,
    public_identity,
    visitor_runnable,
    image_path,
    created_at,
    updated_at
   FROM public.mcp_agent_registry
  WHERE (public_visible = true);


--
-- Name: agent_sod_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_sod_policies (
    policy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    proposer_type character varying(20) NOT NULL,
    approver_type character varying(20) NOT NULL,
    action_key text,
    outcome character varying(10) NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(128),
    CONSTRAINT agent_sod_policies_approver_type_check CHECK (((approver_type)::text = ANY ((ARRAY['human'::character varying, 'agent'::character varying, 'service_account'::character varying, 'external'::character varying])::text[]))),
    CONSTRAINT agent_sod_policies_outcome_check CHECK (((outcome)::text = ANY ((ARRAY['allow'::character varying, 'warn'::character varying, 'escalate'::character varying, 'block'::character varying])::text[]))),
    CONSTRAINT agent_sod_policies_proposer_type_check CHECK (((proposer_type)::text = ANY ((ARRAY['human'::character varying, 'agent'::character varying, 'service_account'::character varying, 'external'::character varying])::text[])))
);

ALTER TABLE ONLY public.agent_sod_policies FORCE ROW LEVEL SECURITY;


--
-- Name: agent_tool_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_tool_permissions (
    permission_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id text NOT NULL,
    tool_name text NOT NULL,
    action text NOT NULL,
    level text NOT NULL,
    conditions jsonb,
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    revoked_by uuid,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    notes text,
    CONSTRAINT agent_tool_permissions_level_check CHECK ((level = ANY (ARRAY['allow'::text, 'deny'::text, 'approval_required'::text])))
);

ALTER TABLE ONLY public.agent_tool_permissions FORCE ROW LEVEL SECURITY;


--
-- Name: agrc_metrics_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrc_metrics_snapshots (
    snapshot_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    cycle_count integer DEFAULT 0,
    avg_cycle_ms integer DEFAULT 0,
    enforcement_rate numeric(5,2) DEFAULT 0,
    stale_control_pct numeric(5,2) DEFAULT 0,
    telemetry_ingestion_rate integer DEFAULT 0,
    event_count integer DEFAULT 0,
    critical_events integer DEFAULT 0,
    snapshot_at timestamp with time zone DEFAULT now()
);


--
-- Name: agrc_os_cycle_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agrc_os_cycle_log (
    cycle_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    telemetry_ingested integer DEFAULT 0,
    controls_evaluated integer DEFAULT 0,
    risks_recomputed integer DEFAULT 0,
    policy_decisions integer DEFAULT 0,
    enforcement_actions integer DEFAULT 0,
    audit_entries integer DEFAULT 0,
    cycle_ms integer NOT NULL,
    warnings jsonb DEFAULT '[]'::jsonb,
    executed_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_activity_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_activity_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    alert_type character varying(50) DEFAULT 'system'::character varying NOT NULL,
    severity character varying(20) DEFAULT 'info'::character varying NOT NULL,
    message text NOT NULL,
    entity_type character varying(50),
    entity_id character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb,
    acknowledged_by character varying(100),
    acknowledged_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ai_activity_alerts_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[])))
);


--
-- Name: ai_agent_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_registry (
    agent_version_id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    version_number integer NOT NULL,
    agent_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    linked_prompt_asset_id uuid,
    linked_model_asset_id uuid,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    approval_status text DEFAULT 'draft'::text NOT NULL,
    deployment_status text DEFAULT 'not_deployed'::text NOT NULL,
    submitted_by text,
    submitted_at timestamp with time zone,
    approved_by text,
    approved_at timestamp with time zone,
    is_active boolean DEFAULT false NOT NULL,
    rollback_from_version_id uuid,
    diff_summary text,
    change_summary text,
    notes text,
    created_by text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_agent_registry_approval_status_chk CHECK ((approval_status = ANY (ARRAY['draft'::text, 'submitted'::text, 'under_review'::text, 'approved'::text, 'rejected'::text, 'suspended'::text, 'retired'::text, 'archived'::text]))),
    CONSTRAINT ai_agent_registry_deployment_status_chk CHECK ((deployment_status = ANY (ARRAY['not_deployed'::text, 'staging'::text, 'canary'::text, 'production'::text, 'rollback'::text, 'decommissioned'::text])))
);


--
-- Name: ai_alert_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_alert_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    rule_name character varying(100) NOT NULL,
    condition_type character varying(50) NOT NULL,
    condition_config jsonb DEFAULT '{}'::jsonb,
    severity character varying(20) DEFAULT 'warning'::character varying,
    message_template text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_budgets (
    budget_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    period text DEFAULT 'monthly'::text NOT NULL,
    monthly_usd_limit numeric(12,4) NOT NULL,
    soft_cap_percent integer DEFAULT 80 NOT NULL,
    warn_emails text[] DEFAULT ARRAY[]::text[] NOT NULL,
    effective_from date DEFAULT CURRENT_DATE NOT NULL,
    effective_until date,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_budgets_monthly_usd_limit_check CHECK ((monthly_usd_limit > (0)::numeric)),
    CONSTRAINT ai_budgets_period_check CHECK ((period = ANY (ARRAY['monthly'::text, 'rolling_30d'::text, 'fiscal_quarter'::text]))),
    CONSTRAINT ai_budgets_soft_cap_percent_check CHECK (((soft_cap_percent >= 1) AND (soft_cap_percent <= 99))),
    CONSTRAINT ai_budgets_status_check CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text, 'expired'::text])))
);


--
-- Name: TABLE ai_budgets; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ai_budgets IS 'Wave 5.4 — tenant USD spend ceilings. Runtime enforcement reads SUM(cost_usd) from each tenant''s ai_agent_executions and compares to monthly_usd_limit. Hard cap → reject + DSOC alert.';


--
-- Name: ai_employee_kpi_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_employee_kpi_snapshots (
    snapshot_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    agent_id character varying(8) NOT NULL,
    kpi_code text NOT NULL,
    value_numeric numeric,
    value_text text,
    target_met boolean,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    computed_for_date date DEFAULT CURRENT_DATE NOT NULL,
    source text
);


--
-- Name: ai_employee_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_employee_reports (
    report_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    agent_id character varying(8) NOT NULL,
    shift_code text,
    deliverable_code text NOT NULL,
    title text NOT NULL,
    summary text,
    body jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    destination text DEFAULT 'manager_inbox'::text NOT NULL,
    status text DEFAULT 'filed'::text NOT NULL,
    acknowledged_by character varying(64),
    acknowledged_at timestamp with time zone,
    filed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_employee_shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_employee_shifts (
    shift_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    agent_id character varying(8) NOT NULL,
    shift_code text NOT NULL,
    cron_expr text NOT NULL,
    local_to_tenant boolean DEFAULT true NOT NULL,
    produces text NOT NULL,
    per_tenant boolean DEFAULT true NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_impact_assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_impact_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    model_id uuid NOT NULL,
    created_by uuid NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    risk_level character varying(20),
    overall_risk_score numeric(5,2),
    sections_json jsonb DEFAULT '[]'::jsonb,
    recommendations_json jsonb DEFAULT '[]'::jsonb,
    classification_json jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_smoke_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_smoke_scores (
    score_id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_code text NOT NULL,
    score numeric(5,4) NOT NULL,
    matched integer DEFAULT 0 NOT NULL,
    total integer DEFAULT 0 NOT NULL,
    trace_ref text,
    prompt_version text,
    evaluated_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT ai_smoke_scores_score_check CHECK (((score >= (0)::numeric) AND (score <= (1)::numeric)))
);


--
-- Name: ai_system_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_system_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    system_name character varying(255) NOT NULL,
    description text,
    risk_level character varying(50) DEFAULT 'medium'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    purpose text,
    sector character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ai_system_registry_risk_level_check CHECK (((risk_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT ai_system_registry_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'deprecated'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: alert_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_definitions (
    alert_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    severity character varying(20) NOT NULL,
    alert_class character varying(20) NOT NULL,
    condition text DEFAULT ''::text NOT NULL,
    threshold_value numeric DEFAULT 0 NOT NULL,
    comparison_operator character varying(10) DEFAULT 'gte'::character varying NOT NULL,
    owner_role character varying(255) DEFAULT ''::character varying NOT NULL,
    runbook_id character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alert_definitions_alert_class_check CHECK (((alert_class)::text = ANY (ARRAY[('page'::character varying)::text, ('warn'::character varying)::text, ('info'::character varying)::text]))),
    CONSTRAINT alert_definitions_comparison_operator_check CHECK (((comparison_operator)::text = ANY (ARRAY[('lt'::character varying)::text, ('lte'::character varying)::text, ('gt'::character varying)::text, ('gte'::character varying)::text]))),
    CONSTRAINT alert_definitions_severity_check CHECK (((severity)::text = ANY (ARRAY[('critical'::character varying)::text, ('high'::character varying)::text, ('medium'::character varying)::text, ('low'::character varying)::text, ('info'::character varying)::text])))
);


--
-- Name: alert_handler_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_handler_registry (
    handler_id character varying(255) NOT NULL,
    module_code character varying(255) DEFAULT 'unknown'::character varying NOT NULL,
    registered_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    key_id character varying(255) NOT NULL,
    hashed_key character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    scopes jsonb DEFAULT '[]'::jsonb NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_chains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_chains (
    chain_id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    entity_type character varying(100) NOT NULL,
    steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    request_id uuid DEFAULT gen_random_uuid() NOT NULL,
    chain_id uuid NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(200) NOT NULL,
    current_step integer DEFAULT 1 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    submitted_by character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT approval_requests_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text, ('escalated'::character varying)::text])))
);


--
-- Name: approval_steps_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_steps_log (
    log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id uuid NOT NULL,
    step_number integer NOT NULL,
    action character varying(20) NOT NULL,
    actor_id character varying(200) NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT approval_steps_log_action_check CHECK (((action)::text = ANY (ARRAY[('submitted'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text, ('delegated'::character varying)::text, ('escalated'::character varying)::text])))
);


--
-- Name: as_built_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.as_built_ledger (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    category text NOT NULL,
    name text NOT NULL,
    owner text NOT NULL,
    owner_layer text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    runtime_dependencies jsonb DEFAULT '[]'::jsonb NOT NULL,
    known_limitations jsonb DEFAULT '[]'::jsonb NOT NULL,
    handover_notes text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT as_built_ledger_category_check CHECK ((category = ANY (ARRAY['service'::text, 'migration'::text, 'config'::text, 'contract'::text, 'schema'::text, 'integration'::text, 'deployment'::text, 'other'::text]))),
    CONSTRAINT as_built_ledger_owner_layer_check CHECK ((owner_layer = ANY (ARRAY['DOS'::text, 'DAuth'::text, 'Product'::text, 'Module'::text, 'AI'::text])))
);


--
-- Name: asset_classification_scheme; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_classification_scheme (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    classification_code character varying(30) NOT NULL,
    classification_label character varying(100) NOT NULL,
    classification_level integer NOT NULL,
    description text,
    handling_requirements text,
    access_controls text,
    color character varying(7) DEFAULT '#000000'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: asset_ownership_matrix; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_ownership_matrix (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_type character varying(50) NOT NULL,
    default_owner_role character varying(50),
    default_custodian_role character varying(50),
    review_frequency_days integer DEFAULT 365,
    classification_required boolean DEFAULT true,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_trail_global; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_trail_global (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT audit_trail_id_not_null NOT NULL,
    tenant_id character varying(255),
    user_id character varying(255),
    module character varying(100),
    action character varying(100),
    entity_type character varying(100),
    entity_id character varying(255),
    before_state jsonb,
    after_state jsonb,
    created_at timestamp with time zone DEFAULT now(),
    module_name character varying(255)
);


--
-- Name: audit_trail; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.audit_trail AS
 SELECT id,
    tenant_id,
    user_id,
    module,
    action,
    entity_type,
    entity_id,
    before_state,
    after_state,
    created_at,
    module_name
   FROM public.audit_trail_global;


--
-- Name: authorization_audit_log; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.authorization_audit_log AS
 SELECT id,
    user_id,
    tenant_id,
    action,
    resource,
    decision,
    reason,
    metadata,
    created_at
   FROM platform_dauth.authorization_audit_log;


--
-- Name: autonomous_engine_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.autonomous_engine_log (
    log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    evidence_alerts integer DEFAULT 0,
    policy_alerts integer DEFAULT 0,
    vendor_alerts integer DEFAULT 0,
    risk_drifts integer DEFAULT 0,
    compliance_gaps integer DEFAULT 0,
    control_issues integer DEFAULT 0,
    sla_warnings integer DEFAULT 0,
    framework_gaps integer DEFAULT 0,
    privacy_alerts integer DEFAULT 0,
    remediations_created integer DEFAULT 0,
    total_actions integer DEFAULT 0,
    cycle_ms integer DEFAULT 0,
    warnings jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: bcp_bia_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcp_bia_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_code character varying(50) NOT NULL,
    template_name character varying(200) NOT NULL,
    description text,
    impact_categories jsonb DEFAULT '["financial", "operational", "regulatory", "reputational"]'::jsonb,
    time_frames jsonb DEFAULT '["1h", "4h", "8h", "24h", "48h", "1w", "2w", "1m"]'::jsonb,
    questions jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: bcp_crisis_teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcp_crisis_teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_name character varying(100) NOT NULL,
    team_type character varying(30) DEFAULT 'crisis_management'::character varying,
    members jsonb DEFAULT '[]'::jsonb,
    activation_criteria text,
    communication_plan jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT bcp_crisis_teams_team_type_check CHECK (((team_type)::text = ANY ((ARRAY['crisis_management'::character varying, 'emergency_response'::character varying, 'business_recovery'::character varying, 'communications'::character varying, 'it_recovery'::character varying])::text[])))
);


--
-- Name: bcp_exercise_schedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcp_exercise_schedule (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exercise_type character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    scheduled_date date,
    frequency_days integer DEFAULT 365,
    plan_id uuid,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    results jsonb DEFAULT '{}'::jsonb,
    lessons_learned text,
    created_by character varying(64) DEFAULT 'system'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT bcp_exercise_schedule_exercise_type_check CHECK (((exercise_type)::text = ANY ((ARRAY['tabletop'::character varying, 'walkthrough'::character varying, 'simulation'::character varying, 'full_test'::character varying, 'notification_drill'::character varying])::text[]))),
    CONSTRAINT bcp_exercise_schedule_status_check CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'postponed'::character varying])::text[])))
);


--
-- Name: bcp_rto_rpo_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcp_rto_rpo_defaults (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    process_category character varying(50) NOT NULL,
    process_label character varying(100) NOT NULL,
    default_rto_hours integer DEFAULT 24 NOT NULL,
    default_rpo_hours integer DEFAULT 4 NOT NULL,
    criticality character varying(20) DEFAULT 'medium'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: compliance_export_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_export_jobs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    scope_type text NOT NULL,
    format text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    query jsonb NOT NULL,
    result_url text,
    error_code text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    CONSTRAINT compliance_export_jobs_format_check CHECK ((format = ANY (ARRAY['csv'::text, 'xlsx'::text, 'pdf'::text, 'json'::text]))),
    CONSTRAINT compliance_export_jobs_progress_check CHECK (((progress >= 0) AND (progress <= 100))),
    CONSTRAINT compliance_export_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'succeeded'::text, 'failed'::text, 'cancelled'::text])))
);


--
-- Name: compliance_module_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_module_config (
    id bigint NOT NULL,
    tenant_id text,
    kind text NOT NULL,
    type text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT compliance_module_config_kind_check CHECK ((kind = ANY (ARRAY['list'::text, 'detail'::text, 'form'::text, 'filters'::text, 'columns'::text, 'actions'::text, 'views'::text])))
);


--
-- Name: compliance_module_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_module_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_module_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_module_config_id_seq OWNED BY public.compliance_module_config.id;


--
-- Name: compliance_user_view_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_user_view_preferences (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    view_key text NOT NULL,
    scope_type text NOT NULL,
    payload jsonb NOT NULL,
    is_shared boolean DEFAULT false NOT NULL,
    shared_with text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: compliance_user_view_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compliance_user_view_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compliance_user_view_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compliance_user_view_preferences_id_seq OWNED BY public.compliance_user_view_preferences.id;


--
-- Name: conditional_access_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conditional_access_policies (
    policy_code character varying(255) NOT NULL,
    conditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    action character varying(20) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT conditional_access_policies_action_check CHECK (((action)::text = ANY (ARRAY[('allow'::character varying)::text, ('deny'::character varying)::text, ('require_mfa'::character varying)::text])))
);


--
-- Name: config_runtime_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_runtime_overrides (
    config_key character varying(255) NOT NULL,
    config_value text NOT NULL,
    set_by character varying(255) NOT NULL,
    set_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: content_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_packs (
    pack_code character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    modules jsonb DEFAULT '[]'::jsonb NOT NULL,
    seeds jsonb DEFAULT '[]'::jsonb NOT NULL,
    version character varying(50) DEFAULT '1.0.0'::character varying NOT NULL
);


--
-- Name: contract_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_catalog (
    contract_code character varying(100) CONSTRAINT contract_catalog_contract_code_not_null1 NOT NULL,
    name character varying(255) NOT NULL,
    owner character varying(100) NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    schema_definition jsonb,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    readers text[] DEFAULT '{}'::text[],
    writers text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contract_catalog_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_catalog_legacy (
    contract_id character varying(64) CONSTRAINT contract_catalog_contract_id_not_null NOT NULL,
    contract_code character varying(200) CONSTRAINT contract_catalog_contract_code_not_null NOT NULL,
    provider character varying(100),
    consumer character varying(100),
    version character varying(20),
    schema jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: copilot_leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.copilot_leads (
    lead_id uuid DEFAULT gen_random_uuid() NOT NULL,
    intent text NOT NULL,
    email text,
    company text,
    role_title text,
    message text,
    visitor_ip inet,
    user_agent text,
    source text,
    session_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    routed_to text,
    routed_at timestamp with time zone,
    status text DEFAULT 'new'::text NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT copilot_leads_intent_check CHECK ((intent = ANY (ARRAY['demo'::text, 'contact'::text, 'pricing'::text, 'docs'::text, 'general'::text]))),
    CONSTRAINT copilot_leads_status_check CHECK ((status = ANY (ARRAY['new'::text, 'routed'::text, 'contacted'::text, 'converted'::text, 'rejected'::text])))
);


--
-- Name: copilot_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.copilot_messages (
    message_id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying(255) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    agent_id character varying(10),
    tool_calls jsonb DEFAULT '[]'::jsonb,
    tokens_in integer DEFAULT 0,
    tokens_out integer DEFAULT 0,
    duration_ms integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT copilot_messages_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'assistant'::character varying, 'system'::character varying])::text[])))
);


--
-- Name: copilot_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.copilot_sessions (
    session_id character varying(255) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id character varying(255) NOT NULL,
    agent_id character varying(10),
    page_context text,
    message_count integer DEFAULT 0,
    started_at timestamp with time zone DEFAULT now(),
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: csrf_failures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csrf_failures (
    failure_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16),
    session_id character varying(64),
    user_id character varying(64),
    ip_address inet,
    user_agent text,
    path character varying(512) NOT NULL,
    method character varying(10) NOT NULL,
    reason character varying(100) NOT NULL,
    hint_returned character varying(50),
    correlation_id character varying(64),
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: csrf_security_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csrf_security_policies (
    policy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    token_max_age_ms integer DEFAULT 14400000 NOT NULL,
    rotation_interval_ms integer DEFAULT 60000 NOT NULL,
    grace_window_ms integer DEFAULT 5000 NOT NULL,
    enforcement_mode character varying(20) DEFAULT 'block'::character varying NOT NULL,
    same_ip_required boolean DEFAULT false NOT NULL,
    same_ua_required boolean DEFAULT true NOT NULL,
    max_failures_per_window integer DEFAULT 10 NOT NULL,
    failure_window_ms integer DEFAULT 300000 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by character varying(64),
    updated_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dead_letter_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dead_letter_queue (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT dead_letter_queue_id_not_null1 NOT NULL,
    event_id uuid NOT NULL,
    event_type character varying(255) NOT NULL,
    payload jsonb NOT NULL,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_retry_at timestamp with time zone
);


--
-- Name: dead_letter_queue_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dead_letter_queue_legacy (
    id integer CONSTRAINT dead_letter_queue_id_not_null NOT NULL,
    event_type character varying(100),
    payload jsonb,
    error text,
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: dead_letter_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dead_letter_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dead_letter_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dead_letter_queue_id_seq OWNED BY public.dead_letter_queue_legacy.id;


--
-- Name: default_navigation_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.default_navigation_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nav_key character varying(80) NOT NULL,
    parent_key character varying(80),
    label_en text NOT NULL,
    label_ar text,
    route text,
    icon character varying(60),
    module_code character varying(50),
    nav_type character varying(20) DEFAULT 'link'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: dos_compatibility_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_compatibility_records (
    compatibility_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid NOT NULL,
    artifact_type character varying(50) NOT NULL,
    artifact_code character varying(255) NOT NULL,
    change_class character varying(30) NOT NULL,
    impact character varying(30) NOT NULL,
    affected_consumers jsonb DEFAULT '[]'::jsonb NOT NULL,
    migration_required boolean DEFAULT false NOT NULL,
    deprecation_notice_required boolean DEFAULT false NOT NULL,
    breaking_change_approval_id uuid,
    notes text,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_cutover_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_cutover_executions (
    execution_id uuid DEFAULT gen_random_uuid() NOT NULL,
    cutover_id uuid NOT NULL,
    release_id uuid NOT NULL,
    status character varying(30) DEFAULT 'planned'::character varying NOT NULL,
    current_checkpoint character varying(255),
    passed_checkpoints jsonb DEFAULT '[]'::jsonb NOT NULL,
    no_go_triggered boolean DEFAULT false NOT NULL,
    no_go_reason text,
    executed_by character varying(255) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    aborted_at timestamp with time zone,
    notes text
);


--
-- Name: dos_cutover_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_cutover_plans (
    cutover_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid NOT NULL,
    scope character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    execution_sequence jsonb DEFAULT '[]'::jsonb NOT NULL,
    checkpoints jsonb DEFAULT '[]'::jsonb NOT NULL,
    no_go_criteria jsonb DEFAULT '[]'::jsonb NOT NULL,
    rollback_triggers jsonb DEFAULT '[]'::jsonb NOT NULL,
    communication_path character varying(500) NOT NULL,
    monitoring_window_minutes integer DEFAULT 60 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_feature_gates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_feature_gates (
    gate_code character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    state character varying(30) DEFAULT 'off'::character varying NOT NULL,
    rollout_percent integer DEFAULT 0 NOT NULL,
    allowed_roles jsonb DEFAULT '[]'::jsonb NOT NULL,
    allowed_tenants jsonb DEFAULT '[]'::jsonb NOT NULL,
    owner_layer character varying(100) NOT NULL,
    owner_code character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_handover_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_handover_locks (
    lock_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid NOT NULL,
    as_built_updated boolean DEFAULT false NOT NULL,
    migrations_verified boolean DEFAULT false NOT NULL,
    release_notes_finalized boolean DEFAULT false NOT NULL,
    known_risks_updated boolean DEFAULT false NOT NULL,
    operational_dashboards_confirmed boolean DEFAULT false NOT NULL,
    support_owner_confirmed boolean DEFAULT false NOT NULL,
    cutover_outcome text,
    rollback_outcome text,
    locked_at timestamp with time zone,
    locked_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_handover_risks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_handover_risks (
    risk_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid NOT NULL,
    description text NOT NULL,
    severity character varying(20) NOT NULL,
    owner character varying(255) NOT NULL,
    mitigation_notes text,
    carry_forward boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_migrations (
    migration_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid,
    migration_type character varying(50) NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    reversible boolean DEFAULT true NOT NULL,
    compatibility_impact character varying(30) NOT NULL,
    affected_schemas jsonb DEFAULT '[]'::jsonb NOT NULL,
    affected_tables jsonb DEFAULT '[]'::jsonb NOT NULL,
    validation_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    rollback_notes text,
    tenant_impact text,
    irreversible_approval_id uuid,
    tenant_id character varying(255),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    failure_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_quality_gates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_quality_gates (
    gate_id uuid DEFAULT gen_random_uuid() NOT NULL,
    gate_code character varying(255) NOT NULL,
    release_id uuid NOT NULL,
    category character varying(50) NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    owner character varying(255) NOT NULL,
    pass_threshold numeric,
    actual_value numeric,
    notes text,
    evaluated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_release_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_release_approvals (
    approval_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid NOT NULL,
    approval_role character varying(255) NOT NULL,
    required_by character varying(255) NOT NULL,
    approved_by character varying(255),
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    comments text,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


--
-- Name: dos_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_releases (
    release_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_code character varying(255) NOT NULL,
    version character varying(100) NOT NULL,
    risk_class character varying(30) NOT NULL,
    status character varying(30) DEFAULT 'draft'::character varying NOT NULL,
    affected_layers jsonb DEFAULT '[]'::jsonb NOT NULL,
    affected_products jsonb DEFAULT '[]'::jsonb NOT NULL,
    affected_modules jsonb DEFAULT '[]'::jsonb NOT NULL,
    migrations jsonb DEFAULT '[]'::jsonb NOT NULL,
    approvals_required jsonb DEFAULT '[]'::jsonb NOT NULL,
    approvals_met jsonb DEFAULT '[]'::jsonb NOT NULL,
    rollback_plan_id uuid,
    smoke_test_inventory jsonb DEFAULT '[]'::jsonb NOT NULL,
    support_owner character varying(255),
    cutover_window_start timestamp with time zone,
    cutover_window_end timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_verification_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_verification_checks (
    check_id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    release_id uuid NOT NULL,
    check_code character varying(255) NOT NULL,
    category character varying(50) NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    owner character varying(255) NOT NULL,
    duration_ms integer,
    failure_detail text,
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_verification_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dos_verification_runs (
    run_id uuid DEFAULT gen_random_uuid() NOT NULL,
    release_id uuid NOT NULL,
    deployment_id uuid NOT NULL,
    status character varying(30) DEFAULT 'running'::character varying NOT NULL,
    total_checks integer DEFAULT 0 NOT NULL,
    passed_checks integer DEFAULT 0 NOT NULL,
    failed_checks integer DEFAULT 0 NOT NULL,
    skipped_checks integer DEFAULT 0 NOT NULL,
    rollback_decision character varying(30),
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    completed_by character varying(255)
);


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verification_tokens (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    token_hash character varying(128) NOT NULL,
    email character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    verified boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    used_at timestamp with time zone,
    verified_at timestamp with time zone
);


--
-- Name: email_verification_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_verification_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_verification_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_verification_tokens_id_seq OWNED BY public.email_verification_tokens.id;


--
-- Name: enforcement_check_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enforcement_check_results (
    id uuid NOT NULL,
    run_id character varying(100) NOT NULL,
    check_name character varying(100) NOT NULL,
    law_ref character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    findings jsonb DEFAULT '[]'::jsonb,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT enforcement_check_results_status_check CHECK (((status)::text = ANY (ARRAY[('PASS'::character varying)::text, ('CONDITIONAL_PASS'::character varying)::text, ('FAIL'::character varying)::text])))
);


--
-- Name: enforcement_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enforcement_runs (
    run_id character varying(100) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    verdict character varying(20) NOT NULL,
    total_duration_ms integer,
    check_count integer DEFAULT 0 NOT NULL,
    fail_count integer DEFAULT 0 NOT NULL,
    triggered_by character varying(50) DEFAULT 'manual'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT enforcement_runs_verdict_check CHECK (((verdict)::text = ANY (ARRAY[('PASS'::character varying)::text, ('CONDITIONAL_PASS'::character varying)::text, ('FAIL'::character varying)::text])))
);


--
-- Name: event_traces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_traces (
    event_id uuid NOT NULL,
    event_type character varying(255) CONSTRAINT event_traces_event_type_not_null1 NOT NULL,
    correlation_id character varying(255),
    status character varying(20) DEFAULT 'in_progress'::character varying NOT NULL,
    spans jsonb DEFAULT '[]'::jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    duration_ms integer
);


--
-- Name: event_traces_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_traces_legacy (
    trace_id character varying(64) CONSTRAINT event_traces_trace_id_not_null NOT NULL,
    event_type character varying(100) CONSTRAINT event_traces_event_type_not_null NOT NULL,
    source character varying(100),
    payload jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: feature_flag_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flag_overrides (
    id integer NOT NULL,
    flag_code character varying(100) NOT NULL,
    scope_type character varying(20) DEFAULT 'global'::character varying,
    scope_id character varying(64),
    enabled boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: feature_flag_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feature_flag_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_flag_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feature_flag_overrides_id_seq OWNED BY public.feature_flag_overrides.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.findings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    finding_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    title text,
    severity character varying(30),
    status character varying(30) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.foundation_schema_migrations (
    filename text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: framework_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.framework_registry (
    framework_code character varying(80) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    summary_en text,
    summary_ar text,
    category character varying(50),
    regulatory_authority character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: grc_architecture_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_architecture_map (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    grc_layer text,
    framework_code text NOT NULL,
    framework_name text,
    issuing_authority text,
    grc_pillar text,
    compliance_type text,
    feeds_into text,
    conflicts_with text,
    gap_filled text,
    hc_iot_weight text,
    priority_tier text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_audit_universe; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_audit_universe (
    audit_id text NOT NULL,
    sector text,
    audit_area text NOT NULL,
    frameworks_covered text,
    audit_type text,
    auditor text,
    frequency text,
    scope_who text,
    key_evidence_tested text,
    risk_rating text,
    est_days text,
    regulatory_deadline text,
    framework_verified text,
    linked_kris text,
    shahin_ai_priority text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_framework_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_framework_dependencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_code text NOT NULL,
    target_code text NOT NULL,
    relationship text,
    notes text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_frameworks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    framework_code text NOT NULL,
    framework_name_en text NOT NULL,
    framework_name_ar text,
    regulator_code text NOT NULL,
    group_code text,
    current_version text,
    year_first_issued text,
    controls_count text,
    framework_type text,
    role text,
    scope text,
    hc_iot_relevance text,
    official_source_url text,
    grc_pillar text,
    applicable_sectors text,
    is_cross_sector boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_kri_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_kri_catalog (
    kri_id text NOT NULL,
    sector text,
    kri_name text NOT NULL,
    framework_source text,
    grc_pillar text,
    risk_domain text,
    measurement_formula text,
    threshold_green text,
    threshold_amber text,
    threshold_red text,
    data_source text,
    owner text,
    frequency text,
    ksa_benchmark text,
    framework_verified text,
    regulator_hc_iot text,
    shahin_ai_tier text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_maturity_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_maturity_model (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    domain_sector text NOT NULL,
    level1_initial text,
    level2_developing text,
    level3_defined text,
    level4_managed text,
    level5_optimising text,
    typical_ksa_2024 text,
    ghicga_target text,
    evidence_at_l3 text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_regulators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_regulators (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    regulator_code text NOT NULL,
    regulator_name text NOT NULL,
    group_code text,
    tier text,
    primary_source_url text,
    own_frameworks_count integer DEFAULT 0 NOT NULL,
    must_comply_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_risk_domain_coverage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_risk_domain_coverage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    framework_code text NOT NULL,
    cyber_risk text,
    privacy_risk text,
    clinical_safety text,
    operational_risk text,
    regulatory_risk text,
    reputational_risk text,
    strategic_risk text,
    supply_chain_risk text,
    financial_risk text,
    availability_risk text,
    cross_border_risk text,
    coverage_score text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: grc_sector_framework_matrix; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_sector_framework_matrix (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    framework_code text NOT NULL,
    group_code text NOT NULL,
    applicability text DEFAULT 'N'::text NOT NULL
);


--
-- Name: grc_sector_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grc_sector_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_code text NOT NULL,
    group_name text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: iam_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iam_identities (
    id bigint NOT NULL,
    user_id character varying(64) NOT NULL,
    provider text NOT NULL,
    external_subject text NOT NULL,
    realm text,
    external_username text,
    external_email text,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT iam_identities_status_check CHECK ((status = ANY (ARRAY['active'::text, 'disabled'::text, 'deleted'::text])))
);


--
-- Name: TABLE iam_identities; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.iam_identities IS 'Cross-reference between public.users.user_id and external identity provider subjects. One user may have multiple rows (e.g., migrated from native → keycloak). UNIQUE(provider, external_subject, realm) prevents duplicate mappings within a realm.';


--
-- Name: COLUMN iam_identities.external_subject; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.iam_identities.external_subject IS 'Provider-assigned opaque user identifier. For Keycloak this is the user UUID; for SAML the NameID; for OIDC the sub claim.';


--
-- Name: COLUMN iam_identities.realm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.iam_identities.realm IS 'Provider realm / tenant. For Keycloak: KEYCLOAK_REALM at the time of mapping. NULL for providers without realms.';


--
-- Name: iam_identities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.iam_identities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: iam_identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.iam_identities_id_seq OWNED BY public.iam_identities.id;


--
-- Name: incident_notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incident_notification_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_code character varying(50) NOT NULL,
    template_name character varying(100) NOT NULL,
    subject_template text,
    body_template text,
    channels text[] DEFAULT '{email}'::text[],
    trigger_event character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: incident_response_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incident_response_actions (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id uuid NOT NULL,
    action_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    assigned_to character varying(64),
    due_date date,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    priority character varying(20),
    outcome text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: incident_response_teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incident_response_teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_name character varying(100) NOT NULL,
    team_type character varying(30) DEFAULT 'primary'::character varying,
    members jsonb DEFAULT '[]'::jsonb,
    on_call_schedule jsonb DEFAULT '{}'::jsonb,
    notification_channels text[] DEFAULT '{}'::text[],
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT incident_response_teams_team_type_check CHECK (((team_type)::text = ANY ((ARRAY['primary'::character varying, 'escalation'::character varying, 'executive'::character varying, 'external'::character varying])::text[])))
);


--
-- Name: incident_severity_matrix; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incident_severity_matrix (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    severity_code character varying(20) NOT NULL,
    severity_label character varying(50) NOT NULL,
    severity_level integer NOT NULL,
    sla_response_hours integer DEFAULT 4 NOT NULL,
    sla_resolution_hours integer DEFAULT 24 NOT NULL,
    escalation_role character varying(50) DEFAULT 'admin'::character varying,
    notification_template character varying(50),
    color character varying(7) DEFAULT '#ff0000'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: incident_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incident_updates (
    update_id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id uuid NOT NULL,
    update_type character varying(50) NOT NULL,
    update_text text,
    updated_by character varying(64),
    status_change_from character varying(30),
    status_change_to character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: invitations; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.invitations AS
 SELECT invitation_id,
    tenant_id,
    email,
    role_code,
    invited_by,
    status,
    token,
    expires_at,
    created_at,
    accepted_at
   FROM platform_dauth.invitations;


--
-- Name: job_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_registry (
    job_name character varying(100) NOT NULL,
    cron_expression character varying(100) NOT NULL,
    enabled boolean DEFAULT true,
    last_run_at timestamp with time zone,
    last_status character varying(20),
    last_error text,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: jwt_signing_keys; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.jwt_signing_keys AS
 SELECT kid,
    secret,
    algorithm,
    status,
    created_at,
    retired_at,
    expires_at
   FROM platform_dauth.jwt_signing_keys;


--
-- Name: lifecycle_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lifecycle_checkpoints (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT lifecycle_checkpoints_id_not_null1 NOT NULL,
    tenant_id uuid NOT NULL,
    entity_type character varying(100) CONSTRAINT lifecycle_checkpoints_entity_type_not_null1 NOT NULL,
    entity_id uuid CONSTRAINT lifecycle_checkpoints_entity_id_not_null1 NOT NULL,
    label character varying(255),
    state_data jsonb NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lifecycle_checkpoints_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lifecycle_checkpoints_legacy (
    id integer CONSTRAINT lifecycle_checkpoints_id_not_null NOT NULL,
    entity_type character varying(50) CONSTRAINT lifecycle_checkpoints_entity_type_not_null NOT NULL,
    entity_id character varying(64) CONSTRAINT lifecycle_checkpoints_entity_id_not_null NOT NULL,
    checkpoint character varying(100) CONSTRAINT lifecycle_checkpoints_checkpoint_not_null NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: lifecycle_checkpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lifecycle_checkpoints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lifecycle_checkpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lifecycle_checkpoints_id_seq OWNED BY public.lifecycle_checkpoints_legacy.id;


--
-- Name: lifecycle_transitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lifecycle_transitions (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT lifecycle_transitions_id_not_null1 NOT NULL,
    module_code character varying(100) NOT NULL,
    entity_type character varying(100) CONSTRAINT lifecycle_transitions_entity_type_not_null1 NOT NULL,
    from_state character varying(100) NOT NULL,
    to_state character varying(100) CONSTRAINT lifecycle_transitions_to_state_not_null1 NOT NULL,
    guard_conditions jsonb DEFAULT '[]'::jsonb,
    required_permission character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lifecycle_transitions_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lifecycle_transitions_legacy (
    id integer CONSTRAINT lifecycle_transitions_id_not_null NOT NULL,
    entity_type character varying(50) CONSTRAINT lifecycle_transitions_entity_type_not_null NOT NULL,
    entity_id character varying(64) CONSTRAINT lifecycle_transitions_entity_id_not_null NOT NULL,
    from_state character varying(50),
    to_state character varying(50) CONSTRAINT lifecycle_transitions_to_state_not_null NOT NULL,
    changed_by character varying(64),
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: lifecycle_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lifecycle_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lifecycle_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lifecycle_transitions_id_seq OWNED BY public.lifecycle_transitions_legacy.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    attempt_id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    ip_address inet,
    success boolean NOT NULL,
    attempted_at timestamp with time zone DEFAULT now()
);


--
-- Name: lookup_cbb_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cbb_categories (
    category_code character varying(30) NOT NULL,
    category_name_en text NOT NULL,
    category_type character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_cbb_categories_category_type_check CHECK (((category_type)::text = ANY (ARRAY[('conventional'::character varying)::text, ('islamic'::character varying)::text])))
);


--
-- Name: lookup_cbe_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cbe_categories (
    category_code character varying(30) NOT NULL,
    category_name_en text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_cbk_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cbk_licenses (
    license_code character varying(30) NOT NULL,
    license_name_en text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_cbo_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cbo_licenses (
    license_code character varying(30) NOT NULL,
    license_name_en text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_cbuae_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cbuae_categories (
    category_code character varying(30) NOT NULL,
    category_name_en text NOT NULL,
    entity_type character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_cbuae_categories_entity_type_check CHECK (((entity_type)::text = ANY (ARRAY[('bank'::character varying)::text, ('insurance'::character varying)::text, ('broker'::character varying)::text, ('exchange'::character varying)::text, ('payment'::character varying)::text])))
);


--
-- Name: lookup_cities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cities (
    city_code character varying(30) NOT NULL,
    country_code character varying(2) NOT NULL,
    city_name_en text NOT NULL,
    city_name_ar text,
    state_code character varying(20),
    region character varying(50),
    timezone character varying(40),
    is_capital boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_cloud_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cloud_providers (
    provider_code character varying(20) NOT NULL,
    provider_name text NOT NULL,
    provider_type character varying(20) NOT NULL,
    regions_available text[],
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT lookup_cloud_providers_provider_type_check CHECK (((provider_type)::text = ANY (ARRAY[('public'::character varying)::text, ('private'::character varying)::text, ('hybrid'::character varying)::text, ('sovereign'::character varying)::text])))
);


--
-- Name: lookup_cloud_regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_cloud_regions (
    region_code character varying(30) NOT NULL,
    provider_code character varying(20) NOT NULL,
    region_name text NOT NULL,
    region_location text,
    data_residency character varying(50),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_compliance_frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_compliance_frameworks (
    framework_code character varying(30) NOT NULL,
    framework_name_en text NOT NULL,
    jurisdiction character varying(50),
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_countries (
    country_code character varying(2) NOT NULL,
    country_code_3 character varying(3),
    name_en text NOT NULL,
    name_ar text,
    flag_emoji text,
    dial_code character varying(10),
    continent character varying(30),
    currency_code character varying(3),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_dfsa_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_dfsa_licenses (
    license_code character varying(30) NOT NULL,
    license_name_en text NOT NULL,
    license_category character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_dfsa_licenses_license_category_check CHECK (((license_category)::text = ANY (ARRAY[('category1'::character varying)::text, ('category2'::character varying)::text, ('category3'::character varying)::text, ('category4'::character varying)::text, ('category5'::character varying)::text])))
);


--
-- Name: lookup_employee_ranges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_employee_ranges (
    range_code character varying(20) NOT NULL,
    range_label_en text NOT NULL,
    range_label_ar text,
    min_employees integer,
    max_employees integer,
    enterprise_type character varying(20),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_frameworks (
    framework_code character varying(30) NOT NULL,
    framework_name text NOT NULL,
    framework_acronym character varying(20),
    regulatory_body character varying(50),
    jurisdiction character varying(50),
    compliance_level character varying(20),
    category character varying(30),
    is_mandatory boolean DEFAULT false NOT NULL,
    description_en text,
    description_ar text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_grc_role_staffing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_grc_role_staffing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    range_code character varying(20) NOT NULL,
    sector_code character varying(50) DEFAULT '*'::character varying,
    role_code character varying(100) NOT NULL,
    role_name_en text NOT NULL,
    role_name_ar text,
    role_category character varying(50) DEFAULT 'core'::character varying,
    recommended_fte numeric(4,1) DEFAULT 1.0 NOT NULL,
    is_mandatory boolean DEFAULT false NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    shahin_title_en text,
    shahin_title_ar text,
    description_en text,
    description_ar text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lookup_identity_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_identity_providers (
    provider_code character varying(30) NOT NULL,
    provider_name text NOT NULL,
    provider_type character varying(20) NOT NULL,
    is_enterprise boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT lookup_identity_providers_provider_type_check CHECK (((provider_type)::text = ANY (ARRAY[('saml'::character varying)::text, ('oidc'::character varying)::text, ('ldap'::character varying)::text, ('proprietary'::character varying)::text])))
);


--
-- Name: lookup_idsca_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_idsca_levels (
    level_code character varying(10) NOT NULL,
    level_name_en text NOT NULL,
    level_description text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_iso_cert_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_iso_cert_bodies (
    body_code character varying(30) NOT NULL,
    body_name text NOT NULL,
    accreditation text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_languages (
    language_code character varying(10) NOT NULL,
    language_name_en text NOT NULL,
    language_name_native text,
    rtl boolean DEFAULT false NOT NULL,
    is_primary boolean DEFAULT false NOT NULL
);


--
-- Name: lookup_nca_sectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_nca_sectors (
    sector_code character varying(30) NOT NULL,
    sector_name_en text NOT NULL,
    sector_name_ar text,
    criticality_level character varying(10) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_nca_sectors_criticality_level_check CHECK (((criticality_level)::text = ANY (ARRAY[('critical'::character varying)::text, ('important'::character varying)::text, ('standard'::character varying)::text])))
);


--
-- Name: lookup_ncec_sectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_ncec_sectors (
    sector_code character varying(30) NOT NULL,
    sector_name_en text NOT NULL,
    criticality character varying(10) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_ncec_sectors_criticality_check CHECK (((criticality)::text = ANY (ARRAY[('critical'::character varying)::text, ('important'::character varying)::text, ('standard'::character varying)::text])))
);


--
-- Name: lookup_org_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_org_types (
    type_code character varying(30) NOT NULL,
    type_name_en text NOT NULL,
    type_name_ar text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_pdpl_scopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_pdpl_scopes (
    scope_code character varying(20) NOT NULL,
    scope_name_en text NOT NULL,
    scope_name_ar text,
    dpo_required boolean DEFAULT false NOT NULL,
    cross_border_restricted boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_qcb_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_qcb_categories (
    category_code character varying(30) NOT NULL,
    category_name_en text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_risk_frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_risk_frameworks (
    framework_code character varying(30) NOT NULL,
    framework_name_en text NOT NULL,
    framework_type character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_risk_frameworks_framework_type_check CHECK (((framework_type)::text = ANY (ARRAY[('enterprise'::character varying)::text, ('it'::character varying)::text, ('operational'::character varying)::text, ('financial'::character varying)::text])))
);


--
-- Name: lookup_sama_license_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_sama_license_types (
    license_code character varying(30) NOT NULL,
    license_name_en text NOT NULL,
    license_name_ar text,
    entity_type character varying(30),
    csf_tier_default character varying(10),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE lookup_sama_license_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.lookup_sama_license_types IS 'SAMA license types for Saudi financial institutions';


--
-- Name: lookup_sama_tiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_sama_tiers (
    tier_code character varying(10) NOT NULL,
    tier_name_en text NOT NULL,
    tier_name_ar text,
    tier_description text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_sectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_sectors (
    sector_code character varying(20) NOT NULL,
    sector_name_en text NOT NULL,
    sector_name_ar text,
    parent_sector_code character varying(20),
    level integer DEFAULT 1 NOT NULL,
    icon_class text,
    typical_frameworks text[],
    description_en text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_siem_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_siem_providers (
    provider_code character varying(30) NOT NULL,
    provider_name text NOT NULL,
    deployment_type character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT lookup_siem_providers_deployment_type_check CHECK (((deployment_type)::text = ANY (ARRAY[('cloud'::character varying)::text, ('on-prem'::character varying)::text, ('hybrid'::character varying)::text])))
);


--
-- Name: lookup_sso_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_sso_providers (
    provider_code character varying(30) NOT NULL,
    provider_name text NOT NULL,
    protocol character varying(20),
    is_enterprise boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: lookup_sub_sectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_sub_sectors (
    sub_sector_code character varying(30) NOT NULL,
    sector_code character varying(20) NOT NULL,
    sub_sector_name_en text NOT NULL,
    sub_sector_name_ar text,
    description_en text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE lookup_sub_sectors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.lookup_sub_sectors IS 'Sub-sectors that cascade from parent sectors for onboarding branching';


--
-- Name: lookup_tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_tables (
    table_name text NOT NULL,
    display_name_en text NOT NULL,
    display_name_ar text,
    has_cascade boolean DEFAULT false NOT NULL,
    cascade_parent text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: lookup_team_functions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_team_functions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    function_code character varying(50) NOT NULL,
    function_name_en text NOT NULL,
    function_name_ar text,
    description_en text,
    description_ar text,
    category character varying(50) DEFAULT 'general'::character varying,
    is_core boolean DEFAULT false NOT NULL,
    min_org_size character varying(20) DEFAULT '1_10'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    typical_size_min integer,
    typical_size_max integer,
    is_grc_critical boolean DEFAULT false,
    required_for_sectors text[]
);


--
-- Name: lookup_timezones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_timezones (
    timezone_code character varying(40) NOT NULL,
    timezone_name text NOT NULL,
    utc_offset character varying(10),
    utc_offset_minutes integer DEFAULT 0 NOT NULL,
    countries text[]
);


--
-- Name: lookup_tra_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_tra_licenses (
    license_code character varying(30) NOT NULL,
    license_name_en text NOT NULL,
    service_type character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT lookup_tra_licenses_service_type_check CHECK (((service_type)::text = ANY (ARRAY[('mobile'::character varying)::text, ('fixed'::character varying)::text, ('internet'::character varying)::text, ('data_center'::character varying)::text])))
);


--
-- Name: lookup_uae_free_zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lookup_uae_free_zones (
    zone_code character varying(30) NOT NULL,
    zone_name_en text NOT NULL,
    zone_name_ar text,
    emirate character varying(20) NOT NULL,
    regulator text,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT lookup_uae_free_zones_emirate_check CHECK (((emirate)::text = ANY (ARRAY[('dubai'::character varying)::text, ('abu_dhabi'::character varying)::text, ('sharjah'::character varying)::text, ('ajman'::character varying)::text, ('ras_al_khaimah'::character varying)::text, ('fujairah'::character varying)::text, ('umm_al_quwain'::character varying)::text])))
);


--
-- Name: mcp_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_audit_log (
    log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    event_type text NOT NULL,
    actor_id character varying(64),
    actor_type character varying(20) DEFAULT 'human'::character varying NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mcp_audit_log_actor_type_check CHECK (((actor_type)::text = ANY ((ARRAY['human'::character varying, 'agent'::character varying, 'service_account'::character varying, 'external'::character varying])::text[])))
);

ALTER TABLE ONLY public.mcp_audit_log FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_prompt_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_prompt_registry (
    prompt_id uuid DEFAULT gen_random_uuid() NOT NULL,
    prompt_name character varying(128) NOT NULL,
    display_name_en character varying(255) NOT NULL,
    display_name_ar character varying(255) NOT NULL,
    description_en text NOT NULL,
    description_ar text,
    owner_module_code character varying(64) NOT NULL,
    agent_id character varying(20),
    domain_code character varying(64) NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    prompt_template text NOT NULL,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_mode character varying(30) DEFAULT 'text'::character varying NOT NULL,
    guardrails jsonb DEFAULT '{}'::jsonb NOT NULL,
    visibility_scope character varying(30) DEFAULT 'all'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    replaced_by character varying(128),
    change_notes text,
    is_enabled boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_by text DEFAULT 'system'::text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mcp_prompt_registry_output_mode_check CHECK (((output_mode)::text = ANY (ARRAY[('text'::character varying)::text, ('json'::character varying)::text, ('structured'::character varying)::text, ('stream'::character varying)::text]))),
    CONSTRAINT mcp_prompt_registry_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('active'::character varying)::text, ('deprecated'::character varying)::text, ('retired'::character varying)::text]))),
    CONSTRAINT mcp_prompt_registry_visibility_scope_check CHECK (((visibility_scope)::text = ANY (ARRAY[('all'::character varying)::text, ('internal'::character varying)::text, ('admin_only'::character varying)::text, ('beta'::character varying)::text])))
);


--
-- Name: mcp_prompts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_prompts (
    prompt_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    server_id uuid NOT NULL,
    prompt_name text NOT NULL,
    description text,
    arguments jsonb DEFAULT '[]'::jsonb NOT NULL,
    template text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.mcp_prompts FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_resource_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_resource_registry (
    resource_id uuid DEFAULT gen_random_uuid() NOT NULL,
    resource_name character varying(128) NOT NULL,
    display_name_en character varying(255) NOT NULL,
    display_name_ar character varying(255) NOT NULL,
    description_en text NOT NULL,
    description_ar text,
    uri_pattern text NOT NULL,
    owner_module_code character varying(64) NOT NULL,
    domain_code character varying(64) NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    resolver_key character varying(255) NOT NULL,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    sensitivity_level character varying(20) DEFAULT 'normal'::character varying NOT NULL,
    data_classification character varying(30) DEFAULT 'internal'::character varying NOT NULL,
    requires_permission text[] DEFAULT '{}'::text[] NOT NULL,
    visibility_scope character varying(30) DEFAULT 'all'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    replaced_by character varying(128),
    is_enabled boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_by text DEFAULT 'system'::text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mcp_resource_registry_data_classification_check CHECK (((data_classification)::text = ANY (ARRAY[('public'::character varying)::text, ('internal'::character varying)::text, ('confidential'::character varying)::text, ('restricted'::character varying)::text]))),
    CONSTRAINT mcp_resource_registry_sensitivity_level_check CHECK (((sensitivity_level)::text = ANY (ARRAY[('normal'::character varying)::text, ('elevated'::character varying)::text, ('high'::character varying)::text, ('critical'::character varying)::text]))),
    CONSTRAINT mcp_resource_registry_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('active'::character varying)::text, ('deprecated'::character varying)::text, ('retired'::character varying)::text]))),
    CONSTRAINT mcp_resource_registry_visibility_scope_check CHECK (((visibility_scope)::text = ANY (ARRAY[('all'::character varying)::text, ('internal'::character varying)::text, ('admin_only'::character varying)::text, ('beta'::character varying)::text])))
);


--
-- Name: mcp_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_resources (
    resource_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    server_id uuid NOT NULL,
    uri text NOT NULL,
    mime_type text,
    name text,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.mcp_resources FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    server_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    server_name text NOT NULL,
    transport text DEFAULT 'stdio'::text NOT NULL,
    endpoint text,
    auth_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'registered'::text NOT NULL,
    capabilities jsonb DEFAULT '{}'::jsonb NOT NULL,
    registered_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mcp_servers_status_check CHECK ((status = ANY (ARRAY['registered'::text, 'active'::text, 'inactive'::text, 'error'::text]))),
    CONSTRAINT mcp_servers_transport_check CHECK ((transport = ANY (ARRAY['stdio'::text, 'http'::text, 'sse'::text, 'streamable-http'::text])))
);

ALTER TABLE ONLY public.mcp_servers FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_sessions (
    session_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    server_id uuid NOT NULL,
    user_id character varying(64),
    agent_code character varying(100),
    actor_type character varying(20) DEFAULT 'human'::character varying NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    CONSTRAINT mcp_sessions_actor_type_check CHECK (((actor_type)::text = ANY ((ARRAY['human'::character varying, 'agent'::character varying, 'service_account'::character varying, 'external'::character varying])::text[]))),
    CONSTRAINT mcp_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'closed'::character varying, 'errored'::character varying])::text[])))
);

ALTER TABLE ONLY public.mcp_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_tool_invocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_tool_invocations (
    invocation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    session_id uuid NOT NULL,
    tool_id uuid,
    tool_name text NOT NULL,
    input jsonb,
    output jsonb,
    latency_ms integer,
    error text,
    actor_type character varying(20) DEFAULT 'human'::character varying NOT NULL,
    actor_id character varying(64),
    invoked_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.mcp_tool_invocations FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_tool_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_tool_registry (
    tool_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tool_name character varying(128) NOT NULL,
    display_name_en character varying(255) NOT NULL,
    display_name_ar character varying(255) NOT NULL,
    description_en text NOT NULL,
    description_ar text,
    agent_id character varying(20) NOT NULL,
    owner_module_code character varying(64) NOT NULL,
    domain_code character varying(64) NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    visibility_scope character varying(30) DEFAULT 'all'::character varying NOT NULL,
    execution_type character varying(30) DEFAULT 'internal_service'::character varying NOT NULL,
    handler_key character varying(255) NOT NULL,
    provider_key character varying(128),
    execution_config jsonb DEFAULT '{"async": false, "retries": 0, "timeout": 30000}'::jsonb NOT NULL,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_level character varying(20) DEFAULT 'low'::character varying NOT NULL,
    data_classification character varying(30) DEFAULT 'internal'::character varying NOT NULL,
    sensitivity_level character varying(20) DEFAULT 'normal'::character varying NOT NULL,
    required_permissions text[] DEFAULT '{}'::text[] NOT NULL,
    required_roles text[] DEFAULT '{}'::text[] NOT NULL,
    allowed_actor_types text[] DEFAULT ARRAY['human'::text, 'copilot'::text, 'assisted'::text, 'autonomous'::text] NOT NULL,
    allowed_platform_modes text[] DEFAULT ARRAY['human'::text, 'copilot'::text, 'assisted'::text, 'autonomous'::text, 'hyper'::text] NOT NULL,
    requires_tenant_context boolean DEFAULT true NOT NULL,
    requires_user_context boolean DEFAULT true NOT NULL,
    approval_mode character varying(30) DEFAULT 'none'::character varying NOT NULL,
    approval_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    min_autonomy character varying(10) DEFAULT 'L0'::character varying NOT NULL,
    max_autonomy character varying(10) DEFAULT 'L3'::character varying NOT NULL,
    default_autonomy character varying(10) DEFAULT 'L0'::character varying NOT NULL,
    human_review_on_error boolean DEFAULT true NOT NULL,
    human_review_on_sensitive_data boolean DEFAULT true NOT NULL,
    autonomous_retries_allowed integer DEFAULT 0 NOT NULL,
    max_calls_per_min integer DEFAULT 60 NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    retired_at timestamp with time zone,
    replaced_by character varying(128),
    change_notes text,
    is_enabled boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_by text DEFAULT 'system'::text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mcp_tool_registry_approval_mode_check CHECK (((approval_mode)::text = ANY (ARRAY[('none'::character varying)::text, ('single'::character varying)::text, ('multi_step'::character varying)::text, ('risk_based'::character varying)::text, ('manual_gate'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_data_classification_check CHECK (((data_classification)::text = ANY (ARRAY[('public'::character varying)::text, ('internal'::character varying)::text, ('confidential'::character varying)::text, ('restricted'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_default_autonomy_check CHECK (((default_autonomy)::text = ANY (ARRAY[('L0'::character varying)::text, ('L1'::character varying)::text, ('L2'::character varying)::text, ('L3'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_execution_type_check CHECK (((execution_type)::text = ANY (ARRAY[('internal_service'::character varying)::text, ('workflow_action'::character varying)::text, ('connector_action'::character varying)::text, ('http_proxy'::character varying)::text, ('job_dispatch'::character varying)::text, ('approval_only'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_max_autonomy_check CHECK (((max_autonomy)::text = ANY (ARRAY[('L0'::character varying)::text, ('L1'::character varying)::text, ('L2'::character varying)::text, ('L3'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_min_autonomy_check CHECK (((min_autonomy)::text = ANY (ARRAY[('L0'::character varying)::text, ('L1'::character varying)::text, ('L2'::character varying)::text, ('L3'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_risk_level_check CHECK (((risk_level)::text = ANY (ARRAY[('critical'::character varying)::text, ('high'::character varying)::text, ('medium'::character varying)::text, ('low'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_sensitivity_level_check CHECK (((sensitivity_level)::text = ANY (ARRAY[('normal'::character varying)::text, ('elevated'::character varying)::text, ('high'::character varying)::text, ('critical'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('active'::character varying)::text, ('deprecated'::character varying)::text, ('retired'::character varying)::text]))),
    CONSTRAINT mcp_tool_registry_visibility_scope_check CHECK (((visibility_scope)::text = ANY (ARRAY[('all'::character varying)::text, ('internal'::character varying)::text, ('admin_only'::character varying)::text, ('beta'::character varying)::text])))
);


--
-- Name: mcp_tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_tools (
    tool_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    server_id uuid NOT NULL,
    tool_name text NOT NULL,
    description text,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_schema jsonb,
    permission_scope text,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.mcp_tools FORCE ROW LEVEL SECURITY;


--
-- Name: module_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_dependencies (
    id integer NOT NULL,
    module_code character varying(50) NOT NULL,
    depends_on character varying(50) NOT NULL,
    dependency_type character varying(20) DEFAULT 'required'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: module_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.module_dependencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.module_dependencies_id_seq OWNED BY public.module_dependencies.id;


--
-- Name: module_health_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_health_events (
    id integer NOT NULL,
    module_code character varying(50) NOT NULL,
    event_type character varying(50) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: module_health_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.module_health_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_health_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.module_health_events_id_seq OWNED BY public.module_health_events.id;


--
-- Name: module_visibility_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_visibility_contracts (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT module_visibility_contracts_id_not_null1 NOT NULL,
    module_code character varying(100) NOT NULL,
    tenant_id uuid NOT NULL,
    visibility character varying(20) DEFAULT 'enabled'::character varying NOT NULL,
    conditions jsonb DEFAULT '[]'::jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: module_visibility_contracts_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_visibility_contracts_legacy (
    id integer CONSTRAINT module_visibility_contracts_id_not_null NOT NULL,
    source_module character varying(50) CONSTRAINT module_visibility_contracts_source_module_not_null NOT NULL,
    target_module character varying(50) CONSTRAINT module_visibility_contracts_target_module_not_null NOT NULL,
    contract_type character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: module_visibility_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.module_visibility_contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_visibility_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.module_visibility_contracts_id_seq OWNED BY public.module_visibility_contracts_legacy.id;


--
-- Name: onboarding_answer_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_answer_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    tenant_id text NOT NULL,
    question_code text NOT NULL,
    stage_code text NOT NULL,
    question_tier text NOT NULL,
    answer_value_hash text,
    answer_type character varying(20) NOT NULL,
    time_to_answer_seconds integer,
    was_inferred boolean DEFAULT false NOT NULL,
    user_confirmed boolean,
    correction_count integer DEFAULT 0 NOT NULL,
    visibility_rules_evaluated boolean DEFAULT false NOT NULL,
    lookup_used text,
    validation_passed boolean,
    validation_errors jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT onboarding_answer_analytics_answer_type_check CHECK (((answer_type)::text = ANY (ARRAY[('text'::character varying)::text, ('number'::character varying)::text, ('boolean'::character varying)::text, ('select'::character varying)::text, ('multi_select'::character varying)::text, ('lookup'::character varying)::text, ('json'::character varying)::text])))
);


--
-- Name: TABLE onboarding_answer_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_answer_analytics IS 'Analytics for answer patterns, AI inference accuracy, and completion metrics';


--
-- Name: mv_question_performance; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_question_performance AS
 SELECT q.question_code,
    q.stage_code,
    q.question_tier,
    count(a.id) AS total_answers,
    count(*) FILTER (WHERE (a.was_inferred AND a.user_confirmed)) AS ai_suggestions_accepted,
    count(*) FILTER (WHERE (a.was_inferred AND (NOT a.user_confirmed))) AS ai_suggestions_rejected,
    avg(a.time_to_answer_seconds) FILTER (WHERE (a.time_to_answer_seconds IS NOT NULL)) AS avg_time_seconds,
    avg(a.correction_count) AS avg_corrections,
    count(*) FILTER (WHERE (NOT a.validation_passed)) AS validation_failures,
    max(a.created_at) AS last_answered_at
   FROM (public.onboarding_question_bank q
     LEFT JOIN public.onboarding_answer_analytics a ON ((q.question_code = a.question_code)))
  WHERE (q.is_active = true)
  GROUP BY q.question_code, q.stage_code, q.question_tier
  WITH NO DATA;


--
-- Name: MATERIALIZED VIEW mv_question_performance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON MATERIALIZED VIEW public.mv_question_performance IS 'Pre-computed question performance metrics for analytics dashboard';


--
-- Name: onboarding_answers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_answers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    question_code character varying(255) NOT NULL,
    answer_text text,
    answer_json jsonb,
    answered_by_user_id character varying(64),
    version integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: onboarding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_configs (
    tenant_id character varying(255) NOT NULL,
    mode character varying(20) NOT NULL,
    steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    completed_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT onboarding_configs_mode_check CHECK (((mode)::text = ANY (ARRAY[('manual'::character varying)::text, ('guided'::character varying)::text, ('assisted'::character varying)::text, ('automated'::character varying)::text])))
);


--
-- Name: onboarding_framework_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_framework_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    framework_code character varying(30) NOT NULL,
    framework_name text NOT NULL,
    condition_json jsonb NOT NULL,
    priority integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_handoff_agent_findings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_handoff_agent_findings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    cycle_id uuid NOT NULL,
    tenant_id text NOT NULL,
    agent_id text NOT NULL,
    finding_type text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    detail text,
    related_kind text,
    related_code text,
    payload_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_handoff_finding_severity CHECK ((severity = ANY (ARRAY['info'::text, 'low'::text, 'medium'::text, 'high'::text, 'critical'::text]))),
    CONSTRAINT chk_handoff_finding_type CHECK ((finding_type = ANY (ARRAY['finding'::text, 'proposed_action'::text, 'validation'::text, 'remediation'::text])))
);


--
-- Name: TABLE onboarding_handoff_agent_findings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_handoff_agent_findings IS 'Phase C2: durable findings and proposed actions produced by a handoff agent run.';


--
-- Name: COLUMN onboarding_handoff_agent_findings.finding_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_agent_findings.finding_type IS 'finding | proposed_action | validation | remediation — drives UI grouping.';


--
-- Name: onboarding_handoff_agent_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_handoff_agent_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cycle_id uuid NOT NULL,
    tenant_id text NOT NULL,
    workspace_id text,
    session_id uuid,
    agent_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    summary text,
    findings_count integer DEFAULT 0 NOT NULL,
    proposed_actions_count integer DEFAULT 0 NOT NULL,
    degraded_reason text,
    error_message text,
    result_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_handoff_run_status CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'completed'::text, 'failed'::text, 'degraded'::text, 'skipped'::text])))
);


--
-- Name: TABLE onboarding_handoff_agent_runs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_handoff_agent_runs IS 'Phase C2: per-agent execution record for a post-provision handoff cycle. One row per (cycle_id, agent_id).';


--
-- Name: COLUMN onboarding_handoff_agent_runs.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_agent_runs.status IS 'pending | running | completed | failed | degraded | skipped — per-agent isolation; one failure does not collapse the wave.';


--
-- Name: COLUMN onboarding_handoff_agent_runs.result_json; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_agent_runs.result_json IS 'Structured executor output — enough to reconstruct what the agent actually did without re-running.';


--
-- Name: onboarding_handoff_evidence_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_handoff_evidence_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cycle_id uuid NOT NULL,
    agent_run_id uuid,
    tenant_id character varying(16) NOT NULL,
    workspace_id text,
    framework_code character varying(100) NOT NULL,
    framework_label text,
    control_code character varying(100),
    control_title text,
    evidence_category character varying(100) NOT NULL,
    evidence_title text NOT NULL,
    evidence_description text,
    suggested_owner_role character varying(100),
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(30) DEFAULT 'proposed'::character varying NOT NULL,
    already_covered boolean DEFAULT false NOT NULL,
    existing_evidence_id uuid,
    rationale text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_evidence_req_priority CHECK (((priority)::text = ANY (ARRAY[('low'::character varying)::text, ('medium'::character varying)::text, ('high'::character varying)::text, ('critical'::character varying)::text]))),
    CONSTRAINT chk_evidence_req_status CHECK (((status)::text = ANY (ARRAY[('proposed'::character varying)::text, ('acknowledged'::character varying)::text, ('in_progress'::character varying)::text, ('satisfied'::character varying)::text, ('dismissed'::character varying)::text])))
);


--
-- Name: TABLE onboarding_handoff_evidence_requests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_handoff_evidence_requests IS 'Phase C4: durable evidence requests produced by A05 at post-onboarding handoff. Grounded in seeded frameworks/controls; idempotent rerun via UNIQUE (cycle, framework, category, control).';


--
-- Name: COLUMN onboarding_handoff_evidence_requests.suggested_owner_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_evidence_requests.suggested_owner_role IS 'Role code (compliance_lead | evidence_coordinator | risk_owner | workspace_admin) A05 proposes as the owner bucket.';


--
-- Name: COLUMN onboarding_handoff_evidence_requests.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_evidence_requests.status IS 'proposed | acknowledged | in_progress | satisfied | dismissed — A05 only writes proposed; downstream mutates.';


--
-- Name: COLUMN onboarding_handoff_evidence_requests.already_covered; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_evidence_requests.already_covered IS 'TRUE when a matching evidence row was found in dos.evidences at resolve time — lets UI dim already-satisfied asks.';


--
-- Name: onboarding_handoff_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_handoff_invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invitation_id character varying(64) NOT NULL,
    cycle_id uuid NOT NULL,
    agent_run_id uuid,
    tenant_id character varying(16) NOT NULL,
    workspace_id text,
    session_id uuid,
    invited_by character varying(64) NOT NULL,
    email character varying(255) NOT NULL,
    role_code character varying(100) NOT NULL,
    proposed_role_title text,
    state text DEFAULT 'invited'::text NOT NULL,
    membership_id uuid,
    accepted_user_id character varying(64),
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    accepted_at timestamp with time zone,
    access_provisioned_at timestamp with time zone,
    role_assigned_at timestamp with time zone,
    last_error text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_handoff_inv_state CHECK ((state = ANY (ARRAY['invited'::text, 'pending_acceptance'::text, 'accepted'::text, 'access_provisioned'::text, 'role_assigned'::text, 'revoked'::text, 'expired'::text, 'failed'::text])))
);


--
-- Name: TABLE onboarding_handoff_invitations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_handoff_invitations IS 'Phase C3: invite records bound to the post-provision handoff cycle. Carries provenance (cycle_id + agent_run_id) and extended state beyond the auth-service invitation row.';


--
-- Name: COLUMN onboarding_handoff_invitations.invitation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_invitations.invitation_id IS 'FK-like reference to public.invitations.invitation_id — 1:1, kept UNIQUE.';


--
-- Name: COLUMN onboarding_handoff_invitations.agent_run_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_invitations.agent_run_id IS 'Provenance: the A02 agent run whose proposal created this invitation (NULL when operator-initiated).';


--
-- Name: COLUMN onboarding_handoff_invitations.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_handoff_invitations.state IS 'invited | pending_acceptance | accepted | access_provisioned | role_assigned | revoked | expired | failed';


--
-- Name: onboarding_inference_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_inference_bundles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    tenant_id text NOT NULL,
    inference_version text NOT NULL,
    mapping_version text NOT NULL,
    agent_model_version text,
    needs_confirmation boolean DEFAULT true NOT NULL,
    needs_deeper_questions boolean DEFAULT false NOT NULL,
    deeper_question_codes text[] DEFAULT '{}'::text[] NOT NULL,
    bundle_json jsonb NOT NULL,
    rationale_json jsonb,
    agent_attempted boolean DEFAULT false NOT NULL,
    agent_succeeded boolean DEFAULT false NOT NULL,
    agent_error text,
    resolved_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    inputs_fingerprint text,
    agent_enrichment_required boolean DEFAULT false NOT NULL,
    agent_enrichment_available boolean,
    degraded_reason text,
    last_auto_resolved_at timestamp with time zone
);


--
-- Name: TABLE onboarding_inference_bundles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_inference_bundles IS 'Phase B2: persisted hybrid inference bundle (lookup-first, agent-assisted) per onboarding session.';


--
-- Name: COLUMN onboarding_inference_bundles.inference_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.inference_version IS 'Version of the resolver logic. Bump when the resolution strategy changes.';


--
-- Name: COLUMN onboarding_inference_bundles.mapping_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.mapping_version IS 'Version of the deterministic mapping data set (rules + crosswalks).';


--
-- Name: COLUMN onboarding_inference_bundles.agent_model_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.agent_model_version IS 'Agent/LLM version used to enrich the bundle (NULL when agent path skipped).';


--
-- Name: COLUMN onboarding_inference_bundles.inputs_fingerprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.inputs_fingerprint IS 'sha256 of normalized anchor answers + inference/mapping versions. When unchanged, auto-resolve is a no-op.';


--
-- Name: COLUMN onboarding_inference_bundles.agent_enrichment_required; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.agent_enrichment_required IS 'When TRUE (production policy), missing/unreachable AI engine surfaces as degraded — not silently hidden.';


--
-- Name: COLUMN onboarding_inference_bundles.agent_enrichment_available; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.agent_enrichment_available IS 'Last-observed availability of the AI engine. NULL = never attempted; FALSE = attempted and failed.';


--
-- Name: COLUMN onboarding_inference_bundles.degraded_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_bundles.degraded_reason IS 'Human-readable degradation cause (e.g. ai_engine_url_missing, http_503, timeout). NULL when healthy.';


--
-- Name: onboarding_inference_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_inference_feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid NOT NULL,
    session_id uuid NOT NULL,
    action text NOT NULL,
    before_status text,
    after_status text,
    payload_json jsonb,
    actor_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_inf_feedback_action CHECK ((action = ANY (ARRAY['accept'::text, 'edit'::text, 'reject'::text, 'reopen'::text])))
);


--
-- Name: onboarding_inference_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_inference_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bundle_id uuid NOT NULL,
    session_id uuid NOT NULL,
    item_kind text NOT NULL,
    item_code text NOT NULL,
    item_label text NOT NULL,
    item_metadata jsonb,
    confidence numeric(4,3) NOT NULL,
    source_tag text NOT NULL,
    rationale text,
    status text DEFAULT 'pending'::text NOT NULL,
    user_override jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_in_version text,
    CONSTRAINT chk_inf_item_kind CHECK ((item_kind = ANY (ARRAY['regulator'::text, 'framework'::text, 'control_bundle'::text, 'risk'::text, 'policy'::text, 'workflow'::text]))),
    CONSTRAINT chk_inf_item_source CHECK ((source_tag = ANY (ARRAY['lookup'::text, 'rule'::text, 'agent'::text, 'hybrid'::text, 'user'::text]))),
    CONSTRAINT chk_inf_item_status CHECK ((status = ANY (ARRAY['pending'::text, 'accepted'::text, 'edited'::text, 'rejected'::text])))
);


--
-- Name: COLUMN onboarding_inference_items.source_tag; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_items.source_tag IS 'Provenance: lookup | rule | agent | hybrid | user';


--
-- Name: COLUMN onboarding_inference_items.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_items.status IS 'pending | accepted | edited | rejected — drives provisioning replay.';


--
-- Name: COLUMN onboarding_inference_items.resolved_in_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_inference_items.resolved_in_version IS 'inference_version that produced this row. Lets us spot stale rows after a re-resolve and decide replay safety.';


--
-- Name: onboarding_module_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_module_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code character varying(50) NOT NULL,
    is_core boolean DEFAULT false NOT NULL,
    condition_json jsonb,
    sort_order integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_persona_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_persona_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    persona_code character varying(50) NOT NULL,
    persona_label text NOT NULL,
    condition_json jsonb NOT NULL,
    priority integer DEFAULT 10 NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_provisioning_intent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_provisioning_intent (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    product_code text DEFAULT 'shahin'::text NOT NULL,
    selected_plan_code text,
    pricing_code text,
    price_amount numeric(12,2),
    currency text DEFAULT 'SAR'::text NOT NULL,
    billing_status text DEFAULT 'trial'::text NOT NULL,
    module_codes jsonb DEFAULT '[]'::jsonb NOT NULL,
    workspace_template_code text,
    derived_from_answer_hash text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT onboarding_provisioning_intent_billing_status_check CHECK ((billing_status = ANY (ARRAY['trial'::text, 'free_trial'::text, 'active'::text, 'pending_payment'::text, 'quote_required'::text, 'enterprise_negotiation'::text]))),
    CONSTRAINT onboarding_provisioning_intent_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'confirmed'::text, 'provisioning'::text, 'provisioned'::text, 'failed'::text])))
);


--
-- Name: TABLE onboarding_provisioning_intent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_provisioning_intent IS 'Deterministic derivation of plan/pricing/modules from saved onboarding answers. Written atomically when session reaches approved_for_provisioning. Provisioning worker reads ONLY from this table — never from frontend payload.';


--
-- Name: onboarding_question_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_question_audit (
    audit_id uuid DEFAULT gen_random_uuid() NOT NULL,
    question_code text NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_by text,
    changed_by_user_id uuid,
    change_reason text,
    tenant_id text,
    session_id text,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT onboarding_question_audit_action_check CHECK (((action)::text = ANY (ARRAY[('INSERT'::character varying)::text, ('UPDATE'::character varying)::text, ('DELETE'::character varying)::text, ('ACTIVATE'::character varying)::text, ('DEACTIVATE'::character varying)::text])))
);


--
-- Name: TABLE onboarding_question_audit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_question_audit IS 'Audit trail for all question bank changes - required for enterprise compliance';


--
-- Name: onboarding_regulator_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_regulator_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    regulator_id character varying(30) NOT NULL,
    regulator_name text NOT NULL,
    regulator_name_ar text,
    condition_json jsonb NOT NULL,
    base_confidence numeric(3,2) DEFAULT 0.85 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_session_answers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_session_answers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    tenant_id text NOT NULL,
    question_code text NOT NULL,
    stage_code text NOT NULL,
    answer_value jsonb NOT NULL,
    answer_type character varying(20) NOT NULL,
    answered_by uuid NOT NULL,
    answered_at timestamp with time zone DEFAULT now() NOT NULL,
    ai_suggested_value jsonb,
    ai_confidence_score numeric(3,2),
    user_modified_ai boolean DEFAULT false NOT NULL,
    validation_passed boolean DEFAULT true NOT NULL,
    validation_errors jsonb,
    information_gain numeric(4,3),
    question_tier_at_answer text,
    used_for_provisioning boolean DEFAULT false NOT NULL,
    provisioned_at timestamp with time zone,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT onboarding_session_answers_answer_type_check CHECK (((answer_type)::text = ANY (ARRAY[('text'::character varying)::text, ('number'::character varying)::text, ('boolean'::character varying)::text, ('date'::character varying)::text, ('select'::character varying)::text, ('multi_select'::character varying)::text, ('lookup'::character varying)::text, ('json_rows'::character varying)::text, ('chips'::character varying)::text])))
);


--
-- Name: TABLE onboarding_session_answers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_session_answers IS 'Real production storage for onboarding answers - every answer stored with full audit trail';


--
-- Name: onboarding_session_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_session_progress (
    session_id uuid NOT NULL,
    tenant_id text NOT NULL,
    total_questions integer DEFAULT 0 NOT NULL,
    answered_questions integer DEFAULT 0 NOT NULL,
    required_questions integer DEFAULT 0 NOT NULL,
    required_answered integer DEFAULT 0 NOT NULL,
    anchor_answered integer DEFAULT 0 NOT NULL,
    inferred_answered integer DEFAULT 0 NOT NULL,
    advanced_answered integer DEFAULT 0 NOT NULL,
    expert_answered integer DEFAULT 0 NOT NULL,
    ai_suggestions_total integer DEFAULT 0 NOT NULL,
    ai_accepted integer DEFAULT 0 NOT NULL,
    ai_rejected integer DEFAULT 0 NOT NULL,
    total_information_gain numeric(10,3) DEFAULT 0 NOT NULL,
    completion_percentage integer DEFAULT 0 NOT NULL,
    stages_completed text[] DEFAULT ARRAY[]::text[] NOT NULL,
    current_stage text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    stage_progress jsonb DEFAULT '{}'::jsonb NOT NULL,
    journey_total integer DEFAULT 0 NOT NULL,
    journey_answered integer DEFAULT 0 NOT NULL,
    journey_required_total integer DEFAULT 0 NOT NULL,
    journey_required_answered integer DEFAULT 0 NOT NULL,
    can_progress boolean DEFAULT false NOT NULL,
    blocked_by text[] DEFAULT ARRAY[]::text[] NOT NULL
);


--
-- Name: COLUMN onboarding_session_progress.stage_progress; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_session_progress.stage_progress IS 'Per-stage progress breakdown: { "<stage_code>": { total, answered, required_total, required_answered, percent } }';


--
-- Name: COLUMN onboarding_session_progress.journey_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_session_progress.journey_total IS 'Size of the resolved effective_question_codes set for the session.';


--
-- Name: COLUMN onboarding_session_progress.can_progress; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_session_progress.can_progress IS 'TRUE iff every required journey question has been answered (drives FE Continue gate).';


--
-- Name: COLUMN onboarding_session_progress.blocked_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_session_progress.blocked_by IS 'Required journey question_codes still missing an answer.';


--
-- Name: onboarding_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_key character varying(100) NOT NULL,
    status character varying(40) DEFAULT 'draft'::character varying NOT NULL,
    tenant_id character varying(64),
    workspace_id character varying(64),
    started_by_user_id character varying(64) NOT NULL,
    organization_name character varying(255),
    display_name character varying(255),
    language_code character varying(10) DEFAULT 'en'::character varying NOT NULL,
    progress_percent numeric(5,2) DEFAULT 0 NOT NULL,
    readiness_score numeric(5,2) DEFAULT 0 NOT NULL,
    blockers_count integer DEFAULT 0 NOT NULL,
    current_stage_code character varying(100),
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_saved_at timestamp with time zone,
    approved_at timestamp with time zone,
    provisioning_started_at timestamp with time zone,
    provisioning_completed_at timestamp with time zone,
    completed_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source character varying(50),
    completed_stages character varying[],
    expires_at timestamp with time zone,
    stage_scores jsonb,
    category_scores jsonb,
    ip_address character varying(50),
    user_agent text,
    module_code character varying(30) DEFAULT 'workspace_setup'::character varying,
    parent_session_id uuid,
    effective_journey_profile character varying(20),
    effective_question_codes text[],
    effective_visible_stages text[],
    effective_required_question_codes text[],
    journey_resolver_version character varying(20),
    journey_resolved_at timestamp with time zone,
    product_key text,
    package_version text,
    completion_contract jsonb,
    contract_hash text,
    frozen_at timestamp with time zone,
    CONSTRAINT onboarding_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['not_started'::character varying, 'draft'::character varying, 'in_progress'::character varying, 'awaiting_review'::character varying, 'review_blocked'::character varying, 'review_ready'::character varying, 'approved_for_provisioning'::character varying, 'provisioning_started'::character varying, 'provisioning'::character varying, 'provisioning_partial'::character varying, 'provisioned'::character varying, 'handover_pending'::character varying, 'active'::character varying, 'failed'::character varying, 'cancelled'::character varying, 'archived'::character varying, 'abandoned'::character varying])::text[])))
);


--
-- Name: COLUMN onboarding_sessions.effective_journey_profile; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.effective_journey_profile IS 'Resolved journey profile (express|guided|expert). Server-owned; FE cannot override.';


--
-- Name: COLUMN onboarding_sessions.effective_question_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.effective_question_codes IS 'Ordered list of question_codes the user will see. Written once at registration, re-written only on explicit profile change.';


--
-- Name: COLUMN onboarding_sessions.effective_visible_stages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.effective_visible_stages IS 'Ordered list of stage_codes the user will see. Derived from effective_question_codes.';


--
-- Name: COLUMN onboarding_sessions.effective_required_question_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.effective_required_question_codes IS 'Subset of effective_question_codes that block progression when unanswered.';


--
-- Name: COLUMN onboarding_sessions.journey_resolver_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.journey_resolver_version IS 'Resolver version tag for auditability. Bump when resolver logic changes.';


--
-- Name: COLUMN onboarding_sessions.product_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.product_key IS 'Product this session belongs to (e.g. shahin, qiyas)';


--
-- Name: COLUMN onboarding_sessions.package_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.package_version IS 'Package version the session was started with (e.g. v1)';


--
-- Name: COLUMN onboarding_sessions.completion_contract; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.completion_contract IS 'Frozen normalized profile + resolved data for provisioning (JSONB)';


--
-- Name: COLUMN onboarding_sessions.contract_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.contract_hash IS 'SHA-256 hash of the completion contract for integrity verification';


--
-- Name: COLUMN onboarding_sessions.frozen_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_sessions.frozen_at IS 'Timestamp when the completion contract was frozen';


--
-- Name: CONSTRAINT onboarding_sessions_status_check ON onboarding_sessions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT onboarding_sessions_status_check ON public.onboarding_sessions IS 'FSM source-of-truth: workflows/onboarding-lifecycle.ts ONBOARDING_SESSION_STATES (16 user-driven) + abandoned (reconciler-driven). Reject any other value to prevent silent drift.';


--
-- Name: onboarding_sla_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_sla_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    stage_code character varying(50),
    max_hours integer DEFAULT 48 NOT NULL,
    warning_hours integer DEFAULT 24 NOT NULL,
    escalation_email text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: onboarding_workspace_handoff_cycles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_workspace_handoff_cycles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workspace_id text,
    session_id uuid,
    user_id text,
    phase text DEFAULT 'post_onboarding_handoff'::text NOT NULL,
    idempotency_key text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    dispatch_target text,
    temporal_workflow_id text,
    agents_planned text[] DEFAULT '{}'::text[] NOT NULL,
    agents_dispatched text[] DEFAULT '{}'::text[] NOT NULL,
    degraded_reason text,
    payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    dispatched_at timestamp with time zone,
    completed_at timestamp with time zone,
    provisioning_job_id text,
    event_id text,
    last_transition_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_handoff_dispatch_target CHECK (((dispatch_target IS NULL) OR (dispatch_target = ANY (ARRAY['temporal'::text, 'http'::text, 'inline'::text, 'none'::text])))),
    CONSTRAINT chk_handoff_status CHECK ((status = ANY (ARRAY['pending'::text, 'queued'::text, 'completed'::text, 'failed'::text, 'degraded'::text])))
);


--
-- Name: TABLE onboarding_workspace_handoff_cycles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.onboarding_workspace_handoff_cycles IS 'Phase C1: post-provision operational handoff cycles. One row per (tenant, workspace, phase).';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.phase; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.phase IS 'Lifecycle phase: post_onboarding_handoff | post_invite_activation | periodic_cycle | remediation_campaign | regulatory_update_wave';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.idempotency_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.idempotency_key IS 'tenantId:workspaceId:phase — UNIQUE, prevents duplicate first-cycle dispatch on event replay.';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.dispatch_target; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.dispatch_target IS 'Where the cycle was dispatched: temporal (preferred), http (ai-engine fallback in dev), inline (fallback only), none (degraded).';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.degraded_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.degraded_reason IS 'Set when status=degraded — explains why the production handoff path was unavailable.';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.payload_json; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.payload_json IS 'Self-contained input snapshot: anchor answers + accepted inference items. Cycle runs from this — no need to re-fetch HTTP context.';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.provisioning_job_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.provisioning_job_id IS 'Provisioning job whose terminal success triggered this handoff. Provenance link.';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.event_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.event_id IS 'Envelope id of the onboarding.workspace_provisioned event that drove this dispatch. Used to prove replay safety.';


--
-- Name: COLUMN onboarding_workspace_handoff_cycles.last_transition_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.onboarding_workspace_handoff_cycles.last_transition_at IS 'Bumps on every status change. Surfaced as lastTransitionAt in the handoff-status API.';


--
-- Name: org_pack_template_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_departments (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    dept_code character varying(50) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255),
    division_code character varying(50),
    sort_order integer DEFAULT 0 NOT NULL,
    is_critical boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_departments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_departments_id_seq OWNED BY public.org_pack_template_departments.id;


--
-- Name: org_pack_template_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_permissions (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    permission_code character varying(150) NOT NULL,
    module_code character varying(50) NOT NULL,
    resource_code character varying(100) NOT NULL,
    action_code character varying(50) NOT NULL,
    description_en text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_permissions_id_seq OWNED BY public.org_pack_template_permissions.id;


--
-- Name: org_pack_template_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_profiles (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    profile_code character varying(100) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255),
    description_en text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_profiles_id_seq OWNED BY public.org_pack_template_profiles.id;


--
-- Name: org_pack_template_role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_role_permissions (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    role_code character varying(100) NOT NULL,
    permission_code character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_role_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_role_permissions_id_seq OWNED BY public.org_pack_template_role_permissions.id;


--
-- Name: org_pack_template_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_roles (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    role_code character varying(100) NOT NULL,
    module_code character varying(50) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255),
    description_en text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_roles_id_seq OWNED BY public.org_pack_template_roles.id;


--
-- Name: org_pack_template_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_sections (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    section_code character varying(50) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255),
    dept_code character varying(50) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_critical boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_sections_id_seq OWNED BY public.org_pack_template_sections.id;


--
-- Name: org_pack_template_sod_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_sod_rules (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    role_code_a character varying(100) NOT NULL,
    role_code_b character varying(100) NOT NULL,
    module_code character varying(50),
    conflict_level character varying(10) NOT NULL,
    scope_rule character varying(20) NOT NULL,
    cross_module boolean DEFAULT false NOT NULL,
    module_code_b character varying(50),
    description_en text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT org_pack_template_sod_rules_conflict_level_check CHECK (((conflict_level)::text = ANY (ARRAY[('warn'::character varying)::text, ('block'::character varying)::text]))),
    CONSTRAINT org_pack_template_sod_rules_scope_rule_check CHECK (((scope_rule)::text = ANY (ARRAY[('same_scope'::character varying)::text, ('tenant_wide'::character varying)::text])))
);


--
-- Name: org_pack_template_sod_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_sod_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_sod_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_sod_rules_id_seq OWNED BY public.org_pack_template_sod_rules.id;


--
-- Name: org_pack_template_teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_teams (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    team_code character varying(50) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255),
    dept_code character varying(50),
    section_code character varying(50),
    sort_order integer DEFAULT 0 NOT NULL,
    is_critical boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT org_pack_template_teams_check CHECK ((((dept_code IS NOT NULL) AND (section_code IS NULL)) OR ((dept_code IS NULL) AND (section_code IS NOT NULL))))
);


--
-- Name: org_pack_template_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_teams_id_seq OWNED BY public.org_pack_template_teams.id;


--
-- Name: org_pack_template_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_template_workflows (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    workflow_code character varying(100) NOT NULL,
    module_code character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    from_status character varying(50) NOT NULL,
    to_status character varying(50) NOT NULL,
    required_role_code character varying(100),
    min_authority_level character varying(30),
    min_approvers integer DEFAULT 0 NOT NULL,
    require_different_user boolean DEFAULT false NOT NULL,
    description_en text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: org_pack_template_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_template_workflows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_template_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_template_workflows_id_seq OWNED BY public.org_pack_template_workflows.id;


--
-- Name: org_pack_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_pack_templates (
    id bigint NOT NULL,
    pack_code character varying(50) NOT NULL,
    name_en character varying(255) NOT NULL,
    name_ar character varying(255),
    size character varying(20) NOT NULL,
    org_type character varying(20) DEFAULT 'standard'::character varying NOT NULL,
    description_en text,
    description_ar text,
    hierarchy_depth integer DEFAULT 4 NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT org_pack_templates_org_type_check CHECK (((org_type)::text = ANY (ARRAY[('standard'::character varying)::text, ('matrix'::character varying)::text]))),
    CONSTRAINT org_pack_templates_size_check CHECK (((size)::text = ANY (ARRAY[('small'::character varying)::text, ('standard'::character varying)::text, ('enterprise'::character varying)::text])))
);


--
-- Name: org_pack_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.org_pack_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: org_pack_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.org_pack_templates_id_seq OWNED BY public.org_pack_templates.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    token_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(64),
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    email text,
    used_at timestamp with time zone
);


--
-- Name: pdpl_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pdpl_consents (
    user_id character varying(255) NOT NULL,
    consent_type character varying(100) NOT NULL,
    granted boolean DEFAULT false NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


--
-- Name: pending_workflow_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_workflow_tasks (
    task_id character varying(80) NOT NULL,
    tenant_id uuid NOT NULL,
    task_type character varying(50) DEFAULT 'generic'::character varying NOT NULL,
    task_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    outcome jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    retries integer DEFAULT 0 NOT NULL,
    last_error text
);


--
-- Name: permission_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_usage (
    permission_code character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    usage_count integer DEFAULT 1 NOT NULL,
    last_used timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_outbox (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id character varying(64),
    headers jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    last_error text,
    published_at timestamp with time zone,
    max_attempts integer DEFAULT 10 NOT NULL,
    dead_at timestamp with time zone,
    CONSTRAINT platform_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'published'::text, 'dead'::text])))
);


--
-- Name: TABLE platform_outbox; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.platform_outbox IS 'Transactional outbox; publisher moves rows to published and pushes to Redis streams.';


--
-- Name: platform_outbox_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_outbox_archive (
    id uuid NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    tenant_id character varying(64),
    headers jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    published_at timestamp with time zone NOT NULL,
    archived_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE platform_outbox_archive; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.platform_outbox_archive IS 'Archive of published outbox rows older than retention window; reaper moves them here, original row is deleted.';


--
-- Name: platform_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_products (
    product_key character varying(50) NOT NULL,
    name_en character varying(200) NOT NULL,
    name_ar character varying(200),
    version character varying(20) DEFAULT '1.0.0'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    manifest jsonb DEFAULT '{}'::jsonb NOT NULL,
    registered_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    domains text[] DEFAULT '{}'::text[],
    default_domain character varying(255),
    landing_route character varying(255) DEFAULT '/workspace-home'::character varying
);


--
-- Name: privacy_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.privacy_budgets (
    tenant_id character varying(255) NOT NULL,
    budget_type character varying(100) NOT NULL,
    allocated numeric DEFAULT 0 NOT NULL,
    consumed numeric DEFAULT 0 NOT NULL
);


--
-- Name: processed_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.processed_events (
    consumer text NOT NULL,
    event_id text NOT NULL,
    event_type text,
    tenant_id character varying(64),
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.processed_events IS 'Consumer-side dedupe ledger — (consumer, event_id) PK enforces exactly-once processing per consumer.';


--
-- Name: product_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_modules (
    id integer NOT NULL,
    product_key character varying(50) NOT NULL,
    module_code character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    enabled boolean DEFAULT true NOT NULL,
    module_type character varying(50) DEFAULT 'product_module'::character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_modules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_modules_id_seq OWNED BY public.product_modules.id;


--
-- Name: product_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_registry (
    product_key character varying(50) NOT NULL,
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: provisioning_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    step_id uuid,
    event_type text NOT NULL,
    level text DEFAULT 'info'::text NOT NULL,
    message text NOT NULL,
    details_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: provisioning_idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_idempotency (
    idempotency_key character varying(512) NOT NULL,
    job_id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: provisioning_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    requested_by_user_id text NOT NULL,
    job_status text DEFAULT 'queued'::text NOT NULL,
    failure_reason text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    failed_at timestamp with time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    summary_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id character varying(64),
    claimed_by text,
    claimed_at timestamp with time zone,
    heartbeat_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 8 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    dead_at timestamp with time zone,
    dead_reason text,
    product_key text,
    package_version text,
    execution_plan_hash text,
    contract_hash text,
    CONSTRAINT provisioning_jobs_job_status_check CHECK ((job_status = ANY (ARRAY['queued'::text, 'running'::text, 'completed'::text, 'succeeded'::text, 'failed'::text, 'dead'::text])))
);


--
-- Name: COLUMN provisioning_jobs.product_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provisioning_jobs.product_key IS 'Product this job provisions for';


--
-- Name: COLUMN provisioning_jobs.package_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provisioning_jobs.package_version IS 'Package version used for this provisioning run';


--
-- Name: COLUMN provisioning_jobs.execution_plan_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provisioning_jobs.execution_plan_hash IS 'Hash of the composite provisioning plan (platform + product steps)';


--
-- Name: COLUMN provisioning_jobs.contract_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provisioning_jobs.contract_hash IS 'Hash of the completion contract consumed by this job';


--
-- Name: provisioning_step_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_step_definitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    step_code character varying(50) NOT NULL,
    step_name text NOT NULL,
    step_name_ar text,
    sequence_no integer DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    can_retry boolean DEFAULT true NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    timeout_seconds integer DEFAULT 300 NOT NULL,
    handler_class character varying(200),
    depends_on text[],
    configuration jsonb,
    error_handling jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    product_code character varying(64) DEFAULT 'shahin-ai'::character varying,
    stage_index integer
);


--
-- Name: provisioning_step_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_step_runs (
    job_id uuid NOT NULL,
    step_code text NOT NULL,
    attempt integer NOT NULL,
    idempotency_key text NOT NULL,
    status text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    duration_ms numeric,
    output jsonb DEFAULT '{}'::jsonb NOT NULL,
    error jsonb,
    CONSTRAINT provisioning_step_runs_status_check CHECK ((status = ANY (ARRAY['running'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: TABLE provisioning_step_runs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provisioning_step_runs IS 'Per-attempt ledger for provisioning steps; worker short-circuits when a succeeded row exists for the step on a given job.';


--
-- Name: provisioning_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    step_code text NOT NULL,
    step_name text NOT NULL,
    sequence_no integer NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    duration_ms numeric,
    payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    step_owner text DEFAULT 'platform'::text,
    CONSTRAINT provisioning_steps_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'completed'::text, 'failed'::text])))
);


--
-- Name: COLUMN provisioning_steps.step_owner; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provisioning_steps.step_owner IS 'Who owns this step: platform or product key (e.g. shahin)';


--
-- Name: provisioning_telemetry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_telemetry (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT provisioning_telemetry_id_not_null1 NOT NULL,
    tenant_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_code character varying(100),
    event_type character varying(50) NOT NULL,
    duration_ms integer,
    error text,
    total_steps integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: provisioning_telemetry_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provisioning_telemetry_legacy (
    id integer CONSTRAINT provisioning_telemetry_id_not_null NOT NULL,
    tenant_id character varying(16),
    step character varying(100),
    status character varying(20),
    duration_ms integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: provisioning_telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.provisioning_telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: provisioning_telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.provisioning_telemetry_id_seq OWNED BY public.provisioning_telemetry_legacy.id;


--
-- Name: recovery_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recovery_actions (
    recovery_id uuid DEFAULT gen_random_uuid() NOT NULL,
    action_type character varying(50) NOT NULL,
    target_service character varying(255) NOT NULL,
    target_tenant_id uuid,
    requested_by character varying(255) NOT NULL,
    approved_by character varying(255),
    requires_approval boolean DEFAULT false NOT NULL,
    status character varying(30) DEFAULT 'pending_approval'::character varying NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    rollback_notes text,
    audit_context jsonb DEFAULT '{}'::jsonb NOT NULL,
    incident_id uuid,
    executed_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recovery_actions_action_type_check CHECK (((action_type)::text = ANY (ARRAY[('rollback'::character varying)::text, ('restart'::character varying)::text, ('disable'::character varying)::text, ('replay'::character varying)::text, ('manual_intervention'::character varying)::text, ('containment'::character varying)::text]))),
    CONSTRAINT recovery_actions_status_check CHECK (((status)::text = ANY (ARRAY[('pending_approval'::character varying)::text, ('approved'::character varying)::text, ('executing'::character varying)::text, ('completed'::character varying)::text, ('failed'::character varying)::text, ('cancelled'::character varying)::text])))
);


--
-- Name: refresh_token_families; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.refresh_token_families AS
 SELECT family_id,
    user_id,
    tenant_id,
    current_jti,
    rotation_count,
    status,
    created_at,
    updated_at,
    expires_at
   FROM platform_dauth.refresh_token_families;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    tenant_id character varying(16),
    token_hash text NOT NULL,
    family_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    replaced_by_token_hash text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: register_idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.register_idempotency (
    idempotency_key_hash character(64) NOT NULL,
    response_status smallint NOT NULL,
    response_body jsonb NOT NULL,
    normalized_email character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE register_idempotency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.register_idempotency IS 'Replay cache for POST .../register when Idempotency-Key header is sent; TTL via expires_at.';


--
-- Name: regulatory_controls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regulatory_controls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    control_code character varying(30) NOT NULL,
    title text NOT NULL,
    description text,
    framework_code character varying(30) NOT NULL,
    domain_name character varying(80),
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: regulatory_frameworks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regulatory_frameworks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    framework_code character varying(30) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    version character varying(20),
    regulator_id character varying(30),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    total_controls integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reliability_dead_letter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reliability_dead_letter (
    id character varying(255) NOT NULL,
    source character varying(255) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message text DEFAULT ''::text NOT NULL,
    attempts integer DEFAULT 1 NOT NULL,
    first_failed_at timestamp with time zone DEFAULT now() NOT NULL,
    last_failed_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id character varying(255),
    correlation_id character varying(255)
);


--
-- Name: retired_entities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retired_entities (
    entity_type character varying(100) NOT NULL,
    entity_id character varying(255) NOT NULL,
    retired_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: risk_score_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_score_history (
    history_id uuid DEFAULT gen_random_uuid() NOT NULL,
    risk_id character varying(16) NOT NULL,
    model_id character varying(100) NOT NULL,
    dimension_scores jsonb NOT NULL,
    composite_score numeric(6,2) NOT NULL,
    zone character varying(20) NOT NULL,
    scored_at timestamp with time zone DEFAULT now()
);


--
-- Name: roles_pre_phase200_quarantine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles_pre_phase200_quarantine (
    role_id character varying(64) CONSTRAINT roles_role_id_not_null NOT NULL,
    role_code character varying(100) CONSTRAINT roles_role_code_not_null NOT NULL,
    display_name character varying(255) CONSTRAINT roles_display_name_not_null NOT NULL,
    description text,
    is_system boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    quarantined_at timestamp with time zone DEFAULT now(),
    quarantined_by text DEFAULT CURRENT_USER
);


--
-- Name: TABLE roles_pre_phase200_quarantine; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.roles_pre_phase200_quarantine IS 'Forensic snapshot of public.roles rows that leaked from services writing to the wrong schema before phase-200 layer-conflict closure. Created by migration 210 to unblock 200_layer_conflict_closure.sql.';


--
-- Name: runbook_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runbook_definitions (
    runbook_id character varying(255) NOT NULL,
    title text NOT NULL,
    owner character varying(255) NOT NULL,
    owner_role character varying(255) NOT NULL,
    escalation_owner character varying(255),
    trigger_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    linked_alert_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    service_code character varying(255),
    dependency_map jsonb DEFAULT '[]'::jsonb NOT NULL,
    health_signals jsonb DEFAULT '[]'::jsonb NOT NULL,
    dashboard_links jsonb DEFAULT '[]'::jsonb NOT NULL,
    alert_sources jsonb DEFAULT '[]'::jsonb NOT NULL,
    recovery_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    rollback_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    common_failure_modes jsonb DEFAULT '[]'::jsonb NOT NULL,
    known_caveats jsonb DEFAULT '[]'::jsonb NOT NULL,
    support_contacts jsonb DEFAULT '[]'::jsonb NOT NULL,
    last_reviewed_at timestamp with time zone,
    version character varying(50) DEFAULT '1.0.0'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: runtime_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_config (
    key character varying(255) NOT NULL,
    value jsonb NOT NULL,
    value_type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    set_by character varying(255),
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: runtime_config_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_config_legacy (
    config_key character varying(200) CONSTRAINT runtime_config_config_key_not_null NOT NULL,
    config_value jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying(50) NOT NULL,
    applied_at timestamp with time zone DEFAULT now()
);


--
-- Name: scim_api_tokens; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.scim_api_tokens AS
 SELECT token_id,
    tenant_id,
    token_hash,
    label,
    created_by,
    created_at,
    expires_at,
    revoked_at,
    last_used
   FROM platform_dauth.scim_api_tokens;


--
-- Name: secret_references; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_references (
    secret_key character varying(255) NOT NULL,
    source character varying(20) NOT NULL,
    last_rotated timestamp with time zone,
    CONSTRAINT secret_references_source_check CHECK (((source)::text = ANY (ARRAY[('env'::character varying)::text, ('vault'::character varying)::text, ('config'::character varying)::text])))
);


--
-- Name: sector_isic_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sector_isic_map (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sector_id character varying(50) NOT NULL,
    isic_letter character varying(2) NOT NULL,
    isic_code character varying(10) NOT NULL,
    country_code character varying(2),
    weight integer DEFAULT 50 NOT NULL
);


--
-- Name: security_events; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.security_events AS
 SELECT event_id,
    tenant_id,
    user_id,
    event_type,
    ip,
    user_agent,
    metadata,
    created_at
   FROM platform_dauth.security_events;


--
-- Name: seed_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_history (
    id integer NOT NULL,
    seed_code character varying(100) NOT NULL,
    tenant_id character varying(16),
    applied_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'applied'::character varying
);


--
-- Name: seed_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seed_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seed_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seed_history_id_seq OWNED BY public.seed_history.id;


--
-- Name: session_security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_security_events (
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying(64) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    user_id character varying(64) NOT NULL,
    event_type character varying(50) NOT NULL,
    risk_level character varying(20) DEFAULT 'low'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sessions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.sessions AS
 SELECT session_id,
    user_id,
    tenant_id,
    jti,
    refresh_jti,
    ip_address,
    user_agent,
    created_at,
    last_active_at,
    expires_at,
    revoked_at
   FROM platform_dauth.sessions;


--
-- Name: shell_extensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shell_extensions (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT shell_extensions_id_not_null1 NOT NULL,
    module_code character varying(100) NOT NULL,
    extension_point character varying(100) NOT NULL,
    component_ref character varying(255) NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    guard_conditions jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shell_extensions_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shell_extensions_legacy (
    id integer CONSTRAINT shell_extensions_id_not_null NOT NULL,
    extension_code character varying(100) CONSTRAINT shell_extensions_extension_code_not_null NOT NULL,
    module_code character varying(50),
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: shell_extensions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shell_extensions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shell_extensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shell_extensions_id_seq OWNED BY public.shell_extensions_legacy.id;


--
-- Name: slo_current_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slo_current_values (
    slo_id character varying(255) NOT NULL,
    current_value numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: slo_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slo_definitions (
    slo_id character varying(255) NOT NULL,
    service_code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    target_percent numeric DEFAULT 99.9 NOT NULL,
    window_days integer DEFAULT 30 NOT NULL,
    metric_name character varying(255) NOT NULL,
    threshold numeric DEFAULT 0 NOT NULL,
    comparison_operator character varying(10) DEFAULT 'gte'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT slo_definitions_comparison_operator_check CHECK (((comparison_operator)::text = ANY (ARRAY[('lt'::character varying)::text, ('lte'::character varying)::text, ('gt'::character varying)::text, ('gte'::character varying)::text])))
);


--
-- Name: sod_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sod_rules (
    policy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_code character varying(100) NOT NULL,
    role_code_a character varying(100) NOT NULL,
    role_code_b character varying(100) NOT NULL,
    conflict_level character varying(20) DEFAULT 'warn'::character varying NOT NULL,
    enforcement character varying(20) DEFAULT 'block'::character varying NOT NULL,
    module_code character varying(100),
    description text,
    is_active boolean DEFAULT true NOT NULL,
    temporary_waiver_allowed boolean DEFAULT false NOT NULL,
    waiver_max_days integer,
    created_by character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sod_rules_conflict_level_check CHECK (((conflict_level)::text = ANY ((ARRAY['block'::character varying, 'escalate'::character varying, 'warn'::character varying, 'allow'::character varying])::text[]))),
    CONSTRAINT sod_rules_enforcement_check CHECK (((enforcement)::text = ANY ((ARRAY['block'::character varying, 'warn'::character varying, 'log'::character varying])::text[])))
);


--
-- Name: sod_waivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sod_waivers (
    waiver_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(64) NOT NULL,
    rule_code character varying(100) NOT NULL,
    granted_by character varying(128) NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by character varying(128),
    revoke_reason text,
    reason text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_key character varying(50) NOT NULL,
    plan character varying(50) DEFAULT 'free'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: team_change_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_change_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    entity_id uuid NOT NULL,
    entity_type text NOT NULL,
    field_name text NOT NULL,
    old_value text,
    new_value text,
    changed_by uuid NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    correlation_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: team_departments; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.team_departments AS
 SELECT department_id AS id,
    department_id,
    department_code,
    display_name AS name_en,
    tenant_id,
    parent_id,
    created_at,
    NULL::timestamp with time zone AS deleted_at
   FROM dos.departments
  WHERE ((tenant_id)::text = current_setting('dos.current_tenant_id'::text, true));


--
-- Name: team_org_chart; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.team_org_chart AS
 SELECT pa.assignment_id AS id,
    pa.user_id,
    pa.position_id,
    p.bu_id,
    b.organization_id,
    pa.tenant_id,
    pa.is_primary,
    pa.assigned_at,
    pa.ended_at
   FROM ((dos.position_assignments pa
     JOIN dos.positions p ON ((p.position_id = pa.position_id)))
     LEFT JOIN dos.business_units b ON ((b.bu_id = p.bu_id)))
  WHERE ((pa.tenant_id)::text = current_setting('dos.current_tenant_id'::text, true));


--
-- Name: team_positions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.team_positions AS
 SELECT position_id AS id,
    position_id,
    code,
    title_en AS name_en,
    title_ar AS name_ar,
    tenant_id,
    bu_id,
    reports_to,
    grade,
    level,
    status,
    created_at,
    updated_at,
    deleted_at
   FROM dos.positions
  WHERE ((tenant_id)::text = current_setting('dos.current_tenant_id'::text, true));


--
-- Name: team_reporting_lines; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.team_reporting_lines AS
 SELECT position_id AS id,
    position_id AS subordinate_position_id,
    reports_to AS manager_position_id,
    tenant_id,
    created_at
   FROM dos.positions p
  WHERE ((deleted_at IS NULL) AND (reports_to IS NOT NULL) AND ((tenant_id)::text = current_setting('dos.current_tenant_id'::text, true)));


--
-- Name: team_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    config_key text NOT NULL,
    config_value jsonb DEFAULT '{}'::jsonb NOT NULL,
    scope text DEFAULT 'tenant'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: team_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    entity_id uuid NOT NULL,
    entity_type text NOT NULL,
    version integer NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    changed_by uuid NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tenant_boundary_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_boundary_configs (
    id integer NOT NULL,
    tenant_id character varying(16) NOT NULL,
    boundary_type character varying(50) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_boundary_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tenant_boundary_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_boundary_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tenant_boundary_configs_id_seq OWNED BY public.tenant_boundary_configs.id;


--
-- Name: tenant_entitlement_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_entitlement_profile (
    entitlement_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    grc_enabled boolean DEFAULT true NOT NULL,
    qiyas_enabled boolean DEFAULT false NOT NULL,
    licensed_modules text[] DEFAULT '{grc}'::text[] NOT NULL,
    default_operation_mode character varying(30) DEFAULT 'human_only'::character varying NOT NULL,
    agent_confidence_threshold numeric(3,2) DEFAULT 0.85 NOT NULL,
    workflow_mode_enforcement character varying(20) DEFAULT 'per_step'::character varying NOT NULL,
    modules_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    activated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_module_entitlements_default_operation_mode_check CHECK (((default_operation_mode)::text = ANY (ARRAY[('human_only'::character varying)::text, ('hybrid_shadow'::character varying)::text, ('hybrid_active'::character varying)::text, ('autonomous'::character varying)::text]))),
    CONSTRAINT tenant_module_entitlements_workflow_mode_enforcement_check CHECK (((workflow_mode_enforcement)::text = ANY (ARRAY[('tenant_wide'::character varying)::text, ('per_team'::character varying)::text, ('per_step'::character varying)::text])))
);


--
-- Name: tenant_user_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_user_memberships (
    membership_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) CONSTRAINT tenant_user_memberships_tenant_id_not_null1 NOT NULL,
    user_id character varying(64) CONSTRAINT tenant_user_memberships_user_id_not_null1 NOT NULL,
    membership_type text DEFAULT 'internal'::text NOT NULL,
    is_tenant_owner boolean DEFAULT false NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    left_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    authz_version integer DEFAULT 1 NOT NULL,
    org_role_code character varying(50),
    CONSTRAINT chk_membership_status CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'pending'::text, 'revoked'::text]))),
    CONSTRAINT chk_membership_type CHECK ((membership_type = ANY (ARRAY['internal'::text, 'consultant'::text, 'vendor'::text, 'regulator'::text, 'auditor'::text, 'partner'::text])))
);


--
-- Name: tenant_memberships; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.tenant_memberships AS
 SELECT membership_id,
    tenant_id,
    user_id,
    membership_type,
    is_tenant_owner,
    status,
    joined_at,
    left_at,
    updated_at,
    authz_version,
    org_role_code
   FROM public.tenant_user_memberships;


--
-- Name: tenant_module_entitlement_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_module_entitlement_registry (
    tenant_id text CONSTRAINT tenant_module_entitlements_tenant_id_not_null NOT NULL,
    module_code text CONSTRAINT tenant_module_entitlements_module_code_not_null NOT NULL,
    entitled boolean DEFAULT true CONSTRAINT tenant_module_entitlements_entitled_not_null NOT NULL,
    status text DEFAULT 'active'::text CONSTRAINT tenant_module_entitlements_status_not_null NOT NULL,
    entitlement_source text,
    activated_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() CONSTRAINT tenant_module_entitlements_updated_at_not_null NOT NULL,
    product_key text DEFAULT 'shahin-ai'::text NOT NULL
);


--
-- Name: tenant_module_entitlements; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.tenant_module_entitlements AS
 SELECT tenant_id,
    product_key,
    module_code,
    entitled,
    status,
    entitlement_source,
    activated_at,
    updated_at
   FROM public.tenant_module_entitlement_registry;


--
-- Name: tenant_status_transitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_status_transitions (
    id integer NOT NULL,
    tenant_id character varying(16) NOT NULL,
    from_status character varying(50),
    to_status character varying(50) NOT NULL,
    changed_by character varying(64),
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_status_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tenant_status_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_status_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tenant_status_transitions_id_seq OWNED BY public.tenant_status_transitions.id;


--
-- Name: tenant_user_memberships_legacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_user_memberships_legacy (
    id integer CONSTRAINT tenant_user_memberships_id_not_null NOT NULL,
    user_id character varying(64) CONSTRAINT tenant_user_memberships_user_id_not_null NOT NULL,
    tenant_id character varying(64) CONSTRAINT tenant_user_memberships_tenant_id_not_null NOT NULL,
    role_code character varying(100) DEFAULT 'viewer'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    joined_at timestamp with time zone DEFAULT now(),
    membership_type character varying(20) DEFAULT 'internal'::character varying,
    is_tenant_owner boolean DEFAULT false
);


--
-- Name: tenant_user_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tenant_user_memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_user_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tenant_user_memberships_id_seq OWNED BY public.tenant_user_memberships_legacy.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    tenant_id character varying(64) NOT NULL,
    org_name character varying(255) NOT NULL,
    industry character varying(100) DEFAULT 'other'::character varying NOT NULL,
    org_size character varying(50) DEFAULT '1-50'::character varying NOT NULL,
    regions text[] DEFAULT '{}'::text[],
    plan character varying(50) DEFAULT 'free'::character varying,
    status character varying(50) DEFAULT 'onboarding'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    tenant_code text NOT NULL,
    tenant_name_en text NOT NULL,
    tenant_name_ar text,
    schema_name text NOT NULL,
    product_key character varying(50) DEFAULT 'shahin-ai'::character varying,
    isolation_mode character varying(20) DEFAULT 'schema'::character varying,
    settings jsonb DEFAULT '{}'::jsonb,
    country_of_incorporation character varying(5),
    CONSTRAINT chk_tenants_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying, 'archived'::character varying, 'onboarding'::character varying, 'registered'::character varying, 'pending_onboarding'::character varying])::text[]))),
    CONSTRAINT tenants_id_format_check CHECK (((tenant_id)::text ~ '^[a-z0-9](?:[a-z0-9_-]{0,62}[a-z0-9])?$'::text)),
    CONSTRAINT tenants_schema_name_canonical_check CHECK ((schema_name = ('tenant_'::text || regexp_replace((tenant_id)::text, '[^a-zA-Z0-9_]'::text, ''::text, 'g'::text)))),
    CONSTRAINT tenants_status_check CHECK (((status)::text = ANY ((ARRAY['registered'::character varying, 'email_pending'::character varying, 'verified'::character varying, 'onboarding'::character varying, 'provisioning'::character varying, 'onboarding_ready'::character varying, 'active'::character varying, 'suspended'::character varying, 'archived'::character varying, 'pending'::character varying, 'deleted'::character varying])::text[])))
);


--
-- Name: COLUMN tenants.country_of_incorporation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.country_of_incorporation IS 'ISO 3166-1 alpha-2 (or alpha-3) country code captured at registration. Source: register-tenant-user.ts ${country} input.';


--
-- Name: CONSTRAINT tenants_id_format_check ON tenants; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT tenants_id_format_check ON public.tenants IS 'Mirrors @dos/db TENANT_ID_REGEX (assertTenantId). Allows lowercase alphanumeric + underscore/hyphen, 1–64 chars, must start and end with alphanumeric. Covers UUID-with-hyphens, slug, and short-hex shapes.';


--
-- Name: CONSTRAINT tenants_schema_name_canonical_check ON tenants; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT tenants_schema_name_canonical_check ON public.tenants IS 'Forces schema_name to match the canonical tenantSchema(tenant_id) computation in @dos/db (strip non-alphanumeric/underscore, prefix with tenant_). Prevents drift between PK and physical schema.';


--
-- Name: CONSTRAINT tenants_status_check ON tenants; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT tenants_status_check ON public.tenants IS 'Tenant lifecycle FSM (registered -> email_pending -> verified -> provisioning -> onboarding_ready -> active) plus admin states (onboarding, suspended, archived, pending) and soft-delete terminal (deleted). Source of truth: registration-lifecycle.constants.ts.';


--
-- Name: tier_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tier_definitions (
    tier_code character varying(50) NOT NULL,
    display_name character varying(255),
    limits jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: token_blacklist; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.token_blacklist AS
 SELECT jti,
    user_id,
    expires_at,
    is_active,
    created_at
   FROM platform_dauth.token_blacklist;


--
-- Name: unresolved_risks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unresolved_risks (
    risk_id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    severity text DEFAULT 'medium'::text NOT NULL,
    area text DEFAULT ''::text NOT NULL,
    owner text,
    mitigation_plan text,
    target_resolution_date text,
    identified_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT unresolved_risks_severity_check CHECK ((severity = ANY (ARRAY['critical'::text, 'high'::text, 'medium'::text, 'low'::text])))
);


--
-- Name: user_access_profiles; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_access_profiles AS
 SELECT id,
    user_id,
    profile_id,
    tenant_id,
    granted_at,
    granted_by
   FROM platform_dauth.user_access_profiles;


--
-- Name: user_mfa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_mfa (
    user_id character varying(64) NOT NULL,
    mfa_type character varying(20) NOT NULL,
    totp_secret character varying(255),
    email_code_hash character varying(255),
    email_code_expires_at timestamp with time zone,
    consecutive_failures integer DEFAULT 0,
    locked_until timestamp with time zone,
    enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_view_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_view_preferences (
    user_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    module_code text NOT NULL,
    view_key text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_shared boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.user_view_preferences FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE user_view_preferences; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_view_preferences IS 'Per-user saved view configs (columns, filters, sort) scoped to tenant + module; `is_shared=true` rows are tenant-visible presets.';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id character varying(64) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    is_super_admin boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    settings jsonb DEFAULT '{}'::jsonb,
    tenant_id character varying(64),
    role character varying(100) DEFAULT 'owner'::character varying,
    name character varying(255),
    full_name character varying(255),
    onboarding_complete boolean DEFAULT false,
    member_onboarded boolean DEFAULT false,
    must_change_password boolean DEFAULT false,
    email_verified boolean DEFAULT false,
    email_verified_at timestamp with time zone,
    locked_until timestamp with time zone,
    platform_role character varying(100) DEFAULT 'admin'::character varying,
    avatar_url text,
    locale character varying(20) DEFAULT 'en'::character varying,
    timezone character varying(64) DEFAULT 'UTC'::character varying,
    last_login_at timestamp with time zone
);

ALTER TABLE ONLY public.users FORCE ROW LEVEL SECURITY;


--
-- Name: v_active_tenant_memberships; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_active_tenant_memberships AS
 SELECT tum.membership_id,
    tum.tenant_id,
    t.tenant_code,
    t.tenant_name_en,
    t.schema_name,
    tum.user_id,
    u.email,
    u.full_name,
    tum.membership_type,
    tum.is_tenant_owner,
    tum.joined_at
   FROM ((public.tenant_user_memberships tum
     JOIN public.users u ON (((u.user_id)::text = (tum.user_id)::text)))
     JOIN public.tenants t ON (((t.tenant_id)::text = (tum.tenant_id)::text)))
  WHERE ((tum.status = 'active'::text) AND ((u.status)::text = 'active'::text) AND ((t.status)::text = 'active'::text));


--
-- Name: v_onboarding_daily_activity; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_daily_activity AS
 SELECT tenant_id,
    date(created_at) AS activity_date,
    count(*) FILTER (WHERE ((action)::text = 'session_created'::text)) AS sessions_created,
    count(*) FILTER (WHERE ((action)::text = 'answers_saved'::text)) AS answers_submitted,
    count(*) FILTER (WHERE ((action)::text = 'review_submitted'::text)) AS reviews_submitted,
    count(*) FILTER (WHERE ((action)::text = 'onboarding_completed'::text)) AS completions,
    count(*) FILTER (WHERE ((action)::text = 'session_patched'::text)) AS edits,
    count(*) AS total_actions
   FROM public.audit_trail
  WHERE ((module)::text = 'onboarding'::text)
  GROUP BY tenant_id, (date(created_at));


--
-- Name: v_onboarding_funnel; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_funnel AS
 SELECT tenant_id,
    count(*) FILTER (WHERE ((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying, 'pending_review'::character varying, 'approved'::character varying, 'provisioning'::character varying, 'active'::character varying, 'completed'::character varying])::text[]))) AS total_sessions,
    count(*) FILTER (WHERE ((status)::text = 'draft'::text)) AS draft_count,
    count(*) FILTER (WHERE ((status)::text = 'in_progress'::text)) AS in_progress_count,
    count(*) FILTER (WHERE ((status)::text = 'pending_review'::text)) AS pending_review_count,
    count(*) FILTER (WHERE ((status)::text = 'approved'::text)) AS approved_count,
    count(*) FILTER (WHERE ((status)::text = 'provisioning'::text)) AS provisioning_count,
    count(*) FILTER (WHERE ((status)::text = 'active'::text)) AS active_count,
    count(*) FILTER (WHERE ((status)::text = 'completed'::text)) AS completed_count,
    count(*) FILTER (WHERE ((status)::text = 'cancelled'::text)) AS cancelled_count,
    count(*) FILTER (WHERE ((status)::text = 'failed'::text)) AS failed_count,
    round(avg(progress_percent), 1) AS avg_progress_pct,
    round(avg((EXTRACT(epoch FROM (COALESCE(updated_at, now()) - created_at)) / (3600)::numeric)), 1) AS avg_hours_to_complete,
    min(created_at) AS earliest_session,
    max(created_at) AS latest_session
   FROM public.onboarding_sessions
  GROUP BY tenant_id;


--
-- Name: v_onboarding_pack_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_pack_analytics AS
 SELECT (answer_json)::text AS selected_pack,
    count(DISTINCT session_id) AS selection_count,
    count(DISTINCT session_id) FILTER (WHERE (EXISTS ( SELECT 1
           FROM public.onboarding_sessions os
          WHERE ((os.id = oa.session_id) AND ((os.status)::text = ANY ((ARRAY['active'::character varying, 'completed'::character varying])::text[])))))) AS completed_count
   FROM public.onboarding_answers oa
  WHERE (((question_code)::text = 'pack.selected_pack'::text) AND (answer_json IS NOT NULL))
  GROUP BY (answer_json)::text;


--
-- Name: v_onboarding_provisioning_health; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_provisioning_health AS
 SELECT job_status,
    (count(*))::integer AS total,
    (count(*) FILTER (WHERE (created_at >= (now() - '24:00:00'::interval))))::integer AS last_24h,
    (count(*) FILTER (WHERE (created_at >= (now() - '7 days'::interval))))::integer AS last_7d,
    (avg(EXTRACT(epoch FROM (COALESCE(completed_at, failed_at, now()) - COALESCE(started_at, created_at)))))::integer AS avg_duration_seconds,
    (avg(attempts))::numeric(10,2) AS avg_attempts,
    max(attempts) AS max_attempts
   FROM public.provisioning_jobs
  GROUP BY job_status
  ORDER BY job_status;


--
-- Name: VIEW v_onboarding_provisioning_health; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.v_onboarding_provisioning_health IS 'Provisioning job FSM health: counts, average duration, retry pressure.';


--
-- Name: v_onboarding_question_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_question_analytics AS
 SELECT qb.stage_code,
    qb.question_code,
    qb.label_en AS question_text_en,
    qb.question_tier,
    count(DISTINCT oa.session_id) AS times_answered,
    count(DISTINCT oa.session_id) FILTER (WHERE ((oa.answer_json IS NOT NULL) AND ((oa.answer_json)::text <> 'null'::text) AND ((oa.answer_json)::text <> '""'::text))) AS non_empty_answers,
    round((((count(DISTINCT oa.session_id) FILTER (WHERE ((oa.answer_json IS NOT NULL) AND ((oa.answer_json)::text <> 'null'::text))))::numeric / (NULLIF(count(DISTINCT oa.session_id), 0))::numeric) * (100)::numeric), 1) AS answer_rate_pct
   FROM (public.onboarding_question_bank qb
     LEFT JOIN public.onboarding_answers oa ON (((oa.question_code)::text = qb.question_code)))
  WHERE (qb.is_active = true)
  GROUP BY qb.stage_code, qb.question_code, qb.label_en, qb.question_tier;


--
-- Name: v_onboarding_stage_analytics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_stage_analytics AS
 SELECT tenant_id,
    current_stage_code AS stage_code,
    count(*) AS sessions_at_stage,
    round(avg(progress_percent), 1) AS avg_progress_at_stage,
    count(*) FILTER (WHERE (updated_at < (now() - '7 days'::interval))) AS stalled_at_stage
   FROM public.onboarding_sessions os
  WHERE ((status)::text = ANY ((ARRAY['draft'::character varying, 'in_progress'::character varying])::text[]))
  GROUP BY tenant_id, current_stage_code;


--
-- Name: v_onboarding_stage_dropoff; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_onboarding_stage_dropoff AS
 WITH all_stages AS (
         SELECT stage_definitions.stage_code,
            stage_definitions.sequence_no
           FROM onb.stage_definitions
          WHERE (stage_definitions.is_active = true)
        ), parked AS (
         SELECT onboarding_sessions.current_stage_code AS stage_code,
            (count(*))::integer AS parked_now,
            (count(*) FILTER (WHERE ((onboarding_sessions.status)::text <> ALL ((ARRAY['completed'::character varying, 'cancelled'::character varying, 'active'::character varying, 'approved_for_provisioning'::character varying])::text[]))))::integer AS parked_open,
            (avg(EXTRACT(epoch FROM (now() - onboarding_sessions.updated_at))))::integer AS avg_seconds_since_last_save
           FROM public.onboarding_sessions
          WHERE (onboarding_sessions.current_stage_code IS NOT NULL)
          GROUP BY onboarding_sessions.current_stage_code
        ), advanced AS (
         SELECT s_self.stage_code,
            (count(DISTINCT os.id))::integer AS advanced_past
           FROM (all_stages s_self
             LEFT JOIN public.onboarding_sessions os ON ((((os.current_stage_code)::text IN ( SELECT all_stages.stage_code
                   FROM all_stages
                  WHERE (all_stages.sequence_no > s_self.sequence_no))) OR ((os.status)::text = ANY ((ARRAY['active'::character varying, 'completed'::character varying, 'approved_for_provisioning'::character varying])::text[])))))
          GROUP BY s_self.stage_code
        )
 SELECT s.stage_code,
    s.sequence_no,
    COALESCE(p.parked_now, 0) AS parked_now,
    COALESCE(p.parked_open, 0) AS parked_open,
    COALESCE(a.advanced_past, 0) AS advanced_past,
    COALESCE(p.avg_seconds_since_last_save, 0) AS avg_seconds_since_last_save,
        CASE
            WHEN ((COALESCE(p.parked_now, 0) + COALESCE(a.advanced_past, 0)) = 0) THEN (0)::numeric
            ELSE round(((100.0 * (COALESCE(a.advanced_past, 0))::numeric) / ((COALESCE(p.parked_now, 0) + COALESCE(a.advanced_past, 0)))::numeric), 2)
        END AS pass_through_percent
   FROM ((all_stages s
     LEFT JOIN parked p ON (((p.stage_code)::text = s.stage_code)))
     LEFT JOIN advanced a ON ((a.stage_code = s.stage_code)))
  ORDER BY s.sequence_no;


--
-- Name: VIEW v_onboarding_stage_dropoff; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.v_onboarding_stage_dropoff IS 'Per-stage funnel: sessions parked on stage vs advanced past. Drives bottleneck detection.';


--
-- Name: v_provisioning_performance; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_provisioning_performance AS
 SELECT os.tenant_id,
    count(*) AS total_jobs,
    count(*) FILTER (WHERE (pj.job_status = 'completed'::text)) AS completed_jobs,
    count(*) FILTER (WHERE (pj.job_status = 'failed'::text)) AS failed_jobs,
    count(*) FILTER (WHERE (pj.job_status = 'running'::text)) AS running_jobs,
    round(avg(EXTRACT(epoch FROM (COALESCE(pj.completed_at, now()) - pj.started_at))), 1) AS avg_duration_seconds,
    max(EXTRACT(epoch FROM (COALESCE(pj.completed_at, now()) - pj.started_at))) AS max_duration_seconds
   FROM (public.provisioning_jobs pj
     JOIN public.onboarding_sessions os ON ((os.id = pj.session_id)))
  GROUP BY os.tenant_id;


--
-- Name: v_user_bootstrap_state; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_user_bootstrap_state AS
 SELECT u.user_id,
    u.email,
    u.full_name,
    u.role,
    u.is_super_admin,
    u.onboarding_complete,
    u.status AS user_status,
    u.tenant_id,
    u.platform_role,
    u.must_change_password,
    t.org_name,
    t.tenant_name_en,
    t.tenant_name_ar,
    t.status AS tenant_status,
    t.schema_name,
    t.product_key,
    t.plan,
    os.id AS onboarding_session_id,
    os.status AS onboarding_status,
    os.progress_percent,
    os.current_stage_code,
    ws.workspace_id,
    ws.name AS workspace_name,
    ws.status AS workspace_status,
    (COALESCE(u.member_onboarded, false) OR (EXISTS ( SELECT 1
           FROM public.tenant_user_memberships_legacy tum
          WHERE (((tum.tenant_id)::text = (u.tenant_id)::text) AND ((tum.user_id)::text = (u.user_id)::text) AND ((tum.status)::text = 'active'::text))))) AS member_onboarded,
    (COALESCE(u.email_verified, false) OR (EXISTS ( SELECT 1
           FROM public.email_verification_tokens evt
          WHERE (((evt.user_id)::text = (u.user_id)::text) AND (evt.verified = true))))) AS email_verified_effective
   FROM (((public.users u
     LEFT JOIN public.tenants t ON (((t.tenant_id)::text = (u.tenant_id)::text)))
     LEFT JOIN LATERAL ( SELECT s.id,
            s.status,
            s.progress_percent,
            s.current_stage_code
           FROM public.onboarding_sessions s
          WHERE ((s.tenant_id)::text = (u.tenant_id)::text)
          ORDER BY s.created_at DESC NULLS LAST
         LIMIT 1) os ON (true))
     LEFT JOIN LATERAL public.fn_tenant_latest_workspace(t.schema_name) ws(workspace_id, name, status) ON (true));


--
-- Name: VIEW v_user_bootstrap_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.v_user_bootstrap_state IS 'Read-only join of user, tenant, latest onboarding session, latest workspace, membership flag, email verification. Adapted 2026-04-24 to match real email_verification_tokens schema (verified bool instead of purpose/used_at).';


--
-- Name: vulnerabilities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vulnerabilities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vulnerability_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    title text,
    severity character varying(30),
    status character varying(30) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_event ALTER COLUMN id SET DEFAULT nextval('dos.ai_event_id_seq'::regclass);


--
-- Name: audit_signoff_ledger bundle_id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_signoff_ledger ALTER COLUMN bundle_id SET DEFAULT nextval('dos.audit_signoff_ledger_bundle_id_seq'::regclass);


--
-- Name: billing_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.billing_event ALTER COLUMN id SET DEFAULT nextval('dos.billing_event_id_seq'::regclass);


--
-- Name: config_audit_logs id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_audit_logs ALTER COLUMN id SET DEFAULT nextval('dos.config_audit_logs_id_seq'::regclass);


--
-- Name: config_definitions id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_definitions ALTER COLUMN id SET DEFAULT nextval('dos.config_definitions_id_seq'::regclass);


--
-- Name: config_locks id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_locks ALTER COLUMN id SET DEFAULT nextval('dos.config_locks_id_seq'::regclass);


--
-- Name: config_runtime_overrides id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_runtime_overrides ALTER COLUMN id SET DEFAULT nextval('dos.config_runtime_overrides_id_seq'::regclass);


--
-- Name: config_values id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_values ALTER COLUMN id SET DEFAULT nextval('dos.config_values_id_seq'::regclass);


--
-- Name: data_governance_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.data_governance_event ALTER COLUMN id SET DEFAULT nextval('dos.data_governance_event_id_seq'::regclass);


--
-- Name: deployment_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.deployment_event ALTER COLUMN id SET DEFAULT nextval('dos.deployment_event_id_seq'::regclass);


--
-- Name: dos_master_drift_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_drift_event ALTER COLUMN id SET DEFAULT nextval('dos.dos_master_drift_event_id_seq'::regclass);


--
-- Name: dos_master_invalidation_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_invalidation_log ALTER COLUMN id SET DEFAULT nextval('dos.dos_master_invalidation_log_id_seq'::regclass);


--
-- Name: dos_master_writer_audit id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_writer_audit ALTER COLUMN id SET DEFAULT nextval('dos.dos_master_writer_audit_id_seq'::regclass);


--
-- Name: dr_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_event ALTER COLUMN id SET DEFAULT nextval('dos.dr_event_id_seq'::regclass);


--
-- Name: feature_flag_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flag_event ALTER COLUMN id SET DEFAULT nextval('dos.feature_flag_event_id_seq'::regclass);


--
-- Name: i18n_fallback_values id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.i18n_fallback_values ALTER COLUMN id SET DEFAULT nextval('dos.i18n_fallback_values_id_seq'::regclass);


--
-- Name: integration_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integration_event ALTER COLUMN id SET DEFAULT nextval('dos.integration_event_id_seq'::regclass);


--
-- Name: marketing_brand_assets id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_brand_assets ALTER COLUMN id SET DEFAULT nextval('dos.marketing_brand_assets_id_seq'::regclass);


--
-- Name: marketing_download_events id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_download_events ALTER COLUMN id SET DEFAULT nextval('dos.marketing_download_events_id_seq'::regclass);


--
-- Name: marketplace_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketplace_event ALTER COLUMN id SET DEFAULT nextval('dos.marketplace_event_id_seq'::regclass);


--
-- Name: migration_history id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.migration_history ALTER COLUMN id SET DEFAULT nextval('dos.migration_history_id_seq'::regclass);


--
-- Name: module_contract_errors id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_contract_errors ALTER COLUMN id SET DEFAULT nextval('dos.module_contract_errors_id_seq'::regclass);


--
-- Name: module_contract_publish_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_contract_publish_log ALTER COLUMN id SET DEFAULT nextval('dos.module_contract_publish_log_id_seq'::regclass);


--
-- Name: module_sla_defaults id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_sla_defaults ALTER COLUMN id SET DEFAULT nextval('dos.module_sla_defaults_id_seq'::regclass);


--
-- Name: navigation_registry id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.navigation_registry ALTER COLUMN id SET DEFAULT nextval('dos.navigation_registry_id_seq'::regclass);


--
-- Name: notification_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.notification_event ALTER COLUMN id SET DEFAULT nextval('dos.notification_event_id_seq'::regclass);


--
-- Name: orphan_schema_audit id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.orphan_schema_audit ALTER COLUMN id SET DEFAULT nextval('dos.orphan_schema_audit_id_seq'::regclass);


--
-- Name: platform_audit_logs id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_audit_logs ALTER COLUMN id SET DEFAULT nextval('dos.platform_audit_logs_id_seq'::regclass);


--
-- Name: platform_drift_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_drift_log ALTER COLUMN id SET DEFAULT nextval('dos.platform_drift_log_id_seq'::regclass);


--
-- Name: platform_operation_config id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_operation_config ALTER COLUMN id SET DEFAULT nextval('dos.platform_operation_config_id_seq'::regclass);


--
-- Name: platform_secret secret_id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_secret ALTER COLUMN secret_id SET DEFAULT nextval('dos.platform_secret_secret_id_seq'::regclass);


--
-- Name: platform_slo_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_slo_event ALTER COLUMN id SET DEFAULT nextval('dos.platform_slo_event_id_seq'::regclass);


--
-- Name: release_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.release_event ALTER COLUMN id SET DEFAULT nextval('dos.release_event_id_seq'::regclass);


--
-- Name: role_profile_sync_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.role_profile_sync_log ALTER COLUMN id SET DEFAULT nextval('dos.role_profile_sync_log_id_seq'::regclass);


--
-- Name: rollout_evaluation id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_evaluation ALTER COLUMN id SET DEFAULT nextval('dos.rollout_evaluation_id_seq'::regclass);


--
-- Name: runtime_config_history id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.runtime_config_history ALTER COLUMN id SET DEFAULT nextval('dos.runtime_config_history_id_seq'::regclass);


--
-- Name: schema_authoring_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_authoring_event ALTER COLUMN id SET DEFAULT nextval('dos.schema_authoring_event_id_seq'::regclass);


--
-- Name: schema_migrations id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_migrations ALTER COLUMN id SET DEFAULT nextval('dos.schema_migrations_id_seq'::regclass);


--
-- Name: security_secret_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.security_secret_event ALTER COLUMN id SET DEFAULT nextval('dos.security_secret_event_id_seq'::regclass);


--
-- Name: system_events id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.system_events ALTER COLUMN id SET DEFAULT nextval('dos.system_events_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.team_members ALTER COLUMN id SET DEFAULT nextval('dos.team_members_id_seq'::regclass);


--
-- Name: telemetry_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.telemetry_event ALTER COLUMN id SET DEFAULT nextval('dos.telemetry_event_id_seq'::regclass);


--
-- Name: tenant_config_versions_legacy id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_config_versions_legacy ALTER COLUMN id SET DEFAULT nextval('dos.tenant_config_versions_id_seq'::regclass);


--
-- Name: tenant_feature_flag_overrides id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_feature_flag_overrides ALTER COLUMN id SET DEFAULT nextval('dos.tenant_feature_flag_overrides_id_seq'::regclass);


--
-- Name: tenant_landing_config id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_landing_config ALTER COLUMN id SET DEFAULT nextval('dos.tenant_landing_config_id_seq'::regclass);


--
-- Name: tenant_memberships id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_memberships ALTER COLUMN id SET DEFAULT nextval('dos.tenant_memberships_id_seq'::regclass);


--
-- Name: tenant_product_activation id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_product_activation ALTER COLUMN id SET DEFAULT nextval('dos.tenant_product_activation_id_seq'::regclass);


--
-- Name: tenant_settings_legacy id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_settings_legacy ALTER COLUMN id SET DEFAULT nextval('dos.tenant_settings_id_seq'::regclass);


--
-- Name: trial_audit_log audit_id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.trial_audit_log ALTER COLUMN audit_id SET DEFAULT nextval('dos.trial_audit_log_audit_id_seq'::regclass);


--
-- Name: ui_route_agent_flow_step id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_flow_step ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_agent_flow_step_id_seq'::regclass);


--
-- Name: ui_route_agent_registry id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_registry ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_agent_registry_id_seq'::regclass);


--
-- Name: ui_route_ai_explainability_block id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_ai_explainability_block ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_ai_explainability_block_id_seq'::regclass);


--
-- Name: ui_route_audit_evidence_artifact id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_evidence_artifact ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_audit_evidence_artifact_id_seq'::regclass);


--
-- Name: ui_route_audit_ledger_row id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_ledger_row ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_audit_ledger_row_id_seq'::regclass);


--
-- Name: ui_route_calendar_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_calendar_event ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_calendar_event_id_seq'::regclass);


--
-- Name: ui_route_case_finalization id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_case_finalization ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_case_finalization_id_seq'::regclass);


--
-- Name: ui_route_column id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_column ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_column_id_seq'::regclass);


--
-- Name: ui_route_delegation_rule id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_delegation_rule ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_delegation_rule_id_seq'::regclass);


--
-- Name: ui_route_export_artifact id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_export_artifact ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_export_artifact_id_seq'::regclass);


--
-- Name: ui_route_filter id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_filter ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_filter_id_seq'::regclass);


--
-- Name: ui_route_follow_up_item id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_follow_up_item ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_follow_up_item_id_seq'::regclass);


--
-- Name: ui_route_heatmap_axis id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_heatmap_axis ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_heatmap_axis_id_seq'::regclass);


--
-- Name: ui_route_identity_graph_edge id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_identity_graph_edge ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_identity_graph_edge_id_seq'::regclass);


--
-- Name: ui_route_identity_graph_node id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_identity_graph_node ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_identity_graph_node_id_seq'::regclass);


--
-- Name: ui_route_incident_communication id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_communication ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_incident_communication_id_seq'::regclass);


--
-- Name: ui_route_incident_runbook_step id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_runbook_step ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_incident_runbook_step_id_seq'::regclass);


--
-- Name: ui_route_kpi id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_kpi ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_kpi_id_seq'::regclass);


--
-- Name: ui_route_nba id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_nba ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_nba_id_seq'::regclass);


--
-- Name: ui_route_org_chart_node id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_org_chart_node ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_org_chart_node_id_seq'::regclass);


--
-- Name: ui_route_ownership_edge id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_ownership_edge ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_ownership_edge_id_seq'::regclass);


--
-- Name: ui_route_policy_simulation_scenario id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_policy_simulation_scenario ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_policy_simulation_scenario_id_seq'::regclass);


--
-- Name: ui_route_report_card id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_report_card ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_report_card_id_seq'::regclass);


--
-- Name: ui_route_roadmap_milestone id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_roadmap_milestone ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_roadmap_milestone_id_seq'::regclass);


--
-- Name: ui_route_setting_section id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_setting_section ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_setting_section_id_seq'::regclass);


--
-- Name: ui_route_tab id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_tab ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_tab_id_seq'::regclass);


--
-- Name: ui_route_table_action id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_table_action ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_table_action_id_seq'::regclass);


--
-- Name: ui_route_workflow_timeline_step id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workflow_timeline_step ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_workflow_timeline_step_id_seq'::regclass);


--
-- Name: ui_route_workqueue_group id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workqueue_group ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_workqueue_group_id_seq'::regclass);


--
-- Name: ui_touch_target_config id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_touch_target_config ALTER COLUMN id SET DEFAULT nextval('dos.ui_touch_target_config_id_seq'::regclass);


--
-- Name: vendor_risk_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendor_risk_event ALTER COLUMN id SET DEFAULT nextval('dos.vendor_risk_event_id_seq'::regclass);


--
-- Name: workflow_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_event ALTER COLUMN id SET DEFAULT nextval('dos.workflow_event_id_seq'::regclass);


--
-- Name: workflow_step_run id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_step_run ALTER COLUMN id SET DEFAULT nextval('dos.workflow_step_run_id_seq'::regclass);


--
-- Name: workspace_shell_binding id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_binding ALTER COLUMN id SET DEFAULT nextval('dos.workspace_shell_binding_id_seq'::regclass);


--
-- Name: workspace_shell_i18n id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_i18n ALTER COLUMN id SET DEFAULT nextval('dos.workspace_shell_i18n_id_seq'::regclass);


--
-- Name: workspace_shell_status_label id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_status_label ALTER COLUMN id SET DEFAULT nextval('dos.workspace_shell_status_label_id_seq'::regclass);


--
-- Name: compliance_module_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_module_config ALTER COLUMN id SET DEFAULT nextval('public.compliance_module_config_id_seq'::regclass);


--
-- Name: compliance_user_view_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_user_view_preferences ALTER COLUMN id SET DEFAULT nextval('public.compliance_user_view_preferences_id_seq'::regclass);


--
-- Name: dead_letter_queue_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_letter_queue_legacy ALTER COLUMN id SET DEFAULT nextval('public.dead_letter_queue_id_seq'::regclass);


--
-- Name: email_verification_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens ALTER COLUMN id SET DEFAULT nextval('public.email_verification_tokens_id_seq'::regclass);


--
-- Name: feature_flag_overrides id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flag_overrides ALTER COLUMN id SET DEFAULT nextval('public.feature_flag_overrides_id_seq'::regclass);


--
-- Name: iam_identities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iam_identities ALTER COLUMN id SET DEFAULT nextval('public.iam_identities_id_seq'::regclass);


--
-- Name: lifecycle_checkpoints_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifecycle_checkpoints_legacy ALTER COLUMN id SET DEFAULT nextval('public.lifecycle_checkpoints_id_seq'::regclass);


--
-- Name: lifecycle_transitions_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifecycle_transitions_legacy ALTER COLUMN id SET DEFAULT nextval('public.lifecycle_transitions_id_seq'::regclass);


--
-- Name: module_dependencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_dependencies ALTER COLUMN id SET DEFAULT nextval('public.module_dependencies_id_seq'::regclass);


--
-- Name: module_health_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_health_events ALTER COLUMN id SET DEFAULT nextval('public.module_health_events_id_seq'::regclass);


--
-- Name: module_visibility_contracts_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_visibility_contracts_legacy ALTER COLUMN id SET DEFAULT nextval('public.module_visibility_contracts_id_seq'::regclass);


--
-- Name: org_pack_template_departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_departments ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_departments_id_seq'::regclass);


--
-- Name: org_pack_template_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_permissions ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_permissions_id_seq'::regclass);


--
-- Name: org_pack_template_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_profiles ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_profiles_id_seq'::regclass);


--
-- Name: org_pack_template_role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_role_permissions ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_role_permissions_id_seq'::regclass);


--
-- Name: org_pack_template_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_roles ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_roles_id_seq'::regclass);


--
-- Name: org_pack_template_sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_sections ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_sections_id_seq'::regclass);


--
-- Name: org_pack_template_sod_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_sod_rules ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_sod_rules_id_seq'::regclass);


--
-- Name: org_pack_template_teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_teams ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_teams_id_seq'::regclass);


--
-- Name: org_pack_template_workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_template_workflows ALTER COLUMN id SET DEFAULT nextval('public.org_pack_template_workflows_id_seq'::regclass);


--
-- Name: org_pack_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_pack_templates ALTER COLUMN id SET DEFAULT nextval('public.org_pack_templates_id_seq'::regclass);


--
-- Name: product_modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_modules ALTER COLUMN id SET DEFAULT nextval('public.product_modules_id_seq'::regclass);


--
-- Name: provisioning_telemetry_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provisioning_telemetry_legacy ALTER COLUMN id SET DEFAULT nextval('public.provisioning_telemetry_id_seq'::regclass);


--
-- Name: seed_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seed_history ALTER COLUMN id SET DEFAULT nextval('public.seed_history_id_seq'::regclass);


--
-- Name: shell_extensions_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shell_extensions_legacy ALTER COLUMN id SET DEFAULT nextval('public.shell_extensions_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: tenant_boundary_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_boundary_configs ALTER COLUMN id SET DEFAULT nextval('public.tenant_boundary_configs_id_seq'::regclass);


--
-- Name: tenant_status_transitions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_status_transitions ALTER COLUMN id SET DEFAULT nextval('public.tenant_status_transitions_id_seq'::regclass);


--
-- Name: tenant_user_memberships_legacy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_user_memberships_legacy ALTER COLUMN id SET DEFAULT nextval('public.tenant_user_memberships_id_seq'::regclass);


--
-- Data for Name: access_review_items; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.access_review_items (item_id, review_id, tenant_id, user_id, resource_type, resource_id, entitlement, decision, decided_by, decided_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: access_reviews; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.access_reviews (review_id, tenant_id, campaign_name, description, scope, status, due_date, created_by, created_at, updated_at, closed_at, deleted_at) FROM stdin;
6676958a-4efe-484a-9861-c060adb04275	t_test_sub_123	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
3ac214cb-2d1a-4801-9b4a-c41a38038df1	t_smoketest-17	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
7cc09b0b-ca7c-4240-a8f2-37b31875e68c	ad49692a66899912	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
d8217a76-2874-4068-a17c-bebf37b31ff5	ltcf89c3cd79100e	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
9576fc4a-d657-40df-8d63-e450ea02c4f3	cf4b5a3d6d7ac8f9	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
6ab97042-9341-48c5-bbfa-98ef5f61cc5b	782b08269e6cc5f9	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
7cdf67dd-8c2c-4a34-9253-ae6d6ed9e54d	26efb4ab96e69d39	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
44e59f0f-a2ab-41ce-830a-0e2084ebc436	9c9b68d25d5bbf12	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
51910c18-c1ca-4ad7-bea7-1f2b5e385b96	268e7256d2b1ad72	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
4b61f8cf-d144-443e-99eb-308b21f17738	618458a5e17306ce	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
6bd423aa-3276-4485-ba33-9eb5800074f2	8cd6729370df67ca	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
67054412-560d-423b-8f5d-bf5e89a5c6fa	c9902893da68d9bb	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
5c17e87d-5699-461c-bdd1-b6111e7b5155	8c9545ebcd5fc572	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
81885d2f-479f-461a-bec2-e3c35474d249	79a8bc5752cf1cea	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
38673b87-3d4d-4191-82cd-403a84cfb4ee	81feb4efc845cf18	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
db16b822-1398-4919-9ac3-a715d23ae61a	fb11c7dad9226ccf	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
07ae568d-5f27-4cf1-9b03-cb60e7ed9b7d	8f3d08c15271bbd6	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
6796b8af-b95e-463f-b5a5-925ffd3b153e	d19bf0ad7544dd99	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
f6d540ca-3d36-4469-97e2-746b36c57785	56c4868ce4ac13eb	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
4ff80151-ba24-4a9d-b0ab-465c7f7d39f4	6d8f5010ab6fe2fd	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
2f6520c6-5798-40a1-ac8f-eca0f4a2277d	2fe2fbf074870d00	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
cb4b6f9c-cc47-4ebb-a971-407be271111b	83f603ec4818beaf	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
f80634e3-aed5-4e02-93a3-bdad9a157d38	988e834dfe054814	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
e5482a93-eedd-4486-8143-9361b14c0769	51f36271df62ea3d	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
d24f8e57-6510-417c-97ea-67b30495dfcc	fe2d05c52cedc166	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
b6b9b995-c5f6-4813-a56c-10a53251eb86	c9ba85c2ac9cd5d3	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
7ae7981d-d2e5-4136-9c9b-6ee97a47345e	c847c95768fee259	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
57e92c97-ca36-424e-a42a-08be3409dd09	14f273cf260a4736	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
41cccb4c-0334-4c65-b450-391305cace55	384d22b24d86a84c	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
83c403e9-669f-4979-9f5d-4df59db9c208	fdc154ec9b342edb	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
0922beb9-78ad-4f31-b7d5-dd16e13f1b2e	163e25f3fc7d4f96	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
2c52b7ad-1d48-4baf-b90f-53aa778e4c38	4f1431397175b90d	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
dce59697-ec64-4923-93cc-f1059dc76843	b833040616bf8897	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
f7ea3ce4-c468-4ea3-8a90-5afe5995978d	4b0583e823c9b81e	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
cc1f79af-502d-4abc-a645-311baa06f846	84e48c1c13ddbab8	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
5ac600c6-3719-4e76-8dd4-373881599c82	dogan	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-05 03:06:18.598449+00	2026-05-05 03:06:18.598449+00	\N	\N
8490640e-c0f0-4d86-8062-14903b7b043d	d6f5b35d7bd0cf55	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-06 07:16:19.779291+00	2026-05-06 07:16:19.779291+00	\N	\N
258f665f-f9b5-4f17-8e6f-450fafe7abaa	7bc7ef1bb1f326ce	Q2 2026 Access Review	Quarterly access review for compliance	{}	not_started	2026-06-30 00:00:00+00	system	2026-05-06 07:16:19.779291+00	2026-05-06 07:16:19.779291+00	\N	\N
\.


--
-- Data for Name: action_items; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.action_items (action_id, tenant_id, remediation_id, title, status, assigned_to, due_date, completed_at, created_at, updated_at, deleted_at, is_deleted) FROM stdin;
\.


--
-- Data for Name: admin_pillar; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.admin_pillar (pillar_code, display_name, description, enabled, display_order) FROM stdin;
DNOC	DOS Network Operations Center	Service health, throughput, capacity, fleet ops.	t	1
DSOC	DOS Security Operations Center	Threat, intrusion, audit, anomaly, response.	t	2
DOS	DOS Operating System	Platform DNA: registry, lifecycle, doctrine, PPD.	t	3
DAuth	DOS Authority	Identity, session, MFA, SoD, authority, access store.	t	4
\.


--
-- Data for Name: admin_pillar_page; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.admin_pillar_page (id, pillar_code, page_key, display_name, archetype, route, permission_required, display_order, enabled) FROM stdin;
a33f2c1d-b019-42df-995d-3d4b4ec8d7f2	DNOC	overview	DNOC Overview	dashboard-grid	/admin/dnoc/overview	pillar.dnoc.access	1	t
cb86ccc6-6165-4ba4-a4b0-0976dd31e09e	DSOC	overview	DSOC Overview	dashboard-grid	/admin/dsoc/overview	pillar.dsoc.access	1	t
a93a26f1-a5c4-4538-9662-d1ac8293412b	DOS	overview	DOS Overview	dashboard-grid	/admin/dos/overview	pillar.dos.access	1	t
50353fad-8021-479b-bc9f-0a997164a831	DAuth	overview	DAuth Overview	dashboard-grid	/admin/dauth/overview	pillar.dauth.access	1	t
\.


--
-- Data for Name: admin_pillar_widget; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.admin_pillar_widget (id, page_id, widget_key, carbon_key, title_en, title_ar, data_source, props, display_order, permission_required) FROM stdin;
18097a7b-fe87-4390-b3ff-1a9e3c65220e	a33f2c1d-b019-42df-995d-3d4b4ec8d7f2	fleet-health	metric-card	Fleet Health	صحة الأسطول	prom:up{job=~"dos-.*"}	{"unit": "%"}	1	\N
1ebf4a04-9e6f-4e95-80b7-9084c6e68b99	a33f2c1d-b019-42df-995d-3d4b4ec8d7f2	service-list	data-table	Service Registry	سجل الخدمات	pg:dos_master.service_registry	{"page_size": 50}	2	\N
440c5d6d-2e3d-42bb-8956-0509c52be101	cb86ccc6-6165-4ba4-a4b0-0976dd31e09e	audit-stream	data-table	Audit Decision Ledger	سجل قرارات التدقيق	pg:dos.dos_master_writer_audit	{"page_size": 50}	1	\N
715d0284-93ef-4d45-b9d7-e5cd8a172c17	cb86ccc6-6165-4ba4-a4b0-0976dd31e09e	anomaly-feed	tile	Anomalies (24h)	حالات شاذة (24س)	loki:{job="audit"} |= "deny"	{}	2	\N
ca69654a-c876-469b-b010-3654e23934d0	a93a26f1-a5c4-4538-9662-d1ac8293412b	doctrine	data-table	Doctrine Articles	مواد العقيدة	pg:dos_master.doctrine_article	{}	1	\N
922857a5-4c5c-4ba0-94a4-7288bc363058	a93a26f1-a5c4-4538-9662-d1ac8293412b	rollout-rings	tile	Active Rollouts	إطلاقات نشطة	pg:dos.rollout_plan	{}	2	\N
90fb8ae1-0d54-4ca4-8a5a-465adc980ed6	50353fad-8021-479b-bc9f-0a997164a831	admin-users	data-table	Platform Admin Users	مدراء المنصة	pg:platform_admin.platform_admin_user	{"page_size": 50}	1	\N
f5920ab6-1a30-41c6-bffb-266d8f8f2c9b	50353fad-8021-479b-bc9f-0a997164a831	admin-grants	tile	Active Grants	الصلاحيات النشطة	pg:platform_admin.platform_admin_grant	{}	2	\N
\.


--
-- Data for Name: agent_action_receipts; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_action_receipts (id, tenant_id, run_id, agent_id, action_id, approved_by, approved_at, before_state, after_state, evidence_ref, rollback_ref, created_at) FROM stdin;
\.


--
-- Data for Name: agent_evidence_links; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_evidence_links (id, tenant_id, run_id, evidence_type, evidence_ref, created_at) FROM stdin;
\.


--
-- Data for Name: agent_memory; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_memory (id, tenant_id, agent_id, subject_type, subject_id, memory_key, payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_module_binding; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_module_binding (agent_code, module_code, workbench_route, audit_route, followup_route, enabled, created_at) FROM stdin;
A01	onboarding	/onboarding/agent	/onboarding/audit	/onboarding/followups	t	2026-05-03 10:47:39.675499+00
A02	identity	/identity/agent	/identity/audit	/identity/followups	t	2026-05-03 10:47:39.675499+00
A04	controls	/controls/agent	/controls/audit	/controls/followups	t	2026-05-03 10:47:39.675499+00
A05	evidence	/evidence/agent	/evidence/audit	/evidence/followups	t	2026-05-03 10:47:39.675499+00
A06	remediation	/remediation/agent	/remediation/audit	/remediation/followups	t	2026-05-03 10:47:39.675499+00
A07	risk	/risk/agent	/risk/audit	/risk/followups	t	2026-05-03 10:47:39.675499+00
A08	policy	/policy/agent	/policy/audit	/policy/followups	t	2026-05-03 10:47:39.675499+00
A09	vendor	/vendor/agent	/vendor/audit	/vendor/followups	t	2026-05-03 10:47:39.675499+00
A10	audit	/audit/agent	/audit/timeline	/audit/followups	t	2026-05-03 10:47:39.675499+00
A13	marketing	/	\N	/contact	t	2026-05-05 07:13:46.817114+00
\.


--
-- Data for Name: agent_recommendations; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_recommendations (id, tenant_id, module_code, route, subject_type, subject_id, agent_id, recommendation, rationale, confidence, risk_level, status, evidence_links, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: agent_registry; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_registry (agent_code, display_name_en, display_name_ar, role_key, capabilities, permission_key, brand_tile_kind, status, confidence_default, created_at, updated_at) FROM stdin;
A01	Onboarding Agent	وكيل التهيئة	onboarding	{observe,suggest,execute}	agent.onboarding.run	agent-tile	active	0.85	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A02	Identity Provisioning Agent	وكيل توفير الهوية	identity	{observe,suggest,approve,execute,verify}	agent.identity.provision	agent-tile	active	0.80	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A04	Control Authoring Agent	وكيل تأليف الضوابط	controls	{observe,suggest,execute,verify}	agent.controls.author	agent-tile	active	0.78	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A05	Evidence Collection Agent	وكيل جمع الأدلة	evidence	{observe,execute,verify,log}	agent.evidence.collect	agent-tile	active	0.82	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A06	Gap Remediation Agent	وكيل معالجة الفجوات	remediation	{observe,suggest,approve,execute}	agent.remediation.run	agent-tile	active	0.74	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A07	Risk Register Agent	وكيل سجل المخاطر	risk	{observe,suggest,log}	agent.risk.register	agent-tile	active	0.80	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A08	Policy Lifecycle Agent	وكيل دورة حياة السياسات	policy	{observe,suggest,approve,execute}	agent.policy.lifecycle	agent-tile	active	0.77	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A09	Third-Party Risk Agent	وكيل مخاطر الأطراف الثالثة	vendor	{observe,suggest,verify}	agent.vendor.risk	agent-tile	active	0.76	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A10	Audit Reporting Agent	وكيل تقارير التدقيق	audit	{observe,execute,log}	agent.audit.report	agent-tile	active	0.83	2026-05-03 10:47:39.675499+00	2026-05-03 10:47:39.675499+00
A13	Landing Copilot Agent	وكيل المساعد في الصفحة الرئيسية	landing	{public_qna,lead_capture,demo_intent,pricing_intent,docs_intent}	agent.public.copilot	agent-tile	active	0.85	2026-05-05 07:13:46.817114+00	2026-05-06 07:16:20.296645+00
\.


--
-- Data for Name: agent_run_steps; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_run_steps (id, run_id, step_index, agent_id, step_type, payload, result, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: agent_runs; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agent_runs (run_id, tenant_id, module_code, route, agent_id, user_id, status, started_at, completed_at, confidence, risk_level, approval_required, correlation_id) FROM stdin;
\.


--
-- Data for Name: agrc_agent_memory; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_agent_memory (memory_id, tenant_id, agent_id, scope, key, value, cycle_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agrc_agent_runs; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_agent_runs (run_id, tenant_id, agent_id, cycle_id, status, mode, task, context, result, discovery_count, action_count, token_usage, duration_ms, error, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: agrc_cycles; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_cycles (cycle_id, tenant_id, mode, status, agents, context, results, wave_count, discovery_count, action_count, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: agrc_discoveries; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_discoveries (discovery_id, tenant_id, cycle_id, agent_id, run_id, type, severity, title, description, entity_type, entity_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: agrc_handoffs; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_handoffs (handoff_id, tenant_id, from_agent, to_agent, payload, priority, status, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: agrc_proposed_actions; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_proposed_actions (action_id, tenant_id, cycle_id, agent_id, run_id, type, title, description, target_entity_type, target_entity_id, payload, risk_level, status, review_reason, reviewed_at, reviewed_by, executed_at, created_at) FROM stdin;
\.


--
-- Data for Name: agrc_tasks; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.agrc_tasks (task_id, tenant_id, title, description, task_type, priority, status, assigned_to, due_date, source_module, source_entity_id, created_at, updated_at, deleted_at, is_deleted, type, module, agent_id, assignee_id, input_data, output_data, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: ai_agent_registry; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.ai_agent_registry (id, agent_code, name_en, name_ar, capabilities, model_code, is_active, created_at) FROM stdin;
e42856e2-201e-4233-bd39-44bbec41947b	A01	Onboarding Agent	وكيل التهيئة	["Industry intake", "Framework recommendation", "Workspace seed"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
dfd77ebe-63e7-41b3-be7c-2d507d5fc5b1	A02	Identity Management Agent	وكيل إدارة الهوية	["SSO / Azure AD", "RBAC", "MFA enforcement"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
2e6bc5d9-f199-4f08-871d-e7153761e44b	A13	Policy Review & Landing Copilot	كوبايلوت مراجعة السياسات والصفحة الترويجية	["copilot", "tool-calling", "multi-tenant"]	claude-3-5-sonnet	t	2026-05-05 09:29:37.486122+00
50c6add7-2007-4647-8840-be1a200cb522	A03	Framework Mapping Agent	وكيل ربط الأطر التنظيمية	["Cross-framework mapping", "Confidence scoring"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
50c172a2-c065-4ad7-b54c-b936b0b7ddc6	A04	Control Authoring Agent	وكيل تأليف الضوابط	["Bilingual drafting", "Test procedures"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
521268ac-99ca-4486-879a-ed8b82bd2431	A05	Evidence Collection Agent	وكيل جمع الأدلة	["Document analysis", "Freshness checks"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
58822596-b16c-4a19-a1cb-f6a2964242c3	A06	Gap Remediation Agent	وكيل معالجة الثغرات	["Priority scoring", "Roadmap generation"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
bd2e3ca5-746d-4374-abc9-be8f1928da91	A07	Risk Register Agent	وكيل سجل المخاطر	["5x5 scoring", "KRI tracking"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
5836f07c-7c9d-4db5-a96d-9ab04a440ba5	A08	Policy Lifecycle Agent	وكيل دورة حياة السياسات	["Approval workflow", "Distribution"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
e65f618a-1e49-4eeb-8b11-e84a93c923f4	A09	Third-Party Risk Agent	وكيل مخاطر الأطراف الثالثة	["DDQ", "SLA monitoring"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
95a783f5-a93b-4ee7-91cc-e68724cf57c2	A10	Audit Reporting Agent	وكيل تقارير التدقيق	["Regulator packs", "Executive dashboards"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
e44b788b-8b0d-485f-979a-5a99193d4c07	A11	Business Continuity Agent	وكيل استمرارية الأعمال	["BIA / RTO / RPO", "Exercise scheduling"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
74e3863e-5534-4cc5-8458-b5eb4450b765	A12	Training & Awareness Agent	وكيل التدريب والتوعية	["Phishing simulation", "Certification"]	claude-3-5-sonnet	t	2026-04-26 07:06:27.543609+00
\.


--
-- Data for Name: ai_event; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.ai_event (id, record_id, record_key, kind, payload, emitted_by, emitted_at) FROM stdin;
1	289b4af2-309d-4135-8e8c-3db74e7822c2	shahin.gpt-classifier	ai_evaluated	{"ctx": {"tenant_id": "t-1"}, "reason": "llm:default_on", "version": 1, "decision": "on"}	ai-os-service	2026-05-04 12:40:42.248807+00
\.


--
-- Data for Name: ai_model_registry; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.ai_model_registry (id, provider, model_code, name, capabilities, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: ai_prompt_registry; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.ai_prompt_registry (id, prompt_code, name, template, model_code, module_code, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: ai_record; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.ai_record (id, record_key, version, title, kind, trust_zone, status, config, created_by, created_at, published_at, retired_at) FROM stdin;
289b4af2-309d-4135-8e8c-3db74e7822c2	shahin.gpt-classifier	1	AI model registry	llm	admin	published	{"seed": true}	dos-master	2026-05-04 11:36:32.37492+00	2026-05-04 11:36:32.37492+00	\N
\.


--
-- Data for Name: approval_matrix_rules; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.approval_matrix_rules (rule_id, module_code, action_code, required_authority_code, min_approvals, value_threshold, description, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.assets (asset_id, tenant_id, name, type, category, status, owner_id, classification, location, value, is_deleted, deleted_at, created_at, updated_at, asset_type, criticality, department_id, owner_user_id, metadata) FROM stdin;
\.


--
-- Data for Name: audit_findings; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.audit_findings (finding_id, tenant_id, title, description, severity, status, control_id, assigned_to, due_date, is_deleted, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_log_archive; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.audit_log_archive (entry_id, tenant_id, actor_id, action, module, entity_type, entity_id, before_state, after_state, ip_address, created_at, archived_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.audit_logs (log_id, tenant_id, action, entity_type, entity_id, actor_id, actor_email, before_state, after_state, metadata, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: audit_plans; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.audit_plans (plan_id, tenant_id, name, audit_type, scope, frequency, year, status, owner_id, is_deleted, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_signoff_ledger; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.audit_signoff_ledger (bundle_id, tenant_id, generated_at, generated_by, bundle_hash, bundle_path, section_counts, signed_by, signed_at, signature_hash, notes) FROM stdin;
1	tenant_test_foundation	2026-05-05 04:23:14.201+00	cli@dos.local	3d04e4da0940805572895757060c0107b5695885fc8c2104f6609f7c6ffbedb5	ops/handover/2026-05-05/audit-shelf/tenant_test_foundation/bundle.json	{"audit_signoff_ledger": 0, "ura_projection_state": 4, "drift_telemetry_window": -1, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
2	tenant_test_foundation	2026-05-05 04:24:14.587+00	cli@dos.local	d7f686e276c8940832dadc6889c5e938da82accc7942ccbae314c0563b427d1e	ops/handover/2026-05-05/audit-shelf/tenant_test_foundation/bundle.json	{"audit_signoff_ledger": 1, "ura_projection_state": 4, "drift_telemetry_window": 20, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
3	tenant_test_foundation	2026-05-05 04:26:09.441+00	cli@dos.local	6c87f69f37154181c063b13fca7202dfc6738a0a803193a0713e3a51fbab29d9	ops/handover/2026-05-05/audit-shelf/tenant_test_foundation/bundle.json	{"audit_signoff_ledger": 2, "ura_projection_state": 4, "drift_telemetry_window": 20, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
4	tenant_test_foundation	2026-05-05 04:28:37.73+00	cli@dos.local	12d7dadd8adfb999bda4f9dbdf43fadbd53bdf77edc7b671e9dc7c877d20573c	ops/handover/2026-05-05/audit-shelf/tenant_test_foundation/bundle.json	{"audit_signoff_ledger": 3, "ura_projection_state": 4, "drift_telemetry_window": 30, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
5	00000000-0000-0000-0000-000000000000	2026-05-06 19:33:14.951+00	cli@dos.local	ccf6a53efd4b7e0dfdb60b79d3e07317a22028ab5a56c70593fc3afd2d1492e4	ops/handover/2026-05-06/audit-shelf/00000000-0000-0000-0000-000000000000/bundle.json	{"audit_signoff_ledger": 0, "ura_projection_state": 0, "drift_telemetry_window": 60, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
6	00000000-0000-0000-0000-000000000000	2026-05-06 19:35:29.11+00	cli@dos.local	5d23dc28049068f3bdaedf2b791b96939c8e39791e8f1a3a956f36418a9fd9e2	ops/handover/2026-05-06/audit-shelf/00000000-0000-0000-0000-000000000000/bundle.json	{"audit_signoff_ledger": 1, "ura_projection_state": 0, "drift_telemetry_window": 60, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
7	00000000-0000-0000-0000-000000000000	2026-05-06 19:38:54.898+00	cli@dos.local	9bc41c46c26b58d275e94af214f7ea432eacfed26fca58caa774e53d176312bf	ops/handover/2026-05-06/audit-shelf/00000000-0000-0000-0000-000000000000/bundle.json	{"audit_signoff_ledger": 2, "ura_projection_state": 0, "drift_telemetry_window": 70, "tenant_migration_ledger": 0, "role_profile_sync_ledger": 0}	\N	\N	\N	\N
\.


--
-- Data for Name: audit_trail; Type: TABLE DATA; Schema: dos; Owner: -
--

COPY dos.audit_trail (entry_id, tenant_id, actor_id, action, entity_type, entity_id, module, payload, created_at) FROM stdin;
