--
-- PostgreSQL database dump
--

\restrict U3SeetXfJvPuGHdGTIIqMRuJ8KFH0iB1tZFRat8Gfu0eWhH9rdOL3WmwVbWfHh4

-- Dumped from database version 18.3 (Ubuntu 18.3-1.pgdg22.04+1)
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dos; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dos;


--
-- Name: ui_ai_action_draft_state_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_ai_action_draft_state_t AS ENUM (
    'pending',
    'confirmed',
    'executed',
    'rejected',
    'expired'
);


--
-- Name: ui_ai_panel_position_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_ai_panel_position_t AS ENUM (
    'left',
    'right',
    'bottom',
    'floating'
);


--
-- Name: ui_brand_asset_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_brand_asset_kind_t AS ENUM (
    'logo',
    'favicon',
    'hero',
    'watermark',
    'social_card',
    'letterhead',
    'email_header'
);


--
-- Name: ui_change_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_change_kind_t AS ENUM (
    'create',
    'update',
    'delete',
    'publish',
    'rollback',
    'approve',
    'reject'
);


--
-- Name: ui_checklist_step_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_checklist_step_status_t AS ENUM (
    'not_started',
    'in_progress',
    'completed',
    'skipped',
    'blocked'
);


--
-- Name: ui_command_surface_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_command_surface_t AS ENUM (
    'palette',
    'shortcut',
    'menu',
    'toolbar',
    'context_menu',
    'programmatic'
);


--
-- Name: ui_contextual_help_display_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_contextual_help_display_t AS ENUM (
    'tooltip',
    'popover',
    'panel',
    'inline',
    'modal'
);


--
-- Name: ui_contrast_mode_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_contrast_mode_t AS ENUM (
    'default',
    'high',
    'inverted'
);


--
-- Name: ui_device_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_device_kind_t AS ENUM (
    'desktop',
    'tablet',
    'mobile',
    'tv',
    'watch'
);


--
-- Name: ui_error_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_error_kind_t AS ENUM (
    'render',
    'api',
    'permission',
    'validation',
    'timeout',
    'network',
    'unknown'
);


--
-- Name: ui_flag_target_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_flag_target_kind_t AS ENUM (
    'tenant',
    'role',
    'user',
    'product',
    'module'
);


--
-- Name: ui_form_decision_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_decision_t AS ENUM (
    'pending',
    'approved',
    'rejected',
    'delegated',
    'escalated'
);


--
-- Name: ui_form_default_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_default_kind_t AS ENUM (
    'static',
    'expression',
    'from_user',
    'from_tenant',
    'from_workflow'
);


--
-- Name: ui_form_field_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_field_kind_t AS ENUM (
    'text',
    'textarea',
    'number',
    'integer',
    'boolean',
    'date',
    'datetime',
    'select',
    'multiselect',
    'radio',
    'checkbox',
    'file',
    'user_picker',
    'entity_picker',
    'rich_text',
    'signature',
    'json',
    'rating'
);


--
-- Name: ui_form_rule_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_rule_kind_t AS ENUM (
    'visible_when',
    'required_when',
    'enabled_when',
    'value_when'
);


--
-- Name: ui_form_submission_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_submission_status_t AS ENUM (
    'draft',
    'submitted',
    'approved',
    'rejected',
    'withdrawn',
    'superseded'
);


--
-- Name: ui_form_validator_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_form_validator_kind_t AS ENUM (
    'required',
    'pattern',
    'range',
    'min_length',
    'max_length',
    'min',
    'max',
    'email',
    'url',
    'phone',
    'custom'
);


--
-- Name: ui_grid_column_capability_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_grid_column_capability_t AS ENUM (
    'view',
    'edit',
    'export',
    'filter',
    'sort'
);


--
-- Name: ui_grid_column_data_type_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_grid_column_data_type_t AS ENUM (
    'text',
    'number',
    'integer',
    'boolean',
    'date',
    'datetime',
    'json',
    'uuid',
    'enum',
    'badge',
    'link',
    'currency',
    'percent'
);


--
-- Name: ui_grid_export_format_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_grid_export_format_t AS ENUM (
    'csv',
    'xlsx',
    'pdf',
    'json'
);


--
-- Name: ui_http_method_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_http_method_t AS ENUM (
    'GET',
    'POST',
    'PUT',
    'DELETE',
    'PATCH'
);


--
-- Name: ui_job_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_job_status_t AS ENUM (
    'queued',
    'running',
    'succeeded',
    'failed',
    'expired',
    'cancelled'
);


--
-- Name: ui_locale_direction_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_locale_direction_t AS ENUM (
    'ltr',
    'rtl'
);


--
-- Name: ui_manager_draft_state_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_manager_draft_state_t AS ENUM (
    'draft',
    'validating',
    'submitted',
    'rejected',
    'published'
);


--
-- Name: ui_notification_channel_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_notification_channel_t AS ENUM (
    'in_app',
    'email',
    'sms',
    'push',
    'webhook'
);


--
-- Name: ui_notification_digest_window_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_notification_digest_window_t AS ENUM (
    'instant',
    'hourly',
    'daily',
    'weekly'
);


--
-- Name: ui_notification_severity_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_notification_severity_t AS ENUM (
    'info',
    'success',
    'warning',
    'error',
    'critical'
);


--
-- Name: ui_perm_effect_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_perm_effect_t AS ENUM (
    'allow',
    'deny'
);


--
-- Name: ui_print_engine_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_print_engine_t AS ENUM (
    'html',
    'latex',
    'docx'
);


--
-- Name: ui_publish_status_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_publish_status_t AS ENUM (
    'pending',
    'approved',
    'rejected',
    'cancelled',
    'superseded'
);


--
-- Name: ui_retry_strategy_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_retry_strategy_t AS ENUM (
    'manual',
    'linear',
    'exponential',
    'none'
);


--
-- Name: ui_split_orientation_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_split_orientation_t AS ENUM (
    'horizontal',
    'vertical'
);


--
-- Name: ui_target_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_target_kind_t AS ENUM (
    'route',
    'page_layout',
    'dashboard',
    'widget_instance',
    'action',
    'form',
    'navigation_node',
    'menu_item',
    'tour',
    'field',
    'grid_column'
);


--
-- Name: ui_theme_target_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_theme_target_kind_t AS ENUM (
    'tenant',
    'role',
    'user',
    'product',
    'module'
);


--
-- Name: ui_theme_token_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_theme_token_kind_t AS ENUM (
    'color',
    'radius',
    'shadow',
    'spacing',
    'typography',
    'motion',
    'z_index',
    'breakpoint'
);


--
-- Name: ui_viewport_breakpoint_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_viewport_breakpoint_t AS ENUM (
    'xs',
    'sm',
    'md',
    'lg',
    'xl',
    'xxl'
);


--
-- Name: ui_visibility_effect_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_visibility_effect_t AS ENUM (
    'show',
    'hide'
);


--
-- Name: ui_visibility_rule_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_visibility_rule_kind_t AS ENUM (
    'permission',
    'role',
    'feature_flag',
    'expression',
    'module_status',
    'time_window',
    'tenant_attribute'
);


--
-- Name: ui_widget_binding_kind_t; Type: TYPE; Schema: dos; Owner: -
--

CREATE TYPE dos.ui_widget_binding_kind_t AS ENUM (
    'rest',
    'graphql',
    'static',
    'temporal_workflow',
    'ai_query',
    'sql_view'
);


--
-- Name: acquire_migration_lock(character varying, character varying, integer); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.acquire_migration_lock(p_service_name character varying, p_locked_by character varying, p_lock_duration_minutes integer DEFAULT 30) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_lock_acquired BOOLEAN;
BEGIN
    -- Clean up expired locks
    DELETE FROM dos.migration_lock WHERE lock_expires_at <= NOW();
    
    -- Try to acquire lock
    INSERT INTO dos.migration_lock (service_name, locked_by, lock_expires_at)
    VALUES (p_service_name, p_locked_by, NOW() + (p_lock_duration_minutes || ' minutes')::INTERVAL)
    ON CONFLICT (service_name) DO NOTHING;
    
    -- Check if lock was acquired
    SELECT EXISTS (
        SELECT 1 FROM dos.migration_lock 
        WHERE service_name = p_service_name 
        AND locked_by = p_locked_by
    ) INTO v_lock_acquired;
    
    RETURN v_lock_acquired;
END;
$$;


--
-- Name: assert_published_by_only(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.assert_published_by_only() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  publisher TEXT;
BEGIN
  publisher := current_setting('dos.publisher_session', true);
  IF publisher IS NULL OR publisher = '' THEN
    RAISE EXCEPTION
      '[contract-publisher] table %.% is publisher-owned; manual writes forbidden. '
      'Run via `pnpm module:publish <code>`.',
      TG_TABLE_SCHEMA, TG_TABLE_NAME;
  END IF;
  IF publisher <> 'contract-publisher@v1' THEN
    RAISE EXCEPTION
      '[contract-publisher] unknown publisher signature %', publisher;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: bump_ui_override_version(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.bump_ui_override_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version    := COALESCE(OLD.version, 0) + 1;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: bump_ui_route_template_version(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.bump_ui_route_template_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version := COALESCE(OLD.version,0) + 1;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: bump_workspace_shell_binding_version(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.bump_workspace_shell_binding_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version := COALESCE(OLD.version, 0) + 1;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: can_execute_migration(character varying, integer, character varying); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.can_execute_migration(p_service_name character varying, p_migration_number integer, p_migration_type character varying) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_last_migration INTEGER;
    v_has_lock BOOLEAN;
BEGIN
    -- Check if service is locked for migration
    SELECT EXISTS (
        SELECT 1 FROM dos.migration_lock 
        WHERE service_name = p_service_name 
        AND lock_expires_at > NOW()
    ) INTO v_has_lock;
    
    IF v_has_lock THEN
        RETURN FALSE;
    END IF;
    
    -- For UP migrations, check if previous migration exists
    IF p_migration_type = 'up' AND p_migration_number > 1 THEN
        SELECT COALESCE(MAX(migration_number), 0) INTO v_last_migration
        FROM dos.migration_history 
        WHERE service_name = p_service_name 
        AND migration_type = 'up' 
        AND success = true;
        
        IF v_last_migration != p_migration_number - 1 THEN
            RETURN FALSE;
        END IF;
    END IF;
    
    -- Check if this migration was already executed successfully
    IF EXISTS (
        SELECT 1 FROM dos.migration_history 
        WHERE service_name = p_service_name 
        AND migration_number = p_migration_number 
        AND migration_type = p_migration_type 
        AND success = true
    ) THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
$$;


--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.current_tenant_id() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  SELECT NULLIF(current_setting('dos.tenant_id', true), '')
$$;


--
-- Name: fn_block_non_ibm_catalog_row(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_block_non_ibm_catalog_row() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.vendor IS DISTINCT FROM 'ibm-carbon' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: ui_carbon_components row "%" rejected — vendor=% (must be ibm-carbon)',
      NEW.carbon_key, NEW.vendor;
  END IF;

  IF NEW.package_name NOT LIKE '@carbon/%'
     AND NEW.package_name <> 'carbon-components-angular' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: ui_carbon_components row "%" rejected — package_name % is not an IBM Carbon package',
      NEW.carbon_key, NEW.package_name;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: fn_block_non_ibm_runtime_row(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_block_non_ibm_runtime_row() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  catalog_vendor          VARCHAR(40);
  catalog_runtime_status  VARCHAR(40);
BEGIN
  -- Vendor lock — registry row must declare ibm-carbon.
  IF NEW.vendor IS DISTINCT FROM 'ibm-carbon' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — vendor=% (must be ibm-carbon)',
      NEW.component_key, NEW.vendor;
  END IF;

  -- Approval lock — only approved rows render.
  IF NEW.approval_status IS DISTINCT FROM 'approved' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — approval_status=% (must be approved)',
      NEW.component_key, NEW.approval_status;
  END IF;

  -- carbon_key linkage — must point at a real catalog row whose vendor is
  -- ibm-carbon and whose runtime_status permits runtime use.
  IF NEW.carbon_key IS NULL THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — carbon_key is NULL (must FK into dos.ui_carbon_components)',
      NEW.component_key;
  END IF;

  SELECT vendor, runtime_status
    INTO catalog_vendor, catalog_runtime_status
    FROM dos.ui_carbon_components
   WHERE carbon_key = NEW.carbon_key;

  IF NOT FOUND THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — carbon_key % not in dos.ui_carbon_components',
      NEW.component_key, NEW.carbon_key;
  END IF;

  IF catalog_vendor <> 'ibm-carbon' THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — catalog row % has vendor=% (must be ibm-carbon)',
      NEW.component_key, NEW.carbon_key, catalog_vendor;
  END IF;

  IF catalog_runtime_status IN ('blocked-react-only', 'missing-upstream-angular-binding', 'catalog-only') THEN
    RAISE EXCEPTION
      'CARBON-ONLY: dynamic_ui_component_registry row "%" rejected — catalog row % runtime_status=% is not runtime-eligible',
      NEW.component_key, NEW.carbon_key, catalog_runtime_status;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: fn_dos_component_carbon_map_check(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_dos_component_carbon_map_check() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rs text;
BEGIN
  SELECT runtime_status INTO rs
    FROM dos.ui_carbon_components
   WHERE carbon_key = NEW.carbon_key
     AND vendor = 'ibm-carbon'
     AND is_active = true;
  IF rs IS NULL THEN
    RAISE EXCEPTION 'carbon_key % is not an active ibm-carbon catalog row', NEW.carbon_key;
  END IF;
  IF rs NOT IN ('active','wrapper-required') THEN
    RAISE EXCEPTION 'carbon_key % runtime_status=% is not Angular-usable', NEW.carbon_key, rs;
  END IF;
  NEW.updated_at := NOW();
  RETURN NEW;
END $$;


--
-- Name: fn_role_profile_project_to_ura(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_role_profile_project_to_ura() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  PERFORM set_config('app.via_role_profile', 'true', true);
  IF TG_OP IN ('INSERT','UPDATE') THEN
    INSERT INTO platform_dauth.user_role_assignments
      (assignment_id, tenant_id, user_id, role_code, scope, granted_by, granted_at, is_active)
    VALUES
      (NEW.profile_id::text, NEW.tenant_id, NEW.user_id, NEW.role_code, NEW.scope,
       NEW.source_system, NEW.created_at, NEW.lifecycle_state = 'active')
    ON CONFLICT (assignment_id) DO UPDATE
      SET role_code = EXCLUDED.role_code,
          scope     = EXCLUDED.scope,
          is_active = EXCLUDED.is_active;
  ELSIF TG_OP = 'DELETE' THEN
    DELETE FROM platform_dauth.user_role_assignments
     WHERE assignment_id = OLD.profile_id::text;
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;


--
-- Name: fn_role_profile_touch_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.fn_role_profile_touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = COALESCE(OLD.version,1) + 1;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: record_migration(character varying, integer, character varying, character varying, character varying, character varying, character varying, integer, boolean, text, boolean); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.record_migration(p_service_name character varying, p_migration_number integer, p_migration_name character varying, p_migration_type character varying, p_executed_by character varying, p_git_sha character varying DEFAULT NULL::character varying, p_checksum character varying DEFAULT NULL::character varying, p_duration_ms integer DEFAULT NULL::integer, p_success boolean DEFAULT true, p_error_message text DEFAULT NULL::text, p_rollback_available boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    INSERT INTO dos.migration_history (
        service_name, migration_number, migration_name, migration_type,
        executed_by, git_sha, checksum, duration_ms, success, error_message, rollback_available
    ) VALUES (
        p_service_name, p_migration_number, p_migration_name, p_migration_type,
        p_executed_by, p_git_sha, p_checksum, p_duration_ms, p_success, p_error_message, p_rollback_available
    );
END;
$$;


--
-- Name: release_migration_lock(character varying, character varying); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.release_migration_lock(p_service_name character varying, p_locked_by character varying) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    DELETE FROM dos.migration_lock 
    WHERE service_name = p_service_name 
    AND locked_by = p_locked_by;
END;
$$;


--
-- Name: seed_workspace_shell_binding_for_tenant(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.seed_workspace_shell_binding_for_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO dos.workspace_shell_binding
    (tenant_id, component_key, position, perms_required, props)
  SELECT
    NEW.tenant_id,
    r.component_key,
    COALESCE(NULLIF(r.metadata->>'position','')::int,
             row_number() OVER (ORDER BY r.component_key)::int),
    ARRAY[]::text[],
    '{}'::jsonb
    FROM dos.dynamic_ui_component_registry r
   WHERE r.component_key LIKE 'workspace.%'
     AND r.approval_status = 'approved'
   ON CONFLICT (tenant_id, component_key) DO NOTHING;
  RETURN NEW;
END
$$;


--
-- Name: FUNCTION seed_workspace_shell_binding_for_tenant(); Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON FUNCTION dos.seed_workspace_shell_binding_for_tenant() IS '2026-05-05 v3 — registry-driven auto-seed for newly-inserted dos.tenants rows. Reads every approved workspace.* component_key from dos.dynamic_ui_component_registry; position lifted from metadata.position with row_number fallback. Idempotent on UNIQUE(tenant_id, component_key).';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: trg_dos_master_only(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'dos', 'public'
    AS $$
DECLARE
  v_actor   text := current_setting('dos.actor', true);
  v_role    text := current_setting('dos.actor_role', true);
  v_cr      uuid := nullif(current_setting('dos.change_request_id', true), '')::uuid;
  v_ring    text := nullif(current_setting('dos.rollout_ring', true), '');
  v_corr    uuid := nullif(current_setting('dos.correlation_id', true), '')::uuid;
  v_session text := current_user;
  v_pk      text;
  v_old     jsonb;
  v_new     jsonb;
BEGIN
  -- Floor: session role must inherit dos_master (skipped only if the
  -- role does not yet exist, which happens when the ops migration has
  -- not been run; the application-identity check below still applies).
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'dos_master')
     AND NOT pg_has_role(v_session, 'dos_master', 'USAGE') THEN
    RAISE EXCEPTION 'DOS Master only: session role % is not granted dos_master', v_session
      USING ERRCODE = '42501';
  END IF;

  -- Application identity must self-identify as dos-master.
  IF v_actor IS NULL OR v_actor = '' OR v_actor <> 'dos-master' THEN
    RAISE EXCEPTION 'DOS Master only: dos.actor must be set to ''dos-master'' (got %)',
      coalesce(v_actor, '<unset>')
      USING ERRCODE = '42501';
  END IF;

  -- Snapshot row payloads for audit.
  IF (TG_OP = 'INSERT') THEN
    v_new := to_jsonb(NEW);
    v_pk  := coalesce(v_new->>'id', v_new->>'code', v_new->>'key');
  ELSIF (TG_OP = 'UPDATE') THEN
    v_old := to_jsonb(OLD);
    v_new := to_jsonb(NEW);
    v_pk  := coalesce(v_new->>'id', v_new->>'code', v_new->>'key');
  ELSE
    v_old := to_jsonb(OLD);
    v_pk  := coalesce(v_old->>'id', v_old->>'code', v_old->>'key');
  END IF;

  INSERT INTO dos.dos_master_writer_audit
    (actor, session_role, table_schema, table_name, op, row_pk,
     old_row, new_row, change_request_id, rollout_ring, correlation_id,
     client_addr, application_name)
  VALUES
    (v_actor, v_session, TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP, v_pk,
     v_old, v_new, v_cr, v_ring, v_corr,
     inet_client_addr(), current_setting('application_name', true));

  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END
$$;


--
-- Name: FUNCTION trg_dos_master_only(); Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON FUNCTION dos.trg_dos_master_only() IS 'M1 D1 — reusable BEFORE INSERT/UPDATE/DELETE trigger. Rejects writes unless the session role inherits dos_master AND dos.actor=''dos-master''. On accept, mirrors the write to dos_master_writer_audit. Attached to every controlled table in M1 D2..D4.';


--
-- Name: trg_dos_master_only_platform_slo(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only_platform_slo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF coalesce(current_setting('dos.actor', true), '') <> 'dos-master' THEN
    RAISE EXCEPTION 'dos.platform_slo write rejected: actor=% (only dos-master may write)',
      coalesce(current_setting('dos.actor', true), '∅');
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: trg_dos_master_only_platform_slo_event(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only_platform_slo_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF coalesce(current_setting('dos.actor', true), '') = '' THEN
    RAISE EXCEPTION 'dos.platform_slo_event write rejected: dos.actor unset';
  END IF;
  IF TG_OP = 'UPDATE' OR TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'dos.platform_slo_event is append-only (TG_OP=%)', TG_OP;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: trg_dos_master_only_session_policy(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.trg_dos_master_only_session_policy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF coalesce(current_setting('dos.actor', true), '') <> 'dos-master' THEN
    RAISE EXCEPTION 'dos.platform_session_policy write rejected: actor=%', current_setting('dos.actor', true);
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;


--
-- Name: update_i18n_fallback_values_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.update_i18n_fallback_values_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: update_tenant_landing_config_updated_at(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.update_tenant_landing_config_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: validate_carbon_key_exists(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.validate_carbon_key_exists() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.carbon_key IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM dos.ui_carbon_components
      WHERE carbon_key = NEW.carbon_key
    ) THEN
      RAISE EXCEPTION 'carbon_key "%" does not exist in ui_carbon_components',
        NEW.carbon_key;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_template_export_registry(); Type: FUNCTION; Schema: dos; Owner: -
--

CREATE FUNCTION dos.validate_template_export_registry() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.template_export IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM dos.dynamic_ui_component_registry
      WHERE component_key = NEW.template_export
      AND approval_status = 'approved'
    ) THEN
      RAISE EXCEPTION 'template_export "%" does not exist in dynamic_ui_component_registry or is not approved',
        NEW.template_export;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: access_profiles; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.access_profiles AS
 SELECT profile_id,
    profile_code,
    display_name,
    description,
    permissions,
    created_at
   FROM platform_dauth.access_profiles_legacy;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_review_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.access_review_items (
    item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    review_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    resource_type text NOT NULL,
    resource_id character varying(64) NOT NULL,
    entitlement text,
    decision text,
    decided_by character varying(64),
    decided_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: access_reviews; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.access_reviews (
    review_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    campaign_name text NOT NULL,
    description text,
    scope jsonb DEFAULT '{}'::jsonb,
    status text DEFAULT 'draft'::text NOT NULL,
    due_date timestamp with time zone,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: action_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.action_items (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    remediation_id uuid,
    title text NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    assigned_to character varying(64),
    due_date date,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: admin_pillar; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.admin_pillar (
    pillar_code text NOT NULL,
    display_name text NOT NULL,
    description text,
    enabled boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT admin_pillar_pillar_code_check CHECK ((pillar_code = ANY (ARRAY['DNOC'::text, 'DSOC'::text, 'DOS'::text, 'DAuth'::text])))
);


--
-- Name: admin_pillar_page; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.admin_pillar_page (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pillar_code text NOT NULL,
    page_key text NOT NULL,
    display_name text NOT NULL,
    archetype text NOT NULL,
    route text NOT NULL,
    permission_required text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: admin_pillar_widget; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.admin_pillar_widget (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    widget_key text NOT NULL,
    carbon_key text NOT NULL,
    title_en text,
    title_ar text,
    data_source text NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    permission_required text
);


--
-- Name: agent_action_receipts; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_action_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    run_id uuid,
    agent_id text NOT NULL,
    action_id text NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    before_state jsonb,
    after_state jsonb,
    evidence_ref text,
    rollback_ref text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_evidence_links; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_evidence_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    run_id uuid,
    evidence_type text NOT NULL,
    evidence_ref text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_memory; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_memory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    agent_id text NOT NULL,
    subject_type text,
    subject_id text,
    memory_key text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_module_binding; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_module_binding (
    agent_code text NOT NULL,
    module_code text NOT NULL,
    workbench_route text,
    audit_route text,
    followup_route text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE agent_module_binding; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.agent_module_binding IS 'M0.5 — per-module enrolment of agents (M:N agent×module).';


--
-- Name: agent_recommendations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_recommendations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    route text,
    subject_type text,
    subject_id text,
    agent_id text NOT NULL,
    recommendation text NOT NULL,
    rationale text,
    confidence numeric(5,4),
    risk_level text,
    status text DEFAULT 'open'::text NOT NULL,
    evidence_links jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT agent_recommendations_risk_level_check CHECK (((risk_level IS NULL) OR (risk_level = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))),
    CONSTRAINT agent_recommendations_status_check CHECK ((status = ANY (ARRAY['open'::text, 'acknowledged'::text, 'accepted'::text, 'rejected'::text, 'expired'::text])))
);


--
-- Name: agent_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_registry (
    agent_code text NOT NULL,
    display_name_en text NOT NULL,
    display_name_ar text NOT NULL,
    role_key text NOT NULL,
    capabilities text[] DEFAULT ARRAY[]::text[] NOT NULL,
    permission_key text NOT NULL,
    brand_tile_kind text DEFAULT 'agent-tile'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    confidence_default numeric(3,2) DEFAULT 0.75 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_registry_brand_tile_chk CHECK ((brand_tile_kind = 'agent-tile'::text)),
    CONSTRAINT agent_registry_code_chk CHECK ((agent_code ~ '^A[0-9]{2}$'::text)),
    CONSTRAINT agent_registry_conf_chk CHECK (((confidence_default >= (0)::numeric) AND (confidence_default <= (1)::numeric))),
    CONSTRAINT agent_registry_status_chk CHECK ((status = ANY (ARRAY['active'::text, 'retired'::text, 'draft'::text])))
);


--
-- Name: TABLE agent_registry; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.agent_registry IS 'M0.5 agentic registry — one row per logical agent (A01..An).';


--
-- Name: agent_run_steps; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_run_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    step_index integer NOT NULL,
    agent_id text,
    step_type text NOT NULL,
    payload jsonb,
    result jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: agent_runs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agent_runs (
    run_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    route text,
    agent_id text NOT NULL,
    user_id text,
    status text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    confidence numeric(5,4),
    risk_level text,
    approval_required boolean DEFAULT false NOT NULL,
    correlation_id text,
    CONSTRAINT agent_runs_risk_level_check CHECK (((risk_level IS NULL) OR (risk_level = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))),
    CONSTRAINT agent_runs_status_check CHECK ((status = ANY (ARRAY['running'::text, 'completed'::text, 'failed'::text, 'aborted'::text])))
);


--
-- Name: agrc_agent_memory; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_agent_memory (
    memory_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    agent_id character varying(10) NOT NULL,
    scope character varying(20) DEFAULT 'working'::character varying NOT NULL,
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    cycle_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_agent_runs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_agent_runs (
    run_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    agent_id character varying(10) NOT NULL,
    cycle_id uuid,
    status character varying(30) DEFAULT 'running'::character varying NOT NULL,
    mode character varying(20) DEFAULT 'hybrid'::character varying NOT NULL,
    task text,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb,
    discovery_count integer DEFAULT 0 NOT NULL,
    action_count integer DEFAULT 0 NOT NULL,
    token_usage integer DEFAULT 0 NOT NULL,
    duration_ms integer,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: agrc_cycles; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_cycles (
    cycle_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    mode character varying(20) DEFAULT 'hybrid'::character varying NOT NULL,
    status character varying(30) DEFAULT 'running'::character varying NOT NULL,
    agents jsonb DEFAULT '[]'::jsonb NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    results jsonb,
    wave_count integer DEFAULT 0 NOT NULL,
    discovery_count integer DEFAULT 0 NOT NULL,
    action_count integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_discoveries; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_discoveries (
    discovery_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    cycle_id uuid,
    agent_id character varying(10) NOT NULL,
    run_id uuid,
    type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'info'::character varying NOT NULL,
    title text NOT NULL,
    description text,
    entity_type character varying(50),
    entity_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_handoffs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_handoffs (
    handoff_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    from_agent character varying(10) NOT NULL,
    to_agent character varying(10) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_proposed_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_proposed_actions (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    cycle_id uuid,
    agent_id character varying(10) NOT NULL,
    run_id uuid,
    type character varying(50) NOT NULL,
    title text NOT NULL,
    description text,
    target_entity_type character varying(50),
    target_entity_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_level character varying(20) DEFAULT 'low'::character varying NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    review_reason text,
    reviewed_at timestamp with time zone,
    reviewed_by character varying(64),
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agrc_tasks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.agrc_tasks (
    task_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    task_type character varying(50),
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    assigned_to character varying(64),
    due_date date,
    source_module character varying(100),
    source_entity_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    type character varying(50),
    module character varying(100),
    agent_id character varying(10),
    assignee_id character varying(64),
    input_data jsonb,
    output_data jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


--
-- Name: ai_agent_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_agent_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_code character varying(200) NOT NULL,
    name_en character varying(255),
    name_ar character varying(255),
    capabilities jsonb DEFAULT '[]'::jsonb,
    model_code character varying(200),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ai_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ai_event_id_seq OWNED BY dos.ai_event.id;


--
-- Name: ai_model_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_model_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider character varying(100) NOT NULL,
    model_code character varying(200) NOT NULL,
    name character varying(255),
    capabilities jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_prompt_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_prompt_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    prompt_code character varying(200) NOT NULL,
    name character varying(255),
    template text,
    model_code character varying(200),
    module_code character varying(128),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ai_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT ai_record_kind_check CHECK ((kind = ANY (ARRAY['llm'::text, 'retrieval'::text, 'classifier'::text, 'agent'::text, 'embedding'::text]))),
    CONSTRAINT ai_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT ai_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: approval_matrix_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.approval_matrix_rules (
    rule_id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text,
    action_code text,
    required_authority_code text,
    min_approvals integer DEFAULT 1,
    value_threshold numeric,
    description text,
    is_active boolean DEFAULT true,
    created_by text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: assets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.assets (
    asset_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    type text,
    category text,
    status text DEFAULT 'active'::text,
    owner_id text,
    classification text,
    location text,
    value numeric,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    asset_type character varying(100),
    criticality character varying(20) DEFAULT 'medium'::character varying,
    department_id uuid,
    owner_user_id character varying(64),
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: audit_findings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_findings (
    finding_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    severity text DEFAULT 'medium'::text,
    status text DEFAULT 'open'::text,
    control_id uuid,
    assigned_to text,
    due_date timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: platform_audit_logs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_audit_logs (
    id integer NOT NULL,
    tenant_id character varying(16),
    user_id character varying(64),
    action character varying(100),
    resource_type character varying(50),
    resource_id character varying(64),
    details jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_log; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.audit_log AS
 SELECT id,
    tenant_id,
    user_id,
    action,
    resource_type,
    resource_id,
    details,
    created_at
   FROM dos.platform_audit_logs;


--
-- Name: audit_log_archive; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_log_archive (
    entry_id uuid NOT NULL,
    tenant_id text NOT NULL,
    actor_id text,
    action text NOT NULL,
    module text,
    entity_type text,
    entity_id text,
    before_state jsonb,
    after_state jsonb,
    ip_address text,
    created_at timestamp with time zone,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_logs (
    log_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    actor_id text,
    actor_email text,
    before_state jsonb,
    after_state jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_plans; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_plans (
    plan_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    audit_type text,
    scope text,
    frequency text,
    year integer,
    status text DEFAULT 'planning'::text,
    owner_id text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_signoff_ledger; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_signoff_ledger (
    bundle_id bigint NOT NULL,
    tenant_id character varying(64) NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    generated_by character varying(128) NOT NULL,
    bundle_hash character varying(96) NOT NULL,
    bundle_path text,
    section_counts jsonb DEFAULT '{}'::jsonb NOT NULL,
    signed_by character varying(128),
    signed_at timestamp with time zone,
    signature_hash character varying(96),
    notes text
);


--
-- Name: TABLE audit_signoff_ledger; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.audit_signoff_ledger IS 'Append-only ledger of audit-shelf bundle exports and counter-signatures.
Every row is one regulator-handover deliverable.';


--
-- Name: audit_signoff_ledger_bundle_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.audit_signoff_ledger_bundle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_signoff_ledger_bundle_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.audit_signoff_ledger_bundle_id_seq OWNED BY dos.audit_signoff_ledger.bundle_id;


--
-- Name: audit_trail; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.audit_trail (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    actor_id character varying(64),
    action text NOT NULL,
    entity_type text,
    entity_id character varying(64),
    module text,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.audit_trail FORCE ROW LEVEL SECURITY;


--
-- Name: auth_mfa_otp; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.auth_mfa_otp (
    otp_id character varying(48) NOT NULL,
    user_sub character varying(255) NOT NULL,
    email character varying(320) NOT NULL,
    code_hash character varying(128) NOT NULL,
    channel character varying(16) DEFAULT 'email'::character varying NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    ip character varying(64),
    user_agent character varying(512),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: bcp_plans; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.bcp_plans (
    plan_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'draft'::text,
    priority text DEFAULT 'medium'::text,
    owner_id text,
    last_tested timestamp with time zone,
    next_test timestamp with time zone,
    rto_hours integer,
    rpo_hours integer,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: billing_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.billing_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: billing_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.billing_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.billing_event_id_seq OWNED BY dos.billing_event.id;


--
-- Name: billing_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.billing_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT billing_record_kind_check CHECK ((kind = ANY (ARRAY['plan'::text, 'addon'::text, 'one-shot'::text, 'metered'::text]))),
    CONSTRAINT billing_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT billing_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: briefings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.briefings (
    briefing_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'weekly'::text,
    status text DEFAULT 'draft'::text,
    content jsonb DEFAULT '{}'::jsonb,
    audience jsonb DEFAULT '[]'::jsonb,
    published_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: business_units; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.business_units (
    bu_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    organization_id uuid,
    parent_bu_id uuid,
    bu_type text,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.business_units FORCE ROW LEVEL SECURITY;


--
-- Name: committee_meetings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.committee_meetings (
    meeting_id uuid DEFAULT gen_random_uuid() NOT NULL,
    committee_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title text NOT NULL,
    agenda text,
    scheduled_at timestamp with time zone NOT NULL,
    location text,
    status text DEFAULT 'scheduled'::text NOT NULL,
    minutes text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: committee_members; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.committee_members (
    member_id uuid DEFAULT gen_random_uuid() NOT NULL,
    committee_id uuid NOT NULL,
    user_id character varying(64) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    role_in_committee text DEFAULT 'member'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.committee_members FORCE ROW LEVEL SECURITY;


--
-- Name: committees; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.committees (
    committee_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    committee_type text,
    charter text,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by character varying(64)
);

ALTER TABLE ONLY dos.committees FORCE ROW LEVEL SECURITY;


--
-- Name: compliance_frameworks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.compliance_frameworks (
    framework_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    version text,
    status text DEFAULT 'active'::text,
    description text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: compliance_requirements; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.compliance_requirements (
    requirement_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    framework_id uuid,
    code character varying(100),
    title text NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: component_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.component_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    csn character varying(500) NOT NULL,
    component_key character varying(255) NOT NULL,
    layer character varying(50) DEFAULT 'frontend'::character varying NOT NULL,
    route_path character varying(500),
    sort_order integer DEFAULT 0 NOT NULL,
    i18n_key character varying(255),
    platform_object_id character varying(255),
    module_code character varying(128),
    product_code character varying(128),
    required_permission character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    tenant_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: config_audit_logs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_audit_logs (
    id integer NOT NULL,
    config_key character varying(200),
    tenant_id character varying(16),
    old_value jsonb,
    new_value jsonb,
    changed_by character varying(64),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_audit_logs_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_audit_logs_id_seq OWNED BY dos.config_audit_logs.id;


--
-- Name: config_center_audit_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_center_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    actor_id uuid,
    actor_type character varying(50) DEFAULT 'user'::character varying,
    change_type character varying(20) NOT NULL,
    key character varying(500) NOT NULL,
    scope character varying(20),
    old_value text,
    new_value text,
    source character varying(100),
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_definitions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_definitions (
    id integer NOT NULL,
    config_key character varying(200),
    display_name character varying(255),
    description text,
    data_type character varying(30) DEFAULT 'string'::character varying,
    default_value jsonb,
    module_code character varying(50),
    category character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    is_secret boolean DEFAULT false NOT NULL,
    deployment_only boolean DEFAULT false NOT NULL,
    ui_exposable boolean DEFAULT true NOT NULL,
    label text,
    owner_domain text,
    value_type text,
    allowed_scopes text[] DEFAULT '{platform}'::text[],
    validation_schema jsonb,
    enum_values text[] DEFAULT '{}'::text[],
    is_required boolean DEFAULT false NOT NULL,
    is_overridable boolean DEFAULT true NOT NULL,
    is_lockable boolean DEFAULT true NOT NULL,
    requires_restart boolean DEFAULT false NOT NULL,
    sdk_exposable boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    key text
);


--
-- Name: config_definitions_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_definitions_id_seq OWNED BY dos.config_definitions.id;


--
-- Name: config_locks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_locks (
    id integer NOT NULL,
    config_key character varying(200) NOT NULL,
    tenant_id character varying(16),
    locked_by character varying(64),
    locked_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


--
-- Name: config_locks_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_locks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_locks_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_locks_id_seq OWNED BY dos.config_locks.id;


--
-- Name: config_runtime_overrides; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_runtime_overrides (
    id integer NOT NULL,
    config_key character varying(200) NOT NULL,
    tenant_id character varying(16),
    override_value jsonb,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_runtime_overrides_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_runtime_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_runtime_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_runtime_overrides_id_seq OWNED BY dos.config_runtime_overrides.id;


--
-- Name: config_values; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.config_values (
    id integer NOT NULL,
    config_key character varying(200) NOT NULL,
    tenant_id character varying(16),
    value jsonb,
    updated_by character varying(64),
    updated_at timestamp with time zone DEFAULT now(),
    definition_id integer,
    scope_type character varying(50) DEFAULT 'platform'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    scope_id text DEFAULT 'platform'::text NOT NULL,
    value_hash text,
    is_encrypted boolean DEFAULT false NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: config_values_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.config_values_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_values_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.config_values_id_seq OWNED BY dos.config_values.id;


--
-- Name: controls; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.controls (
    control_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    framework_id uuid,
    control_ref text,
    title text NOT NULL,
    description text,
    status text DEFAULT 'not_implemented'::text,
    owner_id text,
    effectiveness text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: dashboards; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dashboards (
    dashboard_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'custom'::text,
    config jsonb DEFAULT '{}'::jsonb,
    owner_id text,
    is_public boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: data_governance_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.data_governance_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: data_governance_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.data_governance_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_governance_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.data_governance_event_id_seq OWNED BY dos.data_governance_event.id;


--
-- Name: data_governance_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.data_governance_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT data_governance_record_kind_check CHECK ((kind = ANY (ARRAY['classification'::text, 'retention'::text, 'consent'::text, 'dlp'::text, 'dsar'::text]))),
    CONSTRAINT data_governance_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT data_governance_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: delegations; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.delegations AS
 SELECT delegation_id,
    from_user_id AS delegator_id,
    to_user_id AS delegate_id,
    from_user_id,
    to_user_id,
    tenant_id,
    scope,
    valid_from,
    valid_until,
    status,
    reason,
    permissions,
    created_by,
    approved_by,
    approved_at,
    rejected_reason,
    created_at,
    updated_at,
    deleted_at
   FROM platform_dauth.delegations;


--
-- Name: departments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.departments (
    department_id character varying(64) NOT NULL,
    department_code character varying(100),
    display_name character varying(255),
    tenant_id character varying(64),
    parent_id character varying(64),
    created_at timestamp with time zone DEFAULT now(),
    description text,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    name_en character varying(255),
    name_ar character varying(255),
    code character varying(100),
    bu_id uuid,
    head_user_id character varying(64),
    status character varying(20) DEFAULT 'active'::character varying,
    created_by character varying(64)
);

ALTER TABLE ONLY dos.departments FORCE ROW LEVEL SECURITY;


--
-- Name: deployment_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.deployment_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deployment_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.deployment_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deployment_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.deployment_event_id_seq OWNED BY dos.deployment_event.id;


--
-- Name: deployment_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.deployment_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT deployment_record_kind_check CHECK ((kind = ANY (ARRAY['blue-green'::text, 'canary'::text, 'rolling'::text, 'recreate'::text]))),
    CONSTRAINT deployment_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT deployment_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: dora_assessments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dora_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'draft'::text,
    pillar text,
    score integer,
    findings jsonb DEFAULT '[]'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: dos_master_actor_session; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_actor_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor text NOT NULL,
    session_jwe text NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    scopes text[] DEFAULT ARRAY[]::text[] NOT NULL
);


--
-- Name: dos_master_change_request; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_change_request (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    summary text,
    requested_by text NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_by text,
    approved_at timestamp with time zone,
    status text DEFAULT 'open'::text NOT NULL,
    rollout_plan_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT dos_master_change_request_status_check CHECK ((status = ANY (ARRAY['open'::text, 'approved'::text, 'executed'::text, 'rolled_back'::text, 'rejected'::text])))
);


--
-- Name: dos_master_compensation_chain; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_compensation_chain (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    change_request_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    step_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT dos_master_compensation_chain_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'succeeded'::text, 'failed'::text, 'compensated'::text])))
);


--
-- Name: dos_master_drift_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_drift_event (
    id bigint NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    source text NOT NULL,
    drift_kind text NOT NULL,
    resource_key text,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    resolved_at timestamp with time zone,
    resolution_note text
);


--
-- Name: dos_master_drift_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dos_master_drift_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dos_master_drift_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dos_master_drift_event_id_seq OWNED BY dos.dos_master_drift_event.id;


--
-- Name: dos_master_grant; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_grant (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor text NOT NULL,
    role_code text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    granted_by text NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by text,
    reason text
);


--
-- Name: TABLE dos_master_grant; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.dos_master_grant IS 'Application-level grants of DOS Master roles to service or operator actors. PG role membership is the DB-level floor; this table is the audit truth.';


--
-- Name: dos_master_invalidation_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_invalidation_log (
    id bigint NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL,
    scope text NOT NULL,
    scope_key text,
    reason text NOT NULL,
    cache_version text NOT NULL,
    fan_out_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT dos_master_invalidation_log_scope_check CHECK ((scope = ANY (ARRAY['tenant'::text, 'role'::text, 'module'::text, 'permission'::text, 'global'::text])))
);


--
-- Name: dos_master_invalidation_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dos_master_invalidation_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dos_master_invalidation_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dos_master_invalidation_log_id_seq OWNED BY dos.dos_master_invalidation_log.id;


--
-- Name: dos_master_lock; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_lock (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    resource_key text NOT NULL,
    held_by text NOT NULL,
    acquired_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    released_at timestamp with time zone
);


--
-- Name: dos_master_publish_handle; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_publish_handle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    channel text DEFAULT 'live'::text NOT NULL,
    revision_id uuid NOT NULL,
    activated_at timestamp with time zone DEFAULT now() NOT NULL,
    activated_by text NOT NULL,
    CONSTRAINT dos_master_publish_handle_channel_check CHECK ((channel = ANY (ARRAY['draft'::text, 'staging'::text, 'live'::text, 'rolled_back'::text])))
);


--
-- Name: dos_master_role; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_role (
    role_code text NOT NULL,
    display_name text NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dos_master_writer_audit; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dos_master_writer_audit (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor text NOT NULL,
    session_role text NOT NULL,
    table_schema text NOT NULL,
    table_name text NOT NULL,
    op text NOT NULL,
    row_pk text,
    old_row jsonb,
    new_row jsonb,
    change_request_id uuid,
    rollout_ring text,
    correlation_id uuid,
    client_addr inet,
    application_name text,
    CONSTRAINT dos_master_writer_audit_op_check CHECK ((op = ANY (ARRAY['INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: TABLE dos_master_writer_audit; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.dos_master_writer_audit IS 'Append-only audit of every accepted write to a DOS Master controlled table. Source of truth for change history; rollups feed the decision ledger and PPD evaluations.';


--
-- Name: dos_master_writer_audit_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dos_master_writer_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dos_master_writer_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dos_master_writer_audit_id_seq OWNED BY dos.dos_master_writer_audit.id;


--
-- Name: dr_drill_runs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dr_drill_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scenario text NOT NULL,
    from_region text NOT NULL,
    to_region text,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text DEFAULT 'in_progress'::text NOT NULL,
    rpo_actual_seconds integer,
    rto_actual_seconds integer,
    rpo_target_seconds integer DEFAULT 3600 NOT NULL,
    rto_target_seconds integer DEFAULT 14400 NOT NULL,
    notes text,
    CONSTRAINT dr_drill_runs_scenario_check CHECK ((scenario = ANY (ARRAY['replica-promote'::text, 'pitr-restore'::text, 'region-failover'::text, 'tenant-restore'::text]))),
    CONSTRAINT dr_drill_runs_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'in_progress'::text, 'passed'::text, 'failed'::text, 'aborted'::text])))
);


--
-- Name: TABLE dr_drill_runs; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.dr_drill_runs IS 'Wave 13: cross-region DR drill records. Quarterly cadence required for production promotion.';


--
-- Name: dr_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dr_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dr_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.dr_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dr_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.dr_event_id_seq OWNED BY dos.dr_event.id;


--
-- Name: dr_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dr_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT dr_record_kind_check CHECK ((kind = ANY (ARRAY['failover'::text, 'restore'::text, 'rebuild'::text, 'simulate'::text]))),
    CONSTRAINT dr_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT dr_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: dynamic_ui_ai_tips; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_ai_tips (
    tenant_id character varying(80) DEFAULT ''::character varying NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) DEFAULT ''::character varying NOT NULL,
    tip_code character varying(120) NOT NULL,
    severity character varying(20) DEFAULT 'info'::character varying NOT NULL,
    title_key character varying(200) NOT NULL,
    body_key character varying(200) NOT NULL,
    cta_label_key character varying(200),
    cta_route character varying(300),
    cta_action_id character varying(120),
    audience_role character varying(80),
    source character varying(40) DEFAULT 'rule'::character varying NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT dynamic_ui_ai_tips_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'success'::character varying, 'warning'::character varying, 'danger'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_ai_tips_source_check CHECK (((source)::text = ANY ((ARRAY['rule'::character varying, 'heuristic'::character varying, 'llm'::character varying, 'agent'::character varying])::text[])))
);


--
-- Name: dynamic_ui_component_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_component_registry (
    component_key text NOT NULL,
    bundle_url text,
    schema_version text DEFAULT '1'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    vendor character varying(40) DEFAULT 'custom'::character varying NOT NULL,
    approval_status character varying(20) DEFAULT 'unapproved'::character varying NOT NULL,
    carbon_key character varying(80),
    approved_at timestamp with time zone,
    renderer_key text,
    component_type text,
    CONSTRAINT dynamic_ui_component_registry_approval_status_check CHECK (((approval_status)::text = ANY ((ARRAY['approved'::character varying, 'unapproved'::character varying, 'deprecated'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: dynamic_ui_empty_states; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_empty_states (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state_key character varying(150) NOT NULL,
    title_key character varying(300) NOT NULL,
    description_key character varying(300),
    tone character varying(20) DEFAULT 'neutral'::character varying NOT NULL,
    illustration character varying(80),
    primary_label_key character varying(300),
    primary_route character varying(300),
    primary_permission character varying(150),
    secondary_label_key character varying(300),
    secondary_route character varying(300),
    secondary_permission character varying(150),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_empty_states_tone_check CHECK (((tone)::text = ANY ((ARRAY['neutral'::character varying, 'brand'::character varying, 'accent'::character varying, 'success'::character varying, 'warning'::character varying, 'danger'::character varying, 'info'::character varying])::text[])))
);


--
-- Name: dynamic_ui_grid_columns; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_grid_columns (
    tenant_id character varying(80) DEFAULT ''::character varying NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    column_key character varying(120) NOT NULL,
    label_i18n_key character varying(200) NOT NULL,
    data_path character varying(200) NOT NULL,
    data_type character varying(40) NOT NULL,
    formatter_key character varying(120),
    width_px integer,
    align character varying(20) DEFAULT 'start'::character varying NOT NULL,
    sortable boolean DEFAULT true NOT NULL,
    filterable boolean DEFAULT false NOT NULL,
    hidden_default boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT dynamic_ui_grid_columns_align_check CHECK (((align)::text = ANY ((ARRAY['start'::character varying, 'center'::character varying, 'end'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_grid_columns_data_type_check CHECK (((data_type)::text = ANY ((ARRAY['string'::character varying, 'number'::character varying, 'boolean'::character varying, 'date'::character varying, 'datetime'::character varying, 'enum'::character varying, 'badge'::character varying, 'user'::character varying, 'avatar'::character varying, 'json'::character varying])::text[])))
);


--
-- Name: dynamic_ui_health_probes; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_health_probes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    probe_key character varying(150) NOT NULL,
    label_key character varying(300) NOT NULL,
    description_key character varying(300),
    source_endpoint character varying(500),
    source_kind character varying(40) DEFAULT 'http_status'::character varying NOT NULL,
    ok_threshold jsonb DEFAULT '{}'::jsonb NOT NULL,
    required_permission character varying(150) DEFAULT 'tenant_admin'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_health_probes_source_kind_check CHECK (((source_kind)::text = ANY ((ARRAY['http_status'::character varying, 'count'::character varying, 'signal'::character varying, 'derived'::character varying])::text[])))
);


--
-- Name: dynamic_ui_i18n_keys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_i18n_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    key_path text NOT NULL,
    en text NOT NULL,
    ar text,
    notes text
);


--
-- Name: dynamic_ui_module_icons; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_module_icons (
    module_code text NOT NULL,
    icon text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_navigation_icons; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_navigation_icons (
    module_code text NOT NULL,
    route text NOT NULL,
    icon text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_page_headers; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_page_headers (
    tenant_id character varying(80) DEFAULT ''::character varying NOT NULL,
    module_code character varying(100) NOT NULL,
    route character varying(300) NOT NULL,
    variant character varying(40) DEFAULT 'standard'::character varying NOT NULL,
    eyebrow_key character varying(200),
    title_key character varying(200) NOT NULL,
    subtitle_key character varying(200),
    badge_key character varying(200),
    cta_action_id character varying(120),
    show_breadcrumb boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_page_headers_variant_check CHECK (((variant)::text = ANY ((ARRAY['standard'::character varying, 'hero'::character varying, 'compact'::character varying, 'split'::character varying])::text[])))
);


--
-- Name: dynamic_ui_quick_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_quick_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    surface_key character varying(150) DEFAULT 'workspace.home'::character varying NOT NULL,
    action_key character varying(150) NOT NULL,
    eyebrow_key character varying(300),
    label_key character varying(300) NOT NULL,
    description_key character varying(300),
    icon character varying(80),
    route character varying(300) NOT NULL,
    required_permission character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    variant character varying(20) DEFAULT 'solid'::character varying NOT NULL,
    tone character varying(20) DEFAULT 'neutral'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_quick_actions_tone_check CHECK (((tone)::text = ANY ((ARRAY['neutral'::character varying, 'brand'::character varying, 'accent'::character varying, 'success'::character varying, 'warning'::character varying, 'danger'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_quick_actions_variant_check CHECK (((variant)::text = ANY ((ARRAY['solid'::character varying, 'gradient'::character varying, 'minimal'::character varying])::text[])))
);


--
-- Name: dynamic_ui_route_metadata; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_route_metadata (
    route text NOT NULL,
    render_mode text DEFAULT 'template'::text NOT NULL,
    template_binding_required boolean DEFAULT true NOT NULL,
    notes text,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata_public boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_dynamic_ui_route_metadata_render_mode CHECK ((render_mode = ANY (ARRAY['template'::text, 'shell-only'::text, 'redirect'::text])))
);


--
-- Name: dynamic_ui_route_permissions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_route_permissions (
    route_id uuid NOT NULL,
    permission_key text NOT NULL,
    effect text NOT NULL,
    CONSTRAINT dynamic_ui_route_permissions_effect_check CHECK ((effect = ANY (ARRAY['allow'::text, 'deny'::text])))
);


--
-- Name: dynamic_ui_setup_steps; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_setup_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    step_key character varying(150) NOT NULL,
    label_key character varying(300) NOT NULL,
    description_key character varying(300),
    icon character varying(80),
    route character varying(300) NOT NULL,
    required_permission character varying(150),
    sort_order integer DEFAULT 0 NOT NULL,
    condition_kind character varying(60) DEFAULT 'always_pending'::character varying NOT NULL,
    condition_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_setup_steps_condition_kind_check CHECK (((condition_kind)::text = ANY ((ARRAY['has_user_name'::character varying, 'has_tenant_id'::character varying, 'has_modules'::character varying, 'has_team_members'::character varying, 'custom'::character varying, 'always_pending'::character varying, 'always_done'::character varying])::text[])))
);


--
-- Name: dynamic_ui_skill_packs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_skill_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pack_code text NOT NULL,
    name_key text NOT NULL,
    vendor text,
    version text NOT NULL,
    module_codes text[] DEFAULT '{}'::text[] NOT NULL,
    capabilities text[] DEFAULT '{}'::text[] NOT NULL,
    manifest_uri text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_tenant_overrides; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_tenant_overrides (
    tenant_id text NOT NULL,
    override_key text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dynamic_ui_trial_banner_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_trial_banner_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    threshold_days_min integer DEFAULT 0 NOT NULL,
    threshold_days_max integer DEFAULT 365 NOT NULL,
    severity character varying(20) NOT NULL,
    title_key character varying(300) NOT NULL,
    message_key character varying(300) NOT NULL,
    cta_label_key character varying(300),
    cta_route character varying(300),
    dismissible boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dui_trial_banner_threshold_chk CHECK ((threshold_days_min <= threshold_days_max)),
    CONSTRAINT dynamic_ui_trial_banner_rules_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'danger'::character varying])::text[])))
);


--
-- Name: dynamic_ui_workspace_ai_tips; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workspace_ai_tips (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    tip_key character varying(150) NOT NULL,
    title_key character varying(300) NOT NULL,
    body_key character varying(300) NOT NULL,
    cta_label_key character varying(300),
    cta_route character varying(300),
    icon character varying(80),
    condition_kind character varying(60) DEFAULT 'always'::character varying NOT NULL,
    condition_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    required_permission character varying(150),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_workspace_ai_tips_condition_kind_check CHECK (((condition_kind)::text = ANY ((ARRAY['always'::character varying, 'setup_below'::character varying, 'setup_above'::character varying, 'has_modules'::character varying, 'no_modules'::character varying, 'tenant_admin'::character varying, 'member_count_below'::character varying, 'trial_active'::character varying, 'trial_expired'::character varying, 'custom'::character varying])::text[])))
);


--
-- Name: dynamic_ui_workspace_grid_columns; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workspace_grid_columns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    scope character varying(150) NOT NULL,
    col_key character varying(80) NOT NULL,
    label_key character varying(300) NOT NULL,
    data_field character varying(150) NOT NULL,
    data_kind character varying(40) DEFAULT 'text'::character varying NOT NULL,
    format_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_sortable boolean DEFAULT true NOT NULL,
    is_filterable boolean DEFAULT false NOT NULL,
    default_sort character varying(10),
    sort_priority integer,
    width_hint character varying(40),
    align character varying(20) DEFAULT 'start'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_workspace_grid_columns_align_check CHECK (((align)::text = ANY ((ARRAY['start'::character varying, 'center'::character varying, 'end'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_workspace_grid_columns_data_kind_check CHECK (((data_kind)::text = ANY ((ARRAY['text'::character varying, 'number'::character varying, 'date'::character varying, 'status_pill'::character varying, 'badge'::character varying, 'link'::character varying, 'icon'::character varying, 'code'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_workspace_grid_columns_default_sort_check CHECK (((default_sort)::text = ANY ((ARRAY['asc'::character varying, 'desc'::character varying])::text[])))
);


--
-- Name: dynamic_ui_workspace_page_headers; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.dynamic_ui_workspace_page_headers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64),
    route_key character varying(300) NOT NULL,
    variant character varying(40) DEFAULT 'signature'::character varying NOT NULL,
    density character varying(20) DEFAULT 'comfortable'::character varying NOT NULL,
    eyebrow_key character varying(300),
    title_key character varying(300) NOT NULL,
    subtitle_key character varying(300),
    gradient_token character varying(120) DEFAULT '--dos-gradient-brand-soft'::character varying NOT NULL,
    mesh_layers jsonb DEFAULT '[]'::jsonb NOT NULL,
    hairline_visible boolean DEFAULT true NOT NULL,
    hairline_token character varying(120) DEFAULT '--dos-gradient-kpi-line'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dynamic_ui_workspace_page_headers_density_check CHECK (((density)::text = ANY ((ARRAY['compact'::character varying, 'comfortable'::character varying, 'spacious'::character varying])::text[]))),
    CONSTRAINT dynamic_ui_workspace_page_headers_variant_check CHECK (((variant)::text = ANY ((ARRAY['standard'::character varying, 'hero'::character varying, 'compact'::character varying, 'split'::character varying, 'signature'::character varying])::text[])))
);


--
-- Name: event_dead_letter_queue; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.event_dead_letter_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message text,
    service text DEFAULT 'onboarding-service'::text NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'failed'::text NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT event_dead_letter_queue_status_check CHECK ((status = ANY (ARRAY['failed'::text, 'retrying'::text, 'resolved'::text, 'expired'::text])))
);


--
-- Name: evidence; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.evidence (
    evidence_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text,
    control_id uuid,
    status text DEFAULT 'pending'::text,
    file_path text,
    file_size bigint,
    uploaded_by text,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: evidences; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.evidences (
    evidence_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    control_id uuid,
    file_url text,
    file_type character varying(50),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    collected_by character varying(64),
    reviewed_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: executive_briefings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.executive_briefings (
    briefing_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    content text,
    briefing_type character varying(50) DEFAULT 'weekly'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    target_audience text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: feature_flag_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.feature_flag_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: feature_flag_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.feature_flag_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_flag_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.feature_flag_event_id_seq OWNED BY dos.feature_flag_event.id;


--
-- Name: feature_flag_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.feature_flag_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT feature_flag_record_kind_check CHECK ((kind = ANY (ARRAY['boolean'::text, 'percentage'::text, 'cohort'::text, 'kill-switch'::text]))),
    CONSTRAINT feature_flag_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT feature_flag_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: feature_flags; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.feature_flags (
    flag_code character varying(100) NOT NULL,
    display_name character varying(255),
    enabled boolean DEFAULT false,
    module_code character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    name_en text,
    name_ar text,
    default_value boolean,
    owner_layer text,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_authority_kinds; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_authority_kinds (
    authority_kind text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    is_monetary boolean DEFAULT false NOT NULL,
    default_unit text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_cat_audit_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_audit_actions (
    action_code text NOT NULL,
    category text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    default_severity text NOT NULL,
    evidence_required boolean DEFAULT false NOT NULL,
    CONSTRAINT foundation_cat_audit_actions_category_check CHECK ((category = ANY (ARRAY['crud'::text, 'access'::text, 'workflow'::text, 'security'::text, 'admin'::text]))),
    CONSTRAINT foundation_cat_audit_actions_default_severity_check CHECK ((default_severity = ANY (ARRAY['info'::text, 'low'::text, 'medium'::text, 'high'::text, 'critical'::text])))
);


--
-- Name: foundation_cat_bu_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_bu_templates (
    template_code text NOT NULL,
    sector_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    bu_type text NOT NULL,
    parent_template text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT foundation_cat_bu_templates_bu_type_check CHECK ((bu_type = ANY (ARRAY['line_of_business'::text, 'support'::text, 'control'::text, 'shared_service'::text, 'regulatory_reporting'::text])))
);


--
-- Name: foundation_cat_calendar_systems; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_calendar_systems (
    calendar_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    is_default_in_regions text[]
);


--
-- Name: foundation_cat_coi_categories; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_coi_categories (
    category_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    evidence_required boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_committee_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_committee_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_code text NOT NULL,
    sector_code text,
    name_en text NOT NULL,
    name_ar text,
    charter_en text,
    charter_ar text,
    member_roles text[],
    quorum_pct numeric(5,2) DEFAULT 50.0 NOT NULL,
    meeting_cadence text,
    term_months integer,
    is_mandatory boolean DEFAULT false NOT NULL,
    required_by_frameworks text[],
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_data_classifications; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_data_classifications (
    level_code text NOT NULL,
    level_order integer NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    default_color text,
    encryption_required boolean DEFAULT false CONSTRAINT foundation_cat_data_classification_encryption_required_not_null NOT NULL,
    audit_required boolean DEFAULT false NOT NULL
);


--
-- Name: foundation_cat_dept_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_dept_templates (
    template_code text NOT NULL,
    sector_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    dept_function text NOT NULL,
    bu_template text,
    is_mandatory boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_lawful_bases; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_lawful_bases (
    basis_code text NOT NULL,
    framework text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    requires_consent boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT foundation_cat_lawful_bases_framework_check CHECK ((framework = ANY (ARRAY['PDPL'::text, 'GDPR'::text, 'Both'::text])))
);


--
-- Name: foundation_cat_location_types; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_location_types (
    type_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    applicable_sectors text[],
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_org_types; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_org_types (
    org_type_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    levels integer NOT NULL,
    sample_structure jsonb DEFAULT '[]'::jsonb NOT NULL,
    applicable_sectors text[],
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_ownership_domains; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_ownership_domains (
    domain_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    source_module text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_position_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_position_templates (
    template_code text NOT NULL,
    sector_code text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    grade_code text NOT NULL,
    grade_order integer NOT NULL,
    dept_function text,
    is_executive boolean DEFAULT false NOT NULL,
    required_skills text[],
    reports_to_grade text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_profile_types; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_profile_types (
    profile_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    default_perm_pack text,
    has_lifecycle boolean DEFAULT true NOT NULL,
    has_probation boolean DEFAULT false NOT NULL,
    requires_nda boolean DEFAULT false NOT NULL,
    requires_coi boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_readiness_dimensions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_readiness_dimensions (
    dimension_code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    weight numeric(5,2) DEFAULT 1.0 NOT NULL,
    query_ref text,
    threshold_warn numeric(5,2) DEFAULT 70.0 NOT NULL,
    threshold_crit numeric(5,2) DEFAULT 50.0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_reference; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_reference (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category text NOT NULL,
    code text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    parent_code text,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_role_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_role_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_code text NOT NULL,
    sector_code text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    permissions text[],
    applies_to_profiles text[],
    is_platform_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: foundation_cat_tenant_defaults; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_cat_tenant_defaults (
    region_code text NOT NULL,
    sector_code text,
    default_locale text NOT NULL,
    timezone text NOT NULL,
    currency text NOT NULL,
    fiscal_year_end_month integer NOT NULL,
    calendar_systems text[] NOT NULL,
    date_format text NOT NULL,
    regulators text[] NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: foundation_coi_declarations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_coi_declarations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    declaration_period text NOT NULL,
    has_conflicts boolean NOT NULL,
    disclosures jsonb DEFAULT '[]'::jsonb NOT NULL,
    declared_at timestamp with time zone DEFAULT now() NOT NULL,
    evidence_ref text,
    reviewed_at timestamp with time zone,
    reviewed_by text,
    review_decision text,
    review_note text,
    CONSTRAINT foundation_coi_declarations_review_decision_check CHECK ((review_decision = ANY (ARRAY['cleared'::text, 'mitigation_required'::text, 'blocked'::text])))
);


--
-- Name: foundation_employee_lifecycle_state; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_state (
    user_id text NOT NULL,
    tenant_id text NOT NULL,
    state text NOT NULL,
    state_since timestamp with time zone DEFAULT now() NOT NULL,
    state_due_by timestamp with time zone,
    state_owner text,
    state_meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    workflow_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_employee_lifecycle_state_state_check CHECK ((state = ANY (ARRAY['candidate'::text, 'hired'::text, 'onboarding'::text, 'active'::text, 'probation'::text, 'confirmed'::text, 'on_leave'::text, 'under_review'::text, 'pip'::text, 'transfer_pending'::text, 'promoted'::text, 'exiting'::text, 'alumni'::text])))
);


--
-- Name: foundation_employee_lifecycle_tasks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    workflow_code text NOT NULL,
    workflow_id uuid,
    step_code text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    assigned_to text,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    completed_by text,
    status text DEFAULT 'open'::text NOT NULL,
    blocked_reason text,
    evidence_refs text[],
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_employee_lifecycle_tasks_status_check CHECK ((status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text, 'done'::text, 'skipped'::text])))
);


--
-- Name: foundation_employee_lifecycle_transitions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_transitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    from_state text,
    to_state text NOT NULL,
    workflow_code text,
    workflow_id uuid,
    approved_by text[],
    evidence_refs text[],
    reason text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_id text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: foundation_employee_lifecycle_workflows; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_employee_lifecycle_workflows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_code text NOT NULL,
    tenant_id text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    trigger_state text NOT NULL,
    steps jsonb NOT NULL,
    sla_hours integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_policy_acknowledgments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_policy_acknowledgments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    policy_id text NOT NULL,
    policy_version text NOT NULL,
    required boolean DEFAULT true NOT NULL,
    due_at timestamp with time zone,
    acknowledged_at timestamp with time zone,
    evidence_ref text,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: foundation_position_authority; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_position_authority (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    position_id text NOT NULL,
    authority_kind text NOT NULL,
    monetary_limit numeric(18,2),
    monetary_unit text,
    qualifications text[],
    conditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    effective_from date,
    effective_to date,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text
);


--
-- Name: foundation_sod_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_rules (
    rule_code text NOT NULL,
    tenant_id text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    rule_kind text NOT NULL,
    parameters jsonb NOT NULL,
    severity text NOT NULL,
    is_enforcing boolean DEFAULT true NOT NULL,
    remediation_hint_en text,
    remediation_hint_ar text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    CONSTRAINT foundation_sod_rules_rule_kind_check CHECK ((rule_kind = ANY (ARRAY['mutually_exclusive_roles'::text, 'blocked_role_pair'::text, 'blocked_authority_pair'::text, 'time_separation'::text, 'approval_self_block'::text, 'committee_self_block'::text]))),
    CONSTRAINT foundation_sod_rules_severity_check CHECK ((severity = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))
);


--
-- Name: foundation_sod_violations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_sod_violations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    rule_code text NOT NULL,
    user_id text NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    severity text,
    resolution text DEFAULT 'open'::text NOT NULL,
    resolution_note text,
    resolved_at timestamp with time zone,
    resolved_by text,
    CONSTRAINT foundation_sod_violations_resolution_check CHECK ((resolution = ANY (ARRAY['open'::text, 'accepted_risk'::text, 'remediated'::text, 'false_positive'::text, 'expired'::text])))
);


--
-- Name: foundation_training_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_training_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    course_code text NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    assigned_by text,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    score numeric(5,2),
    pass_threshold numeric(5,2),
    status text DEFAULT 'assigned'::text NOT NULL,
    evidence_ref text,
    reason_assigned text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foundation_training_assignments_status_check CHECK ((status = ANY (ARRAY['assigned'::text, 'in_progress'::text, 'completed'::text, 'failed'::text, 'overdue'::text, 'exempted'::text])))
);


--
-- Name: foundation_training_courses; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.foundation_training_courses (
    course_code text NOT NULL,
    tenant_id text,
    name_en text NOT NULL,
    name_ar text,
    description_en text,
    description_ar text,
    category text,
    duration_minutes integer,
    provider text,
    is_mandatory boolean DEFAULT false NOT NULL,
    renewal_months integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: functional_roles; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.functional_roles AS
 SELECT role_id,
    role_code,
    display_name,
    description,
    permissions,
    created_at
   FROM platform_dauth.functional_roles;


--
-- Name: governance_decisions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.governance_decisions (
    decision_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title text NOT NULL,
    summary text,
    decision_type text DEFAULT 'board'::text NOT NULL,
    status text DEFAULT 'recorded'::text NOT NULL,
    committee_id uuid,
    decided_at timestamp with time zone DEFAULT now() NOT NULL,
    decided_by character varying(64),
    rationale text,
    linked_entity_type text,
    linked_entity_id character varying(64),
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: governance_policies; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.governance_policies (
    policy_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    code text,
    category text,
    scope text,
    description text,
    effective_date date,
    review_date date,
    status text DEFAULT 'draft'::text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    approved_by text,
    approved_at timestamp with time zone
);


--
-- Name: i18n_fallback_values; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.i18n_fallback_values (
    id bigint NOT NULL,
    i18n_key character varying(255) NOT NULL,
    fallback_value_en text NOT NULL,
    fallback_value_ar text,
    tenant_id character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE i18n_fallback_values; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.i18n_fallback_values IS 'I18n fallback values with tenant-specific overrides. NULL tenant_id = global default. Eliminates hardcoded i18n maps.';


--
-- Name: COLUMN i18n_fallback_values.fallback_value_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.i18n_fallback_values.fallback_value_en IS 'English fallback value';


--
-- Name: COLUMN i18n_fallback_values.fallback_value_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.i18n_fallback_values.fallback_value_ar IS 'Arabic fallback value (optional)';


--
-- Name: COLUMN i18n_fallback_values.tenant_id; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.i18n_fallback_values.tenant_id IS 'NULL = global default, specific value = tenant override';


--
-- Name: i18n_fallback_values_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.i18n_fallback_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: i18n_fallback_values_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.i18n_fallback_values_id_seq OWNED BY dos.i18n_fallback_values.id;


--
-- Name: inbox_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.inbox_items (
    item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    type text DEFAULT 'notification'::text NOT NULL,
    title text NOT NULL,
    body text,
    source text,
    entity_type text,
    entity_id text,
    read boolean DEFAULT false,
    actioned boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: incidents; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.incidents (
    incident_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    severity character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    risk_id uuid,
    reported_by character varying(64),
    assigned_to character varying(64),
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: integration_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integration_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: integration_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.integration_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: integration_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.integration_event_id_seq OWNED BY dos.integration_event.id;


--
-- Name: integration_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integration_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT integration_record_kind_check CHECK ((kind = ANY (ARRAY['inbound'::text, 'outbound'::text, 'bidirectional'::text, 'webhook'::text]))),
    CONSTRAINT integration_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT integration_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: integrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.integrations (
    integration_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    provider text,
    status text DEFAULT 'inactive'::text,
    config jsonb DEFAULT '{}'::jsonb,
    credentials jsonb DEFAULT '{}'::jsonb,
    last_sync_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: invitations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.invitations (
    invitation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    email text NOT NULL,
    display_name text,
    role text,
    department_id character varying(64),
    status text DEFAULT 'pending'::text NOT NULL,
    batch_id uuid,
    invited_by character varying(64),
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    accepted_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL
);

ALTER TABLE ONLY dos.invitations FORCE ROW LEVEL SECURITY;


--
-- Name: job_executions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.job_executions (
    execution_id character varying(64) NOT NULL,
    job_id character varying(64) NOT NULL,
    tenant_id character varying(16),
    status character varying(20) DEFAULT 'running'::character varying,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    result jsonb,
    error text,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: job_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.job_registry (
    job_id character varying(64) NOT NULL,
    job_code character varying(100) NOT NULL,
    module_code character varying(50),
    schedule character varying(100),
    handler character varying(255),
    config jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    description text,
    last_run_at timestamp with time zone,
    last_status text,
    last_error text,
    next_run_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lifecycle_auth_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.lifecycle_auth_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text,
    user_id text,
    entity_type text,
    entity_id text,
    action text,
    decision text,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: location_bu_map; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.location_bu_map (
    location_id uuid NOT NULL,
    bu_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.location_bu_map FORCE ROW LEVEL SECURITY;


--
-- Name: locations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.locations (
    location_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    location_type text,
    country text,
    city text,
    address text,
    parent_location_id uuid,
    latitude numeric(10,7),
    longitude numeric(10,7),
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.locations FORCE ROW LEVEL SECURITY;


--
-- Name: login_attempts; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.login_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255),
    user_id uuid,
    tenant_id text,
    ip_address character varying(45),
    user_agent text,
    success boolean DEFAULT false,
    failure_reason text,
    attempted_at timestamp with time zone DEFAULT now()
);


--
-- Name: marketing_assets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_assets (
    asset_key text NOT NULL,
    brand_code text NOT NULL,
    locale text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    asset_type text NOT NULL,
    file_url text NOT NULL,
    thumbnail_url text,
    is_gated boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    approval_status text DEFAULT 'approved'::text NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT marketing_assets_approval_chk CHECK ((approval_status = ANY (ARRAY['draft'::text, 'approved'::text, 'retired'::text]))),
    CONSTRAINT marketing_assets_brand_chk CHECK ((brand_code = ANY (ARRAY['shahin-ai'::text, 'dogan-ai-os'::text]))),
    CONSTRAINT marketing_assets_locale_chk CHECK ((locale = ANY (ARRAY['en'::text, 'ar'::text]))),
    CONSTRAINT marketing_assets_type_chk CHECK ((asset_type = ANY (ARRAY['pdf'::text, 'xlsx'::text, 'pptx'::text, 'zip'::text, 'diagram'::text, 'video'::text, 'png'::text, 'svg'::text])))
);


--
-- Name: TABLE marketing_assets; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_assets IS 'M1.5 — registry of downloadable marketing kits. Public read.';


--
-- Name: marketing_brand_assets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_brand_assets (
    id bigint NOT NULL,
    brand_code text NOT NULL,
    asset_kind text NOT NULL,
    theme text DEFAULT 'light'::text NOT NULL,
    locale text,
    direction text,
    source_kind text NOT NULL,
    svg text,
    url text,
    mime text,
    width integer NOT NULL,
    height integer NOT NULL,
    alt_en text NOT NULL,
    alt_ar text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    asset_code text,
    CONSTRAINT marketing_brand_assets_brand_chk CHECK ((brand_code = ANY (ARRAY['shahin-ai'::text, 'dogan-ai-os'::text]))),
    CONSTRAINT marketing_brand_assets_dims_chk CHECK (((width > 0) AND (height > 0))),
    CONSTRAINT marketing_brand_assets_dir_chk CHECK (((direction IS NULL) OR (direction = ANY (ARRAY['ltr'::text, 'rtl'::text])))),
    CONSTRAINT marketing_brand_assets_kind_chk CHECK ((asset_kind = ANY (ARRAY['logo-eagle'::text, 'logo-wordmark'::text, 'logo-lockup'::text, 'favicon'::text, 'og-image'::text, 'hero-bg'::text, 'agent-tile'::text]))),
    CONSTRAINT marketing_brand_assets_locale_chk CHECK (((locale IS NULL) OR (locale = ANY (ARRAY['en'::text, 'ar'::text])))),
    CONSTRAINT marketing_brand_assets_payload_chk CHECK ((((source_kind = 'svg'::text) AND (svg IS NOT NULL)) OR ((source_kind = 'url'::text) AND (url IS NOT NULL) AND (mime IS NOT NULL)))),
    CONSTRAINT marketing_brand_assets_source_chk CHECK ((source_kind = ANY (ARRAY['svg'::text, 'url'::text]))),
    CONSTRAINT marketing_brand_assets_theme_chk CHECK ((theme = ANY (ARRAY['light'::text, 'dark'::text, 'mono-light'::text, 'mono-dark'::text])))
);


--
-- Name: TABLE marketing_brand_assets; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_brand_assets IS 'M0 brand DNA — per-brand asset rows resolved by BrandResolverService.';


--
-- Name: marketing_brand_assets_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.marketing_brand_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketing_brand_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.marketing_brand_assets_id_seq OWNED BY dos.marketing_brand_assets.id;


--
-- Name: marketing_brand_tokens; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_brand_tokens (
    brand_code text NOT NULL,
    token_key text NOT NULL,
    token_value text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    CONSTRAINT marketing_brand_tokens_brand_chk CHECK ((brand_code = ANY (ARRAY['shahin-ai'::text, 'dogan-ai-os'::text]))),
    CONSTRAINT marketing_brand_tokens_key_chk CHECK ((token_key ~~ '--dos-%'::text))
);


--
-- Name: TABLE marketing_brand_tokens; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_brand_tokens IS 'M0 brand DNA — semantic-token overlays per brand. Mirrors brand-overlays.css.';


--
-- Name: marketing_download_events; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_download_events (
    id bigint NOT NULL,
    event_key text NOT NULL,
    asset_key text NOT NULL,
    brand_code text NOT NULL,
    locale text NOT NULL,
    email text,
    company text,
    job_title text,
    country text,
    interest_area text,
    user_agent text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    visitor_name text,
    CONSTRAINT marketing_download_events_event_chk CHECK ((event_key = ANY (ARRAY['marketing.download.opened'::text, 'marketing.download.submitted'::text, 'marketing.download.completed'::text])))
);


--
-- Name: TABLE marketing_download_events; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.marketing_download_events IS 'M1.5 — append-only event sink for download CTA telemetry.';


--
-- Name: marketing_download_events_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.marketing_download_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketing_download_events_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.marketing_download_events_id_seq OWNED BY dos.marketing_download_events.id;


--
-- Name: marketing_footer_groups; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_footer_groups (
    id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    title_en text NOT NULL,
    title_ar text NOT NULL,
    title_key text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_footer_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_footer_items (
    id text NOT NULL,
    group_id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    label_key text NOT NULL,
    href text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_nav_groups; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_nav_groups (
    id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: marketing_nav_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketing_nav_items (
    id text NOT NULL,
    brand_code text DEFAULT 'shahin-ai'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text NOT NULL,
    label_key text NOT NULL,
    href text NOT NULL,
    variant text DEFAULT 'link'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    hide_for_locales text[],
    carbon_key text DEFAULT 'link'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    nav_group text,
    nav_group_label_en text,
    nav_group_label_ar text,
    CONSTRAINT marketing_nav_items_carbon_key_check CHECK ((carbon_key = ANY (ARRAY['link'::text, 'button'::text, 'header-menu-item'::text]))),
    CONSTRAINT marketing_nav_items_variant_check CHECK ((variant = ANY (ARRAY['link'::text, 'primary'::text, 'secondary'::text, 'ghost'::text])))
);


--
-- Name: marketplace_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketplace_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketplace_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.marketplace_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketplace_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.marketplace_event_id_seq OWNED BY dos.marketplace_event.id;


--
-- Name: marketplace_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.marketplace_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT marketplace_record_kind_check CHECK ((kind = ANY (ARRAY['app'::text, 'module'::text, 'template'::text, 'dataset'::text]))),
    CONSTRAINT marketplace_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT marketplace_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: maturity_assessments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.maturity_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    framework character varying(100),
    overall_score numeric(5,2),
    status character varying(50) DEFAULT 'in_progress'::character varying NOT NULL,
    dimensions jsonb DEFAULT '{}'::jsonb,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: migration_history; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.migration_history (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    migration_number integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    migration_type character varying(20) NOT NULL,
    executed_at timestamp with time zone DEFAULT now(),
    executed_by character varying(255) NOT NULL,
    git_sha character varying(40),
    checksum character varying(64) NOT NULL,
    duration_ms integer,
    success boolean DEFAULT true,
    error_message text,
    rollback_available boolean DEFAULT false,
    CONSTRAINT migration_history_migration_type_check CHECK (((migration_type)::text = ANY ((ARRAY['up'::character varying, 'down'::character varying])::text[])))
);


--
-- Name: migration_history_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.migration_history_id_seq OWNED BY dos.migration_history.id;


--
-- Name: migration_lock; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.migration_lock (
    service_name character varying(100) NOT NULL,
    locked_at timestamp with time zone DEFAULT now(),
    locked_by character varying(255) NOT NULL,
    lock_expires_at timestamp with time zone,
    CONSTRAINT check_lock_expiry CHECK ((lock_expires_at > locked_at))
);


--
-- Name: migration_status; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.migration_status AS
 SELECT service_name,
    max(
        CASE
            WHEN (((migration_type)::text = 'up'::text) AND (success = true)) THEN migration_number
            ELSE NULL::integer
        END) AS last_up_migration,
    max(
        CASE
            WHEN (((migration_type)::text = 'down'::text) AND (success = true)) THEN migration_number
            ELSE NULL::integer
        END) AS last_down_migration,
    count(
        CASE
            WHEN (success = true) THEN 1
            ELSE NULL::integer
        END) AS successful_migrations,
    count(
        CASE
            WHEN (success = false) THEN 1
            ELSE NULL::integer
        END) AS failed_migrations,
    max(executed_at) AS last_execution,
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM dos.migration_lock
              WHERE (((migration_lock.service_name)::text = (mh.service_name)::text) AND (migration_lock.lock_expires_at > now())))) THEN 'locked'::text
            ELSE 'ready'::text
        END AS status
   FROM dos.migration_history mh
  GROUP BY service_name;


--
-- Name: mobile_sessions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.mobile_sessions (
    session_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    device_id text,
    device_type text,
    os_version text,
    app_version text,
    push_token text,
    status text DEFAULT 'active'::text,
    last_active timestamp with time zone DEFAULT now(),
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: module_capability_bindings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_capability_bindings (
    consumer_module text NOT NULL,
    capability_key text NOT NULL,
    semver_range text DEFAULT '*'::text NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: module_capability_flags; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_capability_flags (
    module_code character varying(100) NOT NULL,
    capability_key character varying(120) NOT NULL,
    capability_value text DEFAULT 'true'::text NOT NULL
);


--
-- Name: module_contract_errors; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_contract_errors (
    id bigint NOT NULL,
    module_code text NOT NULL,
    contract_version text NOT NULL,
    phase text NOT NULL,
    error_type text NOT NULL,
    error_path text,
    message text NOT NULL,
    severity text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT module_contract_errors_phase_check CHECK ((phase = ANY (ARRAY['validate'::text, 'dry-run'::text, 'publish'::text, 'activate'::text, 'verify'::text]))),
    CONSTRAINT module_contract_errors_severity_check CHECK ((severity = ANY (ARRAY['BLOCKER'::text, 'WARNING'::text, 'INFO'::text])))
);


--
-- Name: module_contract_errors_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.module_contract_errors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_contract_errors_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.module_contract_errors_id_seq OWNED BY dos.module_contract_errors.id;


--
-- Name: module_contract_publish_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_contract_publish_log (
    id bigint NOT NULL,
    module_code text NOT NULL,
    contract_version text NOT NULL,
    schema_version integer NOT NULL,
    contract_sha256 text NOT NULL,
    sql_sha256 text NOT NULL,
    rows_emitted jsonb DEFAULT '{}'::jsonb NOT NULL,
    applied_by text DEFAULT 'contract-publisher@v1'::text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    summary text
);


--
-- Name: module_contract_publish_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.module_contract_publish_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_contract_publish_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.module_contract_publish_log_id_seq OWNED BY dos.module_contract_publish_log.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.schema_migrations (
    id integer NOT NULL,
    filename text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_by text DEFAULT CURRENT_USER NOT NULL,
    duration_ms integer
);


--
-- Name: module_migrations; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.module_migrations AS
 SELECT split_part(filename, '/'::text, 2) AS module,
    split_part(filename, '/'::text, 3) AS file,
    checksum AS sha,
    applied_at
   FROM dos.schema_migrations
  WHERE (filename ~~ 'module/%'::text);


--
-- Name: module_pool_slots; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_pool_slots (
    slot_id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    module_version text NOT NULL,
    schema_template text NOT NULL,
    state text DEFAULT 'building'::text NOT NULL,
    built_at timestamp with time zone,
    attached_tenant text,
    attached_at timestamp with time zone,
    build_log jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT module_pool_slots_state_check CHECK ((state = ANY (ARRAY['building'::text, 'hot'::text, 'attached'::text, 'draining'::text, 'failed'::text])))
);


--
-- Name: module_readiness; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_readiness (
    module_code text NOT NULL,
    module_version text NOT NULL,
    verdict text NOT NULL,
    gates jsonb DEFAULT '{}'::jsonb NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    computed_by text DEFAULT 'verifier'::text NOT NULL,
    CONSTRAINT module_readiness_verdict_check CHECK ((verdict = ANY (ARRAY['GOLDEN_READY'::text, 'DRIFT'::text, 'BLOCKED'::text, 'UNKNOWN'::text])))
);


--
-- Name: module_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_registry (
    module_code character varying(50) NOT NULL,
    product_key character varying(50),
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: module_sla_defaults; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_sla_defaults (
    id integer NOT NULL,
    module_code character varying(50) NOT NULL,
    sla_type character varying(50),
    threshold_hours integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: module_sla_defaults_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.module_sla_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_sla_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.module_sla_defaults_id_seq OWNED BY dos.module_sla_defaults.id;


--
-- Name: module_sod_rules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.module_sod_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_code text NOT NULL,
    action_a text NOT NULL,
    action_b text NOT NULL,
    conflict_type text DEFAULT 'hard'::text NOT NULL,
    resolution_strategy text DEFAULT 'escalate'::text NOT NULL,
    description_en text,
    description_ar text,
    severity text DEFAULT 'high'::text,
    delegate_to_role text,
    escalation_roles text[] DEFAULT '{}'::text[],
    deadline_hours integer DEFAULT 48,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT module_sod_rules_conflict_type_check CHECK ((conflict_type = ANY (ARRAY['hard'::text, 'soft'::text]))),
    CONSTRAINT module_sod_rules_resolution_strategy_check CHECK ((resolution_strategy = ANY (ARRAY['block'::text, 'warn'::text, 'escalate'::text, 'allow'::text])))
);


--
-- Name: ui_route_template_binding; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_template_binding (
    route text NOT NULL,
    archetype text NOT NULL,
    template_export text NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    title_en text,
    title_ar text,
    subtitle_en text,
    subtitle_ar text,
    eyebrow_en text,
    eyebrow_ar text,
    ai_headline_en text,
    ai_headline_ar text,
    status_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    primary_action jsonb,
    CONSTRAINT chk_archetype CHECK ((archetype = ANY (ARRAY['command-home'::text, 'decision-dashboard'::text, 'command-dashboard'::text, 'posture-overview'::text, 'trend-intelligence'::text, 'intelligent-register'::text, 'risk-landscape'::text, 'record-story'::text, 'guided-create'::text, 'action-queue'::text, 'workflow-control'::text, 'workflow-timeline'::text, 'follow-up-center'::text, 'evidence-reports'::text, 'export-center'::text, 'audit-trail'::text, 'audit-trail-ledger'::text, 'audit-trail-evidence'::text, 'calendar-timeline'::text, 'compliance-calendar'::text, 'remediation-roadmap'::text, 'org-chart'::text, 'ownership-map'::text, 'delegation-center'::text, 'ai-advisor'::text, 'agent-flow'::text, 'agent-registry'::text, 'user-agent-workbench'::text, 'module-settings'::text, 'activation-journey'::text, 'incident-response'::text, 'case-finalization'::text, 'marketing-landing'::text, 'auth-page'::text])))
);


--
-- Name: COLUMN ui_route_template_binding.props; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.props IS 'JSONB props bag for marketing page configuration. For platform: {brandCode, eyebrow, title, sub, overview, architecture, features, integrations, ctaLabel, ctaHref}';


--
-- Name: COLUMN ui_route_template_binding.title_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.title_en IS 'Masthead H1 (en) — projected to props.masthead.title';


--
-- Name: COLUMN ui_route_template_binding.title_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.title_ar IS 'Masthead H1 (ar) — projected to props.masthead.title';


--
-- Name: COLUMN ui_route_template_binding.subtitle_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.subtitle_en IS 'Masthead subtitle (en)';


--
-- Name: COLUMN ui_route_template_binding.subtitle_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.subtitle_ar IS 'Masthead subtitle (ar)';


--
-- Name: COLUMN ui_route_template_binding.eyebrow_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.eyebrow_en IS 'Masthead breadcrumb eyebrow (en)';


--
-- Name: COLUMN ui_route_template_binding.eyebrow_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.eyebrow_ar IS 'Masthead breadcrumb eyebrow (ar)';


--
-- Name: COLUMN ui_route_template_binding.ai_headline_en; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.ai_headline_en IS 'Inline cds-ai-label headline (en)';


--
-- Name: COLUMN ui_route_template_binding.ai_headline_ar; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.ai_headline_ar IS 'Inline cds-ai-label headline (ar)';


--
-- Name: COLUMN ui_route_template_binding.status_tags; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.status_tags IS 'Array of {label,severity} surfacing as cds-tag chips.';


--
-- Name: COLUMN ui_route_template_binding.primary_action; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_route_template_binding.primary_action IS '{label, route, permission?} object surfacing as cdsButton.';


--
-- Name: workspace_shell_binding; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_shell_binding (
    id bigint NOT NULL,
    tenant_id text NOT NULL,
    component_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    perms_required text[] DEFAULT '{}'::text[] NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_workspace_component_key CHECK ((component_key = ANY (ARRAY['workspace.frame.ui-shell'::text, 'workspace.frame.header'::text, 'workspace.frame.header-name'::text, 'workspace.frame.header-navigation'::text, 'workspace.frame.header-menu'::text, 'workspace.frame.header-menu-item'::text, 'workspace.frame.header-global-bar'::text, 'workspace.frame.header-global-action'::text, 'workspace.frame.side-nav'::text, 'workspace.frame.side-nav-items'::text, 'workspace.frame.side-nav-menu'::text, 'workspace.frame.side-nav-menu-item'::text, 'workspace.frame.side-nav-link'::text, 'workspace.frame.content'::text, 'workspace.nav.grid'::text, 'workspace.nav.column'::text, 'workspace.nav.layer'::text, 'workspace.nav.breadcrumb'::text, 'workspace.nav.tabs'::text, 'workspace.nav.tab'::text, 'workspace.nav.tile'::text, 'workspace.nav.clickable-tile'::text, 'workspace.nav.expandable-tile'::text, 'workspace.nav.tag'::text, 'workspace.data.data-table'::text, 'workspace.data.table-toolbar'::text, 'workspace.data.table-toolbar-search'::text, 'workspace.data.table-toolbar-actions'::text, 'workspace.data.table-batch-actions'::text, 'workspace.data.pagination'::text, 'workspace.data.structured-list'::text, 'workspace.input.search'::text, 'workspace.input.dropdown'::text, 'workspace.input.combo-box'::text, 'workspace.input.multi-select'::text, 'workspace.input.date-picker'::text, 'workspace.input.text-input'::text, 'workspace.input.text-area'::text, 'workspace.input.number-input'::text, 'workspace.input.select'::text, 'workspace.input.checkbox'::text, 'workspace.input.radio'::text, 'workspace.input.toggle'::text, 'workspace.action.button'::text, 'workspace.action.icon-button'::text, 'workspace.action.overflow-menu'::text, 'workspace.action.overflow-menu-option'::text, 'workspace.action.modal'::text, 'workspace.action.inline-notification'::text, 'workspace.action.toast-notification'::text, 'workspace.polish.tooltip'::text, 'workspace.polish.toggletip'::text, 'workspace.polish.popover'::text, 'workspace.polish.progress-bar'::text, 'workspace.polish.inline-loading'::text, 'workspace.polish.skeleton-text'::text, 'workspace.polish.skeleton-placeholder'::text, 'workspace.polish.context-menu'::text, 'workspace.polish.file-uploader'::text, 'workspace.polish.accordion'::text, 'workspace.shell.brand'::text, 'workspace.shell.workspace-title'::text, 'workspace.shell.user-menu'::text, 'workspace.shell.settings-action'::text, 'workspace.shell.sidebar-nav'::text, 'workspace.shell.empty-state'::text, 'workspace.shell.module-cards'::text])))
);


--
-- Name: COLUMN workspace_shell_binding.props; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.workspace_shell_binding.props IS 'JSONB props bag for component configuration. For workspace.header: {logoHref, brandLabel, homeRoute, ...}';


--
-- Name: mv_workspace_bootstrap; Type: MATERIALIZED VIEW; Schema: dos; Owner: -
--

CREATE MATERIALIZED VIEW dos.mv_workspace_bootstrap AS
 SELECT tenant_id,
    'v1'::text AS ui_catalog_version,
    COALESCE(( SELECT jsonb_agg(jsonb_build_object('route', b.route, 'archetype', b.archetype, 'titleEn', b.title_en, 'titleAr', b.title_ar) ORDER BY b.route) AS jsonb_agg
           FROM dos.ui_route_template_binding b), '[]'::jsonb) AS routes,
    COALESCE(( SELECT jsonb_agg(jsonb_build_object('componentKey', s.component_key, 'enabled', s.enabled, 'position', s."position", 'permsRequired', s.perms_required) ORDER BY s.component_key) AS jsonb_agg
           FROM dos.workspace_shell_binding s
          WHERE (s.tenant_id = t.tenant_id)), '[]'::jsonb) AS shell,
    COALESCE(( SELECT jsonb_agg(DISTINCT jsonb_build_object('componentKey', r.component_key, 'carbonKey', r.carbon_key)) AS jsonb_agg
           FROM dos.dynamic_ui_component_registry r
          WHERE ((r.approval_status)::text = 'approved'::text)), '[]'::jsonb) AS components,
    now() AS refreshed_at
   FROM ( SELECT DISTINCT workspace_shell_binding.tenant_id
           FROM dos.workspace_shell_binding) t
  WITH NO DATA;


--
-- Name: MATERIALIZED VIEW mv_workspace_bootstrap; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON MATERIALIZED VIEW dos.mv_workspace_bootstrap IS 'M4 D1 — backing store for JWE-signed /api/workspace/bootstrap. Refreshed by workspace-bff on permission/module/binding mutations (M5 SSE channel).';


--
-- Name: navigation_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.navigation_registry (
    id integer NOT NULL,
    module_code character varying(50) NOT NULL,
    nav_item_code character varying(100),
    label_en character varying(255),
    label_ar character varying(255),
    icon character varying(50),
    route character varying(255),
    parent_code character varying(100),
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: navigation_registry_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.navigation_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: navigation_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.navigation_registry_id_seq OWNED BY dos.navigation_registry.id;


--
-- Name: notification_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.notification_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.notification_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.notification_event_id_seq OWNED BY dos.notification_event.id;


--
-- Name: notification_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.notification_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT notification_record_kind_check CHECK ((kind = ANY (ARRAY['email'::text, 'sms'::text, 'push'::text, 'webhook'::text, 'in-app'::text]))),
    CONSTRAINT notification_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT notification_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: onboarding_journeys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.onboarding_journeys (
    journey_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    user_id character varying(64) NOT NULL,
    status character varying(50) DEFAULT 'in_progress'::character varying NOT NULL,
    current_step character varying(100),
    completed_steps text[] DEFAULT '{}'::text[],
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: organizations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.organizations (
    organization_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    code text,
    parent_id uuid,
    org_type text,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.organizations FORCE ROW LEVEL SECURITY;


--
-- Name: orphan_schema_audit; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.orphan_schema_audit (
    id bigint NOT NULL,
    schema_name text NOT NULL,
    table_count integer NOT NULL,
    total_size text NOT NULL,
    data_summary jsonb NOT NULL,
    decision text NOT NULL,
    applied boolean NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    recorded_by text DEFAULT CURRENT_USER NOT NULL
);


--
-- Name: orphan_schema_audit_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.orphan_schema_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orphan_schema_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.orphan_schema_audit_id_seq OWNED BY dos.orphan_schema_audit.id;


--
-- Name: ownership_mappings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ownership_mappings (
    mapping_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying(64) NOT NULL,
    owner_user_id character varying(64) NOT NULL,
    ownership_type text DEFAULT 'primary'::text NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_to timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.ownership_mappings FORCE ROW LEVEL SECURITY;


--
-- Name: permissions; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.permissions AS
 SELECT permission_id,
    permission_code,
    module_code,
    resource_type,
    action_type,
    description,
    created_at
   FROM platform_dauth.permissions;


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_audit_logs_id_seq OWNED BY dos.platform_audit_logs.id;


--
-- Name: platform_drift_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_drift_log (
    id bigint NOT NULL,
    sampled_at timestamp with time zone DEFAULT now() NOT NULL,
    metric_key text NOT NULL,
    value_num numeric,
    value_text text,
    severity text DEFAULT 'info'::text NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT platform_drift_log_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warn'::text, 'critical'::text])))
);


--
-- Name: TABLE platform_drift_log; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.platform_drift_log IS 'Phase 6 runtime drift telemetry. Hourly sampler appends one row per
metric_key. Severity raises to ''critical'' when a CI-guard equivalent
predicate trips at runtime — surfaced to PagerDuty via
scripts/ops/drift-telemetry-sample.mjs';


--
-- Name: platform_drift_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_drift_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_drift_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_drift_log_id_seq OWNED BY dos.platform_drift_log.id;


--
-- Name: platform_migrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_migrations (
    filename text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_ms integer NOT NULL
);


--
-- Name: platform_operation_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_operation_config (
    id integer NOT NULL,
    operation_key character varying(200),
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    description text,
    owner_layer character varying(50) DEFAULT 'DOS'::character varying,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    config_key character varying(200),
    config_value jsonb
);


--
-- Name: platform_operation_config_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_operation_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_operation_config_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_operation_config_id_seq OWNED BY dos.platform_operation_config.id;


--
-- Name: platform_secret; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_secret (
    secret_id bigint NOT NULL,
    secret_key character varying(128) NOT NULL,
    scope character varying(16) DEFAULT 'platform'::character varying NOT NULL,
    tenant_id character varying(64),
    value_ciphertext bytea,
    value_iv bytea,
    value_tag bytea,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(128),
    CONSTRAINT chk_platform_secret_scope CHECK (((scope)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying])::text[]))),
    CONSTRAINT chk_platform_secret_scope_tenant CHECK (((((scope)::text = 'platform'::text) AND (tenant_id IS NULL)) OR (((scope)::text = 'tenant'::text) AND (tenant_id IS NOT NULL))))
);


--
-- Name: platform_secret_definition; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_secret_definition (
    secret_key character varying(128) NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    display_label character varying(160) NOT NULL,
    description text,
    is_sensitive boolean DEFAULT true NOT NULL,
    consumer_service character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_secret_secret_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_secret_secret_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_secret_secret_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_secret_secret_id_seq OWNED BY dos.platform_secret.secret_id;


--
-- Name: platform_session_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_session_policy (
    trust_zone text NOT NULL,
    access_token_ttl_seconds integer NOT NULL,
    refresh_token_ttl_seconds integer NOT NULL,
    pkce_required boolean DEFAULT false NOT NULL,
    cookie_secure boolean DEFAULT true NOT NULL,
    cookie_samesite text DEFAULT 'Lax'::text NOT NULL,
    rate_limit_per_minute integer DEFAULT 600 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    written_by text DEFAULT current_setting('dos.actor'::text, true) NOT NULL,
    CONSTRAINT platform_session_policy_access_token_ttl_seconds_check CHECK ((access_token_ttl_seconds > 0)),
    CONSTRAINT platform_session_policy_cookie_samesite_check CHECK ((cookie_samesite = ANY (ARRAY['Strict'::text, 'Lax'::text, 'None'::text]))),
    CONSTRAINT platform_session_policy_rate_limit_per_minute_check CHECK ((rate_limit_per_minute > 0)),
    CONSTRAINT platform_session_policy_refresh_token_ttl_seconds_check CHECK ((refresh_token_ttl_seconds > 0)),
    CONSTRAINT platform_session_policy_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['admin'::text, 'tenant'::text, 'customer'::text])))
);


--
-- Name: platform_slo; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_slo (
    service_code text NOT NULL,
    availability_target numeric(5,4) NOT NULL,
    latency_p99_ms integer NOT NULL,
    error_budget_seconds_30d integer NOT NULL,
    trust_zone text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    written_by text DEFAULT current_setting('dos.actor'::text, true) NOT NULL,
    CONSTRAINT platform_slo_availability_target_check CHECK (((availability_target > (0)::numeric) AND (availability_target <= (1)::numeric))),
    CONSTRAINT platform_slo_error_budget_seconds_30d_check CHECK ((error_budget_seconds_30d >= 0)),
    CONSTRAINT platform_slo_latency_p99_ms_check CHECK ((latency_p99_ms > 0)),
    CONSTRAINT platform_slo_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['admin'::text, 'tenant'::text, 'customer'::text])))
);


--
-- Name: platform_slo_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.platform_slo_event (
    id bigint NOT NULL,
    service_code text NOT NULL,
    probed_at timestamp with time zone DEFAULT now() NOT NULL,
    ok boolean NOT NULL,
    http_status integer,
    latency_ms integer,
    error_message text,
    emitted_by text DEFAULT current_setting('dos.actor'::text, true) NOT NULL
);


--
-- Name: platform_slo_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.platform_slo_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_slo_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.platform_slo_event_id_seq OWNED BY dos.platform_slo_event.id;


--
-- Name: policies; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.policies (
    policy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    body text,
    version text DEFAULT '1.0'::text,
    status text DEFAULT 'draft'::text,
    category text,
    owner_id text,
    approved_by text,
    approved_at timestamp with time zone,
    effective_date timestamp with time zone,
    review_date timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: portals; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.portals (
    portal_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    name text NOT NULL,
    portal_type character varying(50) DEFAULT 'vendor'::character varying NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    custom_domain character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: position_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.position_assignments (
    assignment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    position_id uuid NOT NULL,
    user_id character varying(64) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    is_primary boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY dos.position_assignments FORCE ROW LEVEL SECURITY;


--
-- Name: positions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.positions (
    position_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    code text,
    bu_id uuid,
    grade text,
    level integer,
    reports_to uuid,
    status text DEFAULT 'active'::text NOT NULL,
    description text,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);

ALTER TABLE ONLY dos.positions FORCE ROW LEVEL SECURITY;


--
-- Name: privacy_assessments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.privacy_assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    assessment_type character varying(50) DEFAULT 'dpia'::character varying,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    data_categories text[],
    processing_purposes text[],
    risk_level character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: product_licenses; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.product_licenses (
    license_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(50) NOT NULL,
    license_type character varying(50) DEFAULT 'standard'::character varying NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    seats_limit integer,
    valid_from date,
    valid_until date,
    features jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: product_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.product_registry (
    product_key character varying(50) NOT NULL,
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: publish_dependency; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_dependency (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_target_id uuid NOT NULL,
    child_target_id uuid NOT NULL,
    dep_kind text NOT NULL,
    CONSTRAINT publish_dependency_check CHECK ((parent_target_id <> child_target_id))
);


--
-- Name: publish_revision; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_revision (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    revision_no bigint NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text NOT NULL,
    change_request_id uuid,
    status text DEFAULT 'draft'::text NOT NULL,
    CONSTRAINT publish_revision_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'staged'::text, 'live'::text, 'rolled_back'::text, 'superseded'::text])))
);


--
-- Name: publish_rollback; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_rollback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    revision_id uuid NOT NULL,
    rolled_back_at timestamp with time zone DEFAULT now() NOT NULL,
    rolled_back_by text NOT NULL,
    reason text NOT NULL
);


--
-- Name: publish_target; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.publish_target (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    display_name text NOT NULL,
    owner_team text,
    notes text
);


--
-- Name: qiyas_journeys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.qiyas_journeys (
    journey_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'assessment'::text,
    status text DEFAULT 'draft'::text,
    score integer,
    config jsonb DEFAULT '{}'::jsonb,
    results jsonb DEFAULT '{}'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: records; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.records (
    record_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    record_type character varying(100) NOT NULL,
    title text NOT NULL,
    content jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    retention_until date,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: release_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.release_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: release_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.release_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: release_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.release_event_id_seq OWNED BY dos.release_event.id;


--
-- Name: release_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.release_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT release_record_kind_check CHECK ((kind = ANY (ARRAY['minor'::text, 'patch'::text, 'major'::text, 'hotfix'::text]))),
    CONSTRAINT release_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT release_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: remediation_actions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.remediation_actions (
    action_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'open'::text,
    priority text DEFAULT 'medium'::text,
    assigned_to text,
    source_type text,
    source_id text,
    due_date timestamp with time zone,
    completed_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: remediations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.remediations (
    remediation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    source_type character varying(50),
    source_id uuid,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    assigned_to character varying(64),
    due_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: report_schedules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.report_schedules (
    schedule_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    report_type text NOT NULL,
    cron text,
    recipients jsonb DEFAULT '[]'::jsonb,
    config jsonb DEFAULT '{}'::jsonb,
    enabled boolean DEFAULT true,
    last_run_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: risks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.risks (
    risk_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    category character varying(100),
    likelihood integer,
    impact integer,
    risk_score integer GENERATED ALWAYS AS ((likelihood * impact)) STORED,
    status character varying(50) DEFAULT 'open'::character varying NOT NULL,
    treatment_plan text,
    owner_user_id character varying(64),
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    CONSTRAINT risks_impact_check CHECK (((impact >= 1) AND (impact <= 5))),
    CONSTRAINT risks_likelihood_check CHECK (((likelihood >= 1) AND (likelihood <= 5)))
);


--
-- Name: role_permissions; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.role_permissions AS
 SELECT role_id,
    permission_id,
    created_at
   FROM platform_dauth.role_permissions;


--
-- Name: role_profile_acceptors; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_profile_acceptors (
    acceptor_id character varying(64) NOT NULL,
    display_name text NOT NULL,
    direction character varying(16) NOT NULL,
    endpoint_url text,
    auth_strategy character varying(32) DEFAULT 'oauth2'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    last_sync_at timestamp with time zone,
    last_status character varying(16),
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT role_profile_acceptors_direction_check CHECK (((direction)::text = ANY ((ARRAY['pull'::character varying, 'push'::character varying, 'two-way'::character varying])::text[])))
);


--
-- Name: TABLE role_profile_acceptors; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.role_profile_acceptors IS 'Registry of stakeholder systems that participate in 2-way role-profile sync.';


--
-- Name: role_profile_sync; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_profile_sync (
    profile_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    role_code character varying(64) NOT NULL,
    scope character varying(32) DEFAULT 'tenant'::character varying NOT NULL,
    permissions text[] DEFAULT ARRAY[]::text[] NOT NULL,
    business_unit_id character varying(64),
    location_id character varying(64),
    lifecycle_state character varying(24) DEFAULT 'active'::character varying NOT NULL,
    external_idp_refs jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_system character varying(64) DEFAULT 'role-profile-service'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT role_profile_sync_lifecycle_state_check CHECK (((lifecycle_state)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'suspended'::character varying, 'offboarding'::character varying, 'terminated'::character varying])::text[])))
);


--
-- Name: TABLE role_profile_sync; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.role_profile_sync IS 'Canonical role-profile substrate. The ONLY legitimate writer to
platform_dauth.user_role_assignments. 2-way sync target for HRIS/SCIM/Okta/AAD
adapters. URA is now a derived projection — see trg_ura_via_role_profile_only.';


--
-- Name: role_profile_sync_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.role_profile_sync_log (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    acceptor_id character varying(64),
    direction character varying(16) NOT NULL,
    profile_id uuid,
    tenant_id character varying(64),
    user_id character varying(64),
    role_code character varying(64),
    outcome character varying(16) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT role_profile_sync_log_direction_check CHECK (((direction)::text = ANY ((ARRAY['pull'::character varying, 'push'::character varying, 'reconcile'::character varying])::text[]))),
    CONSTRAINT role_profile_sync_log_outcome_check CHECK (((outcome)::text = ANY ((ARRAY['ok'::character varying, 'error'::character varying, 'skipped'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: role_profile_sync_log_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.role_profile_sync_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_profile_sync_log_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.role_profile_sync_log_id_seq OWNED BY dos.role_profile_sync_log.id;


--
-- Name: rollout_cohort; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_cohort (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ring_id uuid NOT NULL,
    selector_kind text NOT NULL,
    selector_value text NOT NULL,
    weight integer DEFAULT 100 NOT NULL,
    CONSTRAINT rollout_cohort_selector_kind_check CHECK ((selector_kind = ANY (ARRAY['tenant_id'::text, 'region'::text, 'product'::text, 'edition'::text, 'route_pattern'::text, 'slot'::text, 'archetype'::text, 'tag'::text]))),
    CONSTRAINT rollout_cohort_weight_check CHECK (((weight >= 0) AND (weight <= 100)))
);


--
-- Name: rollout_compensation_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_compensation_step (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    chain_id uuid NOT NULL,
    step_order integer NOT NULL,
    step_kind text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    CONSTRAINT rollout_compensation_step_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: rollout_evaluation; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_evaluation (
    id bigint NOT NULL,
    ring_id uuid NOT NULL,
    evaluated_at timestamp with time zone DEFAULT now() NOT NULL,
    decision text NOT NULL,
    signals jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT rollout_evaluation_decision_check CHECK ((decision = ANY (ARRAY['hold'::text, 'advance'::text, 'rollback'::text])))
);


--
-- Name: rollout_evaluation_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.rollout_evaluation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rollout_evaluation_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.rollout_evaluation_id_seq OWNED BY dos.rollout_evaluation.id;


--
-- Name: rollout_health_gate; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_health_gate (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ring_id uuid NOT NULL,
    gate_kind text NOT NULL,
    threshold numeric NOT NULL,
    comparator text NOT NULL,
    window_sec integer DEFAULT 300 NOT NULL,
    CONSTRAINT rollout_health_gate_comparator_check CHECK ((comparator = ANY (ARRAY['lt'::text, 'lte'::text, 'gt'::text, 'gte'::text, 'eq'::text]))),
    CONSTRAINT rollout_health_gate_gate_kind_check CHECK ((gate_kind = ANY (ARRAY['prom_error_rate'::text, 'jaeger_p95_latency'::text, 'loki_error_volume'::text, 'audit_denial_spike'::text, 'synthetic_pageload'::text])))
);


--
-- Name: rollout_plan; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_plan (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    change_request_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    CONSTRAINT rollout_plan_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'running'::text, 'paused'::text, 'succeeded'::text, 'failed'::text, 'rolled_back'::text])))
);


--
-- Name: rollout_ring; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_ring (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    ring_code text NOT NULL,
    ring_order integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    CONSTRAINT rollout_ring_ring_code_check CHECK ((ring_code = ANY (ARRAY['R0'::text, 'R1'::text, 'R2'::text, 'R3'::text, 'R4'::text, 'R5'::text]))),
    CONSTRAINT rollout_ring_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'succeeded'::text, 'failed'::text, 'rolled_back'::text])))
);


--
-- Name: rollout_rollback; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_rollback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ring_id uuid NOT NULL,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    triggered_by text NOT NULL,
    reason text NOT NULL,
    succeeded_at timestamp with time zone
);


--
-- Name: rollout_signal_threshold; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.rollout_signal_threshold (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    signal_kind text NOT NULL,
    default_value numeric NOT NULL,
    unit text NOT NULL,
    notes text
);


--
-- Name: runtime_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.runtime_config (
    config_key character varying(200) NOT NULL,
    config_value jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: runtime_config_history; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.runtime_config_history (
    id integer NOT NULL,
    config_key character varying(200),
    old_value jsonb,
    new_value jsonb,
    changed_by character varying(64),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: runtime_config_history_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.runtime_config_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runtime_config_history_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.runtime_config_history_id_seq OWNED BY dos.runtime_config_history.id;


--
-- Name: schema_authoring_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.schema_authoring_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_authoring_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.schema_authoring_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schema_authoring_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.schema_authoring_event_id_seq OWNED BY dos.schema_authoring_event.id;


--
-- Name: schema_authoring_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.schema_authoring_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT schema_authoring_record_kind_check CHECK ((kind = ANY (ARRAY['typescript'::text, 'sql'::text, 'json-schema'::text, 'protobuf'::text]))),
    CONSTRAINT schema_authoring_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT schema_authoring_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.schema_migrations_id_seq OWNED BY dos.schema_migrations.id;


--
-- Name: security_secret_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.security_secret_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: security_secret_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.security_secret_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_secret_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.security_secret_event_id_seq OWNED BY dos.security_secret_event.id;


--
-- Name: security_secret_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.security_secret_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT security_secret_record_kind_check CHECK ((kind = ANY (ARRAY['static'::text, 'rotating'::text, 'dynamic'::text, 'federated'::text]))),
    CONSTRAINT security_secret_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT security_secret_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: sessions; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.sessions AS
 SELECT session_id,
    user_id,
    tenant_id,
    jti,
    refresh_jti,
    ip_address,
    user_agent,
    created_at,
    last_active_at,
    expires_at,
    revoked_at
   FROM platform_dauth.sessions_legacy;


--
-- Name: shell_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.shell_config (
    config_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    scope_type character varying(20) NOT NULL,
    scope_key character varying(200),
    module_code character varying(100) NOT NULL,
    product_code character varying(100),
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(64),
    CONSTRAINT shell_config_scope_type_check CHECK (((scope_type)::text = ANY ((ARRAY['platform'::character varying, 'tenant'::character varying, 'role'::character varying, 'user'::character varying])::text[])))
);


--
-- Name: sod_conflict_audit; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sod_conflict_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text,
    user_id text,
    module_code text,
    action_a text,
    action_b text,
    conflict_type text,
    resolution_strategy text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sod_rules; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.sod_rules AS
 SELECT rule_id,
    rule_code,
    module_code,
    conflicting_permissions,
    severity,
    description,
    created_at
   FROM platform_dauth.sod_rules;


--
-- Name: sso_identities; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_identities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    protocol text NOT NULL,
    external_id text NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb,
    linked_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sso_providers; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    protocol text NOT NULL,
    status text DEFAULT 'testing'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sso_providers_protocol_check CHECK ((protocol = ANY (ARRAY['saml'::text, 'oidc'::text]))),
    CONSTRAINT sso_providers_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'testing'::text])))
);


--
-- Name: sso_role_mappings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_role_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    idp_group text NOT NULL,
    platform_role text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sso_sessions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.sso_sessions (
    session_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id uuid NOT NULL,
    idp_session_id text,
    protocol text NOT NULL,
    authenticated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT sso_sessions_protocol_check CHECK ((protocol = ANY (ARRAY['saml'::text, 'oidc'::text])))
);


--
-- Name: system_events; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.system_events (
    id integer NOT NULL,
    event_type character varying(100) NOT NULL,
    source character varying(100),
    payload jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    occurred_at timestamp with time zone DEFAULT now()
);


--
-- Name: system_events_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.system_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_events_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.system_events_id_seq OWNED BY dos.system_events.id;


--
-- Name: team_members; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.team_members (
    id integer NOT NULL,
    team_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    role character varying(50) DEFAULT 'member'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    team_member_id uuid DEFAULT gen_random_uuid(),
    role_in_team character varying(100),
    is_owner boolean DEFAULT false,
    joined_at timestamp with time zone,
    ended_at timestamp with time zone
);


--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.team_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.team_members_id_seq OWNED BY dos.team_members.id;


--
-- Name: team_raci_assignments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.team_raci_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    team_id uuid NOT NULL,
    user_id text NOT NULL,
    scope_type character varying(100) NOT NULL,
    scope_id uuid,
    raci_role character varying(20) NOT NULL,
    assigned_by text,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT team_raci_assignments_raci_role_check CHECK (((raci_role)::text = ANY ((ARRAY['responsible'::character varying, 'accountable'::character varying, 'consulted'::character varying, 'informed'::character varying])::text[])))
);


--
-- Name: teams; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.teams (
    team_id character varying(64) NOT NULL,
    team_code character varying(100) NOT NULL,
    display_name character varying(255),
    tenant_id character varying(64),
    created_at timestamp with time zone DEFAULT now(),
    description text,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    name character varying(255),
    code character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    created_by character varying(64),
    head_user_id character varying(64),
    department_id character varying(64),
    name_en text,
    name_ar text,
    bu_id uuid,
    team_type text,
    function_code text,
    owner_user_id text,
    metadata_json jsonb
);

ALTER TABLE ONLY dos.teams FORCE ROW LEVEL SECURITY;


--
-- Name: telemetry_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.telemetry_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: telemetry_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.telemetry_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: telemetry_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.telemetry_event_id_seq OWNED BY dos.telemetry_event.id;


--
-- Name: telemetry_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.telemetry_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT telemetry_record_kind_check CHECK ((kind = ANY (ARRAY['sink'::text, 'alert'::text, 'dashboard'::text, 'synthetic'::text]))),
    CONSTRAINT telemetry_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT telemetry_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: tenant_config_versions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_config_versions (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT tenant_config_versions_id_not_null1 NOT NULL,
    tenant_id text CONSTRAINT tenant_config_versions_tenant_id_not_null1 NOT NULL,
    config_key character varying(500) CONSTRAINT tenant_config_versions_config_key_not_null1 NOT NULL,
    config_value jsonb,
    version_number integer DEFAULT 1 NOT NULL,
    is_current boolean DEFAULT true,
    set_by text,
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_config_versions_legacy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_config_versions_legacy (
    id integer CONSTRAINT tenant_config_versions_id_not_null NOT NULL,
    tenant_id character varying(16) CONSTRAINT tenant_config_versions_tenant_id_not_null NOT NULL,
    config_key character varying(200) CONSTRAINT tenant_config_versions_config_key_not_null NOT NULL,
    version integer DEFAULT 1,
    config_value jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_config_versions_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_config_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_config_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_config_versions_id_seq OWNED BY dos.tenant_config_versions_legacy.id;


--
-- Name: tenant_feature_flag_overrides; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_feature_flag_overrides (
    id integer NOT NULL,
    tenant_id character varying(16) NOT NULL,
    flag_code character varying(100) NOT NULL,
    enabled boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_feature_flag_overrides_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_feature_flag_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_feature_flag_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_feature_flag_overrides_id_seq OWNED BY dos.tenant_feature_flag_overrides.id;


--
-- Name: tenant_kms_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_kms_config (
    tenant_id text NOT NULL,
    provider text NOT NULL,
    kek_ref text NOT NULL,
    region text,
    rotation_days integer DEFAULT 365 NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_kms_config_provider_check CHECK ((provider = ANY (ARRAY['aws-kms'::text, 'azure-keyvault'::text, 'gcp-kms'::text, 'hashicorp-vault'::text, 'platform-managed'::text]))),
    CONSTRAINT tenant_kms_config_status_check CHECK ((status = ANY (ARRAY['active'::text, 'rotating'::text, 'disabled'::text, 'crypto-erased'::text])))
);


--
-- Name: TABLE tenant_kms_config; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_kms_config IS 'Wave 11: per-tenant CMEK/BYOK configuration. KEK lives in customer KMS.';


--
-- Name: tenant_kms_keys; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_kms_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    kek_ref text NOT NULL,
    algorithm text DEFAULT 'AES-256-GCM'::text NOT NULL,
    wrapped_dek bytea NOT NULL,
    scope text DEFAULT 'compliance'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    rotated_from uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


--
-- Name: TABLE tenant_kms_keys; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_kms_keys IS 'Wave 11: wrapped DEKs per tenant. Plaintext DEKs never persisted.';


--
-- Name: COLUMN tenant_kms_keys.wrapped_dek; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_kms_keys.wrapped_dek IS 'DEK wrapped by KEK in customer KMS. AES-256-GCM (iv || tag || ciphertext).';


--
-- Name: tenant_landing_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_landing_config (
    id bigint NOT NULL,
    tenant_id character varying(255) NOT NULL,
    authenticated_route character varying(255) DEFAULT '/workspace-home'::character varying NOT NULL,
    unauthenticated_route character varying(255) DEFAULT '/'::character varying NOT NULL,
    session_expired_route character varying(255) DEFAULT '/'::character varying NOT NULL,
    post_auth_route character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE tenant_landing_config; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_landing_config IS 'Tenant-specific landing page configuration for different auth states. Eliminates hardcoded route fallbacks.';


--
-- Name: COLUMN tenant_landing_config.authenticated_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.authenticated_route IS 'Route for authenticated users (e.g., /workspace-home, /admin-hub)';


--
-- Name: COLUMN tenant_landing_config.unauthenticated_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.unauthenticated_route IS 'Route for unauthenticated users (e.g., /)';


--
-- Name: COLUMN tenant_landing_config.session_expired_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.session_expired_route IS 'Route when session expires (e.g., /)';


--
-- Name: COLUMN tenant_landing_config.post_auth_route; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.tenant_landing_config.post_auth_route IS 'Route after successful authentication (overrides authenticated_route)';


--
-- Name: tenant_landing_config_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_landing_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_landing_config_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_landing_config_id_seq OWNED BY dos.tenant_landing_config.id;


--
-- Name: tenant_memberships; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_memberships (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    role_code character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    membership_type text DEFAULT 'internal'::text,
    is_tenant_owner boolean DEFAULT false
);


--
-- Name: tenant_memberships_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_memberships_id_seq OWNED BY dos.tenant_memberships.id;


--
-- Name: tenant_migrations; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_migrations (
    tenant_id text NOT NULL,
    migration_id text NOT NULL,
    source text NOT NULL,
    filename text NOT NULL,
    checksum text NOT NULL,
    status text NOT NULL,
    duration_ms integer,
    error_message text,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_by text,
    CONSTRAINT chk_tenant_migrations_status_v2 CHECK ((status = ANY (ARRAY['applied'::text, 'failed'::text, 'verified-by-backfill'::text, 'superseded-misclassified'::text])))
);


--
-- Name: tenant_migrations_latest; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.tenant_migrations_latest AS
 SELECT DISTINCT ON (tenant_id, migration_id) tenant_id,
    migration_id,
    source,
    filename,
    checksum,
    status,
    duration_ms,
    error_message,
    applied_at,
    applied_by
   FROM dos.tenant_migrations
  ORDER BY tenant_id, migration_id, applied_at DESC;


--
-- Name: tenant_migrations_failed; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.tenant_migrations_failed AS
 SELECT tenant_id,
    migration_id,
    filename,
    error_message,
    applied_at
   FROM dos.tenant_migrations_latest
  WHERE (status = 'failed'::text);


--
-- Name: tenant_module_entitlements; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_module_entitlements (
    entitlement_id character varying(32) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    product_code character varying(64) NOT NULL,
    module_code character varying(64) NOT NULL,
    entitlement_status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    source character varying(32) DEFAULT 'paid'::character varying NOT NULL,
    trial_id character varying(32),
    subscription_id character varying(32),
    limits_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    starts_at timestamp with time zone DEFAULT now() NOT NULL,
    ends_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_tenant_module_entitlements_source CHECK (((source)::text = ANY ((ARRAY['trial'::character varying, 'paid'::character varying, 'internal'::character varying, 'admin'::character varying, 'manual'::character varying, 'platform_dna'::character varying])::text[]))),
    CONSTRAINT chk_tenant_module_entitlements_status CHECK (((entitlement_status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'suspended'::character varying, 'cancelled'::character varying, 'pending'::character varying, 'not_entitled'::character varying])::text[])))
);


--
-- Name: tenant_modules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_modules (
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    module_version text NOT NULL,
    status text DEFAULT 'eligible'::text NOT NULL,
    provisioning_mode text DEFAULT 'eager'::text NOT NULL,
    attached_slot_id uuid,
    materialized_at timestamp with time zone,
    last_error text,
    idempotency_key text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_modules_provisioning_mode_check CHECK ((provisioning_mode = ANY (ARRAY['eager'::text, 'on_demand'::text, 'pool_warmed'::text]))),
    CONSTRAINT tenant_modules_status_check CHECK ((status = ANY (ARRAY['eligible'::text, 'attaching'::text, 'active'::text, 'failed'::text, 'draining'::text, 'disabled'::text])))
);


--
-- Name: tenant_product_activation; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_product_activation (
    id integer NOT NULL,
    tenant_id character varying(64) NOT NULL,
    product_key character varying(50) NOT NULL,
    activated_at timestamp with time zone DEFAULT now(),
    status character varying(20) DEFAULT 'active'::character varying
);


--
-- Name: tenant_product_activation_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_product_activation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_product_activation_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_product_activation_id_seq OWNED BY dos.tenant_product_activation.id;


--
-- Name: tenant_schema_allowlist; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_schema_allowlist (
    schema_name character varying(100) NOT NULL,
    reason text NOT NULL,
    evidence text,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    added_by text
);


--
-- Name: TABLE tenant_schema_allowlist; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.tenant_schema_allowlist IS 'Explicit allow-list for `tenant_*` schemas that legitimately exist without
 a `dos.tenants` registry row. Consumed by
 scripts/ci-guards/per-tenant-schema-orphan-detector.mjs. Add a row only
 when the schema carries live data and registration is blocked (e.g.
 tenant_id length cap prevents back-registration).';


--
-- Name: tenant_security_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_security_policy (
    tenant_id character varying(64) NOT NULL,
    mfa_required boolean DEFAULT false NOT NULL,
    mfa_channel character varying(16) DEFAULT 'email'::character varying NOT NULL,
    mfa_otp_ttl_sec integer DEFAULT 300 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(128)
);


--
-- Name: tenant_settings; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_settings (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT tenant_settings_id_not_null1 NOT NULL,
    key character varying(500) NOT NULL,
    value text,
    scope character varying(20) DEFAULT 'tenant'::character varying NOT NULL,
    product_key character varying(128),
    module_code character varying(128),
    workspace_id text,
    owner_user_id text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_settings_legacy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenant_settings_legacy (
    id integer CONSTRAINT tenant_settings_id_not_null NOT NULL,
    tenant_id character varying(16) CONSTRAINT tenant_settings_tenant_id_not_null NOT NULL,
    setting_key character varying(200) CONSTRAINT tenant_settings_setting_key_not_null NOT NULL,
    setting_value jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: tenant_settings_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.tenant_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.tenant_settings_id_seq OWNED BY dos.tenant_settings_legacy.id;


--
-- Name: tenants; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.tenants (
    tenant_id character varying(64) NOT NULL,
    tenant_code character varying(50) NOT NULL,
    tenant_name character varying(255),
    schema_name character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    settings jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: training_courses; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.training_courses (
    course_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    description text,
    category text,
    status text DEFAULT 'active'::text,
    duration_min integer,
    is_mandatory boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: training_enrollments; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.training_enrollments (
    enrollment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    course_id uuid,
    user_id text NOT NULL,
    status text DEFAULT 'enrolled'::text,
    progress integer DEFAULT 0,
    completed_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: training_programs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.training_programs (
    program_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    title text NOT NULL,
    description text,
    category character varying(100),
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    mandatory boolean DEFAULT false,
    due_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: ui_admin_activity_log; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_admin_activity_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    actor_id character varying(64) NOT NULL,
    action_code character varying(150) NOT NULL,
    target_kind dos.ui_target_kind_t,
    target_id character varying(150),
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_admin_activity_log; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_admin_activity_log IS 'UI-OS §16 — append-only admin action audit (actor_id, action_code, target).';


--
-- Name: ui_carbon_components; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_carbon_components (
    carbon_key character varying(80) NOT NULL,
    package_name character varying(120) DEFAULT 'carbon-components-angular'::character varying NOT NULL,
    package_version character varying(40) DEFAULT '5.69.0'::character varying NOT NULL,
    category character varying(40) DEFAULT 'component'::character varying NOT NULL,
    is_experimental boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    source_component_name character varying(120),
    integration_mode character varying(40) DEFAULT 'native-angular'::character varying NOT NULL,
    runtime_status character varying(40) DEFAULT 'active'::character varying NOT NULL,
    angular_native boolean DEFAULT true NOT NULL,
    wrapper_required boolean DEFAULT true NOT NULL,
    stability character varying(20) DEFAULT 'stable'::character varying NOT NULL,
    dynamic_ui_allowed boolean DEFAULT true NOT NULL,
    notes text,
    vendor character varying(40) DEFAULT 'ibm-carbon'::character varying NOT NULL,
    CONSTRAINT ui_carbon_components_category_check CHECK (((category)::text = ANY ((ARRAY['component'::character varying, 'primitive'::character varying, 'layout'::character varying, 'utility'::character varying, 'experimental'::character varying, 'shell'::character varying, 'chart'::character varying, 'ai'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_integration_mode_check CHECK (((integration_mode)::text = ANY ((ARRAY['native-angular'::character varying, 'angular-chart'::character varying, 'web-component-wrapper'::character varying, 'asset-package'::character varying, 'react-only-reference'::character varying, 'deprecated-alias'::character varying, 'unavailable'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_runtime_status_check CHECK (((runtime_status)::text = ANY ((ARRAY['active'::character varying, 'wrapper-required'::character varying, 'catalog-only'::character varying, 'blocked-react-only'::character varying, 'deprecated'::character varying, 'experimental'::character varying, 'missing-upstream-angular-binding'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_stability_check CHECK (((stability)::text = ANY ((ARRAY['stable'::character varying, 'canary'::character varying, 'experimental'::character varying, 'deprecated'::character varying, 'beta'::character varying])::text[]))),
    CONSTRAINT ui_carbon_components_vendor_check CHECK (((vendor)::text = 'ibm-carbon'::text))
);


--
-- Name: ui_dos_component_carbon_map; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_dos_component_carbon_map (
    dos_component_key text NOT NULL,
    carbon_key character varying NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_draft_versions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_draft_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    target_kind dos.ui_target_kind_t NOT NULL,
    target_id character varying(150) NOT NULL,
    version character varying(40) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    author_id character varying(64) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_draft_versions; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_draft_versions IS 'UI-OS §16 — author-owned drafts pending publish; multiple drafts per target via version key.';


--
-- Name: ui_module_nav_group; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_group (
    module_code text NOT NULL,
    group_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_key text,
    label_en text,
    label_ar text,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_group; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_group IS 'Phase F-F10 layer 3.a: ordered groups (sidebar sections) per module. Groups themselves have sort_order; items reference (module_code, group_id).';


--
-- Name: ui_module_nav_item; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_item (
    module_code text NOT NULL,
    item_id text NOT NULL,
    group_id text,
    sort_order integer DEFAULT 0 NOT NULL,
    route text NOT NULL,
    icon text,
    permission text,
    label_key text,
    label_en text,
    label_ar text,
    badge text,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_item; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_item IS 'Phase F-F10 layer 3.b: ordered items per module. Items optionally belong to a group; both groups and items have explicit sort_order.';


--
-- Name: ui_module_nav_override_tenant; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_override_tenant (
    tenant_id text NOT NULL,
    module_code text NOT NULL,
    item_id text NOT NULL,
    sort_order integer,
    enabled boolean,
    label_en text,
    label_ar text,
    badge text,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_override_tenant; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_override_tenant IS 'Phase F-F10 layer 4: per-tenant sparse override. Each non-NULL column wins over the module default; NULL columns inherit.';


--
-- Name: ui_module_nav_override_user; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_module_nav_override_user (
    user_id text NOT NULL,
    module_code text NOT NULL,
    item_id text NOT NULL,
    sort_order integer,
    enabled boolean,
    pinned boolean,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_module_nav_override_user; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_module_nav_override_user IS 'Phase F-F10 layer 5: per-user sparse override + pin. Wins over tenant override.';


--
-- Name: ui_override_module; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_module (
    module_code text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_module; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_module IS 'Phase F-F9 layer 3: per-module UI patch (e.g. compliance, risk, foundation, platform-admin). Sparse jsonb merged after product, before route.';


--
-- Name: ui_override_product; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_product (
    product_code text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_product; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_product IS 'Phase F-F9 layer 2: per-product UI patch (e.g. shahin-ai, doganhub). Sparse jsonb merged after workspace defaults, before module layer.';


--
-- Name: COLUMN ui_override_product.patch; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON COLUMN dos.ui_override_product.patch IS 'Sparse jsonb. Object keys replace; arrays REPLACE in full.';


--
-- Name: ui_override_tenant; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_tenant (
    tenant_id text NOT NULL,
    route text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_tenant; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_tenant IS 'Phase F-F9 layer 5: per-tenant UI patch. Two rows resolved in order: (tenant_id, ''*'') then (tenant_id, route) — both deep-merged after the route layer, with the specific row winning.';


--
-- Name: ui_override_user; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_override_user (
    user_id text NOT NULL,
    route text NOT NULL,
    patch jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_override_user; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_override_user IS 'Phase F-F9 layer 6: per-user UI patch. Final, narrowest layer — deep-merged after the tenant layer.';


--
-- Name: ui_published_versions; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_published_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    target_kind dos.ui_target_kind_t NOT NULL,
    target_id character varying(150) NOT NULL,
    version character varying(40) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    published_by character varying(64) NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    is_current boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE ui_published_versions; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_published_versions IS 'UI-OS §16 — current/historical published payloads per (target_kind,target_id,version). DKNF via dos.ui_target_kind_t.';


--
-- Name: ui_rollback_points; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_rollback_points (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(64) NOT NULL,
    target_kind dos.ui_target_kind_t NOT NULL,
    target_id character varying(150) NOT NULL,
    version character varying(40) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    reason text,
    created_by character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ui_rollback_points; Type: COMMENT; Schema: dos; Owner: -
--

COMMENT ON TABLE dos.ui_rollback_points IS 'UI-OS §16 — explicit restore-points captured before risky publishes; supports rollback flows.';


--
-- Name: ui_route_agent_flow_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_agent_flow_step (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    step_id text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    step_type text,
    agent_id text,
    status text,
    evidence_uri text
);


--
-- Name: ui_route_agent_flow_step_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_agent_flow_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_agent_flow_step_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_agent_flow_step_id_seq OWNED BY dos.ui_route_agent_flow_step.id;


--
-- Name: ui_route_agent_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_agent_registry (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    agent_id text NOT NULL,
    name_en text NOT NULL,
    name_ar text,
    agent_type text,
    capability text,
    status text,
    owner text,
    ai_model text
);


--
-- Name: ui_route_agent_registry_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_agent_registry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_agent_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_agent_registry_id_seq OWNED BY dos.ui_route_agent_registry.id;


--
-- Name: ui_route_audit_evidence_artifact; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_audit_evidence_artifact (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    artifact_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    artifact_type text,
    hash text,
    collected_at timestamp with time zone NOT NULL,
    collected_by text,
    download_url text
);


--
-- Name: ui_route_audit_evidence_artifact_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_audit_evidence_artifact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_audit_evidence_artifact_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_audit_evidence_artifact_id_seq OWNED BY dos.ui_route_audit_evidence_artifact.id;


--
-- Name: ui_route_audit_ledger_row; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_audit_ledger_row (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    ledger_id text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    actor text NOT NULL,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    prev_hash text,
    hash text NOT NULL,
    decision_ref text
);


--
-- Name: ui_route_audit_ledger_row_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_audit_ledger_row_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_audit_ledger_row_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_audit_ledger_row_id_seq OWNED BY dos.ui_route_audit_ledger_row.id;


--
-- Name: ui_route_calendar_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_calendar_event (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    event_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    category text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    status text,
    severity text,
    link text
);


--
-- Name: ui_route_calendar_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_calendar_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_calendar_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_calendar_event_id_seq OWNED BY dos.ui_route_calendar_event.id;


--
-- Name: ui_route_case_finalization; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_case_finalization (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    case_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    case_type text,
    origin_ref text,
    decision text,
    decision_owner text,
    decision_at timestamp with time zone,
    signoff_status text,
    evidence_uri text,
    rationale_en text,
    rationale_ar text,
    next_review_at date,
    status text,
    CONSTRAINT chk_case_finalization_decision CHECK (((decision IS NULL) OR (decision = ANY (ARRAY['approve'::text, 'reject'::text, 'accept-risk'::text, 'escalate'::text, 'defer'::text])))),
    CONSTRAINT chk_case_finalization_signoff CHECK (((signoff_status IS NULL) OR (signoff_status = ANY (ARRAY['pending'::text, 'partial'::text, 'complete'::text, 'rejected'::text])))),
    CONSTRAINT chk_case_finalization_status CHECK (((status IS NULL) OR (status = ANY (ARRAY['open'::text, 'in-review'::text, 'finalized'::text, 'reopened'::text]))))
);


--
-- Name: ui_route_case_finalization_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_case_finalization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_case_finalization_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_case_finalization_id_seq OWNED BY dos.ui_route_case_finalization.id;


--
-- Name: ui_route_column; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_column (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    field_key text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    type text,
    sortable boolean DEFAULT false NOT NULL
);


--
-- Name: ui_route_column_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_column_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_column_id_seq OWNED BY dos.ui_route_column.id;


--
-- Name: ui_route_delegation_rule; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_delegation_rule (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    rule_id text NOT NULL,
    delegator text NOT NULL,
    delegate text NOT NULL,
    scope text NOT NULL,
    permission text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    status text
);


--
-- Name: ui_route_delegation_rule_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_delegation_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_delegation_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_delegation_rule_id_seq OWNED BY dos.ui_route_delegation_rule.id;


--
-- Name: ui_route_export_artifact; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_export_artifact (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    artifact_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    format text NOT NULL,
    status text NOT NULL,
    size_kb integer,
    download_url text,
    generated_at timestamp with time zone,
    CONSTRAINT chk_export_format CHECK ((format = ANY (ARRAY['pdf'::text, 'csv'::text, 'xlsx'::text, 'json'::text]))),
    CONSTRAINT chk_export_status CHECK ((status = ANY (ARRAY['ready'::text, 'generating'::text, 'failed'::text])))
);


--
-- Name: ui_route_export_artifact_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_export_artifact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_export_artifact_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_export_artifact_id_seq OWNED BY dos.ui_route_export_artifact.id;


--
-- Name: ui_route_follow_up_item; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_follow_up_item (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    item_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    origin_ref text,
    owner text,
    due_at timestamp with time zone,
    status text,
    severity text,
    ai_score integer
);


--
-- Name: ui_route_follow_up_item_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_follow_up_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_follow_up_item_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_follow_up_item_id_seq OWNED BY dos.ui_route_follow_up_item.id;


--
-- Name: ui_route_heatmap_axis; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_heatmap_axis (
    id bigint NOT NULL,
    route text NOT NULL,
    axis text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    bucket_key text,
    CONSTRAINT ui_route_heatmap_axis_axis_check CHECK ((axis = ANY (ARRAY['x'::text, 'y'::text])))
);


--
-- Name: ui_route_heatmap_axis_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_heatmap_axis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_heatmap_axis_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_heatmap_axis_id_seq OWNED BY dos.ui_route_heatmap_axis.id;


--
-- Name: ui_route_incident_communication; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_incident_communication (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    comm_id text NOT NULL,
    channel text NOT NULL,
    audience text NOT NULL,
    sent_at timestamp with time zone NOT NULL,
    message_en text NOT NULL,
    message_ar text
);


--
-- Name: ui_route_incident_communication_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_incident_communication_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_incident_communication_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_incident_communication_id_seq OWNED BY dos.ui_route_incident_communication.id;


--
-- Name: ui_route_incident_runbook_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_incident_runbook_step (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    step_id text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    phase text,
    owner text,
    due_at timestamp with time zone,
    status text,
    evidence_uri text
);


--
-- Name: ui_route_incident_runbook_step_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_incident_runbook_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_incident_runbook_step_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_incident_runbook_step_id_seq OWNED BY dos.ui_route_incident_runbook_step.id;


--
-- Name: ui_route_kpi; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_kpi (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    source_path text,
    format text,
    ai_insight text,
    status text,
    link text
);


--
-- Name: ui_route_kpi_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_kpi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_kpi_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_kpi_id_seq OWNED BY dos.ui_route_kpi.id;


--
-- Name: ui_route_nba; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_nba (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    description text,
    ai_score integer,
    target_route text,
    permission text,
    severity text
);


--
-- Name: ui_route_nba_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_nba_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_nba_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_nba_id_seq OWNED BY dos.ui_route_nba.id;


--
-- Name: ui_route_org_chart_node; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_org_chart_node (
    id bigint NOT NULL,
    route text NOT NULL,
    node_id text NOT NULL,
    parent_id text,
    sort_order integer DEFAULT 0 NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    role text,
    owner text,
    badge text
);


--
-- Name: ui_route_org_chart_node_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_org_chart_node_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_org_chart_node_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_org_chart_node_id_seq OWNED BY dos.ui_route_org_chart_node.id;


--
-- Name: ui_route_ownership_edge; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_ownership_edge (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    edge_id text NOT NULL,
    entity_id text NOT NULL,
    entity_label text NOT NULL,
    owner text NOT NULL,
    ownership_role text NOT NULL,
    effective_from date,
    effective_to date,
    CONSTRAINT chk_ownership_role CHECK ((ownership_role = ANY (ARRAY['accountable'::text, 'responsible'::text, 'consulted'::text, 'informed'::text, 'custodian'::text, 'approver'::text, 'reviewer'::text, 'executor'::text, 'observer'::text])))
);


--
-- Name: ui_route_ownership_edge_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_ownership_edge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_ownership_edge_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_ownership_edge_id_seq OWNED BY dos.ui_route_ownership_edge.id;


--
-- Name: ui_route_report_card; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_report_card (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    report_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    description text,
    status text DEFAULT 'ready'::text NOT NULL,
    tag text,
    ai_generated boolean DEFAULT false NOT NULL,
    download_url text
);


--
-- Name: ui_route_report_card_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_report_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_report_card_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_report_card_id_seq OWNED BY dos.ui_route_report_card.id;


--
-- Name: ui_route_roadmap_milestone; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_roadmap_milestone (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    milestone_id text NOT NULL,
    title_en text NOT NULL,
    title_ar text,
    description text,
    target_date date,
    progress integer DEFAULT 0 NOT NULL,
    status text,
    owner text,
    CONSTRAINT chk_roadmap_progress CHECK (((progress >= 0) AND (progress <= 100)))
);


--
-- Name: ui_route_roadmap_milestone_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_roadmap_milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_roadmap_milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_roadmap_milestone_id_seq OWNED BY dos.ui_route_roadmap_milestone.id;


--
-- Name: ui_route_setting_section; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_setting_section (
    id bigint NOT NULL,
    route text NOT NULL,
    section_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    icon text
);


--
-- Name: ui_route_setting_section_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_setting_section_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_setting_section_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_setting_section_id_seq OWNED BY dos.ui_route_setting_section.id;


--
-- Name: ui_route_tab; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_tab (
    id bigint NOT NULL,
    route text NOT NULL,
    tab_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    permission text
);


--
-- Name: ui_route_tab_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_tab_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_tab_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_tab_id_seq OWNED BY dos.ui_route_tab.id;


--
-- Name: ui_route_workflow_timeline_step; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_workflow_timeline_step (
    id bigint NOT NULL,
    route text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    step_id text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    state text NOT NULL,
    description text,
    occurred_at timestamp with time zone,
    actor text,
    CONSTRAINT chk_wf_timeline_state CHECK ((state = ANY (ARRAY['complete'::text, 'current'::text, 'incomplete'::text, 'invalid'::text, 'disabled'::text])))
);


--
-- Name: ui_route_workflow_timeline_step_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_workflow_timeline_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_workflow_timeline_step_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_workflow_timeline_step_id_seq OWNED BY dos.ui_route_workflow_timeline_step.id;


--
-- Name: ui_route_workqueue_group; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_route_workqueue_group (
    id bigint NOT NULL,
    route text NOT NULL,
    group_id text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    urgency text,
    filter_expr jsonb
);


--
-- Name: ui_route_workqueue_group_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.ui_route_workqueue_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ui_route_workqueue_group_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.ui_route_workqueue_group_id_seq OWNED BY dos.ui_route_workqueue_group.id;


--
-- Name: ui_service_registry; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_service_registry (
    service_code character varying(80) NOT NULL,
    display_name character varying(200) NOT NULL,
    module_code character varying(100),
    port integer NOT NULL,
    gateway_prefix character varying(120),
    cwd character varying(300) NOT NULL,
    wave integer,
    registry_status character varying(40) DEFAULT 'active'::character varying NOT NULL,
    health_path character varying(120) DEFAULT '/health'::character varying NOT NULL,
    manifest_path character varying(120) DEFAULT '/manifest'::character varying NOT NULL,
    admin_route character varying(300),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ui_service_registry_registry_status_check CHECK (((registry_status)::text = ANY ((ARRAY['active'::character varying, 'blocked'::character varying, 'deprecated'::character varying, 'draft'::character varying])::text[])))
);


--
-- Name: ui_service_registry_prefixes; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_service_registry_prefixes (
    service_code character varying(80) NOT NULL,
    prefix character varying(120) NOT NULL,
    is_primary boolean DEFAULT false NOT NULL
);


--
-- Name: ui_workspace_banner; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_banner (
    tenant_id character varying(64) NOT NULL,
    banner_id text NOT NULL,
    gate text DEFAULT 'always'::text NOT NULL,
    kind text DEFAULT 'info'::text NOT NULL,
    title_key text,
    title_fallback text,
    message_key text,
    message_fallback text,
    action_label_key text,
    action_json jsonb,
    dismissible boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ui_workspace_banner_kind_check CHECK ((kind = ANY (ARRAY['info'::text, 'warning'::text, 'error'::text, 'success'::text, 'danger'::text])))
);


--
-- Name: ui_workspace_chrome; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_chrome (
    tenant_id character varying(64) NOT NULL,
    chrome_key text NOT NULL,
    value_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_workspace_policy; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_policy (
    tenant_id character varying(64) NOT NULL,
    policy_key text NOT NULL,
    value_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ui_workspace_shortcut; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.ui_workspace_shortcut (
    tenant_id character varying(64) NOT NULL,
    shortcut_id text NOT NULL,
    combo text NOT NULL,
    action_json jsonb NOT NULL,
    when_clause text,
    sort_order integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_access_profiles; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.user_access_profiles AS
 SELECT id,
    user_id,
    profile_id,
    tenant_id,
    granted_at,
    granted_by
   FROM platform_dauth.user_access_profiles_legacy;


--
-- Name: user_org_scope; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.user_org_scope (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    scope_type text NOT NULL,
    scope_id text NOT NULL,
    role text,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_org_scope_scope_type_check CHECK ((scope_type = ANY (ARRAY['business_unit'::text, 'department'::text, 'team'::text, 'location'::text, 'position'::text, 'organization'::text])))
);


--
-- Name: user_role_assignments; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.user_role_assignments AS
 SELECT assignment_id,
    tenant_id,
    user_id,
    role_code,
    scope,
    granted_by,
    granted_at,
    expires_at,
    revoked_at,
    revoked_by,
    is_active
   FROM platform_dauth.user_role_assignments;


--
-- Name: user_roles; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.user_roles (
    user_id uuid NOT NULL,
    role_code character varying(100) NOT NULL,
    tenant_id uuid,
    scope character varying(30) DEFAULT 'org'::character varying,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    granted_by uuid
);


--
-- Name: users; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.users (
    user_id character varying(64) NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    tenant_id character varying(64),
    role character varying(100),
    department_id character varying(64),
    deleted_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now(),
    onboarding_complete boolean DEFAULT false,
    member_onboarded boolean DEFAULT false,
    platform_role character varying(100),
    last_login timestamp with time zone,
    full_name character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    password_hash text,
    must_change_password boolean DEFAULT false,
    password_changed_at timestamp with time zone,
    login_count integer DEFAULT 0,
    email_verified boolean DEFAULT false,
    email_verified_at timestamp with time zone,
    sso_provider text,
    sso_protocol text
);


--
-- Name: v_foundation_entities; Type: VIEW; Schema: dos; Owner: -
--

CREATE VIEW dos.v_foundation_entities AS
 SELECT (u.tenant_id)::text AS tenant_id,
    'user'::text AS entity_type,
    (u.user_id)::text AS entity_id,
    COALESCE(u.full_name, u.display_name, u.email, u.user_id) AS label
   FROM dos.users u
UNION ALL
 SELECT (d.tenant_id)::text AS tenant_id,
    'department'::text AS entity_type,
    (d.department_id)::text AS entity_id,
    COALESCE(d.display_name, d.department_code, d.department_id) AS label
   FROM dos.departments d
UNION ALL
 SELECT (t.tenant_id)::text AS tenant_id,
    'team'::text AS entity_type,
    (t.team_id)::text AS entity_id,
    COALESCE(t.display_name, t.team_code, t.team_id) AS label
   FROM dos.teams t
UNION ALL
 SELECT (l.tenant_id)::text AS tenant_id,
    'location'::text AS entity_type,
    (l.location_id)::text AS entity_id,
    COALESCE(l.name_en, l.code, (l.location_id)::text) AS label
   FROM dos.locations l
UNION ALL
 SELECT (b.tenant_id)::text AS tenant_id,
    'business_unit'::text AS entity_type,
    (b.bu_id)::text AS entity_id,
    COALESCE(b.name_en, b.code, (b.bu_id)::text) AS label
   FROM dos.business_units b;


--
-- Name: vendor_risk_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.vendor_risk_event (
    id bigint NOT NULL,
    record_id uuid,
    record_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendor_risk_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.vendor_risk_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_risk_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.vendor_risk_event_id_seq OWNED BY dos.vendor_risk_event.id;


--
-- Name: vendor_risk_record; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.vendor_risk_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT vendor_risk_record_kind_check CHECK ((kind = ANY (ARRAY['critical'::text, 'elevated'::text, 'standard'::text, 'baseline'::text]))),
    CONSTRAINT vendor_risk_record_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT vendor_risk_record_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: vendors; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.vendors (
    vendor_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(16) NOT NULL,
    name text NOT NULL,
    category character varying(100),
    tier character varying(20) DEFAULT 'standard'::character varying,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    contact_email character varying(255),
    contact_phone character varying(50),
    risk_rating character varying(20),
    last_assessment_date date,
    contract_expiry date,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: widgets; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.widgets (
    widget_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    dashboard_id uuid,
    title text NOT NULL,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    "position" jsonb DEFAULT '{}'::jsonb,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: work_items; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.work_items (
    work_item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    source character varying(50) DEFAULT 'workflow_tasks'::character varying NOT NULL,
    source_id uuid,
    title text NOT NULL,
    description text,
    task_type character varying(100),
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    assigned_to text,
    due_date timestamp with time zone,
    entity_type character varying(100),
    entity_id uuid,
    context jsonb DEFAULT '{}'::jsonb,
    completed_at timestamp with time zone,
    completed_by text,
    is_deleted boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_approvals; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_approvals (
    approval_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workflow_instance_id uuid,
    subject text,
    status text DEFAULT 'pending'::text,
    requested_by text NOT NULL,
    approvers jsonb DEFAULT '[]'::jsonb,
    approved_by text,
    rejected_by text,
    escalated_by text,
    escalated_to text,
    comment text,
    reject_reason text,
    escalation_reason text,
    context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


--
-- Name: workflow_definition; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_definition (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    kind text NOT NULL,
    trust_zone text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    definition jsonb NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT workflow_definition_kind_check CHECK ((kind = ANY (ARRAY['approval'::text, 'provisioning'::text, 'review'::text, 'remediation'::text, 'attestation'::text, 'generic'::text]))),
    CONSTRAINT workflow_definition_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'retired'::text]))),
    CONSTRAINT workflow_definition_trust_zone_check CHECK ((trust_zone = ANY (ARRAY['public'::text, 'tenant'::text, 'admin'::text])))
);


--
-- Name: workflow_event; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_event (
    id bigint NOT NULL,
    instance_id uuid,
    workflow_key text,
    kind text NOT NULL,
    payload jsonb,
    emitted_by text NOT NULL,
    emitted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_event_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workflow_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_event_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workflow_event_id_seq OWNED BY dos.workflow_event.id;


--
-- Name: workflow_instance; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_instance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_id uuid NOT NULL,
    tenant_id uuid,
    initiated_by text NOT NULL,
    status text DEFAULT 'running'::text NOT NULL,
    current_step text,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    error text,
    correlation_id text,
    CONSTRAINT workflow_instance_status_check CHECK ((status = ANY (ARRAY['running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text, 'suspended'::text])))
);


--
-- Name: workflow_instances; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_instances (
    instance_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workflow_type text NOT NULL,
    name text,
    status text DEFAULT 'pending'::text NOT NULL,
    current_step text,
    total_steps integer DEFAULT 0,
    created_by text,
    entity_type text,
    entity_id text,
    context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancel_reason text
);


--
-- Name: workflow_schedules; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_schedules (
    schedule_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    cron_expression text NOT NULL,
    workflow_template_id uuid,
    enabled boolean DEFAULT true,
    config jsonb DEFAULT '{}'::jsonb,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: workflow_sla_configs; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_sla_configs (
    sla_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    workflow_type text NOT NULL,
    name text NOT NULL,
    max_duration_hours integer DEFAULT 72 NOT NULL,
    escalation_rules jsonb DEFAULT '[]'::jsonb,
    enabled boolean DEFAULT true,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: workflow_step_run; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_step_run (
    id bigint NOT NULL,
    instance_id uuid NOT NULL,
    step_id text NOT NULL,
    step_kind text NOT NULL,
    status text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    input jsonb,
    output jsonb,
    error text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    CONSTRAINT workflow_step_run_status_check CHECK ((status = ANY (ARRAY['started'::text, 'completed'::text, 'failed'::text, 'skipped'::text, 'timed-out'::text, 'rolled-back'::text])))
);


--
-- Name: workflow_step_run_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workflow_step_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_step_run_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workflow_step_run_id_seq OWNED BY dos.workflow_step_run.id;


--
-- Name: workflow_tasks; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_tasks (
    task_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    instance_id uuid,
    task_type text,
    title text NOT NULL,
    description text,
    status text DEFAULT 'pending'::text NOT NULL,
    assigned_to text,
    assigned_by text,
    completed_by text,
    outcome text,
    notes text,
    due_at timestamp with time zone,
    context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


--
-- Name: workflow_templates; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workflow_templates (
    template_id character varying(64) NOT NULL,
    template_code character varying(100) NOT NULL,
    module_code character varying(50),
    display_name character varying(255),
    definition jsonb NOT NULL,
    version integer DEFAULT 1,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    tenant_id character varying(64),
    name character varying(255),
    description text,
    category character varying(100),
    parameters_schema jsonb,
    is_active boolean DEFAULT true,
    created_by character varying(64),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: workspace_config; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    config_key character varying(500) NOT NULL,
    config_value jsonb DEFAULT '{}'::jsonb NOT NULL,
    scope character varying(30) DEFAULT 'workspace'::character varying NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_shell_binding_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workspace_shell_binding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspace_shell_binding_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workspace_shell_binding_id_seq OWNED BY dos.workspace_shell_binding.id;


--
-- Name: workspace_shell_i18n; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_shell_i18n (
    id bigint NOT NULL,
    ns text NOT NULL,
    key text NOT NULL,
    locale text NOT NULL,
    value text NOT NULL,
    module_code text DEFAULT 'workspace-shell'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_shell_i18n_locale_check CHECK ((locale = ANY (ARRAY['en'::text, 'ar'::text])))
);


--
-- Name: workspace_shell_i18n_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workspace_shell_i18n_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspace_shell_i18n_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workspace_shell_i18n_id_seq OWNED BY dos.workspace_shell_i18n.id;


--
-- Name: workspace_shell_status_label; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspace_shell_status_label (
    id bigint NOT NULL,
    catalog text NOT NULL,
    code text NOT NULL,
    label_key text NOT NULL,
    tone text NOT NULL,
    icon text,
    module_code text DEFAULT 'workspace-shell'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_shell_status_label_catalog_check CHECK ((catalog = ANY (ARRAY['tenant'::text, 'health'::text, 'sync'::text]))),
    CONSTRAINT workspace_shell_status_label_tone_check CHECK ((tone = ANY (ARRAY['ok'::text, 'info'::text, 'warn'::text, 'error'::text, 'critical'::text, 'neutral'::text])))
);


--
-- Name: workspace_shell_status_label_id_seq; Type: SEQUENCE; Schema: dos; Owner: -
--

CREATE SEQUENCE dos.workspace_shell_status_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspace_shell_status_label_id_seq; Type: SEQUENCE OWNED BY; Schema: dos; Owner: -
--

ALTER SEQUENCE dos.workspace_shell_status_label_id_seq OWNED BY dos.workspace_shell_status_label.id;


--
-- Name: workspaces; Type: TABLE; Schema: dos; Owner: -
--

CREATE TABLE dos.workspaces (
    workspace_id character varying(64) NOT NULL,
    tenant_id character varying(16) NOT NULL,
    workspace_name character varying(255),
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_event ALTER COLUMN id SET DEFAULT nextval('dos.ai_event_id_seq'::regclass);


--
-- Name: audit_signoff_ledger bundle_id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_signoff_ledger ALTER COLUMN bundle_id SET DEFAULT nextval('dos.audit_signoff_ledger_bundle_id_seq'::regclass);


--
-- Name: billing_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.billing_event ALTER COLUMN id SET DEFAULT nextval('dos.billing_event_id_seq'::regclass);


--
-- Name: config_audit_logs id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_audit_logs ALTER COLUMN id SET DEFAULT nextval('dos.config_audit_logs_id_seq'::regclass);


--
-- Name: config_definitions id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_definitions ALTER COLUMN id SET DEFAULT nextval('dos.config_definitions_id_seq'::regclass);


--
-- Name: config_locks id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_locks ALTER COLUMN id SET DEFAULT nextval('dos.config_locks_id_seq'::regclass);


--
-- Name: config_runtime_overrides id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_runtime_overrides ALTER COLUMN id SET DEFAULT nextval('dos.config_runtime_overrides_id_seq'::regclass);


--
-- Name: config_values id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_values ALTER COLUMN id SET DEFAULT nextval('dos.config_values_id_seq'::regclass);


--
-- Name: data_governance_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.data_governance_event ALTER COLUMN id SET DEFAULT nextval('dos.data_governance_event_id_seq'::regclass);


--
-- Name: deployment_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.deployment_event ALTER COLUMN id SET DEFAULT nextval('dos.deployment_event_id_seq'::regclass);


--
-- Name: dos_master_drift_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_drift_event ALTER COLUMN id SET DEFAULT nextval('dos.dos_master_drift_event_id_seq'::regclass);


--
-- Name: dos_master_invalidation_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_invalidation_log ALTER COLUMN id SET DEFAULT nextval('dos.dos_master_invalidation_log_id_seq'::regclass);


--
-- Name: dos_master_writer_audit id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_writer_audit ALTER COLUMN id SET DEFAULT nextval('dos.dos_master_writer_audit_id_seq'::regclass);


--
-- Name: dr_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_event ALTER COLUMN id SET DEFAULT nextval('dos.dr_event_id_seq'::regclass);


--
-- Name: feature_flag_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flag_event ALTER COLUMN id SET DEFAULT nextval('dos.feature_flag_event_id_seq'::regclass);


--
-- Name: i18n_fallback_values id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.i18n_fallback_values ALTER COLUMN id SET DEFAULT nextval('dos.i18n_fallback_values_id_seq'::regclass);


--
-- Name: integration_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integration_event ALTER COLUMN id SET DEFAULT nextval('dos.integration_event_id_seq'::regclass);


--
-- Name: marketing_brand_assets id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_brand_assets ALTER COLUMN id SET DEFAULT nextval('dos.marketing_brand_assets_id_seq'::regclass);


--
-- Name: marketing_download_events id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_download_events ALTER COLUMN id SET DEFAULT nextval('dos.marketing_download_events_id_seq'::regclass);


--
-- Name: marketplace_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketplace_event ALTER COLUMN id SET DEFAULT nextval('dos.marketplace_event_id_seq'::regclass);


--
-- Name: migration_history id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.migration_history ALTER COLUMN id SET DEFAULT nextval('dos.migration_history_id_seq'::regclass);


--
-- Name: module_contract_errors id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_contract_errors ALTER COLUMN id SET DEFAULT nextval('dos.module_contract_errors_id_seq'::regclass);


--
-- Name: module_contract_publish_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_contract_publish_log ALTER COLUMN id SET DEFAULT nextval('dos.module_contract_publish_log_id_seq'::regclass);


--
-- Name: module_sla_defaults id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_sla_defaults ALTER COLUMN id SET DEFAULT nextval('dos.module_sla_defaults_id_seq'::regclass);


--
-- Name: navigation_registry id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.navigation_registry ALTER COLUMN id SET DEFAULT nextval('dos.navigation_registry_id_seq'::regclass);


--
-- Name: notification_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.notification_event ALTER COLUMN id SET DEFAULT nextval('dos.notification_event_id_seq'::regclass);


--
-- Name: orphan_schema_audit id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.orphan_schema_audit ALTER COLUMN id SET DEFAULT nextval('dos.orphan_schema_audit_id_seq'::regclass);


--
-- Name: platform_audit_logs id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_audit_logs ALTER COLUMN id SET DEFAULT nextval('dos.platform_audit_logs_id_seq'::regclass);


--
-- Name: platform_drift_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_drift_log ALTER COLUMN id SET DEFAULT nextval('dos.platform_drift_log_id_seq'::regclass);


--
-- Name: platform_operation_config id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_operation_config ALTER COLUMN id SET DEFAULT nextval('dos.platform_operation_config_id_seq'::regclass);


--
-- Name: platform_secret secret_id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_secret ALTER COLUMN secret_id SET DEFAULT nextval('dos.platform_secret_secret_id_seq'::regclass);


--
-- Name: platform_slo_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_slo_event ALTER COLUMN id SET DEFAULT nextval('dos.platform_slo_event_id_seq'::regclass);


--
-- Name: release_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.release_event ALTER COLUMN id SET DEFAULT nextval('dos.release_event_id_seq'::regclass);


--
-- Name: role_profile_sync_log id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.role_profile_sync_log ALTER COLUMN id SET DEFAULT nextval('dos.role_profile_sync_log_id_seq'::regclass);


--
-- Name: rollout_evaluation id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_evaluation ALTER COLUMN id SET DEFAULT nextval('dos.rollout_evaluation_id_seq'::regclass);


--
-- Name: runtime_config_history id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.runtime_config_history ALTER COLUMN id SET DEFAULT nextval('dos.runtime_config_history_id_seq'::regclass);


--
-- Name: schema_authoring_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_authoring_event ALTER COLUMN id SET DEFAULT nextval('dos.schema_authoring_event_id_seq'::regclass);


--
-- Name: schema_migrations id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_migrations ALTER COLUMN id SET DEFAULT nextval('dos.schema_migrations_id_seq'::regclass);


--
-- Name: security_secret_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.security_secret_event ALTER COLUMN id SET DEFAULT nextval('dos.security_secret_event_id_seq'::regclass);


--
-- Name: system_events id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.system_events ALTER COLUMN id SET DEFAULT nextval('dos.system_events_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.team_members ALTER COLUMN id SET DEFAULT nextval('dos.team_members_id_seq'::regclass);


--
-- Name: telemetry_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.telemetry_event ALTER COLUMN id SET DEFAULT nextval('dos.telemetry_event_id_seq'::regclass);


--
-- Name: tenant_config_versions_legacy id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_config_versions_legacy ALTER COLUMN id SET DEFAULT nextval('dos.tenant_config_versions_id_seq'::regclass);


--
-- Name: tenant_feature_flag_overrides id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_feature_flag_overrides ALTER COLUMN id SET DEFAULT nextval('dos.tenant_feature_flag_overrides_id_seq'::regclass);


--
-- Name: tenant_landing_config id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_landing_config ALTER COLUMN id SET DEFAULT nextval('dos.tenant_landing_config_id_seq'::regclass);


--
-- Name: tenant_memberships id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_memberships ALTER COLUMN id SET DEFAULT nextval('dos.tenant_memberships_id_seq'::regclass);


--
-- Name: tenant_product_activation id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_product_activation ALTER COLUMN id SET DEFAULT nextval('dos.tenant_product_activation_id_seq'::regclass);


--
-- Name: tenant_settings_legacy id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_settings_legacy ALTER COLUMN id SET DEFAULT nextval('dos.tenant_settings_id_seq'::regclass);


--
-- Name: ui_route_agent_flow_step id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_flow_step ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_agent_flow_step_id_seq'::regclass);


--
-- Name: ui_route_agent_registry id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_registry ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_agent_registry_id_seq'::regclass);


--
-- Name: ui_route_audit_evidence_artifact id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_evidence_artifact ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_audit_evidence_artifact_id_seq'::regclass);


--
-- Name: ui_route_audit_ledger_row id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_ledger_row ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_audit_ledger_row_id_seq'::regclass);


--
-- Name: ui_route_calendar_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_calendar_event ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_calendar_event_id_seq'::regclass);


--
-- Name: ui_route_case_finalization id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_case_finalization ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_case_finalization_id_seq'::regclass);


--
-- Name: ui_route_column id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_column ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_column_id_seq'::regclass);


--
-- Name: ui_route_delegation_rule id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_delegation_rule ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_delegation_rule_id_seq'::regclass);


--
-- Name: ui_route_export_artifact id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_export_artifact ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_export_artifact_id_seq'::regclass);


--
-- Name: ui_route_follow_up_item id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_follow_up_item ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_follow_up_item_id_seq'::regclass);


--
-- Name: ui_route_heatmap_axis id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_heatmap_axis ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_heatmap_axis_id_seq'::regclass);


--
-- Name: ui_route_incident_communication id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_communication ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_incident_communication_id_seq'::regclass);


--
-- Name: ui_route_incident_runbook_step id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_runbook_step ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_incident_runbook_step_id_seq'::regclass);


--
-- Name: ui_route_kpi id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_kpi ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_kpi_id_seq'::regclass);


--
-- Name: ui_route_nba id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_nba ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_nba_id_seq'::regclass);


--
-- Name: ui_route_org_chart_node id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_org_chart_node ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_org_chart_node_id_seq'::regclass);


--
-- Name: ui_route_ownership_edge id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_ownership_edge ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_ownership_edge_id_seq'::regclass);


--
-- Name: ui_route_report_card id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_report_card ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_report_card_id_seq'::regclass);


--
-- Name: ui_route_roadmap_milestone id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_roadmap_milestone ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_roadmap_milestone_id_seq'::regclass);


--
-- Name: ui_route_setting_section id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_setting_section ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_setting_section_id_seq'::regclass);


--
-- Name: ui_route_tab id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_tab ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_tab_id_seq'::regclass);


--
-- Name: ui_route_workflow_timeline_step id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workflow_timeline_step ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_workflow_timeline_step_id_seq'::regclass);


--
-- Name: ui_route_workqueue_group id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workqueue_group ALTER COLUMN id SET DEFAULT nextval('dos.ui_route_workqueue_group_id_seq'::regclass);


--
-- Name: vendor_risk_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendor_risk_event ALTER COLUMN id SET DEFAULT nextval('dos.vendor_risk_event_id_seq'::regclass);


--
-- Name: workflow_event id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_event ALTER COLUMN id SET DEFAULT nextval('dos.workflow_event_id_seq'::regclass);


--
-- Name: workflow_step_run id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_step_run ALTER COLUMN id SET DEFAULT nextval('dos.workflow_step_run_id_seq'::regclass);


--
-- Name: workspace_shell_binding id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_binding ALTER COLUMN id SET DEFAULT nextval('dos.workspace_shell_binding_id_seq'::regclass);


--
-- Name: workspace_shell_i18n id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_i18n ALTER COLUMN id SET DEFAULT nextval('dos.workspace_shell_i18n_id_seq'::regclass);


--
-- Name: workspace_shell_status_label id; Type: DEFAULT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_status_label ALTER COLUMN id SET DEFAULT nextval('dos.workspace_shell_status_label_id_seq'::regclass);


--
-- Name: access_review_items access_review_items_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.access_review_items
    ADD CONSTRAINT access_review_items_pkey PRIMARY KEY (item_id);


--
-- Name: access_reviews access_reviews_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.access_reviews
    ADD CONSTRAINT access_reviews_pkey PRIMARY KEY (review_id);


--
-- Name: action_items action_items_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.action_items
    ADD CONSTRAINT action_items_pkey PRIMARY KEY (action_id);


--
-- Name: admin_pillar_page admin_pillar_page_pillar_code_page_key_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar_page
    ADD CONSTRAINT admin_pillar_page_pillar_code_page_key_key UNIQUE (pillar_code, page_key);


--
-- Name: admin_pillar_page admin_pillar_page_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar_page
    ADD CONSTRAINT admin_pillar_page_pkey PRIMARY KEY (id);


--
-- Name: admin_pillar admin_pillar_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar
    ADD CONSTRAINT admin_pillar_pkey PRIMARY KEY (pillar_code);


--
-- Name: admin_pillar_widget admin_pillar_widget_page_id_widget_key_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar_widget
    ADD CONSTRAINT admin_pillar_widget_page_id_widget_key_key UNIQUE (page_id, widget_key);


--
-- Name: admin_pillar_widget admin_pillar_widget_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar_widget
    ADD CONSTRAINT admin_pillar_widget_pkey PRIMARY KEY (id);


--
-- Name: agent_action_receipts agent_action_receipts_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_action_receipts
    ADD CONSTRAINT agent_action_receipts_pkey PRIMARY KEY (id);


--
-- Name: agent_evidence_links agent_evidence_links_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_evidence_links
    ADD CONSTRAINT agent_evidence_links_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_memory
    ADD CONSTRAINT agent_memory_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_tenant_id_agent_id_subject_type_subject_id_mem_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_memory
    ADD CONSTRAINT agent_memory_tenant_id_agent_id_subject_type_subject_id_mem_key UNIQUE (tenant_id, agent_id, subject_type, subject_id, memory_key);


--
-- Name: agent_module_binding agent_module_binding_pk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_module_binding
    ADD CONSTRAINT agent_module_binding_pk PRIMARY KEY (agent_code, module_code);


--
-- Name: agent_recommendations agent_recommendations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_recommendations
    ADD CONSTRAINT agent_recommendations_pkey PRIMARY KEY (id);


--
-- Name: agent_registry agent_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_registry
    ADD CONSTRAINT agent_registry_pkey PRIMARY KEY (agent_code);


--
-- Name: agent_run_steps agent_run_steps_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_run_steps
    ADD CONSTRAINT agent_run_steps_pkey PRIMARY KEY (id);


--
-- Name: agent_run_steps agent_run_steps_run_id_step_index_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_run_steps
    ADD CONSTRAINT agent_run_steps_run_id_step_index_key UNIQUE (run_id, step_index);


--
-- Name: agent_runs agent_runs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_runs
    ADD CONSTRAINT agent_runs_pkey PRIMARY KEY (run_id);


--
-- Name: agrc_agent_memory agrc_agent_memory_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_agent_memory
    ADD CONSTRAINT agrc_agent_memory_pkey PRIMARY KEY (memory_id);


--
-- Name: agrc_agent_runs agrc_agent_runs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_agent_runs
    ADD CONSTRAINT agrc_agent_runs_pkey PRIMARY KEY (run_id);


--
-- Name: agrc_cycles agrc_cycles_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_cycles
    ADD CONSTRAINT agrc_cycles_pkey PRIMARY KEY (cycle_id);


--
-- Name: agrc_discoveries agrc_discoveries_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_discoveries
    ADD CONSTRAINT agrc_discoveries_pkey PRIMARY KEY (discovery_id);


--
-- Name: agrc_handoffs agrc_handoffs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_handoffs
    ADD CONSTRAINT agrc_handoffs_pkey PRIMARY KEY (handoff_id);


--
-- Name: agrc_proposed_actions agrc_proposed_actions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_proposed_actions
    ADD CONSTRAINT agrc_proposed_actions_pkey PRIMARY KEY (action_id);


--
-- Name: agrc_tasks agrc_tasks_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_tasks
    ADD CONSTRAINT agrc_tasks_pkey PRIMARY KEY (task_id);


--
-- Name: ai_agent_registry ai_agent_registry_agent_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_agent_registry
    ADD CONSTRAINT ai_agent_registry_agent_code_key UNIQUE (agent_code);


--
-- Name: ai_agent_registry ai_agent_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_agent_registry
    ADD CONSTRAINT ai_agent_registry_pkey PRIMARY KEY (id);


--
-- Name: ai_event ai_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_event
    ADD CONSTRAINT ai_event_pkey PRIMARY KEY (id);


--
-- Name: ai_model_registry ai_model_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_model_registry
    ADD CONSTRAINT ai_model_registry_pkey PRIMARY KEY (id);


--
-- Name: ai_model_registry ai_model_registry_provider_model_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_model_registry
    ADD CONSTRAINT ai_model_registry_provider_model_code_key UNIQUE (provider, model_code);


--
-- Name: ai_prompt_registry ai_prompt_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_prompt_registry
    ADD CONSTRAINT ai_prompt_registry_pkey PRIMARY KEY (id);


--
-- Name: ai_prompt_registry ai_prompt_registry_prompt_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_prompt_registry
    ADD CONSTRAINT ai_prompt_registry_prompt_code_key UNIQUE (prompt_code);


--
-- Name: ai_record ai_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_record
    ADD CONSTRAINT ai_record_pkey PRIMARY KEY (id);


--
-- Name: ai_record ai_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_record
    ADD CONSTRAINT ai_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: approval_matrix_rules approval_matrix_rules_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.approval_matrix_rules
    ADD CONSTRAINT approval_matrix_rules_pkey PRIMARY KEY (rule_id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (asset_id);


--
-- Name: audit_findings audit_findings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_findings
    ADD CONSTRAINT audit_findings_pkey PRIMARY KEY (finding_id);


--
-- Name: audit_log_archive audit_log_archive_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_log_archive
    ADD CONSTRAINT audit_log_archive_pkey PRIMARY KEY (entry_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (log_id);


--
-- Name: audit_plans audit_plans_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_plans
    ADD CONSTRAINT audit_plans_pkey PRIMARY KEY (plan_id);


--
-- Name: audit_signoff_ledger audit_signoff_ledger_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_signoff_ledger
    ADD CONSTRAINT audit_signoff_ledger_pkey PRIMARY KEY (bundle_id);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (entry_id);


--
-- Name: auth_mfa_otp auth_mfa_otp_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.auth_mfa_otp
    ADD CONSTRAINT auth_mfa_otp_pkey PRIMARY KEY (otp_id);


--
-- Name: bcp_plans bcp_plans_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.bcp_plans
    ADD CONSTRAINT bcp_plans_pkey PRIMARY KEY (plan_id);


--
-- Name: billing_event billing_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.billing_event
    ADD CONSTRAINT billing_event_pkey PRIMARY KEY (id);


--
-- Name: billing_record billing_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.billing_record
    ADD CONSTRAINT billing_record_pkey PRIMARY KEY (id);


--
-- Name: billing_record billing_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.billing_record
    ADD CONSTRAINT billing_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: briefings briefings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.briefings
    ADD CONSTRAINT briefings_pkey PRIMARY KEY (briefing_id);


--
-- Name: business_units business_units_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.business_units
    ADD CONSTRAINT business_units_pkey PRIMARY KEY (bu_id);


--
-- Name: committee_meetings committee_meetings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.committee_meetings
    ADD CONSTRAINT committee_meetings_pkey PRIMARY KEY (meeting_id);


--
-- Name: committee_members committee_members_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.committee_members
    ADD CONSTRAINT committee_members_pkey PRIMARY KEY (member_id);


--
-- Name: committees committees_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.committees
    ADD CONSTRAINT committees_pkey PRIMARY KEY (committee_id);


--
-- Name: compliance_frameworks compliance_frameworks_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.compliance_frameworks
    ADD CONSTRAINT compliance_frameworks_pkey PRIMARY KEY (framework_id);


--
-- Name: compliance_requirements compliance_requirements_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.compliance_requirements
    ADD CONSTRAINT compliance_requirements_pkey PRIMARY KEY (requirement_id);


--
-- Name: component_registry component_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.component_registry
    ADD CONSTRAINT component_registry_pkey PRIMARY KEY (id);


--
-- Name: config_audit_logs config_audit_logs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_audit_logs
    ADD CONSTRAINT config_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: config_center_audit_log config_center_audit_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_center_audit_log
    ADD CONSTRAINT config_center_audit_log_pkey PRIMARY KEY (id);


--
-- Name: config_definitions config_definitions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_definitions
    ADD CONSTRAINT config_definitions_pkey PRIMARY KEY (id);


--
-- Name: config_locks config_locks_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_locks
    ADD CONSTRAINT config_locks_pkey PRIMARY KEY (id);


--
-- Name: config_runtime_overrides config_runtime_overrides_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_runtime_overrides
    ADD CONSTRAINT config_runtime_overrides_pkey PRIMARY KEY (id);


--
-- Name: config_values config_values_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_values
    ADD CONSTRAINT config_values_pkey PRIMARY KEY (id);


--
-- Name: controls controls_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.controls
    ADD CONSTRAINT controls_pkey PRIMARY KEY (control_id);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (dashboard_id);


--
-- Name: data_governance_event data_governance_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.data_governance_event
    ADD CONSTRAINT data_governance_event_pkey PRIMARY KEY (id);


--
-- Name: data_governance_record data_governance_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.data_governance_record
    ADD CONSTRAINT data_governance_record_pkey PRIMARY KEY (id);


--
-- Name: data_governance_record data_governance_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.data_governance_record
    ADD CONSTRAINT data_governance_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: deployment_event deployment_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.deployment_event
    ADD CONSTRAINT deployment_event_pkey PRIMARY KEY (id);


--
-- Name: deployment_record deployment_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.deployment_record
    ADD CONSTRAINT deployment_record_pkey PRIMARY KEY (id);


--
-- Name: deployment_record deployment_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.deployment_record
    ADD CONSTRAINT deployment_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: dora_assessments dora_assessments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dora_assessments
    ADD CONSTRAINT dora_assessments_pkey PRIMARY KEY (assessment_id);


--
-- Name: dos_master_actor_session dos_master_actor_session_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_actor_session
    ADD CONSTRAINT dos_master_actor_session_pkey PRIMARY KEY (id);


--
-- Name: dos_master_change_request dos_master_change_request_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_change_request
    ADD CONSTRAINT dos_master_change_request_pkey PRIMARY KEY (id);


--
-- Name: dos_master_compensation_chain dos_master_compensation_chain_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_compensation_chain
    ADD CONSTRAINT dos_master_compensation_chain_pkey PRIMARY KEY (id);


--
-- Name: dos_master_drift_event dos_master_drift_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_drift_event
    ADD CONSTRAINT dos_master_drift_event_pkey PRIMARY KEY (id);


--
-- Name: dos_master_grant dos_master_grant_actor_role_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_grant
    ADD CONSTRAINT dos_master_grant_actor_role_code_key UNIQUE (actor, role_code) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dos_master_grant dos_master_grant_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_grant
    ADD CONSTRAINT dos_master_grant_pkey PRIMARY KEY (id);


--
-- Name: dos_master_invalidation_log dos_master_invalidation_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_invalidation_log
    ADD CONSTRAINT dos_master_invalidation_log_pkey PRIMARY KEY (id);


--
-- Name: dos_master_lock dos_master_lock_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_lock
    ADD CONSTRAINT dos_master_lock_pkey PRIMARY KEY (id);


--
-- Name: dos_master_lock dos_master_lock_resource_key_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_lock
    ADD CONSTRAINT dos_master_lock_resource_key_key UNIQUE (resource_key) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dos_master_publish_handle dos_master_publish_handle_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_publish_handle
    ADD CONSTRAINT dos_master_publish_handle_pkey PRIMARY KEY (id);


--
-- Name: dos_master_publish_handle dos_master_publish_handle_target_kind_target_key_channel_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_publish_handle
    ADD CONSTRAINT dos_master_publish_handle_target_kind_target_key_channel_key UNIQUE (target_kind, target_key, channel) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dos_master_role dos_master_role_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_role
    ADD CONSTRAINT dos_master_role_pkey PRIMARY KEY (role_code);


--
-- Name: dos_master_writer_audit dos_master_writer_audit_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_writer_audit
    ADD CONSTRAINT dos_master_writer_audit_pkey PRIMARY KEY (id);


--
-- Name: dr_drill_runs dr_drill_runs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_drill_runs
    ADD CONSTRAINT dr_drill_runs_pkey PRIMARY KEY (id);


--
-- Name: dr_event dr_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_event
    ADD CONSTRAINT dr_event_pkey PRIMARY KEY (id);


--
-- Name: dr_record dr_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_record
    ADD CONSTRAINT dr_record_pkey PRIMARY KEY (id);


--
-- Name: dr_record dr_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_record
    ADD CONSTRAINT dr_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: dynamic_ui_empty_states dui_empty_states_uk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_empty_states
    ADD CONSTRAINT dui_empty_states_uk UNIQUE (state_key);


--
-- Name: dynamic_ui_ai_tips dynamic_ui_ai_tips_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_ai_tips
    ADD CONSTRAINT dynamic_ui_ai_tips_pkey PRIMARY KEY (tenant_id, module_code, route, tip_code);


--
-- Name: dynamic_ui_component_registry dynamic_ui_component_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_component_registry
    ADD CONSTRAINT dynamic_ui_component_registry_pkey PRIMARY KEY (component_key);


--
-- Name: dynamic_ui_empty_states dynamic_ui_empty_states_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_empty_states
    ADD CONSTRAINT dynamic_ui_empty_states_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_grid_columns dynamic_ui_grid_columns_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_grid_columns
    ADD CONSTRAINT dynamic_ui_grid_columns_pkey PRIMARY KEY (tenant_id, module_code, route, column_key);


--
-- Name: dynamic_ui_health_probes dynamic_ui_health_probes_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_health_probes
    ADD CONSTRAINT dynamic_ui_health_probes_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_i18n_keys dynamic_ui_i18n_keys_module_code_key_path_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_i18n_keys
    ADD CONSTRAINT dynamic_ui_i18n_keys_module_code_key_path_key UNIQUE (module_code, key_path);


--
-- Name: dynamic_ui_i18n_keys dynamic_ui_i18n_keys_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_i18n_keys
    ADD CONSTRAINT dynamic_ui_i18n_keys_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_module_icons dynamic_ui_module_icons_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_module_icons
    ADD CONSTRAINT dynamic_ui_module_icons_pkey PRIMARY KEY (module_code);


--
-- Name: dynamic_ui_navigation_icons dynamic_ui_navigation_icons_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_navigation_icons
    ADD CONSTRAINT dynamic_ui_navigation_icons_pkey PRIMARY KEY (module_code, route);


--
-- Name: dynamic_ui_page_headers dynamic_ui_page_headers_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_page_headers
    ADD CONSTRAINT dynamic_ui_page_headers_pkey PRIMARY KEY (tenant_id, module_code, route);


--
-- Name: dynamic_ui_quick_actions dynamic_ui_quick_actions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_quick_actions
    ADD CONSTRAINT dynamic_ui_quick_actions_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_route_metadata dynamic_ui_route_metadata_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_route_metadata
    ADD CONSTRAINT dynamic_ui_route_metadata_pkey PRIMARY KEY (route);


--
-- Name: dynamic_ui_route_permissions dynamic_ui_route_permissions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_route_permissions
    ADD CONSTRAINT dynamic_ui_route_permissions_pkey PRIMARY KEY (route_id, permission_key);


--
-- Name: dynamic_ui_setup_steps dynamic_ui_setup_steps_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_setup_steps
    ADD CONSTRAINT dynamic_ui_setup_steps_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_skill_packs dynamic_ui_skill_packs_pack_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_skill_packs
    ADD CONSTRAINT dynamic_ui_skill_packs_pack_code_key UNIQUE (pack_code);


--
-- Name: dynamic_ui_skill_packs dynamic_ui_skill_packs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_skill_packs
    ADD CONSTRAINT dynamic_ui_skill_packs_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_tenant_overrides dynamic_ui_tenant_overrides_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_tenant_overrides
    ADD CONSTRAINT dynamic_ui_tenant_overrides_pkey PRIMARY KEY (tenant_id, override_key);


--
-- Name: dynamic_ui_trial_banner_rules dynamic_ui_trial_banner_rules_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_trial_banner_rules
    ADD CONSTRAINT dynamic_ui_trial_banner_rules_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_workspace_ai_tips dynamic_ui_workspace_ai_tips_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_workspace_ai_tips
    ADD CONSTRAINT dynamic_ui_workspace_ai_tips_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_workspace_grid_columns dynamic_ui_workspace_grid_columns_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_workspace_grid_columns
    ADD CONSTRAINT dynamic_ui_workspace_grid_columns_pkey PRIMARY KEY (id);


--
-- Name: dynamic_ui_workspace_page_headers dynamic_ui_workspace_page_headers_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_workspace_page_headers
    ADD CONSTRAINT dynamic_ui_workspace_page_headers_pkey PRIMARY KEY (id);


--
-- Name: event_dead_letter_queue event_dead_letter_queue_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.event_dead_letter_queue
    ADD CONSTRAINT event_dead_letter_queue_pkey PRIMARY KEY (id);


--
-- Name: evidence evidence_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.evidence
    ADD CONSTRAINT evidence_pkey PRIMARY KEY (evidence_id);


--
-- Name: evidences evidences_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.evidences
    ADD CONSTRAINT evidences_pkey PRIMARY KEY (evidence_id);


--
-- Name: executive_briefings executive_briefings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.executive_briefings
    ADD CONSTRAINT executive_briefings_pkey PRIMARY KEY (briefing_id);


--
-- Name: feature_flag_event feature_flag_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flag_event
    ADD CONSTRAINT feature_flag_event_pkey PRIMARY KEY (id);


--
-- Name: feature_flag_record feature_flag_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flag_record
    ADD CONSTRAINT feature_flag_record_pkey PRIMARY KEY (id);


--
-- Name: feature_flag_record feature_flag_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flag_record
    ADD CONSTRAINT feature_flag_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (flag_code);


--
-- Name: foundation_authority_kinds foundation_authority_kinds_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_authority_kinds
    ADD CONSTRAINT foundation_authority_kinds_pkey PRIMARY KEY (authority_kind);


--
-- Name: foundation_cat_audit_actions foundation_cat_audit_actions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_audit_actions
    ADD CONSTRAINT foundation_cat_audit_actions_pkey PRIMARY KEY (action_code);


--
-- Name: foundation_cat_calendar_systems foundation_cat_calendar_systems_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_calendar_systems
    ADD CONSTRAINT foundation_cat_calendar_systems_pkey PRIMARY KEY (calendar_code);


--
-- Name: foundation_cat_coi_categories foundation_cat_coi_categories_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_coi_categories
    ADD CONSTRAINT foundation_cat_coi_categories_pkey PRIMARY KEY (category_code);


--
-- Name: foundation_cat_committee_templates foundation_cat_committee_templates_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_committee_templates
    ADD CONSTRAINT foundation_cat_committee_templates_pkey PRIMARY KEY (id);


--
-- Name: foundation_cat_data_classifications foundation_cat_data_classifications_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_data_classifications
    ADD CONSTRAINT foundation_cat_data_classifications_pkey PRIMARY KEY (level_code);


--
-- Name: foundation_cat_lawful_bases foundation_cat_lawful_bases_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_lawful_bases
    ADD CONSTRAINT foundation_cat_lawful_bases_pkey PRIMARY KEY (basis_code);


--
-- Name: foundation_cat_location_types foundation_cat_location_types_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_location_types
    ADD CONSTRAINT foundation_cat_location_types_pkey PRIMARY KEY (type_code);


--
-- Name: foundation_cat_org_types foundation_cat_org_types_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_org_types
    ADD CONSTRAINT foundation_cat_org_types_pkey PRIMARY KEY (org_type_code);


--
-- Name: foundation_cat_ownership_domains foundation_cat_ownership_domains_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_ownership_domains
    ADD CONSTRAINT foundation_cat_ownership_domains_pkey PRIMARY KEY (domain_code);


--
-- Name: foundation_cat_profile_types foundation_cat_profile_types_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_profile_types
    ADD CONSTRAINT foundation_cat_profile_types_pkey PRIMARY KEY (profile_code);


--
-- Name: foundation_cat_readiness_dimensions foundation_cat_readiness_dimensions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_readiness_dimensions
    ADD CONSTRAINT foundation_cat_readiness_dimensions_pkey PRIMARY KEY (dimension_code);


--
-- Name: foundation_cat_reference foundation_cat_reference_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_reference
    ADD CONSTRAINT foundation_cat_reference_pkey PRIMARY KEY (id);


--
-- Name: foundation_cat_role_templates foundation_cat_role_templates_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_role_templates
    ADD CONSTRAINT foundation_cat_role_templates_pkey PRIMARY KEY (id);


--
-- Name: foundation_coi_declarations foundation_coi_declarations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_coi_declarations
    ADD CONSTRAINT foundation_coi_declarations_pkey PRIMARY KEY (id);


--
-- Name: foundation_employee_lifecycle_state foundation_employee_lifecycle_state_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_employee_lifecycle_state
    ADD CONSTRAINT foundation_employee_lifecycle_state_pkey PRIMARY KEY (tenant_id, user_id);


--
-- Name: foundation_employee_lifecycle_tasks foundation_employee_lifecycle_tasks_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_employee_lifecycle_tasks
    ADD CONSTRAINT foundation_employee_lifecycle_tasks_pkey PRIMARY KEY (id);


--
-- Name: foundation_employee_lifecycle_transitions foundation_employee_lifecycle_transitions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_employee_lifecycle_transitions
    ADD CONSTRAINT foundation_employee_lifecycle_transitions_pkey PRIMARY KEY (id);


--
-- Name: foundation_employee_lifecycle_workflows foundation_employee_lifecycle_workflows_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_employee_lifecycle_workflows
    ADD CONSTRAINT foundation_employee_lifecycle_workflows_pkey PRIMARY KEY (id);


--
-- Name: foundation_policy_acknowledgments foundation_policy_acknowledgments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_policy_acknowledgments
    ADD CONSTRAINT foundation_policy_acknowledgments_pkey PRIMARY KEY (id);


--
-- Name: foundation_position_authority foundation_position_authority_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_position_authority
    ADD CONSTRAINT foundation_position_authority_pkey PRIMARY KEY (id);


--
-- Name: foundation_sod_violations foundation_sod_violations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_sod_violations
    ADD CONSTRAINT foundation_sod_violations_pkey PRIMARY KEY (id);


--
-- Name: foundation_training_assignments foundation_training_assignments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_training_assignments
    ADD CONSTRAINT foundation_training_assignments_pkey PRIMARY KEY (id);


--
-- Name: governance_decisions governance_decisions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.governance_decisions
    ADD CONSTRAINT governance_decisions_pkey PRIMARY KEY (decision_id);


--
-- Name: governance_policies governance_policies_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.governance_policies
    ADD CONSTRAINT governance_policies_pkey PRIMARY KEY (policy_id);


--
-- Name: i18n_fallback_values i18n_fallback_values_i18n_key_tenant_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.i18n_fallback_values
    ADD CONSTRAINT i18n_fallback_values_i18n_key_tenant_id_key UNIQUE (i18n_key, tenant_id);


--
-- Name: i18n_fallback_values i18n_fallback_values_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.i18n_fallback_values
    ADD CONSTRAINT i18n_fallback_values_pkey PRIMARY KEY (id);


--
-- Name: inbox_items inbox_items_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.inbox_items
    ADD CONSTRAINT inbox_items_pkey PRIMARY KEY (item_id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (incident_id);


--
-- Name: integration_event integration_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integration_event
    ADD CONSTRAINT integration_event_pkey PRIMARY KEY (id);


--
-- Name: integration_record integration_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integration_record
    ADD CONSTRAINT integration_record_pkey PRIMARY KEY (id);


--
-- Name: integration_record integration_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integration_record
    ADD CONSTRAINT integration_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (integration_id);


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.invitations
    ADD CONSTRAINT invitations_pkey PRIMARY KEY (invitation_id);


--
-- Name: invitations invitations_tenant_id_email_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.invitations
    ADD CONSTRAINT invitations_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: job_executions job_executions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.job_executions
    ADD CONSTRAINT job_executions_pkey PRIMARY KEY (execution_id);


--
-- Name: job_registry job_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.job_registry
    ADD CONSTRAINT job_registry_pkey PRIMARY KEY (job_id);


--
-- Name: lifecycle_auth_log lifecycle_auth_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.lifecycle_auth_log
    ADD CONSTRAINT lifecycle_auth_log_pkey PRIMARY KEY (id);


--
-- Name: location_bu_map location_bu_map_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.location_bu_map
    ADD CONSTRAINT location_bu_map_pkey PRIMARY KEY (location_id, bu_id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (location_id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: marketing_assets marketing_assets_pk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_assets
    ADD CONSTRAINT marketing_assets_pk PRIMARY KEY (asset_key, brand_code, locale);


--
-- Name: marketing_brand_assets marketing_brand_assets_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_brand_assets
    ADD CONSTRAINT marketing_brand_assets_pkey PRIMARY KEY (id);


--
-- Name: marketing_brand_tokens marketing_brand_tokens_pk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_brand_tokens
    ADD CONSTRAINT marketing_brand_tokens_pk PRIMARY KEY (brand_code, token_key);


--
-- Name: marketing_download_events marketing_download_events_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_download_events
    ADD CONSTRAINT marketing_download_events_pkey PRIMARY KEY (id);


--
-- Name: marketplace_event marketplace_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketplace_event
    ADD CONSTRAINT marketplace_event_pkey PRIMARY KEY (id);


--
-- Name: marketplace_record marketplace_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketplace_record
    ADD CONSTRAINT marketplace_record_pkey PRIMARY KEY (id);


--
-- Name: marketplace_record marketplace_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketplace_record
    ADD CONSTRAINT marketplace_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: maturity_assessments maturity_assessments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.maturity_assessments
    ADD CONSTRAINT maturity_assessments_pkey PRIMARY KEY (assessment_id);


--
-- Name: migration_history migration_history_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.migration_history
    ADD CONSTRAINT migration_history_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (service_name);


--
-- Name: mobile_sessions mobile_sessions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.mobile_sessions
    ADD CONSTRAINT mobile_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: module_capability_bindings module_capability_bindings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_capability_bindings
    ADD CONSTRAINT module_capability_bindings_pkey PRIMARY KEY (consumer_module, capability_key);


--
-- Name: module_capability_flags module_capability_flags_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_capability_flags
    ADD CONSTRAINT module_capability_flags_pkey PRIMARY KEY (module_code, capability_key);


--
-- Name: module_contract_errors module_contract_errors_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_contract_errors
    ADD CONSTRAINT module_contract_errors_pkey PRIMARY KEY (id);


--
-- Name: module_contract_publish_log module_contract_publish_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_contract_publish_log
    ADD CONSTRAINT module_contract_publish_log_pkey PRIMARY KEY (id);


--
-- Name: module_pool_slots module_pool_slots_module_code_schema_template_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_pool_slots
    ADD CONSTRAINT module_pool_slots_module_code_schema_template_key UNIQUE (module_code, schema_template);


--
-- Name: module_pool_slots module_pool_slots_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_pool_slots
    ADD CONSTRAINT module_pool_slots_pkey PRIMARY KEY (slot_id);


--
-- Name: module_readiness module_readiness_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_readiness
    ADD CONSTRAINT module_readiness_pkey PRIMARY KEY (module_code, module_version);


--
-- Name: module_registry module_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_registry
    ADD CONSTRAINT module_registry_pkey PRIMARY KEY (module_code);


--
-- Name: module_sla_defaults module_sla_defaults_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_sla_defaults
    ADD CONSTRAINT module_sla_defaults_pkey PRIMARY KEY (id);


--
-- Name: module_sod_rules module_sod_rules_module_code_action_a_action_b_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_sod_rules
    ADD CONSTRAINT module_sod_rules_module_code_action_a_action_b_key UNIQUE (module_code, action_a, action_b);


--
-- Name: module_sod_rules module_sod_rules_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.module_sod_rules
    ADD CONSTRAINT module_sod_rules_pkey PRIMARY KEY (id);


--
-- Name: navigation_registry navigation_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.navigation_registry
    ADD CONSTRAINT navigation_registry_pkey PRIMARY KEY (id);


--
-- Name: notification_event notification_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.notification_event
    ADD CONSTRAINT notification_event_pkey PRIMARY KEY (id);


--
-- Name: notification_record notification_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.notification_record
    ADD CONSTRAINT notification_record_pkey PRIMARY KEY (id);


--
-- Name: notification_record notification_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.notification_record
    ADD CONSTRAINT notification_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: onboarding_journeys onboarding_journeys_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.onboarding_journeys
    ADD CONSTRAINT onboarding_journeys_pkey PRIMARY KEY (journey_id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (organization_id);


--
-- Name: orphan_schema_audit orphan_schema_audit_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.orphan_schema_audit
    ADD CONSTRAINT orphan_schema_audit_pkey PRIMARY KEY (id);


--
-- Name: ownership_mappings ownership_mappings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ownership_mappings
    ADD CONSTRAINT ownership_mappings_pkey PRIMARY KEY (mapping_id);


--
-- Name: ownership_mappings ownership_mappings_tenant_id_entity_type_entity_id_owner_us_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ownership_mappings
    ADD CONSTRAINT ownership_mappings_tenant_id_entity_type_entity_id_owner_us_key UNIQUE (tenant_id, entity_type, entity_id, owner_user_id, ownership_type);


--
-- Name: foundation_cat_bu_templates pk_foundation_cat_bu_templates; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_bu_templates
    ADD CONSTRAINT pk_foundation_cat_bu_templates PRIMARY KEY (template_code, sector_code);


--
-- Name: foundation_cat_dept_templates pk_foundation_cat_dept_templates; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_dept_templates
    ADD CONSTRAINT pk_foundation_cat_dept_templates PRIMARY KEY (template_code, sector_code);


--
-- Name: foundation_cat_position_templates pk_foundation_cat_position_templates; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_position_templates
    ADD CONSTRAINT pk_foundation_cat_position_templates PRIMARY KEY (template_code, sector_code);


--
-- Name: marketing_footer_groups pk_marketing_footer_groups; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_footer_groups
    ADD CONSTRAINT pk_marketing_footer_groups PRIMARY KEY (id, brand_code);


--
-- Name: marketing_footer_items pk_marketing_footer_items; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_footer_items
    ADD CONSTRAINT pk_marketing_footer_items PRIMARY KEY (id, group_id, brand_code);


--
-- Name: marketing_nav_groups pk_marketing_nav_groups; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_nav_groups
    ADD CONSTRAINT pk_marketing_nav_groups PRIMARY KEY (id, brand_code);


--
-- Name: marketing_nav_items pk_marketing_nav_items; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_nav_items
    ADD CONSTRAINT pk_marketing_nav_items PRIMARY KEY (id, brand_code);


--
-- Name: platform_audit_logs platform_audit_logs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: platform_drift_log platform_drift_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_drift_log
    ADD CONSTRAINT platform_drift_log_pkey PRIMARY KEY (id);


--
-- Name: platform_migrations platform_migrations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_migrations
    ADD CONSTRAINT platform_migrations_pkey PRIMARY KEY (filename);


--
-- Name: platform_operation_config platform_operation_config_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_operation_config
    ADD CONSTRAINT platform_operation_config_pkey PRIMARY KEY (id);


--
-- Name: platform_secret_definition platform_secret_definition_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_secret_definition
    ADD CONSTRAINT platform_secret_definition_pkey PRIMARY KEY (secret_key);


--
-- Name: platform_secret platform_secret_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_secret
    ADD CONSTRAINT platform_secret_pkey PRIMARY KEY (secret_id);


--
-- Name: platform_session_policy platform_session_policy_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_session_policy
    ADD CONSTRAINT platform_session_policy_pkey PRIMARY KEY (trust_zone);


--
-- Name: platform_slo_event platform_slo_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_slo_event
    ADD CONSTRAINT platform_slo_event_pkey PRIMARY KEY (id);


--
-- Name: platform_slo platform_slo_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_slo
    ADD CONSTRAINT platform_slo_pkey PRIMARY KEY (service_code);


--
-- Name: policies policies_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.policies
    ADD CONSTRAINT policies_pkey PRIMARY KEY (policy_id);


--
-- Name: portals portals_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.portals
    ADD CONSTRAINT portals_pkey PRIMARY KEY (portal_id);


--
-- Name: position_assignments position_assignments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.position_assignments
    ADD CONSTRAINT position_assignments_pkey PRIMARY KEY (assignment_id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (position_id);


--
-- Name: privacy_assessments privacy_assessments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.privacy_assessments
    ADD CONSTRAINT privacy_assessments_pkey PRIMARY KEY (assessment_id);


--
-- Name: product_licenses product_licenses_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.product_licenses
    ADD CONSTRAINT product_licenses_pkey PRIMARY KEY (license_id);


--
-- Name: product_registry product_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.product_registry
    ADD CONSTRAINT product_registry_pkey PRIMARY KEY (product_key);


--
-- Name: publish_dependency publish_dependency_parent_target_id_child_target_id_dep_kin_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_dependency
    ADD CONSTRAINT publish_dependency_parent_target_id_child_target_id_dep_kin_key UNIQUE (parent_target_id, child_target_id, dep_kind);


--
-- Name: publish_dependency publish_dependency_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_dependency
    ADD CONSTRAINT publish_dependency_pkey PRIMARY KEY (id);


--
-- Name: publish_revision publish_revision_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_revision
    ADD CONSTRAINT publish_revision_pkey PRIMARY KEY (id);


--
-- Name: publish_revision publish_revision_target_kind_target_key_revision_no_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_revision
    ADD CONSTRAINT publish_revision_target_kind_target_key_revision_no_key UNIQUE (target_kind, target_key, revision_no);


--
-- Name: publish_rollback publish_rollback_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_rollback
    ADD CONSTRAINT publish_rollback_pkey PRIMARY KEY (id);


--
-- Name: publish_target publish_target_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_target
    ADD CONSTRAINT publish_target_pkey PRIMARY KEY (id);


--
-- Name: publish_target publish_target_target_kind_target_key_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_target
    ADD CONSTRAINT publish_target_target_kind_target_key_key UNIQUE (target_kind, target_key);


--
-- Name: qiyas_journeys qiyas_journeys_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.qiyas_journeys
    ADD CONSTRAINT qiyas_journeys_pkey PRIMARY KEY (journey_id);


--
-- Name: records records_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.records
    ADD CONSTRAINT records_pkey PRIMARY KEY (record_id);


--
-- Name: release_event release_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.release_event
    ADD CONSTRAINT release_event_pkey PRIMARY KEY (id);


--
-- Name: release_record release_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.release_record
    ADD CONSTRAINT release_record_pkey PRIMARY KEY (id);


--
-- Name: release_record release_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.release_record
    ADD CONSTRAINT release_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: remediation_actions remediation_actions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.remediation_actions
    ADD CONSTRAINT remediation_actions_pkey PRIMARY KEY (action_id);


--
-- Name: remediations remediations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.remediations
    ADD CONSTRAINT remediations_pkey PRIMARY KEY (remediation_id);


--
-- Name: report_schedules report_schedules_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.report_schedules
    ADD CONSTRAINT report_schedules_pkey PRIMARY KEY (schedule_id);


--
-- Name: risks risks_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.risks
    ADD CONSTRAINT risks_pkey PRIMARY KEY (risk_id);


--
-- Name: role_profile_acceptors role_profile_acceptors_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.role_profile_acceptors
    ADD CONSTRAINT role_profile_acceptors_pkey PRIMARY KEY (acceptor_id);


--
-- Name: role_profile_sync_log role_profile_sync_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.role_profile_sync_log
    ADD CONSTRAINT role_profile_sync_log_pkey PRIMARY KEY (id);


--
-- Name: role_profile_sync role_profile_sync_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.role_profile_sync
    ADD CONSTRAINT role_profile_sync_pkey PRIMARY KEY (profile_id);


--
-- Name: rollout_cohort rollout_cohort_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_cohort
    ADD CONSTRAINT rollout_cohort_pkey PRIMARY KEY (id);


--
-- Name: rollout_cohort rollout_cohort_ring_id_selector_kind_selector_value_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_cohort
    ADD CONSTRAINT rollout_cohort_ring_id_selector_kind_selector_value_key UNIQUE (ring_id, selector_kind, selector_value);


--
-- Name: rollout_compensation_step rollout_compensation_step_chain_id_step_order_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_compensation_step
    ADD CONSTRAINT rollout_compensation_step_chain_id_step_order_key UNIQUE (chain_id, step_order);


--
-- Name: rollout_compensation_step rollout_compensation_step_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_compensation_step
    ADD CONSTRAINT rollout_compensation_step_pkey PRIMARY KEY (id);


--
-- Name: rollout_evaluation rollout_evaluation_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_evaluation
    ADD CONSTRAINT rollout_evaluation_pkey PRIMARY KEY (id);


--
-- Name: rollout_health_gate rollout_health_gate_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_health_gate
    ADD CONSTRAINT rollout_health_gate_pkey PRIMARY KEY (id);


--
-- Name: rollout_health_gate rollout_health_gate_ring_id_gate_kind_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_health_gate
    ADD CONSTRAINT rollout_health_gate_ring_id_gate_kind_key UNIQUE (ring_id, gate_kind);


--
-- Name: rollout_plan rollout_plan_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_plan
    ADD CONSTRAINT rollout_plan_pkey PRIMARY KEY (id);


--
-- Name: rollout_ring rollout_ring_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_ring
    ADD CONSTRAINT rollout_ring_pkey PRIMARY KEY (id);


--
-- Name: rollout_ring rollout_ring_plan_id_ring_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_ring
    ADD CONSTRAINT rollout_ring_plan_id_ring_code_key UNIQUE (plan_id, ring_code);


--
-- Name: rollout_rollback rollout_rollback_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_rollback
    ADD CONSTRAINT rollout_rollback_pkey PRIMARY KEY (id);


--
-- Name: rollout_signal_threshold rollout_signal_threshold_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_signal_threshold
    ADD CONSTRAINT rollout_signal_threshold_pkey PRIMARY KEY (id);


--
-- Name: rollout_signal_threshold rollout_signal_threshold_signal_kind_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_signal_threshold
    ADD CONSTRAINT rollout_signal_threshold_signal_kind_key UNIQUE (signal_kind);


--
-- Name: runtime_config_history runtime_config_history_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.runtime_config_history
    ADD CONSTRAINT runtime_config_history_pkey PRIMARY KEY (id);


--
-- Name: runtime_config runtime_config_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.runtime_config
    ADD CONSTRAINT runtime_config_pkey PRIMARY KEY (config_key);


--
-- Name: schema_authoring_event schema_authoring_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_authoring_event
    ADD CONSTRAINT schema_authoring_event_pkey PRIMARY KEY (id);


--
-- Name: schema_authoring_record schema_authoring_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_authoring_record
    ADD CONSTRAINT schema_authoring_record_pkey PRIMARY KEY (id);


--
-- Name: schema_authoring_record schema_authoring_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_authoring_record
    ADD CONSTRAINT schema_authoring_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: schema_migrations schema_migrations_filename_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_migrations
    ADD CONSTRAINT schema_migrations_filename_key UNIQUE (filename);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: security_secret_event security_secret_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.security_secret_event
    ADD CONSTRAINT security_secret_event_pkey PRIMARY KEY (id);


--
-- Name: security_secret_record security_secret_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.security_secret_record
    ADD CONSTRAINT security_secret_record_pkey PRIMARY KEY (id);


--
-- Name: security_secret_record security_secret_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.security_secret_record
    ADD CONSTRAINT security_secret_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: shell_config shell_config_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.shell_config
    ADD CONSTRAINT shell_config_pkey PRIMARY KEY (config_id);


--
-- Name: sod_conflict_audit sod_conflict_audit_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.sod_conflict_audit
    ADD CONSTRAINT sod_conflict_audit_pkey PRIMARY KEY (id);


--
-- Name: sso_identities sso_identities_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.sso_identities
    ADD CONSTRAINT sso_identities_pkey PRIMARY KEY (id);


--
-- Name: sso_identities sso_identities_user_id_protocol_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.sso_identities
    ADD CONSTRAINT sso_identities_user_id_protocol_key UNIQUE (user_id, protocol);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: sso_role_mappings sso_role_mappings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.sso_role_mappings
    ADD CONSTRAINT sso_role_mappings_pkey PRIMARY KEY (id);


--
-- Name: sso_sessions sso_sessions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.sso_sessions
    ADD CONSTRAINT sso_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: system_events system_events_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.system_events
    ADD CONSTRAINT system_events_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_team_user_uniq; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.team_members
    ADD CONSTRAINT team_members_team_user_uniq UNIQUE (team_id, user_id);


--
-- Name: team_raci_assignments team_raci_assignments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.team_raci_assignments
    ADD CONSTRAINT team_raci_assignments_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (team_id);


--
-- Name: telemetry_event telemetry_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.telemetry_event
    ADD CONSTRAINT telemetry_event_pkey PRIMARY KEY (id);


--
-- Name: telemetry_record telemetry_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.telemetry_record
    ADD CONSTRAINT telemetry_record_pkey PRIMARY KEY (id);


--
-- Name: telemetry_record telemetry_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.telemetry_record
    ADD CONSTRAINT telemetry_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: tenant_config_versions_legacy tenant_config_versions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_config_versions_legacy
    ADD CONSTRAINT tenant_config_versions_pkey PRIMARY KEY (id);


--
-- Name: tenant_config_versions tenant_config_versions_pkey1; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_config_versions
    ADD CONSTRAINT tenant_config_versions_pkey1 PRIMARY KEY (id);


--
-- Name: tenant_feature_flag_overrides tenant_feature_flag_overrides_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_feature_flag_overrides
    ADD CONSTRAINT tenant_feature_flag_overrides_pkey PRIMARY KEY (id);


--
-- Name: tenant_kms_config tenant_kms_config_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_kms_config
    ADD CONSTRAINT tenant_kms_config_pkey PRIMARY KEY (tenant_id);


--
-- Name: tenant_kms_keys tenant_kms_keys_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_kms_keys
    ADD CONSTRAINT tenant_kms_keys_pkey PRIMARY KEY (id);


--
-- Name: tenant_landing_config tenant_landing_config_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_landing_config
    ADD CONSTRAINT tenant_landing_config_pkey PRIMARY KEY (id);


--
-- Name: tenant_landing_config tenant_landing_config_tenant_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_landing_config
    ADD CONSTRAINT tenant_landing_config_tenant_id_key UNIQUE (tenant_id);


--
-- Name: tenant_memberships tenant_memberships_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_memberships
    ADD CONSTRAINT tenant_memberships_pkey PRIMARY KEY (id);


--
-- Name: tenant_migrations tenant_migrations_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_migrations
    ADD CONSTRAINT tenant_migrations_pkey PRIMARY KEY (tenant_id, migration_id, checksum);


--
-- Name: tenant_module_entitlements tenant_module_entitlements_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_module_entitlements
    ADD CONSTRAINT tenant_module_entitlements_pkey PRIMARY KEY (entitlement_id);


--
-- Name: tenant_modules tenant_modules_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_modules
    ADD CONSTRAINT tenant_modules_pkey PRIMARY KEY (tenant_id, module_code);


--
-- Name: tenant_product_activation tenant_product_activation_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_product_activation
    ADD CONSTRAINT tenant_product_activation_pkey PRIMARY KEY (id);


--
-- Name: tenant_schema_allowlist tenant_schema_allowlist_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_schema_allowlist
    ADD CONSTRAINT tenant_schema_allowlist_pkey PRIMARY KEY (schema_name);


--
-- Name: tenant_security_policy tenant_security_policy_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_security_policy
    ADD CONSTRAINT tenant_security_policy_pkey PRIMARY KEY (tenant_id);


--
-- Name: tenant_settings_legacy tenant_settings_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_settings_legacy
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey1; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey1 PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (tenant_id);


--
-- Name: training_courses training_courses_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.training_courses
    ADD CONSTRAINT training_courses_pkey PRIMARY KEY (course_id);


--
-- Name: training_enrollments training_enrollments_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.training_enrollments
    ADD CONSTRAINT training_enrollments_pkey PRIMARY KEY (enrollment_id);


--
-- Name: training_programs training_programs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.training_programs
    ADD CONSTRAINT training_programs_pkey PRIMARY KEY (program_id);


--
-- Name: ui_admin_activity_log ui_admin_activity_log_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_admin_activity_log
    ADD CONSTRAINT ui_admin_activity_log_pkey PRIMARY KEY (id);


--
-- Name: ui_carbon_components ui_carbon_components_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_carbon_components
    ADD CONSTRAINT ui_carbon_components_pkey PRIMARY KEY (carbon_key);


--
-- Name: ui_dos_component_carbon_map ui_dos_component_carbon_map_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_dos_component_carbon_map
    ADD CONSTRAINT ui_dos_component_carbon_map_pkey PRIMARY KEY (dos_component_key);


--
-- Name: ui_draft_versions ui_draft_versions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_draft_versions
    ADD CONSTRAINT ui_draft_versions_pkey PRIMARY KEY (id);


--
-- Name: ui_draft_versions ui_draft_versions_uk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_draft_versions
    ADD CONSTRAINT ui_draft_versions_uk UNIQUE (tenant_id, target_kind, target_id, version);


--
-- Name: ui_module_nav_group ui_module_nav_group_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_module_nav_group
    ADD CONSTRAINT ui_module_nav_group_pkey PRIMARY KEY (module_code, group_id);


--
-- Name: ui_module_nav_item ui_module_nav_item_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_module_nav_item
    ADD CONSTRAINT ui_module_nav_item_pkey PRIMARY KEY (module_code, item_id);


--
-- Name: ui_module_nav_override_tenant ui_module_nav_override_tenant_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_module_nav_override_tenant
    ADD CONSTRAINT ui_module_nav_override_tenant_pkey PRIMARY KEY (tenant_id, module_code, item_id);


--
-- Name: ui_module_nav_override_user ui_module_nav_override_user_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_module_nav_override_user
    ADD CONSTRAINT ui_module_nav_override_user_pkey PRIMARY KEY (user_id, module_code, item_id);


--
-- Name: ui_override_module ui_override_module_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_override_module
    ADD CONSTRAINT ui_override_module_pkey PRIMARY KEY (module_code);


--
-- Name: ui_override_product ui_override_product_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_override_product
    ADD CONSTRAINT ui_override_product_pkey PRIMARY KEY (product_code);


--
-- Name: ui_override_tenant ui_override_tenant_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_override_tenant
    ADD CONSTRAINT ui_override_tenant_pkey PRIMARY KEY (tenant_id, route);


--
-- Name: ui_override_user ui_override_user_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_override_user
    ADD CONSTRAINT ui_override_user_pkey PRIMARY KEY (user_id, route);


--
-- Name: ui_published_versions ui_published_versions_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_published_versions
    ADD CONSTRAINT ui_published_versions_pkey PRIMARY KEY (id);


--
-- Name: ui_published_versions ui_published_versions_uk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_published_versions
    ADD CONSTRAINT ui_published_versions_uk UNIQUE (tenant_id, target_kind, target_id, version);


--
-- Name: ui_rollback_points ui_rollback_points_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_rollback_points
    ADD CONSTRAINT ui_rollback_points_pkey PRIMARY KEY (id);


--
-- Name: ui_rollback_points ui_rollback_points_uk; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_rollback_points
    ADD CONSTRAINT ui_rollback_points_uk UNIQUE (tenant_id, target_kind, target_id, version);


--
-- Name: ui_route_agent_flow_step ui_route_agent_flow_step_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_flow_step
    ADD CONSTRAINT ui_route_agent_flow_step_pkey PRIMARY KEY (id);


--
-- Name: ui_route_agent_flow_step ui_route_agent_flow_step_route_step_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_flow_step
    ADD CONSTRAINT ui_route_agent_flow_step_route_step_id_key UNIQUE (route, step_id);


--
-- Name: ui_route_agent_registry ui_route_agent_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_registry
    ADD CONSTRAINT ui_route_agent_registry_pkey PRIMARY KEY (id);


--
-- Name: ui_route_agent_registry ui_route_agent_registry_route_agent_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_agent_registry
    ADD CONSTRAINT ui_route_agent_registry_route_agent_id_key UNIQUE (route, agent_id);


--
-- Name: ui_route_audit_evidence_artifact ui_route_audit_evidence_artifact_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_evidence_artifact
    ADD CONSTRAINT ui_route_audit_evidence_artifact_pkey PRIMARY KEY (id);


--
-- Name: ui_route_audit_evidence_artifact ui_route_audit_evidence_artifact_route_artifact_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_evidence_artifact
    ADD CONSTRAINT ui_route_audit_evidence_artifact_route_artifact_id_key UNIQUE (route, artifact_id);


--
-- Name: ui_route_audit_ledger_row ui_route_audit_ledger_row_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_ledger_row
    ADD CONSTRAINT ui_route_audit_ledger_row_pkey PRIMARY KEY (id);


--
-- Name: ui_route_audit_ledger_row ui_route_audit_ledger_row_route_ledger_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_audit_ledger_row
    ADD CONSTRAINT ui_route_audit_ledger_row_route_ledger_id_key UNIQUE (route, ledger_id);


--
-- Name: ui_route_calendar_event ui_route_calendar_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_calendar_event
    ADD CONSTRAINT ui_route_calendar_event_pkey PRIMARY KEY (id);


--
-- Name: ui_route_calendar_event ui_route_calendar_event_route_event_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_calendar_event
    ADD CONSTRAINT ui_route_calendar_event_route_event_id_key UNIQUE (route, event_id);


--
-- Name: ui_route_case_finalization ui_route_case_finalization_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_case_finalization
    ADD CONSTRAINT ui_route_case_finalization_pkey PRIMARY KEY (id);


--
-- Name: ui_route_case_finalization ui_route_case_finalization_route_case_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_case_finalization
    ADD CONSTRAINT ui_route_case_finalization_route_case_id_key UNIQUE (route, case_id);


--
-- Name: ui_route_column ui_route_column_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_column
    ADD CONSTRAINT ui_route_column_pkey PRIMARY KEY (id);


--
-- Name: ui_route_delegation_rule ui_route_delegation_rule_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_delegation_rule
    ADD CONSTRAINT ui_route_delegation_rule_pkey PRIMARY KEY (id);


--
-- Name: ui_route_delegation_rule ui_route_delegation_rule_route_rule_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_delegation_rule
    ADD CONSTRAINT ui_route_delegation_rule_route_rule_id_key UNIQUE (route, rule_id);


--
-- Name: ui_route_export_artifact ui_route_export_artifact_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_export_artifact
    ADD CONSTRAINT ui_route_export_artifact_pkey PRIMARY KEY (id);


--
-- Name: ui_route_export_artifact ui_route_export_artifact_route_artifact_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_export_artifact
    ADD CONSTRAINT ui_route_export_artifact_route_artifact_id_key UNIQUE (route, artifact_id);


--
-- Name: ui_route_follow_up_item ui_route_follow_up_item_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_follow_up_item
    ADD CONSTRAINT ui_route_follow_up_item_pkey PRIMARY KEY (id);


--
-- Name: ui_route_follow_up_item ui_route_follow_up_item_route_item_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_follow_up_item
    ADD CONSTRAINT ui_route_follow_up_item_route_item_id_key UNIQUE (route, item_id);


--
-- Name: ui_route_heatmap_axis ui_route_heatmap_axis_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_heatmap_axis
    ADD CONSTRAINT ui_route_heatmap_axis_pkey PRIMARY KEY (id);


--
-- Name: ui_route_heatmap_axis ui_route_heatmap_axis_route_axis_sort_order_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_heatmap_axis
    ADD CONSTRAINT ui_route_heatmap_axis_route_axis_sort_order_key UNIQUE (route, axis, sort_order);


--
-- Name: ui_route_incident_communication ui_route_incident_communication_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_communication
    ADD CONSTRAINT ui_route_incident_communication_pkey PRIMARY KEY (id);


--
-- Name: ui_route_incident_communication ui_route_incident_communication_route_comm_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_communication
    ADD CONSTRAINT ui_route_incident_communication_route_comm_id_key UNIQUE (route, comm_id);


--
-- Name: ui_route_incident_runbook_step ui_route_incident_runbook_step_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_runbook_step
    ADD CONSTRAINT ui_route_incident_runbook_step_pkey PRIMARY KEY (id);


--
-- Name: ui_route_incident_runbook_step ui_route_incident_runbook_step_route_step_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_incident_runbook_step
    ADD CONSTRAINT ui_route_incident_runbook_step_route_step_id_key UNIQUE (route, step_id);


--
-- Name: ui_route_kpi ui_route_kpi_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_kpi
    ADD CONSTRAINT ui_route_kpi_pkey PRIMARY KEY (id);


--
-- Name: ui_route_nba ui_route_nba_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_nba
    ADD CONSTRAINT ui_route_nba_pkey PRIMARY KEY (id);


--
-- Name: ui_route_org_chart_node ui_route_org_chart_node_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_org_chart_node
    ADD CONSTRAINT ui_route_org_chart_node_pkey PRIMARY KEY (id);


--
-- Name: ui_route_org_chart_node ui_route_org_chart_node_route_node_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_org_chart_node
    ADD CONSTRAINT ui_route_org_chart_node_route_node_id_key UNIQUE (route, node_id);


--
-- Name: ui_route_ownership_edge ui_route_ownership_edge_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_ownership_edge
    ADD CONSTRAINT ui_route_ownership_edge_pkey PRIMARY KEY (id);


--
-- Name: ui_route_ownership_edge ui_route_ownership_edge_route_edge_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_ownership_edge
    ADD CONSTRAINT ui_route_ownership_edge_route_edge_id_key UNIQUE (route, edge_id);


--
-- Name: ui_route_report_card ui_route_report_card_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_report_card
    ADD CONSTRAINT ui_route_report_card_pkey PRIMARY KEY (id);


--
-- Name: ui_route_report_card ui_route_report_card_route_report_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_report_card
    ADD CONSTRAINT ui_route_report_card_route_report_id_key UNIQUE (route, report_id);


--
-- Name: ui_route_roadmap_milestone ui_route_roadmap_milestone_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_roadmap_milestone
    ADD CONSTRAINT ui_route_roadmap_milestone_pkey PRIMARY KEY (id);


--
-- Name: ui_route_roadmap_milestone ui_route_roadmap_milestone_route_milestone_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_roadmap_milestone
    ADD CONSTRAINT ui_route_roadmap_milestone_route_milestone_id_key UNIQUE (route, milestone_id);


--
-- Name: ui_route_setting_section ui_route_setting_section_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_setting_section
    ADD CONSTRAINT ui_route_setting_section_pkey PRIMARY KEY (id);


--
-- Name: ui_route_setting_section ui_route_setting_section_route_section_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_setting_section
    ADD CONSTRAINT ui_route_setting_section_route_section_id_key UNIQUE (route, section_id);


--
-- Name: ui_route_tab ui_route_tab_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_tab
    ADD CONSTRAINT ui_route_tab_pkey PRIMARY KEY (id);


--
-- Name: ui_route_tab ui_route_tab_route_tab_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_tab
    ADD CONSTRAINT ui_route_tab_route_tab_id_key UNIQUE (route, tab_id);


--
-- Name: ui_route_template_binding ui_route_template_binding_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_template_binding
    ADD CONSTRAINT ui_route_template_binding_pkey PRIMARY KEY (route);


--
-- Name: ui_route_workflow_timeline_step ui_route_workflow_timeline_step_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workflow_timeline_step
    ADD CONSTRAINT ui_route_workflow_timeline_step_pkey PRIMARY KEY (id);


--
-- Name: ui_route_workflow_timeline_step ui_route_workflow_timeline_step_route_step_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workflow_timeline_step
    ADD CONSTRAINT ui_route_workflow_timeline_step_route_step_id_key UNIQUE (route, step_id);


--
-- Name: ui_route_workqueue_group ui_route_workqueue_group_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workqueue_group
    ADD CONSTRAINT ui_route_workqueue_group_pkey PRIMARY KEY (id);


--
-- Name: ui_route_workqueue_group ui_route_workqueue_group_route_group_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_workqueue_group
    ADD CONSTRAINT ui_route_workqueue_group_route_group_id_key UNIQUE (route, group_id);


--
-- Name: ui_service_registry ui_service_registry_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_service_registry
    ADD CONSTRAINT ui_service_registry_pkey PRIMARY KEY (service_code);


--
-- Name: ui_service_registry_prefixes ui_service_registry_prefixes_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_service_registry_prefixes
    ADD CONSTRAINT ui_service_registry_prefixes_pkey PRIMARY KEY (service_code, prefix);


--
-- Name: ui_workspace_banner ui_workspace_banner_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_workspace_banner
    ADD CONSTRAINT ui_workspace_banner_pkey PRIMARY KEY (tenant_id, banner_id);


--
-- Name: ui_workspace_chrome ui_workspace_chrome_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_workspace_chrome
    ADD CONSTRAINT ui_workspace_chrome_pkey PRIMARY KEY (tenant_id, chrome_key);


--
-- Name: ui_workspace_policy ui_workspace_policy_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_workspace_policy
    ADD CONSTRAINT ui_workspace_policy_pkey PRIMARY KEY (tenant_id, policy_key);


--
-- Name: ui_workspace_shortcut ui_workspace_shortcut_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_workspace_shortcut
    ADD CONSTRAINT ui_workspace_shortcut_pkey PRIMARY KEY (tenant_id, shortcut_id);


--
-- Name: migration_history unique_service_migration; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.migration_history
    ADD CONSTRAINT unique_service_migration UNIQUE (service_name, migration_number, migration_type);


--
-- Name: foundation_cat_committee_templates uq_foundation_cat_committee_templates; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_committee_templates
    ADD CONSTRAINT uq_foundation_cat_committee_templates UNIQUE NULLS NOT DISTINCT (template_code, sector_code);


--
-- Name: foundation_cat_reference uq_foundation_cat_reference; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_reference
    ADD CONSTRAINT uq_foundation_cat_reference UNIQUE (category, code);


--
-- Name: foundation_cat_role_templates uq_foundation_cat_role_templates; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_role_templates
    ADD CONSTRAINT uq_foundation_cat_role_templates UNIQUE NULLS NOT DISTINCT (role_code, sector_code);


--
-- Name: foundation_cat_tenant_defaults uq_foundation_cat_tenant_defaults; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_cat_tenant_defaults
    ADD CONSTRAINT uq_foundation_cat_tenant_defaults UNIQUE NULLS NOT DISTINCT (region_code, sector_code);


--
-- Name: foundation_coi_declarations uq_foundation_coi_period; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_coi_declarations
    ADD CONSTRAINT uq_foundation_coi_period UNIQUE NULLS NOT DISTINCT (tenant_id, user_id, declaration_period);


--
-- Name: foundation_employee_lifecycle_workflows uq_foundation_lifecycle_workflows; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_employee_lifecycle_workflows
    ADD CONSTRAINT uq_foundation_lifecycle_workflows UNIQUE NULLS NOT DISTINCT (tenant_id, workflow_code);


--
-- Name: foundation_policy_acknowledgments uq_foundation_policy_ack; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_policy_acknowledgments
    ADD CONSTRAINT uq_foundation_policy_ack UNIQUE NULLS NOT DISTINCT (tenant_id, user_id, policy_id, policy_version);


--
-- Name: foundation_position_authority uq_foundation_position_authority; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_position_authority
    ADD CONSTRAINT uq_foundation_position_authority UNIQUE NULLS NOT DISTINCT (tenant_id, position_id, authority_kind, effective_from);


--
-- Name: foundation_sod_rules uq_foundation_sod_rules; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_sod_rules
    ADD CONSTRAINT uq_foundation_sod_rules UNIQUE NULLS NOT DISTINCT (tenant_id, rule_code);


--
-- Name: foundation_training_courses uq_foundation_training_courses; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_training_courses
    ADD CONSTRAINT uq_foundation_training_courses UNIQUE NULLS NOT DISTINCT (tenant_id, course_code);


--
-- Name: role_profile_sync uq_role_profile_natural; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.role_profile_sync
    ADD CONSTRAINT uq_role_profile_natural UNIQUE (tenant_id, user_id, role_code, scope);


--
-- Name: tenant_product_activation uq_tenant_product_activation; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_product_activation
    ADD CONSTRAINT uq_tenant_product_activation UNIQUE (tenant_id, product_key);


--
-- Name: user_org_scope user_org_scope_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.user_org_scope
    ADD CONSTRAINT user_org_scope_pkey PRIMARY KEY (id);


--
-- Name: user_org_scope user_org_scope_tenant_id_user_id_scope_type_scope_id_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.user_org_scope
    ADD CONSTRAINT user_org_scope_tenant_id_user_id_scope_type_scope_id_key UNIQUE (tenant_id, user_id, scope_type, scope_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_code);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: vendor_risk_event vendor_risk_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendor_risk_event
    ADD CONSTRAINT vendor_risk_event_pkey PRIMARY KEY (id);


--
-- Name: vendor_risk_record vendor_risk_record_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendor_risk_record
    ADD CONSTRAINT vendor_risk_record_pkey PRIMARY KEY (id);


--
-- Name: vendor_risk_record vendor_risk_record_record_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendor_risk_record
    ADD CONSTRAINT vendor_risk_record_record_key_version_key UNIQUE (record_key, version);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (vendor_id);


--
-- Name: widgets widgets_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.widgets
    ADD CONSTRAINT widgets_pkey PRIMARY KEY (widget_id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (work_item_id);


--
-- Name: workflow_approvals workflow_approvals_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_approvals
    ADD CONSTRAINT workflow_approvals_pkey PRIMARY KEY (approval_id);


--
-- Name: workflow_definition workflow_definition_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_definition
    ADD CONSTRAINT workflow_definition_pkey PRIMARY KEY (id);


--
-- Name: workflow_definition workflow_definition_workflow_key_version_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_definition
    ADD CONSTRAINT workflow_definition_workflow_key_version_key UNIQUE (workflow_key, version);


--
-- Name: workflow_event workflow_event_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_event
    ADD CONSTRAINT workflow_event_pkey PRIMARY KEY (id);


--
-- Name: workflow_instance workflow_instance_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_instance
    ADD CONSTRAINT workflow_instance_pkey PRIMARY KEY (id);


--
-- Name: workflow_instances workflow_instances_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_instances
    ADD CONSTRAINT workflow_instances_pkey PRIMARY KEY (instance_id);


--
-- Name: workflow_schedules workflow_schedules_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_schedules
    ADD CONSTRAINT workflow_schedules_pkey PRIMARY KEY (schedule_id);


--
-- Name: workflow_sla_configs workflow_sla_configs_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_sla_configs
    ADD CONSTRAINT workflow_sla_configs_pkey PRIMARY KEY (sla_id);


--
-- Name: workflow_step_run workflow_step_run_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_step_run
    ADD CONSTRAINT workflow_step_run_pkey PRIMARY KEY (id);


--
-- Name: workflow_tasks workflow_tasks_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_tasks
    ADD CONSTRAINT workflow_tasks_pkey PRIMARY KEY (task_id);


--
-- Name: workflow_templates workflow_templates_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_templates
    ADD CONSTRAINT workflow_templates_pkey PRIMARY KEY (template_id);


--
-- Name: workspace_config workspace_config_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_config
    ADD CONSTRAINT workspace_config_pkey PRIMARY KEY (id);


--
-- Name: workspace_shell_binding workspace_shell_binding_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_binding
    ADD CONSTRAINT workspace_shell_binding_pkey PRIMARY KEY (id);


--
-- Name: workspace_shell_binding workspace_shell_binding_tenant_id_component_key_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_binding
    ADD CONSTRAINT workspace_shell_binding_tenant_id_component_key_key UNIQUE (tenant_id, component_key);


--
-- Name: workspace_shell_i18n workspace_shell_i18n_key_locale_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_i18n
    ADD CONSTRAINT workspace_shell_i18n_key_locale_key UNIQUE (key, locale);


--
-- Name: workspace_shell_i18n workspace_shell_i18n_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_i18n
    ADD CONSTRAINT workspace_shell_i18n_pkey PRIMARY KEY (id);


--
-- Name: workspace_shell_status_label workspace_shell_status_label_catalog_code_key; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_status_label
    ADD CONSTRAINT workspace_shell_status_label_catalog_code_key UNIQUE (catalog, code);


--
-- Name: workspace_shell_status_label workspace_shell_status_label_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspace_shell_status_label
    ADD CONSTRAINT workspace_shell_status_label_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (workspace_id);


--
-- Name: _test_idx_1777175520671; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX _test_idx_1777175520671 ON dos.platform_migrations USING btree (filename);


--
-- Name: _test_idx_1777175884026; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX _test_idx_1777175884026 ON dos.platform_migrations USING btree (filename);


--
-- Name: _test_idx_1777176053988; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX _test_idx_1777176053988 ON dos.platform_migrations USING btree (filename);


--
-- Name: _test_idx_1777176770694; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX _test_idx_1777176770694 ON dos.platform_migrations USING btree (filename);


--
-- Name: _test_idx_1777177123074; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX _test_idx_1777177123074 ON dos.platform_migrations USING btree (filename);


--
-- Name: _test_idx_1777177740058; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX _test_idx_1777177740058 ON dos.platform_migrations USING btree (filename);


--
-- Name: config_definitions_key_uk; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX config_definitions_key_uk ON dos.config_definitions USING btree (key);


--
-- Name: config_values_definition_id_idx; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX config_values_definition_id_idx ON dos.config_values USING btree (definition_id);


--
-- Name: config_values_definition_scope_active_idx; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX config_values_definition_scope_active_idx ON dos.config_values USING btree (definition_id, scope_type, is_active);


--
-- Name: config_values_scope_idx; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX config_values_scope_idx ON dos.config_values USING btree (scope_type, scope_id);


--
-- Name: idx_action_items_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_action_items_deleted ON dos.action_items USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_actions_remediation; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_actions_remediation ON dos.action_items USING btree (remediation_id);


--
-- Name: idx_actions_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_actions_tenant ON dos.action_items USING btree (tenant_id);


--
-- Name: idx_agrc_agent_memory_agent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_agent_memory_agent ON dos.agrc_agent_memory USING btree (tenant_id, agent_id);


--
-- Name: idx_agrc_agent_runs_agent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_agent_runs_agent ON dos.agrc_agent_runs USING btree (tenant_id, agent_id);


--
-- Name: idx_agrc_agent_runs_cycle; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_agent_runs_cycle ON dos.agrc_agent_runs USING btree (cycle_id);


--
-- Name: idx_agrc_agent_runs_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_agent_runs_tenant ON dos.agrc_agent_runs USING btree (tenant_id);


--
-- Name: idx_agrc_cycles_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_cycles_status ON dos.agrc_cycles USING btree (tenant_id, status);


--
-- Name: idx_agrc_cycles_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_cycles_tenant ON dos.agrc_cycles USING btree (tenant_id);


--
-- Name: idx_agrc_discoveries_agent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_discoveries_agent ON dos.agrc_discoveries USING btree (tenant_id, agent_id);


--
-- Name: idx_agrc_discoveries_cycle; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_discoveries_cycle ON dos.agrc_discoveries USING btree (cycle_id);


--
-- Name: idx_agrc_discoveries_severity; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_discoveries_severity ON dos.agrc_discoveries USING btree (tenant_id, severity);


--
-- Name: idx_agrc_discoveries_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_discoveries_tenant ON dos.agrc_discoveries USING btree (tenant_id);


--
-- Name: idx_agrc_handoffs_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_handoffs_tenant ON dos.agrc_handoffs USING btree (tenant_id);


--
-- Name: idx_agrc_handoffs_to; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_handoffs_to ON dos.agrc_handoffs USING btree (tenant_id, to_agent, status);


--
-- Name: idx_agrc_proposed_actions_cycle; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_proposed_actions_cycle ON dos.agrc_proposed_actions USING btree (cycle_id);


--
-- Name: idx_agrc_proposed_actions_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_proposed_actions_status ON dos.agrc_proposed_actions USING btree (tenant_id, status);


--
-- Name: idx_agrc_proposed_actions_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_proposed_actions_tenant ON dos.agrc_proposed_actions USING btree (tenant_id);


--
-- Name: idx_agrc_tasks_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_tasks_deleted ON dos.agrc_tasks USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_agrc_tasks_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_tasks_status ON dos.agrc_tasks USING btree (tenant_id, status);


--
-- Name: idx_agrc_tasks_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_agrc_tasks_tenant ON dos.agrc_tasks USING btree (tenant_id);


--
-- Name: idx_approval_matrix_action; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_approval_matrix_action ON dos.approval_matrix_rules USING btree (action_code, module_code);


--
-- Name: idx_assets_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_assets_tenant ON dos.assets USING btree (tenant_id);


--
-- Name: idx_assets_type; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_assets_type ON dos.assets USING btree (tenant_id, asset_type);


--
-- Name: idx_audit_findings_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_findings_tenant ON dos.audit_findings USING btree (tenant_id);


--
-- Name: idx_audit_log_archive_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_log_archive_tenant ON dos.audit_log_archive USING btree (tenant_id, created_at DESC);


--
-- Name: idx_audit_logs_actor; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_logs_actor ON dos.audit_logs USING btree (actor_id);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_logs_created ON dos.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_logs_entity ON dos.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_audit_logs_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_logs_tenant ON dos.audit_logs USING btree (tenant_id);


--
-- Name: idx_audit_plans_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_plans_tenant ON dos.audit_plans USING btree (tenant_id);


--
-- Name: idx_audit_plans_year; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_audit_plans_year ON dos.audit_plans USING btree (tenant_id, year);


--
-- Name: idx_bcp_plans_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_bcp_plans_tenant ON dos.bcp_plans USING btree (tenant_id);


--
-- Name: idx_briefings_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_briefings_tenant ON dos.briefings USING btree (tenant_id);


--
-- Name: idx_compliance_frameworks_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_compliance_frameworks_tenant ON dos.compliance_frameworks USING btree (tenant_id);


--
-- Name: idx_component_registry_csn; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX idx_component_registry_csn ON dos.component_registry USING btree (csn) WHERE (tenant_id IS NULL);


--
-- Name: idx_component_registry_layer; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_component_registry_layer ON dos.component_registry USING btree (layer) WHERE (is_active = true);


--
-- Name: idx_component_registry_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_component_registry_module ON dos.component_registry USING btree (module_code);


--
-- Name: idx_config_audit_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_config_audit_key ON dos.config_center_audit_log USING btree (key);


--
-- Name: idx_config_audit_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_config_audit_tenant ON dos.config_center_audit_log USING btree (tenant_id, created_at DESC);


--
-- Name: idx_config_values_definition_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_config_values_definition_id ON dos.config_values USING btree (definition_id);


--
-- Name: idx_config_values_scope_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_config_values_scope_active ON dos.config_values USING btree (scope_type, is_active);


--
-- Name: idx_config_versions_tenant_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_config_versions_tenant_key ON dos.tenant_config_versions USING btree (tenant_id, config_key, is_current);


--
-- Name: idx_controls_framework; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_controls_framework ON dos.controls USING btree (framework_id);


--
-- Name: idx_controls_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_controls_tenant ON dos.controls USING btree (tenant_id);


--
-- Name: idx_dashboards_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dashboards_tenant ON dos.dashboards USING btree (tenant_id);


--
-- Name: idx_departments_bu; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_departments_bu ON dos.departments USING btree (bu_id) WHERE (bu_id IS NOT NULL);


--
-- Name: idx_departments_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_departments_tenant ON dos.departments USING btree (tenant_id);


--
-- Name: idx_dlq_event_type; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dlq_event_type ON dos.event_dead_letter_queue USING btree (event_type, created_at);


--
-- Name: idx_dlq_service_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dlq_service_status ON dos.event_dead_letter_queue USING btree (service, status);


--
-- Name: idx_dora_assessments_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dora_assessments_tenant ON dos.dora_assessments USING btree (tenant_id);


--
-- Name: idx_dora_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dora_tenant ON dos.dora_assessments USING btree (tenant_id);


--
-- Name: idx_dos_access_review_items_review; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_access_review_items_review ON dos.access_review_items USING btree (review_id, tenant_id);


--
-- Name: idx_dos_access_reviews_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_access_reviews_tenant ON dos.access_reviews USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_audit_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_audit_module ON dos.audit_trail USING btree (tenant_id, module, created_at DESC);


--
-- Name: idx_dos_audit_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_audit_tenant ON dos.audit_trail USING btree (tenant_id, created_at DESC);


--
-- Name: idx_dos_bu_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_bu_tenant ON dos.business_units USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_cm_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_cm_tenant ON dos.committee_members USING btree (committee_id, tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_committee_meetings_committee; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_committee_meetings_committee ON dos.committee_meetings USING btree (committee_id, tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_committee_meetings_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_committee_meetings_tenant ON dos.committee_meetings USING btree (tenant_id, scheduled_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_committees_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_committees_tenant ON dos.committees USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_decisions_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_decisions_tenant ON dos.governance_decisions USING btree (tenant_id, decided_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_departments_tenant_not_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_departments_tenant_not_deleted ON dos.departments USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_invitations_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_invitations_tenant ON dos.invitations USING btree (tenant_id);


--
-- Name: idx_dos_locations_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_locations_tenant ON dos.locations USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_orgs_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_orgs_tenant ON dos.organizations USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_ownership_mappings_tenant_not_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_ownership_mappings_tenant_not_deleted ON dos.ownership_mappings USING btree (tenant_id, entity_type) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_posassign_pos; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_posassign_pos ON dos.position_assignments USING btree (position_id, tenant_id);


--
-- Name: idx_dos_positions_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_positions_tenant ON dos.positions USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_teams_tenant_not_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_teams_tenant_not_deleted ON dos.teams USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_users_email_lower; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_users_email_lower ON dos.users USING btree (lower((email)::text));


--
-- Name: idx_dos_users_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_users_tenant ON dos.users USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_dos_users_tenant_email; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dos_users_tenant_email ON dos.users USING btree (tenant_id, email) WHERE (deleted_at IS NULL);


--
-- Name: idx_dr_drill_runs_completed; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dr_drill_runs_completed ON dos.dr_drill_runs USING btree (completed_at DESC) WHERE (status = 'passed'::text);


--
-- Name: idx_dr_drill_runs_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_dr_drill_runs_status ON dos.dr_drill_runs USING btree (status, started_at DESC);


--
-- Name: idx_evidence_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_evidence_tenant ON dos.evidence USING btree (tenant_id);


--
-- Name: idx_evidences_control; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_evidences_control ON dos.evidences USING btree (control_id);


--
-- Name: idx_evidences_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_evidences_tenant ON dos.evidences USING btree (tenant_id);


--
-- Name: idx_findings_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_findings_tenant ON dos.audit_findings USING btree (tenant_id);


--
-- Name: idx_frameworks_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_frameworks_tenant ON dos.compliance_frameworks USING btree (tenant_id);


--
-- Name: idx_governance_policies_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_governance_policies_tenant ON dos.governance_policies USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_governance_policies_tenant_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_governance_policies_tenant_status ON dos.governance_policies USING btree (tenant_id, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_i18n_fallback_values_enabled; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_i18n_fallback_values_enabled ON dos.i18n_fallback_values USING btree (enabled);


--
-- Name: idx_i18n_fallback_values_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_i18n_fallback_values_key ON dos.i18n_fallback_values USING btree (i18n_key);


--
-- Name: idx_i18n_fallback_values_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_i18n_fallback_values_tenant ON dos.i18n_fallback_values USING btree (tenant_id);


--
-- Name: idx_inbox_items_tenant_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_inbox_items_tenant_user ON dos.inbox_items USING btree (tenant_id, user_id);


--
-- Name: idx_incidents_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_incidents_deleted ON dos.incidents USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_incidents_risk; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_incidents_risk ON dos.incidents USING btree (risk_id);


--
-- Name: idx_incidents_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_incidents_tenant ON dos.incidents USING btree (tenant_id);


--
-- Name: idx_integrations_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_integrations_tenant ON dos.integrations USING btree (tenant_id);


--
-- Name: idx_job_executions_job_started; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_job_executions_job_started ON dos.job_executions USING btree (job_id, started_at DESC);


--
-- Name: idx_job_executions_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_job_executions_status ON dos.job_executions USING btree (status) WHERE ((status)::text = 'running'::text);


--
-- Name: idx_licenses_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_licenses_tenant ON dos.product_licenses USING btree (tenant_id);


--
-- Name: idx_lifecycle_auth_log_entity; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_lifecycle_auth_log_entity ON dos.lifecycle_auth_log USING btree (entity_type, entity_id);


--
-- Name: idx_login_attempts_email; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_login_attempts_email ON dos.login_attempts USING btree (email, attempted_at DESC);


--
-- Name: idx_login_attempts_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_login_attempts_time ON dos.login_attempts USING btree (attempted_at DESC);


--
-- Name: idx_maturity_assessments_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_maturity_assessments_deleted ON dos.maturity_assessments USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_maturity_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_maturity_tenant ON dos.maturity_assessments USING btree (tenant_id);


--
-- Name: idx_migration_history_executed_at; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_migration_history_executed_at ON dos.migration_history USING btree (executed_at);


--
-- Name: idx_migration_history_git_sha; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_migration_history_git_sha ON dos.migration_history USING btree (git_sha);


--
-- Name: idx_migration_history_service; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_migration_history_service ON dos.migration_history USING btree (service_name);


--
-- Name: idx_migration_lock_expires_at; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_migration_lock_expires_at ON dos.migration_lock USING btree (lock_expires_at);


--
-- Name: idx_mkt_footer_grp_brand; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_mkt_footer_grp_brand ON dos.marketing_footer_groups USING btree (brand_code, is_active, sort_order);


--
-- Name: idx_mkt_footer_itm_grp; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_mkt_footer_itm_grp ON dos.marketing_footer_items USING btree (group_id, brand_code, sort_order);


--
-- Name: idx_mkt_nav_brand; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_mkt_nav_brand ON dos.marketing_nav_items USING btree (brand_code, is_active, sort_order);


--
-- Name: idx_mobile_sessions_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_mobile_sessions_tenant ON dos.mobile_sessions USING btree (tenant_id);


--
-- Name: idx_mobile_sessions_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_mobile_sessions_user ON dos.mobile_sessions USING btree (user_id);


--
-- Name: idx_module_readiness_verdict; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_module_readiness_verdict ON dos.module_readiness USING btree (verdict, computed_at DESC);


--
-- Name: idx_module_sod_rules_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_module_sod_rules_module ON dos.module_sod_rules USING btree (module_code, active);


--
-- Name: idx_nav_registry_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_nav_registry_module ON dos.navigation_registry USING btree (module_code);


--
-- Name: idx_nav_registry_parent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_nav_registry_parent ON dos.navigation_registry USING btree (parent_code);


--
-- Name: idx_onboarding_journeys_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_onboarding_journeys_deleted ON dos.onboarding_journeys USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_onboarding_journeys_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_onboarding_journeys_tenant ON dos.onboarding_journeys USING btree (tenant_id);


--
-- Name: idx_onboarding_journeys_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_onboarding_journeys_user ON dos.onboarding_journeys USING btree (user_id);


--
-- Name: idx_onboarding_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_onboarding_tenant ON dos.onboarding_journeys USING btree (tenant_id);


--
-- Name: idx_policies_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_policies_tenant ON dos.policies USING btree (tenant_id);


--
-- Name: idx_pool_slots_hot; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_pool_slots_hot ON dos.module_pool_slots USING btree (module_code, state) WHERE (state = 'hot'::text);


--
-- Name: idx_pool_slots_state; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_pool_slots_state ON dos.module_pool_slots USING btree (state, module_code);


--
-- Name: idx_portals_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_portals_deleted ON dos.portals USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_portals_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_portals_tenant ON dos.portals USING btree (tenant_id);


--
-- Name: idx_privacy_assessments_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_privacy_assessments_deleted ON dos.privacy_assessments USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_privacy_assessments_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_privacy_assessments_tenant ON dos.privacy_assessments USING btree (tenant_id);


--
-- Name: idx_privacy_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_privacy_tenant ON dos.privacy_assessments USING btree (tenant_id);


--
-- Name: idx_product_licenses_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_product_licenses_deleted ON dos.product_licenses USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_product_licenses_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_product_licenses_tenant ON dos.product_licenses USING btree (tenant_id);


--
-- Name: idx_qiyas_journeys_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_qiyas_journeys_tenant ON dos.qiyas_journeys USING btree (tenant_id);


--
-- Name: idx_raci_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_raci_scope ON dos.team_raci_assignments USING btree (scope_type, scope_id);


--
-- Name: idx_raci_team; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_raci_team ON dos.team_raci_assignments USING btree (team_id);


--
-- Name: idx_raci_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_raci_tenant ON dos.team_raci_assignments USING btree (tenant_id);


--
-- Name: idx_raci_unique_assignment; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX idx_raci_unique_assignment ON dos.team_raci_assignments USING btree (tenant_id, team_id, user_id, scope_type, COALESCE(scope_id, '00000000-0000-0000-0000-000000000000'::uuid), raci_role) WHERE (revoked_at IS NULL);


--
-- Name: idx_raci_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_raci_user ON dos.team_raci_assignments USING btree (user_id);


--
-- Name: idx_records_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_records_deleted ON dos.records USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_records_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_records_tenant ON dos.records USING btree (tenant_id);


--
-- Name: idx_records_type; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_records_type ON dos.records USING btree (tenant_id, record_type);


--
-- Name: idx_remediation_actions_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_remediation_actions_tenant ON dos.remediation_actions USING btree (tenant_id);


--
-- Name: idx_remediations_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_remediations_deleted ON dos.remediations USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_remediations_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_remediations_tenant ON dos.remediations USING btree (tenant_id);


--
-- Name: idx_report_schedules_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_report_schedules_tenant ON dos.report_schedules USING btree (tenant_id);


--
-- Name: idx_requirements_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_requirements_tenant ON dos.compliance_requirements USING btree (tenant_id);


--
-- Name: idx_risks_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_risks_deleted ON dos.risks USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_risks_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_risks_status ON dos.risks USING btree (tenant_id, status);


--
-- Name: idx_risks_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_risks_tenant ON dos.risks USING btree (tenant_id);


--
-- Name: idx_sod_conflict_audit_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_sod_conflict_audit_tenant ON dos.sod_conflict_audit USING btree (tenant_id);


--
-- Name: idx_sso_providers_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_sso_providers_tenant ON dos.sso_providers USING btree (tenant_id);


--
-- Name: idx_sso_providers_tenant_protocol; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_sso_providers_tenant_protocol ON dos.sso_providers USING btree (tenant_id, protocol);


--
-- Name: idx_sso_role_mappings_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_sso_role_mappings_tenant ON dos.sso_role_mappings USING btree (tenant_id);


--
-- Name: idx_sso_sessions_expires; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_sso_sessions_expires ON dos.sso_sessions USING btree (expires_at);


--
-- Name: idx_sso_sessions_tenant_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_sso_sessions_tenant_user ON dos.sso_sessions USING btree (tenant_id, user_id);


--
-- Name: idx_system_events_type; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_system_events_type ON dos.system_events USING btree (event_type, occurred_at DESC);


--
-- Name: idx_tenant_kms_config_provider; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_kms_config_provider ON dos.tenant_kms_config USING btree (provider);


--
-- Name: idx_tenant_kms_config_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_kms_config_status ON dos.tenant_kms_config USING btree (status);


--
-- Name: idx_tenant_kms_keys_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_kms_keys_active ON dos.tenant_kms_keys USING btree (tenant_id, scope) WHERE (active = true);


--
-- Name: idx_tenant_kms_keys_kek_ref; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_kms_keys_kek_ref ON dos.tenant_kms_keys USING btree (kek_ref);


--
-- Name: idx_tenant_landing_config_enabled; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_landing_config_enabled ON dos.tenant_landing_config USING btree (enabled);


--
-- Name: idx_tenant_landing_config_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_landing_config_tenant_id ON dos.tenant_landing_config USING btree (tenant_id);


--
-- Name: idx_tenant_module_entitlements_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_module_entitlements_module ON dos.tenant_module_entitlements USING btree (tenant_id, module_code);


--
-- Name: idx_tenant_module_entitlements_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_module_entitlements_status ON dos.tenant_module_entitlements USING btree (entitlement_status);


--
-- Name: idx_tenant_module_entitlements_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_module_entitlements_tenant ON dos.tenant_module_entitlements USING btree (tenant_id);


--
-- Name: idx_tenant_modules_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_modules_status ON dos.tenant_modules USING btree (status, module_code);


--
-- Name: idx_tenant_settings_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_settings_key ON dos.tenant_settings USING btree (key);


--
-- Name: idx_tenant_settings_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_tenant_settings_scope ON dos.tenant_settings USING btree (scope);


--
-- Name: idx_tenant_settings_unique; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX idx_tenant_settings_unique ON dos.tenant_settings USING btree (key, scope, COALESCE(product_key, ''::character varying), COALESCE(module_code, ''::character varying), COALESCE(workspace_id, ''::text), COALESCE(owner_user_id, ''::text));


--
-- Name: idx_training_courses_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_training_courses_tenant ON dos.training_courses USING btree (tenant_id);


--
-- Name: idx_training_enrollments_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_training_enrollments_tenant ON dos.training_enrollments USING btree (tenant_id);


--
-- Name: idx_training_enrollments_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_training_enrollments_user ON dos.training_enrollments USING btree (user_id);


--
-- Name: idx_training_programs_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_training_programs_deleted ON dos.training_programs USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_training_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_training_tenant ON dos.training_programs USING btree (tenant_id);


--
-- Name: idx_user_roles_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_user_roles_tenant ON dos.user_roles USING btree (tenant_id);


--
-- Name: idx_vendors_deleted; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_vendors_deleted ON dos.vendors USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_vendors_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_vendors_status ON dos.vendors USING btree (tenant_id, status);


--
-- Name: idx_vendors_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_vendors_tenant ON dos.vendors USING btree (tenant_id);


--
-- Name: idx_widgets_dashboard; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_widgets_dashboard ON dos.widgets USING btree (dashboard_id);


--
-- Name: idx_widgets_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_widgets_tenant ON dos.widgets USING btree (tenant_id);


--
-- Name: idx_work_items_assigned; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_work_items_assigned ON dos.work_items USING btree (assigned_to);


--
-- Name: idx_work_items_source; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_work_items_source ON dos.work_items USING btree (source, source_id);


--
-- Name: idx_work_items_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_work_items_status ON dos.work_items USING btree (status) WHERE (is_deleted = false);


--
-- Name: idx_work_items_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_work_items_tenant ON dos.work_items USING btree (tenant_id);


--
-- Name: idx_workflow_approvals_instance; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_approvals_instance ON dos.workflow_approvals USING btree (workflow_instance_id);


--
-- Name: idx_workflow_approvals_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_approvals_tenant ON dos.workflow_approvals USING btree (tenant_id);


--
-- Name: idx_workflow_instances_entity; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_instances_entity ON dos.workflow_instances USING btree (entity_type, entity_id);


--
-- Name: idx_workflow_instances_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_instances_status ON dos.workflow_instances USING btree (tenant_id, status);


--
-- Name: idx_workflow_instances_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_instances_tenant ON dos.workflow_instances USING btree (tenant_id);


--
-- Name: idx_workflow_schedules_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_schedules_tenant ON dos.workflow_schedules USING btree (tenant_id);


--
-- Name: idx_workflow_sla_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_sla_tenant ON dos.workflow_sla_configs USING btree (tenant_id);


--
-- Name: idx_workflow_tasks_assigned; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_tasks_assigned ON dos.workflow_tasks USING btree (assigned_to);


--
-- Name: idx_workflow_tasks_instance; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_tasks_instance ON dos.workflow_tasks USING btree (instance_id);


--
-- Name: idx_workflow_tasks_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_tasks_tenant ON dos.workflow_tasks USING btree (tenant_id);


--
-- Name: idx_workflow_tasks_type; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_tasks_type ON dos.workflow_tasks USING btree (task_type);


--
-- Name: idx_workflow_templates_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_templates_active ON dos.workflow_templates USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_workflow_templates_code; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX idx_workflow_templates_code ON dos.workflow_templates USING btree (template_code);


--
-- Name: idx_workspace_config_tenant_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX idx_workspace_config_tenant_key ON dos.workspace_config USING btree (tenant_id, config_key);


--
-- Name: ix_admin_pillar_page_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_admin_pillar_page_route ON dos.admin_pillar_page USING btree (route);


--
-- Name: ix_agent_action_receipts_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_agent_action_receipts_tenant_id ON dos.agent_action_receipts USING btree (tenant_id);


--
-- Name: ix_agent_evidence_links_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_agent_evidence_links_tenant_id ON dos.agent_evidence_links USING btree (tenant_id);


--
-- Name: ix_agent_memory_tenant_agent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_agent_memory_tenant_agent ON dos.agent_memory USING btree (tenant_id, agent_id);


--
-- Name: ix_agent_recommendations_tenant_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_agent_recommendations_tenant_module ON dos.agent_recommendations USING btree (tenant_id, module_code, status);


--
-- Name: ix_agent_runs_tenant_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_agent_runs_tenant_module ON dos.agent_runs USING btree (tenant_id, module_code, started_at DESC);


--
-- Name: ix_ai_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ai_event_record ON dos.ai_event USING btree (record_id, emitted_at);


--
-- Name: ix_ai_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ai_record_status ON dos.ai_record USING btree (record_key, status);


--
-- Name: ix_audit_signoff_tenant_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_audit_signoff_tenant_time ON dos.audit_signoff_ledger USING btree (tenant_id, generated_at DESC);


--
-- Name: ix_audit_signoff_unsigned; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_audit_signoff_unsigned ON dos.audit_signoff_ledger USING btree (tenant_id) WHERE (signed_at IS NULL);


--
-- Name: ix_auth_mfa_otp_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_auth_mfa_otp_active ON dos.auth_mfa_otp USING btree (user_sub, expires_at) WHERE (consumed_at IS NULL);


--
-- Name: ix_auth_mfa_otp_user_sent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_auth_mfa_otp_user_sent ON dos.auth_mfa_otp USING btree (user_sub, sent_at DESC);


--
-- Name: ix_billing_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_billing_event_record ON dos.billing_event USING btree (record_id, emitted_at);


--
-- Name: ix_billing_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_billing_record_status ON dos.billing_record USING btree (record_key, status);


--
-- Name: ix_business_units_organization_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_business_units_organization_id ON dos.business_units USING btree (organization_id);


--
-- Name: ix_compliance_requirements_framework_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_compliance_requirements_framework_id ON dos.compliance_requirements USING btree (framework_id);


--
-- Name: ix_config_audit_logs_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_config_audit_logs_tenant_id ON dos.config_audit_logs USING btree (tenant_id);


--
-- Name: ix_config_locks_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_config_locks_tenant_id ON dos.config_locks USING btree (tenant_id);


--
-- Name: ix_config_runtime_overrides_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_config_runtime_overrides_tenant_id ON dos.config_runtime_overrides USING btree (tenant_id);


--
-- Name: ix_config_values_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_config_values_tenant_id ON dos.config_values USING btree (tenant_id);


--
-- Name: ix_data_governance_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_data_governance_event_record ON dos.data_governance_event USING btree (record_id, emitted_at);


--
-- Name: ix_data_governance_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_data_governance_record_status ON dos.data_governance_record USING btree (record_key, status);


--
-- Name: ix_deployment_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_deployment_event_record ON dos.deployment_event USING btree (record_id, emitted_at);


--
-- Name: ix_deployment_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_deployment_record_status ON dos.deployment_record USING btree (record_key, status);


--
-- Name: ix_dmas_actor_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dmas_actor_active ON dos.dos_master_actor_session USING btree (actor) WHERE (revoked_at IS NULL);


--
-- Name: ix_dmcr_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dmcr_status ON dos.dos_master_change_request USING btree (status, requested_at DESC);


--
-- Name: ix_dmde_open; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dmde_open ON dos.dos_master_drift_event USING btree (source, detected_at DESC) WHERE (resolved_at IS NULL);


--
-- Name: ix_dmil_scope_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dmil_scope_time ON dos.dos_master_invalidation_log USING btree (scope, emitted_at DESC);


--
-- Name: ix_dml_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dml_active ON dos.dos_master_lock USING btree (resource_key) WHERE (released_at IS NULL);


--
-- Name: ix_dmph_target; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dmph_target ON dos.dos_master_publish_handle USING btree (target_kind, target_key);


--
-- Name: ix_dos_departments_parent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_departments_parent ON dos.departments USING btree (parent_id);


--
-- Name: ix_dos_departments_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_departments_tenant ON dos.departments USING btree (tenant_id);


--
-- Name: ix_dos_master_grant_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_master_grant_active ON dos.dos_master_grant USING btree (actor, role_code) WHERE (revoked_at IS NULL);


--
-- Name: ix_dos_master_writer_audit_actor_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_master_writer_audit_actor_time ON dos.dos_master_writer_audit USING btree (actor, occurred_at DESC);


--
-- Name: ix_dos_master_writer_audit_change_request; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_master_writer_audit_change_request ON dos.dos_master_writer_audit USING btree (change_request_id) WHERE (change_request_id IS NOT NULL);


--
-- Name: ix_dos_master_writer_audit_table_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_master_writer_audit_table_time ON dos.dos_master_writer_audit USING btree (table_schema, table_name, occurred_at DESC);


--
-- Name: ix_dos_shell_config_tenant_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_shell_config_tenant_module ON dos.shell_config USING btree (tenant_id, module_code, product_code);


--
-- Name: ix_dos_team_members_team; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_team_members_team ON dos.team_members USING btree (team_id);


--
-- Name: ix_dos_team_members_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_team_members_user ON dos.team_members USING btree (user_id);


--
-- Name: ix_dos_teams_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dos_teams_tenant ON dos.teams USING btree (tenant_id);


--
-- Name: ix_dr_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dr_event_record ON dos.dr_event USING btree (record_id, emitted_at);


--
-- Name: ix_dr_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dr_record_status ON dos.dr_record USING btree (record_key, status);


--
-- Name: ix_dui_quick_actions_surface; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dui_quick_actions_surface ON dos.dynamic_ui_quick_actions USING btree (surface_key, is_active, sort_order);


--
-- Name: ix_dui_setup_steps_tenant_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dui_setup_steps_tenant_active ON dos.dynamic_ui_setup_steps USING btree (tenant_id, is_active, sort_order);


--
-- Name: ix_dui_trial_banner_rules_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dui_trial_banner_rules_active ON dos.dynamic_ui_trial_banner_rules USING btree (is_active, sort_order);


--
-- Name: ix_dui_ws_ai_tips_active_priority; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dui_ws_ai_tips_active_priority ON dos.dynamic_ui_workspace_ai_tips USING btree (is_active, priority);


--
-- Name: ix_dui_ws_grid_columns_scope_visible; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dui_ws_grid_columns_scope_visible ON dos.dynamic_ui_workspace_grid_columns USING btree (scope, is_visible, sort_order);


--
-- Name: ix_dyn_ai_tips_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dyn_ai_tips_module ON dos.dynamic_ui_ai_tips USING btree (module_code, route);


--
-- Name: ix_dyn_comp_reg_approval; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dyn_comp_reg_approval ON dos.dynamic_ui_component_registry USING btree (approval_status);


--
-- Name: ix_dyn_grid_col_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dyn_grid_col_route ON dos.dynamic_ui_grid_columns USING btree (module_code, route);


--
-- Name: ix_dyn_page_hdr_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dyn_page_hdr_module ON dos.dynamic_ui_page_headers USING btree (module_code, route);


--
-- Name: ix_dynamic_ui_component_registry_component_type; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_component_registry_component_type ON dos.dynamic_ui_component_registry USING btree (component_type) WHERE (component_type IS NOT NULL);


--
-- Name: ix_dynamic_ui_component_registry_renderer_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_component_registry_renderer_key ON dos.dynamic_ui_component_registry USING btree (renderer_key) WHERE (renderer_key IS NOT NULL);


--
-- Name: ix_dynamic_ui_navigation_icons_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_navigation_icons_module ON dos.dynamic_ui_navigation_icons USING btree (module_code);


--
-- Name: ix_dynamic_ui_route_metadata_is_public; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_route_metadata_is_public ON dos.dynamic_ui_route_metadata USING btree (is_public) WHERE (is_public = true);


--
-- Name: ix_dynamic_ui_route_metadata_metadata_public; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_route_metadata_metadata_public ON dos.dynamic_ui_route_metadata USING btree (metadata_public) WHERE (metadata_public = true);


--
-- Name: ix_dynamic_ui_route_metadata_render_mode; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_route_metadata_render_mode ON dos.dynamic_ui_route_metadata USING btree (render_mode);


--
-- Name: ix_dynamic_ui_route_permissions_permission; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_dynamic_ui_route_permissions_permission ON dos.dynamic_ui_route_permissions USING btree (permission_key);


--
-- Name: ix_executive_briefings_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_executive_briefings_tenant_id ON dos.executive_briefings USING btree (tenant_id);


--
-- Name: ix_feature_flag_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_feature_flag_event_record ON dos.feature_flag_event USING btree (record_id, emitted_at);


--
-- Name: ix_feature_flag_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_feature_flag_record_status ON dos.feature_flag_record USING btree (record_key, status);


--
-- Name: ix_foundation_cat_bu_templates_sector; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_cat_bu_templates_sector ON dos.foundation_cat_bu_templates USING btree (sector_code) WHERE (is_active = true);


--
-- Name: ix_foundation_cat_committee_templates_sector; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_cat_committee_templates_sector ON dos.foundation_cat_committee_templates USING btree (sector_code) WHERE (is_active = true);


--
-- Name: ix_foundation_cat_dept_templates_sector; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_cat_dept_templates_sector ON dos.foundation_cat_dept_templates USING btree (sector_code) WHERE (is_active = true);


--
-- Name: ix_foundation_cat_position_templates_sector; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_cat_position_templates_sector ON dos.foundation_cat_position_templates USING btree (sector_code) WHERE (is_active = true);


--
-- Name: ix_foundation_cat_reference_cat; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_cat_reference_cat ON dos.foundation_cat_reference USING btree (category) WHERE (is_active = true);


--
-- Name: ix_foundation_cat_role_templates_sector; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_cat_role_templates_sector ON dos.foundation_cat_role_templates USING btree (sector_code) WHERE (is_active = true);


--
-- Name: ix_foundation_coi_pending_review; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_coi_pending_review ON dos.foundation_coi_declarations USING btree (tenant_id, has_conflicts, review_decision) WHERE ((has_conflicts = true) AND (reviewed_at IS NULL));


--
-- Name: ix_foundation_coi_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_coi_user ON dos.foundation_coi_declarations USING btree (tenant_id, user_id);


--
-- Name: ix_foundation_lifecycle_state_due; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_state_due ON dos.foundation_employee_lifecycle_state USING btree (tenant_id, state, state_due_by) WHERE (state_due_by IS NOT NULL);


--
-- Name: ix_foundation_lifecycle_state_state; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_state_state ON dos.foundation_employee_lifecycle_state USING btree (tenant_id, state);


--
-- Name: ix_foundation_lifecycle_tasks_assigned; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_tasks_assigned ON dos.foundation_employee_lifecycle_tasks USING btree (tenant_id, assigned_to, status) WHERE (assigned_to IS NOT NULL);


--
-- Name: ix_foundation_lifecycle_tasks_due; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_tasks_due ON dos.foundation_employee_lifecycle_tasks USING btree (tenant_id, due_at) WHERE (status = ANY (ARRAY['open'::text, 'in_progress'::text, 'blocked'::text]));


--
-- Name: ix_foundation_lifecycle_tasks_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_tasks_user ON dos.foundation_employee_lifecycle_tasks USING btree (tenant_id, user_id, status);


--
-- Name: ix_foundation_lifecycle_transitions_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_transitions_user ON dos.foundation_employee_lifecycle_transitions USING btree (tenant_id, user_id, occurred_at DESC);


--
-- Name: ix_foundation_lifecycle_transitions_workflow; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_transitions_workflow ON dos.foundation_employee_lifecycle_transitions USING btree (tenant_id, workflow_id) WHERE (workflow_id IS NOT NULL);


--
-- Name: ix_foundation_lifecycle_workflows_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_lifecycle_workflows_active ON dos.foundation_employee_lifecycle_workflows USING btree (workflow_code) WHERE (is_active = true);


--
-- Name: ix_foundation_policy_ack_overdue; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_policy_ack_overdue ON dos.foundation_policy_acknowledgments USING btree (tenant_id, due_at) WHERE (acknowledged_at IS NULL);


--
-- Name: ix_foundation_policy_ack_policy; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_policy_ack_policy ON dos.foundation_policy_acknowledgments USING btree (tenant_id, policy_id, policy_version);


--
-- Name: ix_foundation_policy_ack_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_policy_ack_user ON dos.foundation_policy_acknowledgments USING btree (tenant_id, user_id);


--
-- Name: ix_foundation_position_authority; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_position_authority ON dos.foundation_position_authority USING btree (tenant_id, position_id);


--
-- Name: ix_foundation_position_authority_kind; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_position_authority_kind ON dos.foundation_position_authority USING btree (tenant_id, authority_kind);


--
-- Name: ix_foundation_sod_rules_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_sod_rules_active ON dos.foundation_sod_rules USING btree (tenant_id, is_active) WHERE (is_active = true);


--
-- Name: ix_foundation_sod_violations_open; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_sod_violations_open ON dos.foundation_sod_violations USING btree (tenant_id, resolution, severity) WHERE (resolution = 'open'::text);


--
-- Name: ix_foundation_sod_violations_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_sod_violations_user ON dos.foundation_sod_violations USING btree (tenant_id, user_id);


--
-- Name: ix_foundation_training_assignments_course; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_training_assignments_course ON dos.foundation_training_assignments USING btree (tenant_id, course_code);


--
-- Name: ix_foundation_training_assignments_due; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_training_assignments_due ON dos.foundation_training_assignments USING btree (tenant_id, due_at) WHERE (status = ANY (ARRAY['assigned'::text, 'in_progress'::text, 'overdue'::text]));


--
-- Name: ix_foundation_training_assignments_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_foundation_training_assignments_user ON dos.foundation_training_assignments USING btree (tenant_id, user_id, status);


--
-- Name: ix_integration_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_integration_event_record ON dos.integration_event USING btree (record_id, emitted_at);


--
-- Name: ix_integration_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_integration_record_status ON dos.integration_record USING btree (record_key, status);


--
-- Name: ix_job_executions_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_job_executions_tenant_id ON dos.job_executions USING btree (tenant_id);


--
-- Name: ix_lifecycle_auth_log_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_lifecycle_auth_log_tenant_id ON dos.lifecycle_auth_log USING btree (tenant_id);


--
-- Name: ix_location_bu_map_bu_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_location_bu_map_bu_id ON dos.location_bu_map USING btree (bu_id);


--
-- Name: ix_location_bu_map_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_location_bu_map_tenant_id ON dos.location_bu_map USING btree (tenant_id);


--
-- Name: ix_login_attempts_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_login_attempts_tenant_id ON dos.login_attempts USING btree (tenant_id);


--
-- Name: ix_marketplace_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_marketplace_event_record ON dos.marketplace_event USING btree (record_id, emitted_at);


--
-- Name: ix_marketplace_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_marketplace_record_status ON dos.marketplace_record USING btree (record_key, status);


--
-- Name: ix_mce_module_phase; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_mce_module_phase ON dos.module_contract_errors USING btree (module_code, phase, created_at DESC);


--
-- Name: ix_mcpl_module_applied; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_mcpl_module_applied ON dos.module_contract_publish_log USING btree (module_code, applied_at DESC);


--
-- Name: ix_notification_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_notification_event_record ON dos.notification_event USING btree (record_id, emitted_at);


--
-- Name: ix_notification_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_notification_record_status ON dos.notification_record USING btree (record_key, status);


--
-- Name: ix_platform_audit_logs_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_platform_audit_logs_tenant_id ON dos.platform_audit_logs USING btree (tenant_id);


--
-- Name: ix_platform_drift_log_metric_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_platform_drift_log_metric_time ON dos.platform_drift_log USING btree (metric_key, sampled_at DESC);


--
-- Name: ix_platform_drift_log_severity_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_platform_drift_log_severity_time ON dos.platform_drift_log USING btree (severity, sampled_at DESC) WHERE (severity <> 'info'::text);


--
-- Name: ix_platform_secret_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_platform_secret_tenant ON dos.platform_secret USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


--
-- Name: ix_platform_slo_event_svc_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_platform_slo_event_svc_time ON dos.platform_slo_event USING btree (service_code, probed_at DESC);


--
-- Name: ix_positions_bu_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_positions_bu_id ON dos.positions USING btree (bu_id);


--
-- Name: ix_pr_target_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_pr_target_status ON dos.publish_revision USING btree (target_kind, target_key, status);


--
-- Name: ix_re_ring_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_re_ring_time ON dos.rollout_evaluation USING btree (ring_id, evaluated_at DESC);


--
-- Name: ix_release_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_release_event_record ON dos.release_event USING btree (record_id, emitted_at);


--
-- Name: ix_release_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_release_record_status ON dos.release_record USING btree (record_key, status);


--
-- Name: ix_role_profile_lifecycle; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_role_profile_lifecycle ON dos.role_profile_sync USING btree (lifecycle_state) WHERE ((lifecycle_state)::text <> 'active'::text);


--
-- Name: ix_role_profile_tenant_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_role_profile_tenant_user ON dos.role_profile_sync USING btree (tenant_id, user_id);


--
-- Name: ix_rps_log_occurred; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_rps_log_occurred ON dos.role_profile_sync_log USING btree (occurred_at DESC);


--
-- Name: ix_rps_log_outcome_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_rps_log_outcome_time ON dos.role_profile_sync_log USING btree (outcome, occurred_at DESC) WHERE ((outcome)::text <> 'ok'::text);


--
-- Name: ix_rr_plan_order; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_rr_plan_order ON dos.rollout_ring USING btree (plan_id, ring_order);


--
-- Name: ix_schema_authoring_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_schema_authoring_event_record ON dos.schema_authoring_event USING btree (record_id, emitted_at);


--
-- Name: ix_schema_authoring_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_schema_authoring_record_status ON dos.schema_authoring_record USING btree (record_key, status);


--
-- Name: ix_security_secret_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_security_secret_event_record ON dos.security_secret_event USING btree (record_id, emitted_at);


--
-- Name: ix_security_secret_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_security_secret_record_status ON dos.security_secret_record USING btree (record_key, status);


--
-- Name: ix_telemetry_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_telemetry_event_record ON dos.telemetry_event USING btree (record_id, emitted_at);


--
-- Name: ix_telemetry_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_telemetry_record_status ON dos.telemetry_record USING btree (record_key, status);


--
-- Name: ix_tenant_config_versions_legacy_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_config_versions_legacy_tenant_id ON dos.tenant_config_versions_legacy USING btree (tenant_id);


--
-- Name: ix_tenant_feature_flag_overrides_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_feature_flag_overrides_tenant_id ON dos.tenant_feature_flag_overrides USING btree (tenant_id);


--
-- Name: ix_tenant_memberships_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_memberships_tenant_id ON dos.tenant_memberships USING btree (tenant_id);


--
-- Name: ix_tenant_migrations_applied_at; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_migrations_applied_at ON dos.tenant_migrations USING btree (applied_at DESC);


--
-- Name: ix_tenant_migrations_migration_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_migrations_migration_status ON dos.tenant_migrations USING btree (migration_id, status);


--
-- Name: ix_tenant_migrations_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_migrations_tenant_id ON dos.tenant_migrations USING btree (tenant_id);


--
-- Name: ix_tenant_migrations_tenant_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_migrations_tenant_status ON dos.tenant_migrations USING btree (tenant_id, status);


--
-- Name: ix_tenant_product_activation_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_product_activation_tenant_id ON dos.tenant_product_activation USING btree (tenant_id);


--
-- Name: ix_tenant_settings_legacy_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_tenant_settings_legacy_tenant_id ON dos.tenant_settings_legacy USING btree (tenant_id);


--
-- Name: ix_training_enrollments_course_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_training_enrollments_course_id ON dos.training_enrollments USING btree (course_id);


--
-- Name: ix_ui_admin_activity_log_actor; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_admin_activity_log_actor ON dos.ui_admin_activity_log USING btree (tenant_id, actor_id, occurred_at DESC);


--
-- Name: ix_ui_carbon_components_integration; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_carbon_components_integration ON dos.ui_carbon_components USING btree (integration_mode);


--
-- Name: ix_ui_carbon_components_package; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_carbon_components_package ON dos.ui_carbon_components USING btree (package_name);


--
-- Name: ix_ui_carbon_components_runtime; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_carbon_components_runtime ON dos.ui_carbon_components USING btree (runtime_status);


--
-- Name: ix_ui_carbon_components_vendor_pkg; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_carbon_components_vendor_pkg ON dos.ui_carbon_components USING btree (vendor, package_name);


--
-- Name: ix_ui_draft_versions_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_draft_versions_active ON dos.ui_draft_versions USING btree (tenant_id, target_kind, target_id) WHERE (is_active = true);


--
-- Name: ix_ui_module_nav_group_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_module_nav_group_module ON dos.ui_module_nav_group USING btree (module_code, sort_order);


--
-- Name: ix_ui_module_nav_item_module_group; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_module_nav_item_module_group ON dos.ui_module_nav_item USING btree (module_code, group_id, sort_order);


--
-- Name: ix_ui_module_nav_override_tenant_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_module_nav_override_tenant_module ON dos.ui_module_nav_override_tenant USING btree (tenant_id, module_code);


--
-- Name: ix_ui_module_nav_override_user_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_module_nav_override_user_module ON dos.ui_module_nav_override_user USING btree (user_id, module_code);


--
-- Name: ix_ui_override_tenant_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_override_tenant_route ON dos.ui_override_tenant USING btree (route);


--
-- Name: ix_ui_override_user_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_override_user_route ON dos.ui_override_user USING btree (route);


--
-- Name: ix_ui_published_versions_current; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_published_versions_current ON dos.ui_published_versions USING btree (tenant_id, target_kind, target_id) WHERE (is_current = true);


--
-- Name: ix_ui_rollback_points_target; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_rollback_points_target ON dos.ui_rollback_points USING btree (tenant_id, target_kind, target_id, created_at DESC);


--
-- Name: ix_ui_route_agent_flow_step_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_agent_flow_step_route ON dos.ui_route_agent_flow_step USING btree (route);


--
-- Name: ix_ui_route_agent_registry_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_agent_registry_route ON dos.ui_route_agent_registry USING btree (route);


--
-- Name: ix_ui_route_audit_evidence_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_audit_evidence_route ON dos.ui_route_audit_evidence_artifact USING btree (route);


--
-- Name: ix_ui_route_audit_ledger_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_audit_ledger_route ON dos.ui_route_audit_ledger_row USING btree (route);


--
-- Name: ix_ui_route_audit_ledger_time; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_audit_ledger_time ON dos.ui_route_audit_ledger_row USING btree (occurred_at);


--
-- Name: ix_ui_route_calendar_event_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_calendar_event_route ON dos.ui_route_calendar_event USING btree (route);


--
-- Name: ix_ui_route_calendar_event_starts; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_calendar_event_starts ON dos.ui_route_calendar_event USING btree (starts_at);


--
-- Name: ix_ui_route_case_finalization_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_case_finalization_route ON dos.ui_route_case_finalization USING btree (route);


--
-- Name: ix_ui_route_case_finalization_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_case_finalization_status ON dos.ui_route_case_finalization USING btree (status);


--
-- Name: ix_ui_route_column_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_column_route ON dos.ui_route_column USING btree (route);


--
-- Name: ix_ui_route_delegation_rule_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_delegation_rule_route ON dos.ui_route_delegation_rule USING btree (route);


--
-- Name: ix_ui_route_export_artifact_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_export_artifact_route ON dos.ui_route_export_artifact USING btree (route);


--
-- Name: ix_ui_route_follow_up_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_follow_up_route ON dos.ui_route_follow_up_item USING btree (route);


--
-- Name: ix_ui_route_incident_comm_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_incident_comm_route ON dos.ui_route_incident_communication USING btree (route);


--
-- Name: ix_ui_route_incident_runbook_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_incident_runbook_route ON dos.ui_route_incident_runbook_step USING btree (route);


--
-- Name: ix_ui_route_kpi_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_kpi_route ON dos.ui_route_kpi USING btree (route);


--
-- Name: ix_ui_route_nba_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_nba_route ON dos.ui_route_nba USING btree (route);


--
-- Name: ix_ui_route_org_chart_parent; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_org_chart_parent ON dos.ui_route_org_chart_node USING btree (route, parent_id);


--
-- Name: ix_ui_route_org_chart_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_org_chart_route ON dos.ui_route_org_chart_node USING btree (route);


--
-- Name: ix_ui_route_ownership_edge_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_ownership_edge_route ON dos.ui_route_ownership_edge USING btree (route);


--
-- Name: ix_ui_route_roadmap_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_roadmap_route ON dos.ui_route_roadmap_milestone USING btree (route);


--
-- Name: ix_ui_route_wf_timeline_route; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_route_wf_timeline_route ON dos.ui_route_workflow_timeline_step USING btree (route);


--
-- Name: ix_ui_service_registry_module; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_service_registry_module ON dos.ui_service_registry USING btree (module_code);


--
-- Name: ix_ui_service_registry_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_service_registry_status ON dos.ui_service_registry USING btree (registry_status);


--
-- Name: ix_ui_workspace_banner_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_workspace_banner_tenant ON dos.ui_workspace_banner USING btree (tenant_id, sort_order) WHERE (enabled = true);


--
-- Name: ix_ui_workspace_chrome_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_workspace_chrome_tenant ON dos.ui_workspace_chrome USING btree (tenant_id) WHERE (enabled = true);


--
-- Name: ix_ui_workspace_policy_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_workspace_policy_tenant ON dos.ui_workspace_policy USING btree (tenant_id) WHERE (enabled = true);


--
-- Name: ix_ui_workspace_shortcut_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_ui_workspace_shortcut_tenant ON dos.ui_workspace_shortcut USING btree (tenant_id, sort_order) WHERE (enabled = true);


--
-- Name: ix_user_org_scope_tenant_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_user_org_scope_tenant_user ON dos.user_org_scope USING btree (tenant_id, user_id);


--
-- Name: ix_vendor_risk_event_record; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_vendor_risk_event_record ON dos.vendor_risk_event USING btree (record_id, emitted_at);


--
-- Name: ix_vendor_risk_record_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_vendor_risk_record_status ON dos.vendor_risk_record USING btree (record_key, status);


--
-- Name: ix_workflow_definition_key_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workflow_definition_key_status ON dos.workflow_definition USING btree (workflow_key, status);


--
-- Name: ix_workflow_event_instance; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workflow_event_instance ON dos.workflow_event USING btree (instance_id, emitted_at);


--
-- Name: ix_workflow_instance_status; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workflow_instance_status ON dos.workflow_instance USING btree (workflow_id, status);


--
-- Name: ix_workflow_instance_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workflow_instance_tenant ON dos.workflow_instance USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


--
-- Name: ix_workflow_step_run_instance; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workflow_step_run_instance ON dos.workflow_step_run USING btree (instance_id, started_at);


--
-- Name: ix_workflow_templates_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workflow_templates_tenant_id ON dos.workflow_templates USING btree (tenant_id);


--
-- Name: ix_workspace_shell_binding_tenant; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workspace_shell_binding_tenant ON dos.workspace_shell_binding USING btree (tenant_id);


--
-- Name: ix_workspaces_tenant_id; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_workspaces_tenant_id ON dos.workspaces USING btree (tenant_id);


--
-- Name: ix_wsi_ns_locale; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX ix_wsi_ns_locale ON dos.workspace_shell_i18n USING btree (ns, locale);


--
-- Name: marketing_brand_assets_match_uq; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX marketing_brand_assets_match_uq ON dos.marketing_brand_assets USING btree (brand_code, asset_kind, theme, COALESCE(locale, ''::text), COALESCE(direction, ''::text), COALESCE(asset_code, ''::text)) WHERE (active = true);


--
-- Name: marketing_download_events_asset_idx; Type: INDEX; Schema: dos; Owner: -
--

CREATE INDEX marketing_download_events_asset_idx ON dos.marketing_download_events USING btree (asset_key, occurred_at DESC);


--
-- Name: platform_operation_config_config_key_uk; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX platform_operation_config_config_key_uk ON dos.platform_operation_config USING btree (config_key);


--
-- Name: uq_dos_ai_agent_registry_agent_code; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX uq_dos_ai_agent_registry_agent_code ON dos.ai_agent_registry USING btree (agent_code);


--
-- Name: uq_governance_policies_tenant_code; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX uq_governance_policies_tenant_code ON dos.governance_policies USING btree (tenant_id, code) WHERE ((deleted_at IS NULL) AND (code IS NOT NULL));


--
-- Name: uq_tenant_module_entitlements_active; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX uq_tenant_module_entitlements_active ON dos.tenant_module_entitlements USING btree (tenant_id, product_code, module_code) WHERE ((entitlement_status)::text = 'active'::text);


--
-- Name: uq_tenant_modules_idem; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX uq_tenant_modules_idem ON dos.tenant_modules USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: ux_config_definitions_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_config_definitions_key ON dos.config_definitions USING btree (config_key);


--
-- Name: ux_dos_shell_config_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dos_shell_config_scope ON dos.shell_config USING btree (tenant_id, scope_type, COALESCE(scope_key, ''::character varying), module_code, COALESCE(product_code, ''::character varying));


--
-- Name: ux_dos_team_members_team_user; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dos_team_members_team_user ON dos.team_members USING btree (team_id, user_id);


--
-- Name: ux_dos_teams_tenant_code; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dos_teams_tenant_code ON dos.teams USING btree (tenant_id, team_code);


--
-- Name: ux_dui_health_probes_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dui_health_probes_scope ON dos.dynamic_ui_health_probes USING btree (probe_key, COALESCE(tenant_id, '*'::character varying));


--
-- Name: ux_dui_quick_actions_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dui_quick_actions_scope ON dos.dynamic_ui_quick_actions USING btree (surface_key, action_key, COALESCE(tenant_id, '*'::character varying));


--
-- Name: ux_dui_setup_steps_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dui_setup_steps_scope ON dos.dynamic_ui_setup_steps USING btree (step_key, COALESCE(tenant_id, '*'::character varying));


--
-- Name: ux_dui_ws_ai_tips_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dui_ws_ai_tips_scope ON dos.dynamic_ui_workspace_ai_tips USING btree (tip_key, COALESCE(tenant_id, '*'::character varying));


--
-- Name: ux_dui_ws_grid_columns_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dui_ws_grid_columns_scope ON dos.dynamic_ui_workspace_grid_columns USING btree (scope, col_key, COALESCE(tenant_id, '*'::character varying));


--
-- Name: ux_dui_ws_page_headers_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_dui_ws_page_headers_scope ON dos.dynamic_ui_workspace_page_headers USING btree (route_key, COALESCE(tenant_id, '*'::character varying));


--
-- Name: ux_mv_workspace_bootstrap_key; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_mv_workspace_bootstrap_key ON dos.mv_workspace_bootstrap USING btree (tenant_id, ui_catalog_version);


--
-- Name: ux_platform_secret_key_scope; Type: INDEX; Schema: dos; Owner: -
--

CREATE UNIQUE INDEX ux_platform_secret_key_scope ON dos.platform_secret USING btree (secret_key, scope, COALESCE(tenant_id, ''::character varying));


--
-- Name: ui_module_nav_group trg_bump_ui_module_nav_group_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_module_nav_group_version BEFORE UPDATE ON dos.ui_module_nav_group FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_module_nav_item trg_bump_ui_module_nav_item_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_module_nav_item_version BEFORE UPDATE ON dos.ui_module_nav_item FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_module_nav_override_tenant trg_bump_ui_module_nav_override_tenant_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_module_nav_override_tenant_version BEFORE UPDATE ON dos.ui_module_nav_override_tenant FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_module_nav_override_user trg_bump_ui_module_nav_override_user_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_module_nav_override_user_version BEFORE UPDATE ON dos.ui_module_nav_override_user FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_override_module trg_bump_ui_override_module_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_override_module_version BEFORE UPDATE ON dos.ui_override_module FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_override_product trg_bump_ui_override_product_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_override_product_version BEFORE UPDATE ON dos.ui_override_product FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_override_tenant trg_bump_ui_override_tenant_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_override_tenant_version BEFORE UPDATE ON dos.ui_override_tenant FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_override_user trg_bump_ui_override_user_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_override_user_version BEFORE UPDATE ON dos.ui_override_user FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_override_version();


--
-- Name: ui_route_template_binding trg_bump_ui_route_template_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_ui_route_template_version BEFORE UPDATE ON dos.ui_route_template_binding FOR EACH ROW EXECUTE FUNCTION dos.bump_ui_route_template_version();


--
-- Name: workspace_shell_binding trg_bump_workspace_shell_binding_version; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_bump_workspace_shell_binding_version BEFORE UPDATE ON dos.workspace_shell_binding FOR EACH ROW EXECUTE FUNCTION dos.bump_workspace_shell_binding_version();


--
-- Name: ui_carbon_components trg_carbon_only_catalog; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_carbon_only_catalog BEFORE INSERT OR UPDATE ON dos.ui_carbon_components FOR EACH ROW EXECUTE FUNCTION dos.fn_block_non_ibm_catalog_row();


--
-- Name: dynamic_ui_component_registry trg_carbon_only_runtime; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_carbon_only_runtime BEFORE INSERT OR UPDATE ON dos.dynamic_ui_component_registry FOR EACH ROW EXECUTE FUNCTION dos.fn_block_non_ibm_runtime_row();


--
-- Name: ui_dos_component_carbon_map trg_dos_component_carbon_map_check; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_component_carbon_map_check BEFORE INSERT OR UPDATE ON dos.ui_dos_component_carbon_map FOR EACH ROW EXECUTE FUNCTION dos.fn_dos_component_carbon_map_check();


--
-- Name: admin_pillar trg_dos_master_only_admin_pillar; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_admin_pillar BEFORE INSERT OR DELETE OR UPDATE ON dos.admin_pillar FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: admin_pillar_page trg_dos_master_only_admin_pillar_page; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_admin_pillar_page BEFORE INSERT OR DELETE OR UPDATE ON dos.admin_pillar_page FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: admin_pillar_widget trg_dos_master_only_admin_pillar_widget; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_admin_pillar_widget BEFORE INSERT OR DELETE OR UPDATE ON dos.admin_pillar_widget FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: ai_event trg_dos_master_only_ai_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_ai_event BEFORE INSERT OR DELETE OR UPDATE ON dos.ai_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: ai_record trg_dos_master_only_ai_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_ai_record BEFORE INSERT OR DELETE OR UPDATE ON dos.ai_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: billing_event trg_dos_master_only_billing_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_billing_event BEFORE INSERT OR DELETE OR UPDATE ON dos.billing_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: billing_record trg_dos_master_only_billing_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_billing_record BEFORE INSERT OR DELETE OR UPDATE ON dos.billing_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: data_governance_event trg_dos_master_only_data_governance_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_data_governance_event BEFORE INSERT OR DELETE OR UPDATE ON dos.data_governance_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: data_governance_record trg_dos_master_only_data_governance_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_data_governance_record BEFORE INSERT OR DELETE OR UPDATE ON dos.data_governance_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: deployment_event trg_dos_master_only_deployment_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_deployment_event BEFORE INSERT OR DELETE OR UPDATE ON dos.deployment_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: deployment_record trg_dos_master_only_deployment_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_deployment_record BEFORE INSERT OR DELETE OR UPDATE ON dos.deployment_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_actor_session trg_dos_master_only_dos_master_actor_session; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_actor_session BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_actor_session FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_change_request trg_dos_master_only_dos_master_change_request; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_change_request BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_change_request FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_compensation_chain trg_dos_master_only_dos_master_compensation_chain; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_compensation_chain BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_compensation_chain FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_drift_event trg_dos_master_only_dos_master_drift_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_drift_event BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_drift_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_invalidation_log trg_dos_master_only_dos_master_invalidation_log; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_invalidation_log BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_invalidation_log FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_lock trg_dos_master_only_dos_master_lock; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_lock BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_lock FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_publish_handle trg_dos_master_only_dos_master_publish_handle; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dos_master_publish_handle BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_publish_handle FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dr_event trg_dos_master_only_dr_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dr_event BEFORE INSERT OR DELETE OR UPDATE ON dos.dr_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dr_record trg_dos_master_only_dr_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_dr_record BEFORE INSERT OR DELETE OR UPDATE ON dos.dr_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: feature_flag_event trg_dos_master_only_feature_flag_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_feature_flag_event BEFORE INSERT OR DELETE OR UPDATE ON dos.feature_flag_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: feature_flag_record trg_dos_master_only_feature_flag_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_feature_flag_record BEFORE INSERT OR DELETE OR UPDATE ON dos.feature_flag_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_grant trg_dos_master_only_grant; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_grant BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_grant FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: integration_event trg_dos_master_only_integration_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_integration_event BEFORE INSERT OR DELETE OR UPDATE ON dos.integration_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: integration_record trg_dos_master_only_integration_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_integration_record BEFORE INSERT OR DELETE OR UPDATE ON dos.integration_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: marketplace_event trg_dos_master_only_marketplace_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_marketplace_event BEFORE INSERT OR DELETE OR UPDATE ON dos.marketplace_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: marketplace_record trg_dos_master_only_marketplace_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_marketplace_record BEFORE INSERT OR DELETE OR UPDATE ON dos.marketplace_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: notification_event trg_dos_master_only_notification_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_notification_event BEFORE INSERT OR DELETE OR UPDATE ON dos.notification_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: notification_record trg_dos_master_only_notification_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_notification_record BEFORE INSERT OR DELETE OR UPDATE ON dos.notification_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: platform_slo trg_dos_master_only_platform_slo; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_platform_slo BEFORE INSERT OR DELETE OR UPDATE ON dos.platform_slo FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only_platform_slo();


--
-- Name: platform_slo_event trg_dos_master_only_platform_slo_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_platform_slo_event BEFORE INSERT OR DELETE OR UPDATE ON dos.platform_slo_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only_platform_slo_event();


--
-- Name: publish_dependency trg_dos_master_only_publish_dependency; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_publish_dependency BEFORE INSERT OR DELETE OR UPDATE ON dos.publish_dependency FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: publish_revision trg_dos_master_only_publish_revision; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_publish_revision BEFORE INSERT OR DELETE OR UPDATE ON dos.publish_revision FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: publish_rollback trg_dos_master_only_publish_rollback; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_publish_rollback BEFORE INSERT OR DELETE OR UPDATE ON dos.publish_rollback FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: publish_target trg_dos_master_only_publish_target; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_publish_target BEFORE INSERT OR DELETE OR UPDATE ON dos.publish_target FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: release_event trg_dos_master_only_release_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_release_event BEFORE INSERT OR DELETE OR UPDATE ON dos.release_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: release_record trg_dos_master_only_release_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_release_record BEFORE INSERT OR DELETE OR UPDATE ON dos.release_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: dos_master_role trg_dos_master_only_role; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_role BEFORE INSERT OR DELETE OR UPDATE ON dos.dos_master_role FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_cohort trg_dos_master_only_rollout_cohort; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_cohort BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_cohort FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_compensation_step trg_dos_master_only_rollout_compensation_step; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_compensation_step BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_compensation_step FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_evaluation trg_dos_master_only_rollout_evaluation; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_evaluation BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_evaluation FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_health_gate trg_dos_master_only_rollout_health_gate; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_health_gate BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_health_gate FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_plan trg_dos_master_only_rollout_plan; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_plan BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_plan FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_ring trg_dos_master_only_rollout_ring; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_ring BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_ring FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_rollback trg_dos_master_only_rollout_rollback; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_rollback BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_rollback FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: rollout_signal_threshold trg_dos_master_only_rollout_signal_threshold; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_rollout_signal_threshold BEFORE INSERT OR DELETE OR UPDATE ON dos.rollout_signal_threshold FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: schema_authoring_event trg_dos_master_only_schema_authoring_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_schema_authoring_event BEFORE INSERT OR DELETE OR UPDATE ON dos.schema_authoring_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: schema_authoring_record trg_dos_master_only_schema_authoring_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_schema_authoring_record BEFORE INSERT OR DELETE OR UPDATE ON dos.schema_authoring_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: security_secret_event trg_dos_master_only_security_secret_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_security_secret_event BEFORE INSERT OR DELETE OR UPDATE ON dos.security_secret_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: security_secret_record trg_dos_master_only_security_secret_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_security_secret_record BEFORE INSERT OR DELETE OR UPDATE ON dos.security_secret_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: platform_session_policy trg_dos_master_only_session_policy; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_session_policy BEFORE INSERT OR DELETE OR UPDATE ON dos.platform_session_policy FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only_session_policy();


--
-- Name: telemetry_event trg_dos_master_only_telemetry_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_telemetry_event BEFORE INSERT OR DELETE OR UPDATE ON dos.telemetry_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: telemetry_record trg_dos_master_only_telemetry_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_telemetry_record BEFORE INSERT OR DELETE OR UPDATE ON dos.telemetry_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: vendor_risk_event trg_dos_master_only_vendor_risk_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_vendor_risk_event BEFORE INSERT OR DELETE OR UPDATE ON dos.vendor_risk_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: vendor_risk_record trg_dos_master_only_vendor_risk_record; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_vendor_risk_record BEFORE INSERT OR DELETE OR UPDATE ON dos.vendor_risk_record FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: workflow_definition trg_dos_master_only_workflow_workflow_definition; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_workflow_workflow_definition BEFORE INSERT OR DELETE OR UPDATE ON dos.workflow_definition FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: workflow_event trg_dos_master_only_workflow_workflow_event; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_workflow_workflow_event BEFORE INSERT OR DELETE OR UPDATE ON dos.workflow_event FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: workflow_instance trg_dos_master_only_workflow_workflow_instance; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_workflow_workflow_instance BEFORE INSERT OR DELETE OR UPDATE ON dos.workflow_instance FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: workflow_step_run trg_dos_master_only_workflow_workflow_step_run; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_dos_master_only_workflow_workflow_step_run BEFORE INSERT OR DELETE OR UPDATE ON dos.workflow_step_run FOR EACH ROW EXECUTE FUNCTION dos.trg_dos_master_only();


--
-- Name: i18n_fallback_values trg_i18n_fallback_values_updated_at; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_i18n_fallback_values_updated_at BEFORE UPDATE ON dos.i18n_fallback_values FOR EACH ROW EXECUTE FUNCTION dos.update_i18n_fallback_values_updated_at();


--
-- Name: module_contract_publish_log trg_published_by_only; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_published_by_only BEFORE INSERT OR UPDATE ON dos.module_contract_publish_log FOR EACH ROW EXECUTE FUNCTION dos.assert_published_by_only();


--
-- Name: workspace_shell_i18n trg_published_by_only; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_published_by_only BEFORE INSERT OR UPDATE ON dos.workspace_shell_i18n FOR EACH ROW EXECUTE FUNCTION dos.assert_published_by_only();


--
-- Name: workspace_shell_status_label trg_published_by_only; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_published_by_only BEFORE INSERT OR UPDATE ON dos.workspace_shell_status_label FOR EACH ROW EXECUTE FUNCTION dos.assert_published_by_only();


--
-- Name: role_profile_sync trg_role_profile_project; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_role_profile_project AFTER INSERT OR DELETE OR UPDATE ON dos.role_profile_sync FOR EACH ROW EXECUTE FUNCTION dos.fn_role_profile_project_to_ura();


--
-- Name: role_profile_sync trg_role_profile_touch; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_role_profile_touch BEFORE INSERT OR UPDATE ON dos.role_profile_sync FOR EACH ROW EXECUTE FUNCTION dos.fn_role_profile_touch_updated_at();


--
-- Name: tenants trg_seed_workspace_shell_binding; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_seed_workspace_shell_binding AFTER INSERT ON dos.tenants FOR EACH ROW EXECUTE FUNCTION dos.seed_workspace_shell_binding_for_tenant();


--
-- Name: tenant_landing_config trg_tenant_landing_config_updated_at; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_tenant_landing_config_updated_at BEFORE UPDATE ON dos.tenant_landing_config FOR EACH ROW EXECUTE FUNCTION dos.update_tenant_landing_config_updated_at();


--
-- Name: dynamic_ui_component_registry trg_validate_carbon_key; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_validate_carbon_key BEFORE INSERT OR UPDATE OF carbon_key ON dos.dynamic_ui_component_registry FOR EACH ROW EXECUTE FUNCTION dos.validate_carbon_key_exists();


--
-- Name: ui_route_template_binding trg_validate_template_export; Type: TRIGGER; Schema: dos; Owner: -
--

CREATE TRIGGER trg_validate_template_export BEFORE INSERT OR UPDATE OF template_export ON dos.ui_route_template_binding FOR EACH ROW EXECUTE FUNCTION dos.validate_template_export_registry();


--
-- Name: access_review_items access_review_items_review_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.access_review_items
    ADD CONSTRAINT access_review_items_review_id_fkey FOREIGN KEY (review_id) REFERENCES dos.access_reviews(review_id) ON DELETE CASCADE;


--
-- Name: action_items action_items_remediation_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.action_items
    ADD CONSTRAINT action_items_remediation_id_fkey FOREIGN KEY (remediation_id) REFERENCES dos.remediations(remediation_id);


--
-- Name: admin_pillar_page admin_pillar_page_pillar_code_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar_page
    ADD CONSTRAINT admin_pillar_page_pillar_code_fkey FOREIGN KEY (pillar_code) REFERENCES dos.admin_pillar(pillar_code) ON DELETE CASCADE;


--
-- Name: admin_pillar_widget admin_pillar_widget_page_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.admin_pillar_widget
    ADD CONSTRAINT admin_pillar_widget_page_id_fkey FOREIGN KEY (page_id) REFERENCES dos.admin_pillar_page(id) ON DELETE CASCADE;


--
-- Name: agent_action_receipts agent_action_receipts_run_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_action_receipts
    ADD CONSTRAINT agent_action_receipts_run_id_fkey FOREIGN KEY (run_id) REFERENCES dos.agent_runs(run_id) ON DELETE SET NULL;


--
-- Name: agent_evidence_links agent_evidence_links_run_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_evidence_links
    ADD CONSTRAINT agent_evidence_links_run_id_fkey FOREIGN KEY (run_id) REFERENCES dos.agent_runs(run_id) ON DELETE CASCADE;


--
-- Name: agent_module_binding agent_module_binding_agent_code_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_module_binding
    ADD CONSTRAINT agent_module_binding_agent_code_fkey FOREIGN KEY (agent_code) REFERENCES dos.agent_registry(agent_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_run_steps agent_run_steps_run_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agent_run_steps
    ADD CONSTRAINT agent_run_steps_run_id_fkey FOREIGN KEY (run_id) REFERENCES dos.agent_runs(run_id) ON DELETE CASCADE;


--
-- Name: agrc_agent_runs agrc_agent_runs_cycle_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_agent_runs
    ADD CONSTRAINT agrc_agent_runs_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES dos.agrc_cycles(cycle_id);


--
-- Name: agrc_discoveries agrc_discoveries_cycle_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_discoveries
    ADD CONSTRAINT agrc_discoveries_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES dos.agrc_cycles(cycle_id);


--
-- Name: agrc_discoveries agrc_discoveries_run_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_discoveries
    ADD CONSTRAINT agrc_discoveries_run_id_fkey FOREIGN KEY (run_id) REFERENCES dos.agrc_agent_runs(run_id);


--
-- Name: agrc_proposed_actions agrc_proposed_actions_cycle_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_proposed_actions
    ADD CONSTRAINT agrc_proposed_actions_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES dos.agrc_cycles(cycle_id);


--
-- Name: agrc_proposed_actions agrc_proposed_actions_run_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.agrc_proposed_actions
    ADD CONSTRAINT agrc_proposed_actions_run_id_fkey FOREIGN KEY (run_id) REFERENCES dos.agrc_agent_runs(run_id);


--
-- Name: ai_event ai_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ai_event
    ADD CONSTRAINT ai_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.ai_record(id) ON DELETE CASCADE;


--
-- Name: billing_event billing_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.billing_event
    ADD CONSTRAINT billing_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.billing_record(id) ON DELETE CASCADE;


--
-- Name: business_units business_units_organization_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.business_units
    ADD CONSTRAINT business_units_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES dos.organizations(organization_id) ON DELETE SET NULL;


--
-- Name: committee_meetings committee_meetings_committee_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.committee_meetings
    ADD CONSTRAINT committee_meetings_committee_id_fkey FOREIGN KEY (committee_id) REFERENCES dos.committees(committee_id) ON DELETE CASCADE;


--
-- Name: committee_members committee_members_committee_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.committee_members
    ADD CONSTRAINT committee_members_committee_id_fkey FOREIGN KEY (committee_id) REFERENCES dos.committees(committee_id) ON DELETE CASCADE;


--
-- Name: compliance_requirements compliance_requirements_framework_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.compliance_requirements
    ADD CONSTRAINT compliance_requirements_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES dos.compliance_frameworks(framework_id);


--
-- Name: config_values config_values_definition_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.config_values
    ADD CONSTRAINT config_values_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES dos.config_definitions(id) ON DELETE CASCADE;


--
-- Name: controls controls_framework_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.controls
    ADD CONSTRAINT controls_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES dos.compliance_frameworks(framework_id);


--
-- Name: data_governance_event data_governance_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.data_governance_event
    ADD CONSTRAINT data_governance_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.data_governance_record(id) ON DELETE CASCADE;


--
-- Name: deployment_event deployment_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.deployment_event
    ADD CONSTRAINT deployment_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.deployment_record(id) ON DELETE CASCADE;


--
-- Name: dos_master_compensation_chain dos_master_compensation_chain_change_request_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_compensation_chain
    ADD CONSTRAINT dos_master_compensation_chain_change_request_id_fkey FOREIGN KEY (change_request_id) REFERENCES dos.dos_master_change_request(id) ON DELETE CASCADE;


--
-- Name: dos_master_grant dos_master_grant_role_code_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dos_master_grant
    ADD CONSTRAINT dos_master_grant_role_code_fkey FOREIGN KEY (role_code) REFERENCES dos.dos_master_role(role_code) ON DELETE CASCADE;


--
-- Name: dr_event dr_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dr_event
    ADD CONSTRAINT dr_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.dr_record(id) ON DELETE CASCADE;


--
-- Name: dynamic_ui_component_registry dynamic_ui_component_registry_carbon_key_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_component_registry
    ADD CONSTRAINT dynamic_ui_component_registry_carbon_key_fkey FOREIGN KEY (carbon_key) REFERENCES dos.ui_carbon_components(carbon_key) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: feature_flag_event feature_flag_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.feature_flag_event
    ADD CONSTRAINT feature_flag_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.feature_flag_record(id) ON DELETE CASCADE;


--
-- Name: dynamic_ui_component_registry fk_carbon_key_registry; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.dynamic_ui_component_registry
    ADD CONSTRAINT fk_carbon_key_registry FOREIGN KEY (carbon_key) REFERENCES dos.ui_carbon_components(carbon_key) ON DELETE RESTRICT;


--
-- Name: team_members fk_dos_team_members_team; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.team_members
    ADD CONSTRAINT fk_dos_team_members_team FOREIGN KEY (team_id) REFERENCES dos.teams(team_id) ON DELETE CASCADE;


--
-- Name: marketing_footer_items fk_footer_items_group; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketing_footer_items
    ADD CONSTRAINT fk_footer_items_group FOREIGN KEY (group_id, brand_code) REFERENCES dos.marketing_footer_groups(id, brand_code) ON DELETE CASCADE;


--
-- Name: incidents fk_incidents_risk_id; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.incidents
    ADD CONSTRAINT fk_incidents_risk_id FOREIGN KEY (risk_id) REFERENCES dos.risks(risk_id);


--
-- Name: ui_route_template_binding fk_template_export_registry; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_route_template_binding
    ADD CONSTRAINT fk_template_export_registry FOREIGN KEY (template_export) REFERENCES dos.dynamic_ui_component_registry(component_key) ON DELETE RESTRICT;


--
-- Name: tenant_migrations fk_tenant_migrations_tenant; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_migrations
    ADD CONSTRAINT fk_tenant_migrations_tenant FOREIGN KEY (tenant_id) REFERENCES dos.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: foundation_position_authority foundation_position_authority_authority_kind_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.foundation_position_authority
    ADD CONSTRAINT foundation_position_authority_authority_kind_fkey FOREIGN KEY (authority_kind) REFERENCES dos.foundation_authority_kinds(authority_kind);


--
-- Name: governance_decisions governance_decisions_committee_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.governance_decisions
    ADD CONSTRAINT governance_decisions_committee_id_fkey FOREIGN KEY (committee_id) REFERENCES dos.committees(committee_id) ON DELETE SET NULL;


--
-- Name: incidents incidents_risk_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.incidents
    ADD CONSTRAINT incidents_risk_id_fkey FOREIGN KEY (risk_id) REFERENCES dos.risks(risk_id);


--
-- Name: integration_event integration_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.integration_event
    ADD CONSTRAINT integration_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.integration_record(id) ON DELETE CASCADE;


--
-- Name: location_bu_map location_bu_map_bu_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.location_bu_map
    ADD CONSTRAINT location_bu_map_bu_id_fkey FOREIGN KEY (bu_id) REFERENCES dos.business_units(bu_id) ON DELETE CASCADE;


--
-- Name: location_bu_map location_bu_map_location_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.location_bu_map
    ADD CONSTRAINT location_bu_map_location_id_fkey FOREIGN KEY (location_id) REFERENCES dos.locations(location_id) ON DELETE CASCADE;


--
-- Name: marketplace_event marketplace_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.marketplace_event
    ADD CONSTRAINT marketplace_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.marketplace_record(id) ON DELETE CASCADE;


--
-- Name: notification_event notification_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.notification_event
    ADD CONSTRAINT notification_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.notification_record(id) ON DELETE CASCADE;


--
-- Name: platform_secret platform_secret_secret_key_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_secret
    ADD CONSTRAINT platform_secret_secret_key_fkey FOREIGN KEY (secret_key) REFERENCES dos.platform_secret_definition(secret_key) ON UPDATE CASCADE;


--
-- Name: platform_slo_event platform_slo_event_service_code_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.platform_slo_event
    ADD CONSTRAINT platform_slo_event_service_code_fkey FOREIGN KEY (service_code) REFERENCES dos.platform_slo(service_code);


--
-- Name: position_assignments position_assignments_position_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.position_assignments
    ADD CONSTRAINT position_assignments_position_id_fkey FOREIGN KEY (position_id) REFERENCES dos.positions(position_id) ON DELETE CASCADE;


--
-- Name: positions positions_bu_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.positions
    ADD CONSTRAINT positions_bu_id_fkey FOREIGN KEY (bu_id) REFERENCES dos.business_units(bu_id) ON DELETE SET NULL;


--
-- Name: publish_dependency publish_dependency_child_target_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_dependency
    ADD CONSTRAINT publish_dependency_child_target_id_fkey FOREIGN KEY (child_target_id) REFERENCES dos.publish_target(id) ON DELETE CASCADE;


--
-- Name: publish_dependency publish_dependency_parent_target_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_dependency
    ADD CONSTRAINT publish_dependency_parent_target_id_fkey FOREIGN KEY (parent_target_id) REFERENCES dos.publish_target(id) ON DELETE CASCADE;


--
-- Name: publish_revision publish_revision_change_request_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_revision
    ADD CONSTRAINT publish_revision_change_request_id_fkey FOREIGN KEY (change_request_id) REFERENCES dos.dos_master_change_request(id);


--
-- Name: publish_rollback publish_rollback_revision_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.publish_rollback
    ADD CONSTRAINT publish_rollback_revision_id_fkey FOREIGN KEY (revision_id) REFERENCES dos.publish_revision(id) ON DELETE CASCADE;


--
-- Name: release_event release_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.release_event
    ADD CONSTRAINT release_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.release_record(id) ON DELETE CASCADE;


--
-- Name: rollout_cohort rollout_cohort_ring_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_cohort
    ADD CONSTRAINT rollout_cohort_ring_id_fkey FOREIGN KEY (ring_id) REFERENCES dos.rollout_ring(id) ON DELETE CASCADE;


--
-- Name: rollout_compensation_step rollout_compensation_step_chain_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_compensation_step
    ADD CONSTRAINT rollout_compensation_step_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES dos.dos_master_compensation_chain(id) ON DELETE CASCADE;


--
-- Name: rollout_evaluation rollout_evaluation_ring_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_evaluation
    ADD CONSTRAINT rollout_evaluation_ring_id_fkey FOREIGN KEY (ring_id) REFERENCES dos.rollout_ring(id) ON DELETE CASCADE;


--
-- Name: rollout_health_gate rollout_health_gate_ring_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_health_gate
    ADD CONSTRAINT rollout_health_gate_ring_id_fkey FOREIGN KEY (ring_id) REFERENCES dos.rollout_ring(id) ON DELETE CASCADE;


--
-- Name: rollout_plan rollout_plan_change_request_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_plan
    ADD CONSTRAINT rollout_plan_change_request_id_fkey FOREIGN KEY (change_request_id) REFERENCES dos.dos_master_change_request(id) ON DELETE SET NULL;


--
-- Name: rollout_ring rollout_ring_plan_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_ring
    ADD CONSTRAINT rollout_ring_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES dos.rollout_plan(id) ON DELETE CASCADE;


--
-- Name: rollout_rollback rollout_rollback_ring_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.rollout_rollback
    ADD CONSTRAINT rollout_rollback_ring_id_fkey FOREIGN KEY (ring_id) REFERENCES dos.rollout_ring(id) ON DELETE CASCADE;


--
-- Name: schema_authoring_event schema_authoring_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.schema_authoring_event
    ADD CONSTRAINT schema_authoring_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.schema_authoring_record(id) ON DELETE CASCADE;


--
-- Name: security_secret_event security_secret_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.security_secret_event
    ADD CONSTRAINT security_secret_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.security_secret_record(id) ON DELETE CASCADE;


--
-- Name: telemetry_event telemetry_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.telemetry_event
    ADD CONSTRAINT telemetry_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.telemetry_record(id) ON DELETE CASCADE;


--
-- Name: tenant_kms_config tenant_kms_config_tenant_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_kms_config
    ADD CONSTRAINT tenant_kms_config_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES dos.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: tenant_kms_keys tenant_kms_keys_rotated_from_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_kms_keys
    ADD CONSTRAINT tenant_kms_keys_rotated_from_fkey FOREIGN KEY (rotated_from) REFERENCES dos.tenant_kms_keys(id);


--
-- Name: tenant_kms_keys tenant_kms_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_kms_keys
    ADD CONSTRAINT tenant_kms_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES dos.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: tenant_module_entitlements tenant_module_entitlements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_module_entitlements
    ADD CONSTRAINT tenant_module_entitlements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES dos.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: tenant_modules tenant_modules_attached_slot_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.tenant_modules
    ADD CONSTRAINT tenant_modules_attached_slot_id_fkey FOREIGN KEY (attached_slot_id) REFERENCES dos.module_pool_slots(slot_id) ON DELETE SET NULL;


--
-- Name: training_enrollments training_enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.training_enrollments
    ADD CONSTRAINT training_enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES dos.training_courses(course_id);


--
-- Name: ui_dos_component_carbon_map ui_dos_component_carbon_map_carbon_key_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_dos_component_carbon_map
    ADD CONSTRAINT ui_dos_component_carbon_map_carbon_key_fkey FOREIGN KEY (carbon_key) REFERENCES dos.ui_carbon_components(carbon_key) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ui_module_nav_item ui_module_nav_item_module_code_group_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_module_nav_item
    ADD CONSTRAINT ui_module_nav_item_module_code_group_id_fkey FOREIGN KEY (module_code, group_id) REFERENCES dos.ui_module_nav_group(module_code, group_id) ON DELETE SET NULL;


--
-- Name: ui_service_registry_prefixes ui_service_registry_prefixes_service_code_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.ui_service_registry_prefixes
    ADD CONSTRAINT ui_service_registry_prefixes_service_code_fkey FOREIGN KEY (service_code) REFERENCES dos.ui_service_registry(service_code) ON DELETE CASCADE;


--
-- Name: vendor_risk_event vendor_risk_event_record_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.vendor_risk_event
    ADD CONSTRAINT vendor_risk_event_record_id_fkey FOREIGN KEY (record_id) REFERENCES dos.vendor_risk_record(id) ON DELETE CASCADE;


--
-- Name: widgets widgets_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.widgets
    ADD CONSTRAINT widgets_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES dos.dashboards(dashboard_id);


--
-- Name: workflow_approvals workflow_approvals_workflow_instance_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_approvals
    ADD CONSTRAINT workflow_approvals_workflow_instance_id_fkey FOREIGN KEY (workflow_instance_id) REFERENCES dos.workflow_instances(instance_id);


--
-- Name: workflow_event workflow_event_instance_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_event
    ADD CONSTRAINT workflow_event_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES dos.workflow_instance(id) ON DELETE CASCADE;


--
-- Name: workflow_instance workflow_instance_workflow_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_instance
    ADD CONSTRAINT workflow_instance_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES dos.workflow_definition(id);


--
-- Name: workflow_step_run workflow_step_run_instance_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_step_run
    ADD CONSTRAINT workflow_step_run_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES dos.workflow_instance(id) ON DELETE CASCADE;


--
-- Name: workflow_tasks workflow_tasks_instance_id_fkey; Type: FK CONSTRAINT; Schema: dos; Owner: -
--

ALTER TABLE ONLY dos.workflow_tasks
    ADD CONSTRAINT workflow_tasks_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES dos.workflow_instances(instance_id);


--
-- Name: access_review_items; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.access_review_items ENABLE ROW LEVEL SECURITY;

--
-- Name: access_reviews; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.access_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: action_items; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.action_items ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_action_receipts; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agent_action_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_evidence_links; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agent_evidence_links ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_memory; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agent_memory ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_recommendations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agent_recommendations ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_runs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agent_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_agent_memory; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_agent_memory ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_agent_runs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_agent_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_cycles; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_cycles ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_discoveries; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_discoveries ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_handoffs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_handoffs ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_proposed_actions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_proposed_actions ENABLE ROW LEVEL SECURITY;

--
-- Name: agrc_tasks; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.agrc_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: assets; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.assets ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_findings; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.audit_findings ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log_archive; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.audit_log_archive ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_plans; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.audit_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_signoff_ledger; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.audit_signoff_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_trail; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.audit_trail ENABLE ROW LEVEL SECURITY;

--
-- Name: bcp_plans; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.bcp_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: briefings; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.briefings ENABLE ROW LEVEL SECURITY;

--
-- Name: business_units; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.business_units ENABLE ROW LEVEL SECURITY;

--
-- Name: committee_meetings; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.committee_meetings ENABLE ROW LEVEL SECURITY;

--
-- Name: committee_members; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.committee_members ENABLE ROW LEVEL SECURITY;

--
-- Name: committees; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.committees ENABLE ROW LEVEL SECURITY;

--
-- Name: compliance_frameworks; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.compliance_frameworks ENABLE ROW LEVEL SECURITY;

--
-- Name: compliance_requirements; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.compliance_requirements ENABLE ROW LEVEL SECURITY;

--
-- Name: component_registry; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.component_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: config_audit_logs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.config_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: config_center_audit_log; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.config_center_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: config_locks; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.config_locks ENABLE ROW LEVEL SECURITY;

--
-- Name: config_runtime_overrides; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.config_runtime_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: config_values; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.config_values ENABLE ROW LEVEL SECURITY;

--
-- Name: controls; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.controls ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboards; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dashboards ENABLE ROW LEVEL SECURITY;

--
-- Name: departments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.departments ENABLE ROW LEVEL SECURITY;

--
-- Name: dora_assessments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dora_assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_ai_tips; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_ai_tips ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_grid_columns; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_grid_columns ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_health_probes; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_health_probes ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_page_headers; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_page_headers ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_quick_actions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_quick_actions ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_setup_steps; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_setup_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_tenant_overrides; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_tenant_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_trial_banner_rules; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_trial_banner_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_workspace_ai_tips; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_workspace_ai_tips ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_workspace_grid_columns; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_workspace_grid_columns ENABLE ROW LEVEL SECURITY;

--
-- Name: dynamic_ui_workspace_page_headers; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.dynamic_ui_workspace_page_headers ENABLE ROW LEVEL SECURITY;

--
-- Name: evidence; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.evidence ENABLE ROW LEVEL SECURITY;

--
-- Name: evidences; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.evidences ENABLE ROW LEVEL SECURITY;

--
-- Name: executive_briefings; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.executive_briefings ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_coi_declarations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_coi_declarations ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_employee_lifecycle_state; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_employee_lifecycle_state ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_employee_lifecycle_tasks; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_employee_lifecycle_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_employee_lifecycle_transitions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_employee_lifecycle_transitions ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_employee_lifecycle_workflows; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_employee_lifecycle_workflows ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_policy_acknowledgments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_policy_acknowledgments ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_position_authority; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_position_authority ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_sod_rules; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_sod_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_sod_violations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_sod_violations ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_trail foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.audit_trail FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: business_units foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.business_units FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: committee_members foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.committee_members FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: committees foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.committees FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: invitations foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.invitations FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: location_bu_map foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.location_bu_map FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: locations foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.locations FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: organizations foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.organizations FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: ownership_mappings foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.ownership_mappings FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: position_assignments foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.position_assignments FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: positions foundation_tenant_read; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_read ON dos.positions FOR SELECT USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: audit_trail foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.audit_trail USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: business_units foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.business_units USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: committee_members foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.committee_members USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: committees foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.committees USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: invitations foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.invitations USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: location_bu_map foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.location_bu_map USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: locations foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.locations USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: organizations foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.organizations USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: ownership_mappings foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.ownership_mappings USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: position_assignments foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.position_assignments USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: positions foundation_tenant_write; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY foundation_tenant_write ON dos.positions USING (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) IS NULL) OR (current_setting('app.current_tenant_id'::text, true) = ''::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: foundation_training_assignments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_training_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: foundation_training_courses; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.foundation_training_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: governance_decisions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.governance_decisions ENABLE ROW LEVEL SECURITY;

--
-- Name: governance_policies; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.governance_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: i18n_fallback_values; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.i18n_fallback_values ENABLE ROW LEVEL SECURITY;

--
-- Name: inbox_items; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.inbox_items ENABLE ROW LEVEL SECURITY;

--
-- Name: incidents; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: integrations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.integrations ENABLE ROW LEVEL SECURITY;

--
-- Name: invitations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.invitations ENABLE ROW LEVEL SECURITY;

--
-- Name: job_executions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.job_executions ENABLE ROW LEVEL SECURITY;

--
-- Name: lifecycle_auth_log; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.lifecycle_auth_log ENABLE ROW LEVEL SECURITY;

--
-- Name: location_bu_map; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.location_bu_map ENABLE ROW LEVEL SECURITY;

--
-- Name: locations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.locations ENABLE ROW LEVEL SECURITY;

--
-- Name: login_attempts; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: maturity_assessments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.maturity_assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: mobile_sessions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.mobile_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: onboarding_journeys; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.onboarding_journeys ENABLE ROW LEVEL SECURITY;

--
-- Name: organizations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.organizations ENABLE ROW LEVEL SECURITY;

--
-- Name: ownership_mappings; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ownership_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: platform_audit_logs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.platform_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: platform_secret; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.platform_secret ENABLE ROW LEVEL SECURITY;

--
-- Name: policies; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.policies ENABLE ROW LEVEL SECURITY;

--
-- Name: portals; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.portals ENABLE ROW LEVEL SECURITY;

--
-- Name: position_assignments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.position_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: positions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.positions ENABLE ROW LEVEL SECURITY;

--
-- Name: privacy_assessments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.privacy_assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: product_licenses; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.product_licenses ENABLE ROW LEVEL SECURITY;

--
-- Name: qiyas_journeys; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.qiyas_journeys ENABLE ROW LEVEL SECURITY;

--
-- Name: records; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.records ENABLE ROW LEVEL SECURITY;

--
-- Name: remediation_actions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.remediation_actions ENABLE ROW LEVEL SECURITY;

--
-- Name: remediations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.remediations ENABLE ROW LEVEL SECURITY;

--
-- Name: report_schedules; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.report_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: risks; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.risks ENABLE ROW LEVEL SECURITY;

--
-- Name: role_profile_sync; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.role_profile_sync ENABLE ROW LEVEL SECURITY;

--
-- Name: role_profile_sync_log; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.role_profile_sync_log ENABLE ROW LEVEL SECURITY;

--
-- Name: shell_config; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.shell_config ENABLE ROW LEVEL SECURITY;

--
-- Name: sod_conflict_audit; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.sod_conflict_audit ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_role_mappings; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.sso_role_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_sessions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.sso_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: team_raci_assignments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.team_raci_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: teams; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_config_versions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_config_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_config_versions_legacy; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_config_versions_legacy ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_feature_flag_overrides; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_feature_flag_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: access_review_items tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.access_review_items USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: access_reviews tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.access_reviews USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: action_items tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.action_items USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agent_action_receipts tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agent_action_receipts USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: agent_evidence_links tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agent_evidence_links USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: agent_memory tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agent_memory USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: agent_recommendations tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agent_recommendations USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: agent_runs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agent_runs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: agrc_agent_memory tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_agent_memory USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agrc_agent_runs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_agent_runs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agrc_cycles tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_cycles USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agrc_discoveries tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_discoveries USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agrc_handoffs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_handoffs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agrc_proposed_actions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_proposed_actions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: agrc_tasks tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.agrc_tasks USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: assets tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.assets USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: audit_findings tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.audit_findings USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: audit_log_archive tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.audit_log_archive USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: audit_logs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.audit_logs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: audit_plans tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.audit_plans USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: audit_signoff_ledger tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.audit_signoff_ledger USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: bcp_plans tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.bcp_plans USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: briefings tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.briefings USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: committee_meetings tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.committee_meetings USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: compliance_frameworks tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.compliance_frameworks USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: compliance_requirements tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.compliance_requirements USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: component_registry tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.component_registry USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: config_audit_logs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.config_audit_logs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: config_center_audit_log tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.config_center_audit_log USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: config_locks tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.config_locks USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: config_runtime_overrides tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.config_runtime_overrides USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: config_values tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.config_values USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: controls tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.controls USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: dashboards tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dashboards USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: departments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.departments USING (((public.app_current_tenant_id() IS NULL) OR ((tenant_id)::text = public.app_current_tenant_id()))) WITH CHECK (((public.app_current_tenant_id() IS NULL) OR ((tenant_id)::text = public.app_current_tenant_id())));


--
-- Name: dora_assessments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dora_assessments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: dynamic_ui_ai_tips tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_ai_tips USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_grid_columns tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_grid_columns USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_health_probes tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_health_probes USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_page_headers tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_page_headers USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_quick_actions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_quick_actions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_setup_steps tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_setup_steps USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_tenant_overrides tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_tenant_overrides USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: dynamic_ui_trial_banner_rules tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_trial_banner_rules USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_workspace_ai_tips tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_workspace_ai_tips USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_workspace_grid_columns tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_workspace_grid_columns USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: dynamic_ui_workspace_page_headers tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.dynamic_ui_workspace_page_headers USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: evidence tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.evidence USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: evidences tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.evidences USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: executive_briefings tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.executive_briefings USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: foundation_coi_declarations tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_coi_declarations USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_employee_lifecycle_state tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_employee_lifecycle_state USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_employee_lifecycle_tasks tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_employee_lifecycle_tasks USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_employee_lifecycle_transitions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_employee_lifecycle_transitions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_employee_lifecycle_workflows tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_employee_lifecycle_workflows USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_policy_acknowledgments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_policy_acknowledgments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_position_authority tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_position_authority USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_sod_rules tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_sod_rules USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_sod_violations tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_sod_violations USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_training_assignments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_training_assignments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: foundation_training_courses tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.foundation_training_courses USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: governance_decisions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.governance_decisions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: governance_policies tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.governance_policies USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: i18n_fallback_values tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.i18n_fallback_values USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: inbox_items tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.inbox_items USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: incidents tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.incidents USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: integrations tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.integrations USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: job_executions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.job_executions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: lifecycle_auth_log tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.lifecycle_auth_log USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: login_attempts tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.login_attempts USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: maturity_assessments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.maturity_assessments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: mobile_sessions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.mobile_sessions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: onboarding_journeys tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.onboarding_journeys USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: platform_audit_logs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.platform_audit_logs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: platform_secret tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.platform_secret USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: policies tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.policies USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: portals tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.portals USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: privacy_assessments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.privacy_assessments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: product_licenses tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.product_licenses USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: qiyas_journeys tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.qiyas_journeys USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: records tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.records USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: remediation_actions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.remediation_actions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: remediations tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.remediations USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: report_schedules tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.report_schedules USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: risks tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.risks USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: role_profile_sync tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.role_profile_sync USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: role_profile_sync_log tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.role_profile_sync_log USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: shell_config tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.shell_config USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: sod_conflict_audit tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.sod_conflict_audit USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: sso_providers tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.sso_providers USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: sso_role_mappings tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.sso_role_mappings USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: sso_sessions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.sso_sessions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: team_raci_assignments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.team_raci_assignments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: teams tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.teams USING (((public.app_current_tenant_id() IS NULL) OR ((tenant_id)::text = public.app_current_tenant_id()))) WITH CHECK (((public.app_current_tenant_id() IS NULL) OR ((tenant_id)::text = public.app_current_tenant_id())));


--
-- Name: tenant_config_versions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_config_versions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: tenant_config_versions_legacy tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_config_versions_legacy USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_feature_flag_overrides tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_feature_flag_overrides USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_kms_config tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_kms_config USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: tenant_kms_keys tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_kms_keys USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: tenant_landing_config tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_landing_config USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_memberships tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_memberships USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_migrations tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_migrations USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: tenant_modules tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_modules USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: tenant_product_activation tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_product_activation USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_security_policy tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_security_policy USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_settings_legacy tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenant_settings_legacy USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenants tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.tenants USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: training_courses tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.training_courses USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: training_enrollments tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.training_enrollments USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: training_programs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.training_programs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_admin_activity_log tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_admin_activity_log USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_draft_versions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_draft_versions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_module_nav_override_tenant tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_module_nav_override_tenant USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: ui_override_tenant tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_override_tenant USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: ui_published_versions tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_published_versions USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_rollback_points tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_rollback_points USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_workspace_banner tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_workspace_banner USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_workspace_chrome tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_workspace_chrome USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_workspace_policy tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_workspace_policy USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: ui_workspace_shortcut tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.ui_workspace_shortcut USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: user_org_scope tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.user_org_scope USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: user_roles tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.user_roles USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: users tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.users USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: vendors tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.vendors USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: widgets tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.widgets USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: work_items tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.work_items USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workflow_approvals tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_approvals USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workflow_instance tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_instance USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: workflow_instances tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_instances USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workflow_schedules tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_schedules USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workflow_sla_configs tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_sla_configs USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workflow_tasks tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_tasks USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workflow_templates tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workflow_templates USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: workspace_config tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workspace_config USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workspace_shell_binding tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workspace_shell_binding USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR (tenant_id = dos.current_tenant_id())));


--
-- Name: workspaces tenant_isolation; Type: POLICY; Schema: dos; Owner: -
--

CREATE POLICY tenant_isolation ON dos.workspaces USING (((dos.current_tenant_id() IS NULL) OR (tenant_id IS NULL) OR ((tenant_id)::text = dos.current_tenant_id())));


--
-- Name: tenant_kms_config; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_kms_config ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_kms_keys; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_kms_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_landing_config; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_landing_config ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_memberships; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_memberships ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_migrations; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_modules; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_modules ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_product_activation; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_product_activation ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_security_policy; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_security_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_settings_legacy; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenant_settings_legacy ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: training_courses; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.training_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: training_enrollments; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.training_enrollments ENABLE ROW LEVEL SECURITY;

--
-- Name: training_programs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.training_programs ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_admin_activity_log; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_admin_activity_log ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_draft_versions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_draft_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_module_nav_override_tenant; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_module_nav_override_tenant ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_override_tenant; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_override_tenant ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_published_versions; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_published_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_rollback_points; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_rollback_points ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_workspace_banner; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_workspace_banner ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_workspace_chrome; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_workspace_chrome ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_workspace_policy; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_workspace_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: ui_workspace_shortcut; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.ui_workspace_shortcut ENABLE ROW LEVEL SECURITY;

--
-- Name: user_org_scope; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.user_org_scope ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.users ENABLE ROW LEVEL SECURITY;

--
-- Name: vendors; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.vendors ENABLE ROW LEVEL SECURITY;

--
-- Name: widgets; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.widgets ENABLE ROW LEVEL SECURITY;

--
-- Name: work_items; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.work_items ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_approvals; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_approvals ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_instance; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_instance ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_instances; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_instances ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_schedules; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_sla_configs; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_sla_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_tasks; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_templates; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workflow_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: workspace_config; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workspace_config ENABLE ROW LEVEL SECURITY;

--
-- Name: workspace_shell_binding; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workspace_shell_binding ENABLE ROW LEVEL SECURITY;

--
-- Name: workspaces; Type: ROW SECURITY; Schema: dos; Owner: -
--

ALTER TABLE dos.workspaces ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict U3SeetXfJvPuGHdGTIIqMRuJ8KFH0iB1tZFRat8Gfu0eWhH9rdOL3WmwVbWfHh4

